#!/usr/bin/env python3
"""R15 exact dehomogenized q=1 negative conic / norm certificate."""
from pathlib import Path
import sympy as sp

OUT=Path(__file__).resolve().parent
G,K,a,tau,Y=sp.symbols('G K a tau Y', integer=True)
S=(G+1)*(2*G+3)
AG=10*G**2+4*G-2
Q=4*G**3*K**2-4*G**3+8*G**2*K**2-12*G**2+4*G*K**2-13*G-6
M=sp.expand(G**3*tau-AG*a)
L=sp.cancel((Q*M+4*S*a)/G)
assert sp.denom(L)==1
D=sp.factor(M*L/4-S**2*a**2)
P=sp.Poly(sp.expand(D),a)
A2=sp.factor(P.nth(2)); B1=sp.factor(P.nth(1)); C0=sp.factor(P.nth(0))
Disc=sp.factor(B1**2-4*A2*C0)
T4=4*G**4*K**2-4*G**4+8*G**3*K**2-12*G**3+4*G**2*K**2-13*G**2-6*G+1
assert sp.factor(Disc-G**4*tau**2*S**2*T4)==0
# completed-square norm form
assert sp.expand((2*A2*a+B1)**2-4*A2*D-Disc)==0

# Negative Gaussian inequality in m=-M>0. Substitute a=(m+G^3 tau)/A_G.
m=sp.symbols('m', positive=True, integer=True)
C=G**3*tau
ineq_poly=sp.expand(m*(Q*m-4*S*(m+C)/AG)-4*G*S**2*((m+C)/AG)**2)
cleared=sp.Poly(sp.expand(ineq_poly*AG**2),m)
aa=sp.factor(cleared.nth(2)); bb=sp.factor(cleared.nth(1)); cc=sp.factor(cleared.nth(0))
assert aa==sp.factor(Q*AG**2-4*S*AG-4*G*S**2)
assert bb==sp.factor(-4*S*AG*C-8*G*S**2*C)
assert cc==sp.factor(-4*G*S**2*C**2)

cert=OUT/'J2-55-R15-q1-NegativeConic-certificate.txt'
cert.write_text('\n'.join([
'J2-55 R15 q1 negative fixed-conic certificate',
'Y0^2 = A2(G,K) a^2 + B1(G,K,tau) a + C0(G,K,tau)',
'A2='+str(A2),
'B1='+str(B1),
'C0='+str(C0),
'DISC_A='+str(Disc),
'T4='+str(T4),
'NORM_FORM=(2*A2*a+B1)^2 - 4*A2*Y0^2 = DISC_A',
'NEG_G_CLEARED_AA='+str(aa),
'NEG_G_CLEARED_BB='+str(bb),
'NEG_G_CLEARED_CC='+str(cc),
'NEG_G_POSITIVE_ROOT=m_min=(-bb+sqrt(bb^2-4aa*cc))/(2aa) whenever aa>0',
'GLOBAL_STATUS=OPEN_FIXED_TAU_NORM_ORBIT',
]),encoding='utf-8')

print('NEG_CONIC=EXACT')
print('A2='+str(A2))
print('B1='+str(B1))
print('C0='+str(C0))
print('DISC_A=G^4*tau^2*(G+1)^2*(2G+3)^2*T4')
print('T4='+str(T4))
print('NORM_FORM=(2A2*a+B1)^2-4A2*Y0^2=DISC_A')
print('NEG_G_RADICAL_BOUND=EXACT_QUADRATIC_ROOT')
print('FIXED_TAU_DEHOMOGENIZATION=PROVED; R10 homogeneous zero-refinement objection no longer applies')
print('GLOBAL_STATUS=OPEN_FIXED_TAU_PELL_NORM_ORBIT')
print('CERTIFICATE='+cert.name)
