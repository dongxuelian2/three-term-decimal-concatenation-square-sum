#!/usr/bin/env python3
"""R15 reverse gamma=0 coefficient descent.

Uses the R14-certified j=1 coefficients and the R14 carry-spliced C2 factors.
It does not reopen the gamma bit ladder.
"""
import sympy as sp

q,K,f,w,e,t,x=sp.symbols('q K f w e t x', integer=True)

# R14 gamma=0 lowest coefficients.
C1g=sp.factor(-1024*e*f**4*q**5*w**2*(q**2+4*q-4)*(-K*e+4*f*q*(q+4)*t))
C1k=sp.factor(640*e*q**5*(q**2+4*q-4)*(-5*e+2*q*(q+4)*t))

# Carry-spliced C2 factors on the three normalizer-one priority branches.
F1k=2*q*(q+4)*t-5*e
F2k=e-8*q**2*(q+4)*x
C2k=-16*q**4*(q**3+10*q**2+12*q+8)*F1k*F2k

# Fixed k=2 factors.
F17=-25*e+77*t; F27=e-4312*x
F111=-e+33*t; F211=e-72600*x

# The gamma-zero j=1 linear factor is exactly the splice F1 up to a unit/constant.
Lgen=-K*e+4*f*q*(q+4)*t
assert sp.factor(Lgen.subs({K:100,f:1,q:7})-4*F17)==0
assert sp.factor(Lgen.subs({K:100,f:5,q:11})-100*F111)==0
assert sp.factor((-5*e+2*q*(q+4)*t)-F1k)==0

# e=0: j=1 vanishes, but C2 is nonzero for t>0,x>0 in all three priority types.
# Algebraically the products reduce to nonzero monomials times t*x.
C2k_e0=sp.factor(C2k.subs(e,0))
C27_e0=sp.factor((sp.Integer(14213920000)*F17*F27).subs(e,0))
C211_e0=sp.factor((sp.Integer(6280403360000)*F111*F211).subs(e,0))
assert C2k_e0 != 0 and C27_e0 != 0 and C211_e0 != 0

print('GAMMA_ZERO_GENERIC_C1='+str(C1g))
print('GAMMA_ZERO_K1_C1='+str(C1k))
print('GENERIC_LINEAR_FACTOR='+str(Lgen))
print('K1_LINEAR_FACTOR=F1 exactly')
print('K2_Q7_LINEAR_FACTOR=4*F1')
print('K2_Q11_LINEAR_FACTOR=100*F1')
print('E0_LOCUS=C1_ZERO_BUT_C2_NONZERO_FOR_t>0,x>0; lowest coefficient becomes j=2')
print('E0_K1_C2='+str(C2k_e0))
print('E0_Q7_C2='+str(C27_e0))
print('E0_Q11_C2='+str(C211_e0))
print('E_NONZERO_F1_NONZERO=lowest coefficient j=1')
print('E_NONZERO_F1_ZERO=C1_AND_C2_BOTH_ZERO; must descend to j=3')
print('GAMMA_ZERO_STATUS=OPEN_EXPLICIT_DOUBLE_CANCELLATION_LOCUS')
