#!/usr/bin/env python3
"""R15 special k=1,b=0 factor-allocation audit."""
import sympy as sp
from math import gcd

q,e,t,x=sp.symbols('q e t x', integer=True)
F1=2*q*(q+4)*t-5*e
F2=e-8*q**2*(q+4)*x
COMB=sp.factor(F1+5*F2)
assert sp.expand(COMB-2*q*(q+4)*(t-20*q*x))==0

# 2-adic theorem: q,t odd and e even => F1,F2 even; combination has exact v2=1.
# Hence min(v2(F1),v2(F2))=1, equivalently v2(gcd(F1,F2))=1.
for Q in (7,17,19,29):
    for E in range(-10,11):
        ee=2*E
        for T in (1,3,5,7,9):
            for X in (1,2,5,10):
                a=int(F1.subs({q:Q,e:ee,t:T,x:X})); b=int(F2.subs({q:Q,e:ee,t:T,x:X}))
                assert a%2==b%2==0
                def v2(n):
                    n=abs(n);v=0
                    if n==0:return 99
                    while n%2==0:v+=1;n//=2
                    return v
                assert min(v2(a),v2(b))==1

# 5-adic scope audit.
# R8 freezes 5|t on active k=1,b=0 types. The stronger v5(t)=v5(c) theorem
# had a scope condition (notably k>w_c) and is NOT globally applicable at k=1.
# R12 freezes gcd(x,u)=1 only, not x being a 5-unit.
GLOBAL_GCD5_THEOREM=False
CONDITIONAL_GCD5='if x is 5-unit and v5(t)>=2 then v5(t-20qx)=1; if v5(t)=1 exceptional t/5==4qx (mod5)'

# q=7 F2=0 height comparison at k=1 is too close for the current safe bound.
Q=7; B=153; f=1; coeff=8*Q*Q*(Q+4) # 4312
# G=10R: A>20R/q, x>AG/10>20R^2/q.
F2zero_lower_num=coeff*20      # e > lower_num/q R^2
safe_upper=18*f*B+30*f*Q**3   # |e| < upper R^2
assert F2zero_lower_num < Q*safe_upper  # so this bound alone cannot kill F2=0

# q=7 live cyclotomic class.
assert all(r%6==2 for r in (8,14,20))

print('K1_COMB='+str(COMB))
print('K1_GCD2_FACTOR=v2(gcd(F1,F2))=1 PROVED')
print('K1_GCD5_FACTOR=CONDITIONAL_ONLY; global theorem NOT proved')
print('K1_GCD5_SCOPE_BLOCKER_1=R8 v5(t)=v5(c) not globally applicable at k=1')
print('K1_GCD5_SCOPE_BLOCKER_2=R12 proves gcd(x,u)=1, not x 5-unit')
print('K1_CONDITIONAL_GCD5='+CONDITIONAL_GCD5)
print('K1_F1_ZERO=OPEN_EXPLICIT_LOCUS 5e=2q(q+4)t')
print('K1_F2_ZERO_Q7=NOT_KILLED_BY_CURRENT_SAFE_HEIGHT_BOUND')
print(f'K1_Q7_F2ZERO_LOWER_COEFF={F2zero_lower_num}/7; SAFE_E_UPPER_COEFF={safe_upper}')
print('K1_Q7_CYCLOTOMIC=r==2 (mod6); r=2 frozen ell=5 dead; live r>=8')
print('K1_Q7_R_BOUND=NOT_PROVED')
print('K1_Q7_STATUS=OPEN')
