#!/usr/bin/env python3
"""R15 q=1 negative branch: 24 fixed (K,d,tau) cases.
This script proves the exact residue/lattice/window formulas and audits the proposed
'window < one lattice step' route.  It also performs a bounded *diagnostic* all-a
local-prime search; absence of such a prime is not promoted beyond the searched range.
"""
from pathlib import Path
from math import gcd
import csv
from sympy import primerange

OUT=Path(__file__).resolve().parent
PAIRS=((1,1),(1,3),(3,1),(1,7),(7,1),(1,9),(3,3),(9,1))

def ord10(p):
    x=1
    for n in range(1,p):
        x=x*10%p
        if x==1:return n
    raise RuntimeError

def Dmod(G,K,tau,a,p):
    S=((G+1)*(2*G+3))%p
    Q=(4*G**3*K**2-4*G**3+8*G**2*K**2-12*G**2+4*G*K**2-13*G-6)%p
    M=(G**3*tau-(10*G**2+4*G-2)*a)%p
    L=((Q*M+4*S*a)*pow(G,-1,p))%p
    return (M*L*pow(4,-1,p)-S*S*a*a)%p

def all_a_killer(K,tau,p):
    if p in (2,5) or (2*K)%p==0:return False
    sq={z*z%p for z in range(p)}
    o=ord10(p)
    for g in range(o):
        G=pow(10,g,p)
        # a is free mod p because gcd(p,2K)=1 and j varies.
        if any(Dmod(G,K,tau,a,p) in sq for a in range(p)):
            return False
    return True

rows=[]
for K in (10,100,1000):
    mod=2*K; inv31=pow(31,-1,mod)
    gmin=4 if K<1000 else 5
    Gmin=10**gmin
    for d,tau in PAIRS:
        t=d*tau
        a0=(-tau*inv31)%mod
        assert (31*a0+tau)%mod==0 and gcd(a0,10)==1
        # exact normalized a-window width / residue-lattice step 2K at the first live G
        AG=10*Gmin**2+4*Gmin-2
        width_num=Gmin*((10-t)*Gmin**2+4*Gmin-2)
        width_den=2*K*d*AG
        # m_- step is 2K*A_G and the m_- interval width is A_G times the a-window width,
        # so the same ratio applies.
        killers=[p for p in primerange(3,200) if p!=5 and (2*K)%p and all_a_killer(K,tau,p)]
        assert not killers
        rows.append(dict(
            K=K,d=d,tau=tau,t=t,a_mod_2K=a0,g_min=gmin,
            negative_a_window=f'G^3*{tau}/A_G < a < G/{d}',
            mminus_progression=f'm=(A_G*{a0}-G^3*{tau}) + (2K*A_G)j',
            gaussian_lower_bound='m >= (-b+sqrt(b^2-4ac))/(2a), coefficients in NegativeConic certificate',
            candidate_width=f'width/(2K)={width_num}/{width_den} at g={gmin}; asymptotic ~ R*{10-t}/({20*d})',
            width_lt_one_at_first_live='YES' if width_num<width_den else 'NO',
            local_prime='NONE_ALL_A_p<200',
            periodic_status='a mod p remains free for p coprime 2K; no bounded all-a killer found',
            global_status='OPEN_FIXED_NORM_ORBIT'))

p=OUT/'J2-55-R15-q1-NegativeFixed.tsv'
with p.open('w',newline='',encoding='utf-8') as fh:
    wr=csv.DictWriter(fh,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)
assert len(rows)==24

print('NEGATIVE_FIXED_CASES=24')
print('NEG_A_CELL=31a+tau==0 (mod 2K), unique a0')
print('NEG_A_WIN=G^3*tau/A_G < a < G/d')
print('NEG_M_LATTICE=m0 + 2K*A_G*j')
print('NEGATIVE_LATTICE_WIDTH_RATIO=R*((10-t)G^2+4G-2)/(2d*(10G^2+4G-2))')
print('NEGATIVE_LATTICE_UNIFORM_ONE_STEP=FALSE; ratio grows linearly in R')
print('NEGATIVE_CONIC_LOCAL=NO_ALL_A_KILLER_PRIME_p<200 in all 24 fixed cases (diagnostic only)')
for K in (10,100,1000):
    print(f'K{K}_NEG=OPEN_FIXED_NORM_ORBIT')
print('NEGATIVE_BRANCH=OPEN_STRICTLY_BEYOND_R14_24_CASE_LABEL: each case now has exact residue lattice + norm form target')
print('LEDGER='+p.name)
