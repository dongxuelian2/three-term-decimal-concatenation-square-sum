#!/usr/bin/env python3
"""R15 boundary/high independent constant-coefficient 2-adic descent.
The B0/H0 inners below are the exact frozen R14 constant coefficients, whose
parent polynomials have the R12 hashes recorded here.  No gamma carry ladder is used.
"""
from fractions import Fraction
from math import gcd
from pathlib import Path
import csv, sympy as sp

OUT=Path(__file__).resolve().parent
R12_HASH_B='92af2937c40fdf2dc056472228ec1a91d7b01444dd26f6f6718e68b261a35648'
R12_HASH_H='cf7b8ef58e9e24e8a63daf29d5d78ea5184bf19052a525563c5cb0ff80f5e180'
q,e,f,w,t,gamma,H,E=sp.symbols('q e f w t gamma H E', integer=True)

B0i=(
 e**2*f*w*(q**9+22*q**8+164*q**7+504*q**6+816*q**5+800*q**4+448*q**3+128*q**2)
 +e*f**2*t*w*(-16*q**11-368*q**10-2976*q**9-12352*q**8-35840*q**7-65792*q**6-37888*q**5+21504*q**4+49152*q**3+32768*q**2+8192*q)
 +f**3*t**2*w*(64*q**13+1536*q**12+14656*q**11+83840*q**10+344320*q**9+897536*q**8+1088512*q**7-51200*q**6-1638400*q**5-1769472*q**4-294912*q**3+786432*q**2+589824*q+131072)
 +16*gamma*q**4*(q+4)*t)

H0i=(
 H**4*e*f**2*t*w*(256*q**9+2048*q**8+3072*q**7-4096*q**6)
 +H**4*f**3*t**2*w*(-512*q**11-1024*q**10+30720*q**9+143360*q**8+114688*q**7-163840*q**6-131072*q**5)
 +H**2*e*f**2*t*w*(-64*q**9-896*q**8-5632*q**7-15872*q**6-15360*q**5-4096*q**4)
 +H**2*f**3*t**2*w*(256*q**11+6144*q**10+57344*q**9+241664*q**8+458752*q**7+278528*q**6-294912*q**5-425984*q**4-131072*q**3)
 -16*H**2*gamma*q**4*(q+4)*t
 +e**2*f*w*(q**9+22*q**8+164*q**7+504*q**6+816*q**5+800*q**4+448*q**3+128*q**2)
 +e*f**2*t*w*(-16*q**11-368*q**10-3168*q**9-13504*q**8-33280*q**7-45824*q**6-22528*q**5+25600*q**4+49152*q**3+32768*q**2+8192*q)
 +f**3*t**2*w*(64*q**13+1536*q**12+14912*q**11+78720*q**10+256256*q**9+512512*q**8+515072*q**7-165888*q**6-1212416*q**5-1343488*q**4-163840*q**3+786432*q**2+589824*q+131072))

assert sp.diff(B0i,gamma)==16*q**4*(q+4)*t
assert sp.diff(H0i,gamma)==-16*H**2*q**4*(q+4)*t

Q,F,W,T,U=sp.symbols('Q F W T U', integer=True)
odd={q:2*Q+1,f:2*F+1,w:2*W+1,t:2*T+1,H:2*U}
def even_content(expr):
    ex=sp.expand(expr.subs(odd)); syms=sorted(ex.free_symbols,key=str)
    return int(sp.Poly(ex,*syms).content())%2==0

# First two content levels.
assert even_content(B0i-e**2)
assert even_content(H0i-e**2)
assert sp.denom(sp.cancel(B0i.subs(e,2*E)/4))==1
assert sp.denom(sp.cancel(H0i.subs(e,2*E)/4))==1
assert even_content(sp.expand(B0i.subs(e,2*E)/4)-E**2)
assert even_content(sp.expand(H0i.subs(e,2*E)/4)-E**2)

# Third level: boundary and high differ.
assert sp.denom(sp.cancel(B0i.subs(e,4*E)/16))==1
assert sp.denom(sp.cancel(H0i.subs(e,4*E)/16))==1
assert even_content(sp.expand(B0i.subs(e,4*E)/16)-(E**2+gamma))
assert even_content(sp.expand(H0i.subs(e,4*E)/16)-E**2)

# Fourth high level.  H=10 (delta=1) retains gamma; H divisible by 100 (delta>=2) does not.
H8=sp.expand(H0i.subs(e,8*E)/64)
odd_noH={q:2*Q+1,f:2*F+1,w:2*W+1,t:2*T+1}
def even_after(expr,subs):
    ex=sp.expand(expr.subs(subs)); syms=sorted(ex.free_symbols,key=str)
    return int(sp.Poly(ex,*syms).content())%2==0
assert even_after(H8-(E**2+gamma),{**odd_noH,H:10})
assert even_after(H8-E**2,{**odd_noH,H:100})
# H=100*odd multiple is enough modulo 2; delta>=2 has H^2/4 even.

# Boundary G=10^6 edge: exact replay of the frozen DCDC/RCE reconstruction.
ETA=Fraction(1299,500)
def ceil_div(a,b): return -((-a)//b)
def unit10(x): return gcd(x,10)==1
def solve_cong_interval(a,b,m,L,U):
    if L>U:return ()
    d=gcd(a,m)
    if b%d:return ()
    aa,bb,mm=a//d,b//d,m//d
    r=0 if mm==1 else (bb*pow(aa,-1,mm))%mm
    if r<L:r+=ceil_div(L-r,mm)*mm
    return range(r,U+1,mm)
def digit_t_interval(G,q,N):
    return (ceil_div((q+4)*(G//5)+q*N,G-1),(2*(q+4)*G+q*N-1)//(G-1))
def reconstruct(G,q,N,t):
    if (G+1)%q:return None
    u=(G+1)//q; A=2*u+1; M=q*(q+4)
    znum=A*t-2*N
    if znum%M:return None
    Z=znum//M
    anum=(G-1)*t-q*N; aden=2*(q+4)
    if anum%aden:return None
    a3=anum//aden
    if (Z+u*N)%2:return None
    X=(Z+u*N)//2
    if (N+q*Z)%2:return None
    h=(N+q*Z)//2
    if (A*N+(q+2)*Z)%2:return None
    m=(A*N+(q+2)*Z)//2; r=(G//2)*h-u*a3; D2=u*a3+G*X
    return dict(G=G,q=q,u=u,A=A,N=N,t=t,Z=Z,a3=a3,X=X,h=h,m=m,r=r,D2=D2)
def linear_ok(row,k):
    G,u,A=row['G'],row['u'],row['A']; K=10**k
    for z in ('a3','Z','X','D2','h','m','r'):
        if not(row[z]>0 and unit10(row[z])):return False
    if not(G//10<=row['a3']<G):return False
    if not row['X']*K < ETA*u*G*G:return False
    if not Fraction(row['Z'],1)<2*ETA*u/K+Fraction(2*u*A,G):return False
    return True
def Ftilde(row):return row['A']*row['X']**2+row['Z']*row['D2']
def dcore(g,k):return (2**min(k+1,2*g-2))*(5**min(k,2*g))
def scan_g6(q):
    G=10**6;k=6;K=10**k;u=(G+1)//q;A=2*u+1;M=q*(q+4)
    lo=-(2*ETA/K+Fraction(2*A,G)); hi=2*ETA*G*G/K
    nmin=lo.numerator//lo.denominator+1
    while Fraction(nmin,1)<=lo:nmin+=1
    nmax=(hi.numerator+hi.denominator-1)//hi.denominator-1
    while Fraction(nmax,1)>=hi:nmax-=1
    if nmin%2==0:nmin+=1
    if nmax%2==0:nmax-=1
    st={'N':0,'congruence':0,'reconstructed':0,'linear_legal':0,'dcdc':0}
    for N in range(nmin,nmax+1,2):
        st['N']+=1;L,U=digit_t_interval(G,q,N)
        for tt in solve_cong_interval(A,2*N,M,L,U):
            st['congruence']+=1; row=reconstruct(G,q,N,tt)
            if row is None:continue
            st['reconstructed']+=1
            if not linear_ok(row,k):continue
            st['linear_legal']+=1
            if Ftilde(row)%dcore(6,6):continue
            st['dcdc']+=1
    return st

G6=10**6
assert G6+1==101*9901
edge101=scan_g6(101); edge9901=scan_g6(9901)
assert edge101=={'N':2598000,'congruence':46311,'reconstructed':23089,'linear_legal':7398,'dcdc':0}
assert edge9901=={'N':2598000,'congruence':0,'reconstructed':0,'linear_legal':0,'dcdc':0}

# Boundary B1 on the constant-zero q|t locus.  This is the exact G^1 coefficient
# extracted from the frozen P_B source.
B1=(
 e**2*f**4*w**2*(-128*q**9-2080*q**8-9600*q**7-16768*q**6-26624*q**5-15872*q**4-2048*q**3-2048*q**2)
 +e*f**5*t*w**2*(1280*q**11+20480*q**10+102912*q**9+253952*q**8+628736*q**7+708608*q**6-884736*q**5-1277952*q**4-425984*q**3-196608*q**2-131072*q)
 +e*f**2*gamma*w*(-8*q**5-96*q**4-192*q**3-256*q**2-128*q)
 +f**6*t**2*w**2*(-2048*q**13-24576*q**12-6144*q**11+776192*q**10+3538944*q**9+9871360*q**8+18481152*q**7+5472256*q**6-31981568*q**5-30670848*q**4-1572864*q**3+2097152*q**2-4194304*q-2097152)
 +f**3*gamma*t*w*(64*q**7+832*q**6+3328*q**5+8704*q**4+11776*q**3-2048*q**2-10240*q-4096))
tau,g1=sp.symbols('tau g1', integer=True)
B1qt=sp.factor(B1.subs({t:q*tau,gamma:q*g1}))
J=sp.factor(B1qt/(-8*f**2*q**2*w))
assert sp.denom(J)==1
# On live boundary e=4E and q,f,w,tau odd: J/4 == E*g1 (mod2).
assert sp.denom(sp.cancel(J.subs(e,4*E)/4))==1
oddqt={q:2*Q+1,f:2*F+1,w:2*W+1,tau:2*T+1}
assert even_after(sp.expand(J.subs(e,4*E)/4)-E*g1,oddqt)

cells=[
 dict(branch='BOUNDARY',m=1,e_residue='1 mod2',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(B0)=4 exact',unique_newton_min='N/A',lift_status='KILL_g>=6'),
 dict(branch='HIGH',m=1,e_residue='1 mod2',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(H0)=4 exact',unique_newton_min='N/A',lift_status='KILL_g>=7'),
 dict(branch='BOUNDARY',m=2,e_residue='2 mod4',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(B0)=6 exact',unique_newton_min='N/A',lift_status='ONLY_g=6_THEN_EXACT_DCDC_KILL'),
 dict(branch='HIGH',m=2,e_residue='2 mod4',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(H0)=6 exact',unique_newton_min='N/A',lift_status='KILL_g>=7'),
 dict(branch='BOUNDARY',m=4,e_residue='4 mod8',gamma_residue='0 mod2',t_residue='odd',coefficient_index=0,v2_lower='v2(B0)=8 exact',unique_newton_min='NOT_AUDITED',lift_status='KILL_g>=9'),
 dict(branch='BOUNDARY',m=4,e_residue='4 mod8',gamma_residue='1 mod2',t_residue='odd',coefficient_index=0,v2_lower='>=9',unique_newton_min='NOT_AUDITED',lift_status='LIFT_STABLE_CELL'),
 dict(branch='HIGH',m=4,e_residue='4 mod8',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(H0)=8 exact',unique_newton_min='N/A',lift_status='KILL_g>=9'),
 dict(branch='HIGH_delta>=2',m=6,e_residue='8 mod16',gamma_residue='*',t_residue='odd',coefficient_index=0,v2_lower='v2(H0)=10 exact',unique_newton_min='NOT_AUDITED',lift_status='KILL_g>=11'),
 dict(branch='HIGH_delta=1',m=6,e_residue='8 mod16',gamma_residue='0 mod2',t_residue='odd',coefficient_index=0,v2_lower='v2(H0)=10 exact',unique_newton_min='NOT_AUDITED',lift_status='KILL_g>=11'),
 dict(branch='HIGH_delta=1',m=6,e_residue='8 mod16',gamma_residue='1 mod2',t_residue='odd',coefficient_index=0,v2_lower='>=11',unique_newton_min='NOT_AUDITED',lift_status='LIFT_STABLE_CELL'),
 dict(branch='BOUNDARY_B0_ZERO_q|t',m=5,e_residue='4E',gamma_residue='q*g1',t_residue='q*tau; tau odd',coefficient_index=1,v2_lower='B1=-8 f^2 q^2 w J; J/4=E*g1 mod2',unique_newton_min='NOT_AUDITED',lift_status='E*g1 odd => KILL; else LIFT')]
path=OUT/'J2-55-R15-BH2AdicCells.tsv'
with path.open('w',newline='',encoding='utf-8') as fh:
    wr=csv.DictWriter(fh,fieldnames=list(cells[0]),delimiter='\t');wr.writeheader();wr.writerows(cells)

print('R12_HASH_B='+R12_HASH_B)
print('R12_HASH_H='+R12_HASH_H)
print('B0_MOD2=e^2')
print('H0_MOD2=e^2')
print('BH_E_EVEN=PROVED')
print('B0_INNER_OVER4_MOD2=(e/2)^2 on e even')
print('H0_INNER_OVER4_MOD2=(e/2)^2 on e even')
print('HIGH_E_DIV4=PROVED')
print('BOUNDARY_g>=7_E_DIV4=PROVED')
print('BOUNDARY_g6_EDGE_q101='+str(edge101))
print('BOUNDARY_g6_EDGE_q9901='+str(edge9901))
print('BOUNDARY_g6_EDGE=CLOSED_BY_DCDC')
print('BOUNDARY_ALL_LIVE_E_DIV4=PROVED')
print('B0_INNER_OVER16_MOD2=e/4+gamma on v2(e)>=2')
print('H0_INNER_OVER16_MOD2=e/4 (NOT e/4+gamma) on v2(e)>=2')
print('HIGH_g>=9_E_DIV8=PROVED')
print('HIGH_INNER_OVER64_MOD2_delta1=e/8+gamma')
print('HIGH_INNER_OVER64_MOD2_delta>=2=e/8')
print('BOUNDARY_B0_ZERO_B1_QCONTENT=q^2 exact structural content')
print('BOUNDARY_B0_ZERO_B1_AFTER_e4: J/4 == (e/4)*(gamma/q) mod2')
print('BINARY_AUTOMATON=PARTIAL; stable boundary/high cells remain, no infinite accepting-branch theorem')
print('HIGH_STATUS=OPEN')
print('BOUNDARY_STATUS=OPEN')
print('LEDGER='+path.name)
