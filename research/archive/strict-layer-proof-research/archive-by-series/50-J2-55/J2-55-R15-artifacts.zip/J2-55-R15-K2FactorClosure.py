#!/usr/bin/env python3
"""R15 k=2 carry-spliced factor audit.
Exact algebra only. Reduced-gate pseudo-families are explicitly NOT full J2 states.
"""
from math import gcd
from pathlib import Path
import csv

OUT=Path(__file__).resolve().parent

def vp(n,p):
    n=abs(int(n)); v=0
    if n==0:return 10**9
    while n%p==0:v+=1;n//=p
    return v

def c2(q,e,t,x):
    if q==7:
        C=14213920000; F1=-25*e+77*t; F2=e-4312*x
    elif q==11:
        C=6280403360000; F1=-e+33*t; F2=e-72600*x
    else: raise ValueError
    return C,F1,F2,C*F1*F2

# Frozen outer constants.
assert vp(14213920000,2)==8 and vp(14213920000,5)==4
assert vp(6280403360000,2)==8 and vp(6280403360000,5)==4

# Exactly one factor is odd, for odd t.
for q in (7,11):
    for ee in range(2):
        for tt in (1,3):
            xx=1
            _,F1,F2,_=c2(q,ee,tt,xx)
            assert (F1&1) != (F2&1)

# Provenance audit: R12 gives gcd(x,u)=1 only. Since u=(G+1)/q is itself a ten-unit,
# this gives no information on v2(x) or v5(x). Hence coefficient*x valuations cannot
# be frozen to v2(4312x)=3 etc.
X_TEN_UNIT_INHERITED=False

# F2=0 is impossible from the root lower bound and the safe tail e-height.
def f2_zero_height_kill(q):
    if q==7:
        coeff,f,B=4312,1,153
    else:
        coeff,f,B=72600,5,949
    # k=2: G=100R, u=(G+1)/q, A=2u+1 > 200R/q.
    # x>AG/10 > 2000 R^2/q.
    lower_num=coeff*2000  # e > lower_num/q * R^2 on F2=0
    upper=18*f*B + 30*f*q**3  # |e| < upper R^2
    return lower_num > q*upper, lower_num, q*upper, upper

for q in (7,11):
    ok,_,_,_=f2_zero_height_kill(q); assert ok

# Exact TQR data for the two frozen types.
TQR={7:(1,11),11:(5,3)} # f,h5, with h5*eta=e+8 R f t(3q+5)

def check_pseudo(q,r):
    R=10**r; G=100*R
    assert (G+1)%q==0
    u=(G+1)//q; A=2*u+1
    if q==7:
        x=300*R*R; e=10000*R*R; t=175; f=1; B=153; h5=11
        assert r%6==1 and t%25==0
    else:
        x=200*R*R; e=100000*R*R; t=1; f=5; B=949; h5=3
        assert r%2==1
    # legal inherited coarse gates used in this counter-route audit
    assert t%2==1 and t < 9*q*R
    alpha=2*R*f*B*t-q*e
    assert abs(alpha) < 30*f*q**4*R*R
    assert 10*x > A*G  # x>AG/10
    eta_num=e+8*R*f*t*(3*q+5)
    assert eta_num%h5==0
    C,F1,F2,C2=c2(q,e,t,x)
    assert C2%R==0
    # F2=0 is not used; indeed these families make F2 carry huge R-content.
    assert F2!=0
    return dict(q=q,r=r,R=R,e=e,t=t,x=x,alpha=alpha,F1=F1,F2=F2,
                v2_F1=vp(F1,2),v2_F2=vp(F2,2),v5_F1=vp(F1,5),v5_F2=vp(F2,5),
                C2_over_R=C2//R,
                scope='REDUCED_GATE_PSEUDO_FAMILY_NOT_RCE_DCDC_FULL_ROOT')

rows=[]
for r in (7,13,19): rows.append(check_pseudo(7,r))
for r in (3,5,7,9): rows.append(check_pseudo(11,r))

# The families show why an absolute r-bound does NOT follow from C2 parity + TQR + LOW/height.
# They are not counterexamples to J2: RCE/DCDC/primitive/full-root are deliberately unverified.

path=OUT/'J2-55-R15-K2FactorClosure.tsv'
with path.open('w',newline='',encoding='utf-8') as fh:
    wr=csv.DictWriter(fh,fieldnames=list(rows[0]),delimiter='\t');wr.writeheader();wr.writerows(rows)

print('Q7_F1_PARITY=e+1 (mod2)')
print('Q7_F2_PARITY=e (mod2)')
print('Q7_C2_FACTOR_PARITY=EXACTLY_ONE_ODD_ONE_EVEN')
print('Q7_even_factor_v2=UNBOUNDED_FROM_CURRENT_INHERITED_DATA')
print('Q7_product_v5=UNBOUNDED_FROM_CURRENT_INHERITED_DATA')
print('Q7_F2_ZERO=IMPOSSIBLE_BY_HEIGHT')
print('Q7_r_bound=NOT_PROVED; conjectured r<=8 downgraded')
print('Q7_allowed_r=7,13,19,... (r=1 lies in frozen ell<=5 closure)')
print('Q7_exact_survivors=NOT_FINITEIZED')
print('Q7_STATUS=OPEN')
print('Q11_F1_PARITY=e+1 (mod2)')
print('Q11_F2_PARITY=e (mod2)')
print('Q11_C2_FACTOR_PARITY=EXACTLY_ONE_ODD_ONE_EVEN')
print('Q11_even_factor_v2=UNBOUNDED_FROM_CURRENT_INHERITED_DATA')
print('Q11_product_v5=UNBOUNDED_FROM_CURRENT_INHERITED_DATA')
print('Q11_F2_ZERO=IMPOSSIBLE_BY_HEIGHT')
print('Q11_r_bound=NOT_PROVED; conjectured r<=8 downgraded')
print('Q11_allowed_r=3,5,7,9,... (r=1 lies in frozen ell<=5 closure)')
print('Q11_exact_survivors=NOT_FINITEIZED')
print('Q11_STATUS=OPEN')
print('X_TEN_UNIT_INHERITED=FALSE; only gcd(x,u)=1 is frozen')
print('REDUCED_GATE_PSEUDO_FAMILIES=',len(rows))
print('LEDGER='+path.name)
