#!/usr/bin/env python3
"""Conditional low-k consequences of the R13 constant-term valuation theorem."""
def cyclo(q,k,r): return (pow(10,k+r,q)+1)%q==0
cases=[]
# k=1,q=7: gamma odd already contradicts any r>=1 before cyclotomic filtering.
cases.append((1,7,'IF gamma odd: CLOSED (v2(S0)=0 while 2^r|S0, r>=1)'))
# k=2 gamma odd gives r<=4.
for q in (7,11):
    rs=[r for r in range(1,5) if cyclo(q,2,r)]
    cases.append((2,q,f'IF gamma odd: r<=4; cyclotomic survivors r={rs}'))
for x in cases:print(*x,sep='\t')
print('UNCONDITIONAL_LOWK_CLOSURE=NOT_PROVED_BECAUSE_GAMMA_PARITY_OPEN')
