# Structural-prime summary

After the exact Brauer reduction

\[
(A_2,T_4)=(-1,T_4),
\]

a prime can kill a specialization only if

\[
p\equiv3\pmod4
\]

and

\[
v_p(T_4(10^g,K))
\]

is odd.

Selected useful primes:

- K=100:
  - p=23: ord=22, first exponent root 8 mod22, simple p-adic lifting;
  - p=47: ord=46, roots 34 and 40;
  - p=59: ord=58, roots 25 and 48;
  - p=107: ord=53, root 15.

- K=1000:
  - p=19: ord=18, pure killer class 10 mod18;
  - p=43: ord=21, pure killer class 12 mod21;
  - p=59: ord=58, roots 20 and 51;
  - p=83: ord=41, root 22;
  - p=163: ord=81, roots 2 and 38.

The discriminant primes p=19 and p=43 are unusually strong because the G-root is multiple mod p while the specialized value remains exactly p-adically simple along the entire exponent class.
