# Hilbert symbol formulas used in R5

For odd p, if a=p^alpha u and b=p^beta v with p-adic units u,v,

(a,b)_p =
(-1)^{alpha beta (p-1)/2} (u/p)^beta (v/p)^alpha.

For p=2, with a=2^alpha u, b=2^beta v and u,v odd,

(a,b)_2 =
(-1)^{
((u-1)/2)((v-1)/2)
+ alpha (v^2-1)/8
+ beta (u^2-1)/8
}.

R5 proves the stronger project-specific identity

(A2,T4)=(-1,T4).

Therefore for odd p,

H_{K,p}(g) =
-1 iff p == 3 mod 4 and v_p(T_{K,g}) is odd.

At p=2, T_{K,g}=1 mod 8, so H=+1.
