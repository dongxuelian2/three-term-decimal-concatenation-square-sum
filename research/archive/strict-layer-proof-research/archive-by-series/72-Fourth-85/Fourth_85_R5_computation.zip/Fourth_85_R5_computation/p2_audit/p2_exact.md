# p=2 audit

For all actual G=10^g, T4(G,K) == 1 (mod 8), hence (-1,T)_2=+1.

K=100, live g>=4:
v2(A)=6.
g=4: A/2^6 == 5 mod 8.
g>=5: A/2^6 == 1 mod 8.

K=1000, live g>=5:
v2(A)=8.
g=5: A/2^8 == 5 mod 8.
g>=6: A/2^8 == 1 mod 8.

Verdict: H_{K,2}(g)=+1 identically on the live shell.
