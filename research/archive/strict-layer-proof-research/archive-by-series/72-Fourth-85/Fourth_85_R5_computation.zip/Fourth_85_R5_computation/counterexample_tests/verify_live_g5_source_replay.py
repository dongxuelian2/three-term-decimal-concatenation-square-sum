#!/usr/bin/env python3
from math import gcd, isqrt

pairs=[(1,1),(1,3),(3,1),(1,7),(7,1),(1,9),(3,3),(9,1)]

def rkt(K,tau):
    return (-tau*pow(31,-1,2*K))%(2*K)

def A(K,G):
    return (100*G**6*K**2-100*G**6+280*G**5*K**2-380*G**5+
            236*G**4*K**2-545*G**4+16*G**3*K**2-362*G**3-
            52*G**2*K**2-93*G**2-8*G*K**2+4*K**2)

def P(K,G):
    return (20*G**5*K**2-20*G**5+48*G**4*K**2-68*G**4+
            32*G**3*K**2-85*G**3-46*G**2-4*G*K**2-4*G+3)

def Q(K,G):
    return (4*G**3*K**2-4*G**3+8*G**2*K**2-12*G**2+
            4*G*K**2-13*G-6)

for K in (100,1000):
    g=5
    G=10**g
    Av=A(K,G)
    print("K=",K,"g=5")
    for d,tau in pairs:
        r=rkt(K,tau)
        legal=primitive=squares=0
        n=0
        while True:
            rho=r+2*K*n
            if not (10*d*rho < (10-d*tau)*G):
                break
            legal+=1
            if gcd(rho,10*tau)==1:
                primitive+=1
                Z=tau*G+10*r+20*K*n
                B1=-tau*G**2*P(K,G)
                F=Av*Z*Z+10*B1*Z+25*tau*tau*G**5*Q(K,G)
                if F>=0 and isqrt(F)**2==F:
                    squares+=1
            n+=1
        print((d,tau,r,legal,primitive,squares))
        assert squares==0
print("All live g=5 source templates have zero square values.")
