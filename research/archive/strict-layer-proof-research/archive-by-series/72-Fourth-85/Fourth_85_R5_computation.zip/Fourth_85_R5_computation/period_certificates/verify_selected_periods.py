#!/usr/bin/env python3
import sympy as sp

G,K=sp.symbols("G K", integer=True)
T=(4*G**4*K**2-4*G**4+8*G**3*K**2-12*G**3+
   4*G**2*K**2-13*G**2-6*G+1)
Tp=sp.diff(T,G)

def vp(n,p):
    n=abs(int(n)); c=0
    while n%p==0:
        n//=p; c+=1
    return c

def Tval(Kv,g):
    return int(T.subs({K:Kv,G:10**g}))

checks=[
    (100,23,22,[8]),
    (1000,19,18,[10]),
    (1000,43,21,[12]),
]
for Kv,p,m,roots in checks:
    assert sp.n_order(10,p)==m
    found=[]
    for r in range(m):
        x=pow(10,r,p)
        if int(T.subs({K:Kv,G:x}))%p==0:
            found.append(r)
    assert found==roots
    print("K,p,ord,roots =",Kv,p,m,found)

# p=23 lift root n=5 mod23
Kv,p,r,m=100,23,8,22
assert vp(Tval(Kv,r),p)==1
assert vp(10**m-1,p)==1
assert int(Tp.subs({K:Kv,G:pow(10,r,p)}))%p != 0
lift=[]
for n in range(p):
    g=r+m*n
    if Tval(Kv,g)%(p*p)==0:
        lift.append(n)
assert lift==[5]
print("p=23 first lift n mod23 =",lift)

# p=19,43: valuation exactly 1 throughout one full p-lift of the exponent class
for Kv,p,r,m in [(1000,19,10,18),(1000,43,12,21)]:
    vals=[vp(Tval(Kv,r+m*n),p) for n in range(p)]
    assert set(vals)=={1}
    print("pure class",p,"valuation set",set(vals))

print("Selected period/lifting certificates verified.")
