# Selected exact period / lifting certificates

## K=100, p=23

ord_23(10)=22.
T(10^g)=0 mod 23 iff g=8 mod 22.
At g=8:
v23(T)=1,
v23(10^22-1)=1,
T'(10^8)=11 mod 23.
Writing g=8+22n, the normalized analytic function T(10^{8+22n})/23 has unit derivative mod 23.
Its unique 23-adic zero gamma satisfies gamma=5 mod 23.
Therefore
v23(T)=1+v23(n-gamma).

## K=1000, p=19

ord_19(10)=18.
T(10^g)=0 mod 19 iff g=10 mod 18.
At g=10:
v19(T)=1, T'(10^10)=0 mod19, and T/19=10 mod19.
Since motion in the exponent class changes G only by a 19-multiple and the derivative is itself 0 mod19,
T remains nonzero mod19^2 throughout the class.
Hence v19(T)=1 exactly for every g=10 mod18.

## K=1000, p=43

ord_43(10)=21.
T(10^g)=0 mod43 iff g=12 mod21.
At g=12:
v43(T)=1, T'(10^12)=0 mod43, T/43=9 mod43.
Thus v43(T)=1 throughout the exponent class.
