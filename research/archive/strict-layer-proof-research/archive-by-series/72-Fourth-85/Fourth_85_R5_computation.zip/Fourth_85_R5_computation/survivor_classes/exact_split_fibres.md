# Exact split fibres

By the R5 identity beta=(-1,T), it is enough to factor T and check that every prime 3 mod4 has even exponent.

## K=100

g=5:
T = 3^2 * 444408887599985555488889.

g=9:
T = 3^2 * 937 * 4742796167436025144075299418948654097.
Both odd factors are 1 mod4.

g=10:
T = 3^2 * 91034561 * 2716939598873 * 179675045923984597455713.
All non-3 factors are 1 mod4.

g=11:
T = 3^2 * 10715284115986174397 * 41473468663876625785997934637.
Both non-3 factors are 1 mod4.

g=14:
T = 3^2 * 212955901 * 501629395277 * 4160077231670233484302640846155663489057.
All non-3 factors are 1 mod4.

Hence beta_{100,g}=0 for g=5,9,10,11,14.

## K=1000

g=5:
T = 3^2 * 44445288891999985555488889.

g=8:
T = 3^2 * 5981 * 36761 * 202141710807997620712852542229.

g=9:
T = 3^2 * 17 * 122561 * 213312267019442206209920224865483497.

All non-3 prime factors are 1 mod4.

Hence beta_{1000,g}=0 for g=5,8,9.
