#!/usr/bin/env python3
import sympy as sp
from math import gcd, isqrt

G,K=sp.symbols("G K", integer=True)
A=(100*G**6*K**2-100*G**6+280*G**5*K**2-380*G**5+
   236*G**4*K**2-545*G**4+16*G**3*K**2-362*G**3-
   52*G**2*K**2-93*G**2-8*G*K**2+4*K**2)
T=(4*G**4*K**2-4*G**4+8*G**3*K**2-12*G**3+
   4*G**2*K**2-13*G**2-6*G+1)
S=1-(4*K**2-3)*G-(8*K**2-10)*G**2-(4*K**2-4)*G**3
Q=(4*K**2+21)*G**2+(8*K**2+12)*G+(4*K**2+1)
Rnum=(2100*(K**2-1)*G**5 +(4180*K**2-6280)*G**4
      +(1296*K**2-6085)*G**3 -(1376*K**2+1737)*G**2
      +(-420*K**2+348)*G +(172*K**2+58))
R=Rnum/sp.Integer(58)

assert sp.expand(A+S**2-T*Q)==0
rem=sp.rem(sp.Poly(sp.expand(R**2-Q),G,domain=sp.QQ[K]),
          sp.Poly(A,G,domain=sp.QQ[K]))
assert rem.as_expr()==0

resAQ=sp.factor(sp.resultant(A,Q,G))
assert resAQ==4*(1152*K**6+14864*K**4+2016*K**2+5093)**2

print("Brauer-to-Gaussian polynomial identities verified.")
print("Res(A,Q) =",resAQ)
