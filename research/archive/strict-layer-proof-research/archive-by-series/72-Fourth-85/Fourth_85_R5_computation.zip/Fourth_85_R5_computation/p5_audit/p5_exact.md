# p=5 audit

Because -1 is a square in Q_5, (-1,T)_5=+1 identically.

K=100, live g>=4:
v5(A)=4, A/5^4 == 14 mod 25, T == 1 mod 25.

K=1000, live g>=5:
v5(A)=6, A/5^6 == 6 mod 25, T == 1 mod 25.

Verdict: H_{K,5}(g)=+1 identically.
