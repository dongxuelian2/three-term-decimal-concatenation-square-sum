# Finite-cover search status

No finite local cover was extracted.

Exact scan:
- K=100, g=4..200, p<20000 and p=3 mod4: 68/197 killed, 129 survive.
- K=1000, g=5..200, p<20000 and p=3 mod4: 79/196 killed, 117 survive.

This is only a finite reconnaissance certificate.

The stronger structural obstruction to a universal local-killer theorem is the existence of exact split Brauer fibres, where beta=0 and therefore no local place can kill the fibre.

No claim is made that an eventual finite cover after removing finitely many split endpoints is impossible.
