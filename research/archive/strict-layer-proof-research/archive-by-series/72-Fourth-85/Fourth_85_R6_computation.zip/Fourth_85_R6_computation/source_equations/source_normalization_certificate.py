from sympy import symbols, expand, factor

G,K,tau,r,n = symbols("G K tau r n", integer=True)
A = (100*(K**2-1)*G**6 + (280*K**2-380)*G**5
     + (236*K**2-545)*G**4 + (16*K**2-362)*G**3
     - (52*K**2+93)*G**2 - 8*K**2*G + 4*K**2)
P = (20*G**5*K**2-20*G**5+48*G**4*K**2-68*G**4
     +32*G**3*K**2-85*G**3-46*G**2-4*G*K**2-4*G+3)
B1 = -tau*G**2*P
QK = 4*G**3*K**2-4*G**3+8*G**2*K**2-12*G**2+4*G*K**2-13*G-6
C0 = tau**2*G**5*QK/4
T = 4*(K**2-1)*G**4+(8*K**2-12)*G**3+(4*K**2-13)*G**2-6*G+1

a = tau*G/10 + r + 2*K*n
Z0 = tau*G + 10*r
AK = 400*K**2*A
BK = 40*K*(A*Z0 + 5*B1)
D = tau*G**2*(G+1)*(2*G+3)
Ssource = 200*K*D

# exact numerator simplification
assert expand((2*AK*n+BK) - 200*K*(2*A*a+B1)) == 0

# conic completion-square identity after Y0^2 substitution
completion = expand((2*A*a+B1)**2 - 4*A*(A*a**2+B1*a+C0) - D**2*T)
assert completion == 0

print("CERTIFICATE_STATUS=PASS")
print("EXACT_R4_NORMALIZATION_SIMPLIFIED=TRUE")
print("D=tau*G^2*(G+1)*(2G+3)")
print("x=(2*A*a+B1)/D")
print("v=2*Y0/D")
print("HOMOGENEOUS_INTEGER_FORM:")
print("  X=2*A*a+B1")
print("  V=2*Y0")
print("  X^2-A*V^2=D^2*T")
print("USING_Y0=2*K*y:")
print("  C=X/(4K)")
print("  Y=y")
print("  Z=D/(4K)")
print("  C^2-A*Y^2=T*Z^2")
print("AND a=a0+2K*n IMPLIES:")
print("  C=c_(K,tau,g)+A*n")
print("  c=(2*A*a0+B1)/(4K)")
