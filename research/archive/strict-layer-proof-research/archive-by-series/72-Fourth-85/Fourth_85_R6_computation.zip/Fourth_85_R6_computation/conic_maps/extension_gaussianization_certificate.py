from sympy import symbols, expand, Matrix, Poly, factor, discriminant

G,K,X,V,Z,q = symbols("G K X V Z q")
A = (100*(K**2-1)*G**6 + (280*K**2-380)*G**5
     + (236*K**2-545)*G**4 + (16*K**2-362)*G**3
     - (52*K**2+93)*G**2 - 8*K**2*G + 4*K**2)
T = 4*(K**2-1)*G**4 + (8*K**2-12)*G**3 + (4*K**2-13)*G**2 - 6*G + 1
S = 1-(4*K**2-3)*G-(8*K**2-10)*G**2-(4*K**2-4)*G**3
Q = (4*K**2+21)*G**2+(8*K**2+12)*G+(4*K**2+1)

assert expand(A + S**2 - T*Q) == 0

def reduce_q2(expr):
    p = Poly(expand(expr), q)
    rem = p.rem(Poly(q**2-Q, q))
    return expand(rem.as_expr())

U = S*X + q*T*Z
W = -A*V
ZG = q*X + S*Z

lhs = U**2 + W**2 - T*ZG**2
rhs = -A*(X**2 - A*V**2 - T*Z**2)
assert reduce_q2(lhs-rhs) == 0

M = Matrix([[S,0,q*T],[0,-A,0],[q,0,S]])
N = Matrix([[S,0,-q*T],[0,1,0],[-q,0,S]])
prod = N*M
for i in range(3):
    for j in range(3):
        target = -A if i == j else 0
        assert reduce_q2(prod[i,j]-target) == 0

detM = reduce_q2(M.det())
assert expand(detM - A**2) == 0
discQ = factor(discriminant(Q,G))
assert expand(discQ + 20*(8*K**2-3)) == 0

print("CERTIFICATE_STATUS=PASS")
print("BASE_FIELD=Q(G)")
print("EXTENSION_FIELD=Q(G,sqrt(Q))")
print("A_PLUS_S2_EQ_TQ=PASS")
print("FORWARD_PROJECTIVE:")
print("  U = S*X + sqrt(Q)*T*Z")
print("  W = -A*V")
print("  ZG = sqrt(Q)*X + S*Z")
print("IDENTITY: U^2+W^2-T*ZG^2 = -A*(X^2-A*V^2-T*Z^2)")
print("INVERSE_PROJECTIVE (up to scalar):")
print("  X = S*U - sqrt(Q)*T*ZG")
print("  V = W")
print("  Z = S*ZG - sqrt(Q)*U")
print("DET_FORWARD=A^2")
print("DISC_Q=", discQ)
print("Q_IS_NONSQUARE_QUADRATIC_OVER_Q(G)=TRUE")
print("AFFINE_FORWARD:")
print("  u=(S*x+sqrt(Q)*T)/(S+sqrt(Q)*x)")
print("  w=-A*v/(S+sqrt(Q)*x)")
print("AFFINE_INVERSE:")
print("  x=(S*u-sqrt(Q)*T)/(S-sqrt(Q)*u)")
print("  v=w/(S-sqrt(Q)*u)")
