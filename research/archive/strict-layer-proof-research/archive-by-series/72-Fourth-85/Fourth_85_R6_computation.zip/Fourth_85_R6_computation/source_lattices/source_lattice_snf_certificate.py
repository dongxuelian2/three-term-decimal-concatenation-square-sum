from math import gcd

RES = {
    100:{1:129,3:187,7:103,9:161},
    1000:{1:129,3:387,7:903,9:1161},
}
def A2(G,K):
    return (100*(K*K-1)*G**6+(280*K*K-380)*G**5+(236*K*K-545)*G**4
            +(16*K*K-362)*G**3-(52*K*K+93)*G**2-8*K*K*G+4*K*K)
def P(G,K):
    return (20*G**5*K*K-20*G**5+48*G**4*K*K-68*G**4
            +32*G**3*K*K-85*G**3-46*G**2-4*G*K*K-4*G+3)
for K in (100,1000):
    G=10**5
    A=A2(G,K)
    print(f"K={K} g=5 A2={A}")
    print(f"SNF=(1,{A}) INDEX={A}")
    for tau,r in RES[K].items():
        a0=tau*G//10+r
        B1=-tau*G*G*P(G,K)
        num=2*A*a0+B1
        assert num%(4*K)==0
        c=num//(4*K)
        D=tau*G*G*(G+1)*(2*G+3)
        assert D%(4*K)==0
        Z=D//(4*K)
        print(f"  tau={tau} c={c} Z={Z}")
print("CERTIFICATE_STATUS=PASS")
print("LATTICE_BASIS=diag(A2,1)")
print("SMITH_NORMAL_FORM=diag(1,A2)")
print("d_CHANGES_COSET=FALSE")
print("d_CHANGES_WINDOW_ONLY=TRUE")
