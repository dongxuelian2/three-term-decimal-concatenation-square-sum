from math import gcd,isqrt

PAIRS=[(1,1),(1,3),(3,1),(1,7),(7,1),(1,9),(3,3),(9,1)]
RES={
100:{1:129,3:187,7:103,9:161},
1000:{1:129,3:387,7:903,9:1161},
}
def polys(G,K,tau):
    A=(100*(K*K-1)*G**6+(280*K*K-380)*G**5+(236*K*K-545)*G**4+
       (16*K*K-362)*G**3-(52*K*K+93)*G**2-8*K*K*G+4*K*K)
    P=(20*G**5*K*K-20*G**5+48*G**4*K*K-68*G**4+
       32*G**3*K*K-85*G**3-46*G**2-4*G*K*K-4*G+3)
    B1=-tau*G**2*P
    QK=4*G**3*K*K-4*G**3+8*G**2*K*K-12*G**2+4*G*K*K-13*G-6
    C0=tau*tau*G**5*QK//4
    return A,B1,C0
for K in (100,1000):
    G=10**5
    print(f"K={K},g=5")
    for d,tau in PAIRS:
        r=RES[K][tau]
        ub=(10-d*tau)*G
        den=10*d
        ns=[]
        n=0
        while True:
            rho=r+2*K*n
            if den*rho>=ub:
                break
            if gcd(rho,10*tau)==1:
                ns.append(n)
            n+=1
        A,B,C=polys(G,K,tau)
        hits=[]
        for n in ns:
            rho=r+2*K*n
            a=tau*G//10+rho
            F=A*a*a+B*a+C
            y=isqrt(F) if F>=0 else -1
            if y>=0 and y*y==F:
                hits.append((n,rho,y))
        print(f"  (d,tau)=({d},{tau}) legal_n={len(ns)} square_hits={len(hits)}")
        assert not hits
    print("  ALL_8_ZERO=PASS")
print("CERTIFICATE_STATUS=PASS")
print("NOTE=d affects only the upper rho-window; for fixed tau the conic/coset is unchanged.")
