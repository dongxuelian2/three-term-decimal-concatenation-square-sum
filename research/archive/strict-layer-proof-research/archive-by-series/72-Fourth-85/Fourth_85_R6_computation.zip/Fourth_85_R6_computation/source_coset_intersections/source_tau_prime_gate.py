from math import gcd

def A2mod(g,K,p):
    G=pow(10,g,p)
    K0=K%p
    return (100*(K0*K0-1)*G**6+(280*K0*K0-380)*G**5+
            (236*K0*K0-545)*G**4+(16*K0*K0-362)*G**3-
            (52*K0*K0+93)*G**2-8*K0*K0*G+4*K0*K0)%p

# p=3: powers of ten are 1, and K=100,1000 are 1 modulo 3.
for K in (100,1000):
    for g in range(1,25):
        assert A2mod(g,K,3)==2
print("P3_UNIFORM_A2_MOD3=2: PASS")
print("If 3|tau, B1=C0=0 mod3; gcd(rho,tau)=1 gives a!=0 mod3.")
print("Therefore Y0^2=2*a^2=2 mod3: impossible.")
print("TAU_DIVISIBLE_BY_3_SOURCE_CLOSED=TRUE")
print("Closed historical pairs per K: (1,3),(1,9),(3,3)")

# p=7 source-prime gate for tau=7.
squares7={0,1,2,4}
for K in (100,1000):
    vals=[]
    killed=[]
    for r in range(1,7):
        a=A2mod(r,K,7)
        vals.append((r,a))
        if a not in squares7:
            killed.append(r%6)
    print(f"K={K} A2_mod7_by_gmod6={vals} killed_classes={killed}")
print("P7_TAU7_FILTER=PASS")
print("Interpretation: source-specific FILTER only, not family closure.")
print("CERTIFICATE_STATUS=PASS")
