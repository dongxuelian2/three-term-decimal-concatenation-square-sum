from math import isqrt
from sympy import isprime

def T4(G,K):
    return 4*(K*K-1)*G**4+(8*K*K-12)*G**3+(4*K*K-13)*G**2-6*G+1

def cornacchia_prime_sum2(p):
    assert p % 4 == 1 and isprime(p)
    # find sqrt(-1) mod p
    a = None
    for g in range(2,1000):
        r = pow(g,(p-1)//4,p)
        if (r*r) % p == p-1:
            a = r
            break
    assert a is not None
    for root in (a, p-a):
        r0,r1=p,root
        while r1*r1 > p:
            r0,r1=r1,r0%r1
        y2=p-r1*r1
        y=isqrt(y2)
        if y*y==y2:
            return abs(r1),y
    raise RuntimeError("Cornacchia failed")

for K in (100,1000):
    G=10**5
    T=T4(G,K)
    assert T%9==0
    p=T//9
    assert p%4==1 and isprime(p)
    a,b=cornacchia_prime_sum2(p)
    U,W=3*a,3*b
    assert U*U+W*W==T
    r2=8  # 4*(1+1): only one split rational prime with exponent 1; 3^2 inert.
    print(f"K={K}")
    print(f"T={T}")
    print(f"T=3^2*{p}")
    print(f"p_is_prime={isprime(p)} p_mod4={p%4}")
    print(f"p={a}^2+{b}^2")
    print(f"T={U}^2+{W}^2")
    print(f"r2(T)={r2}")
    print(f"gcd_every_integral_rep_has_factor_3=TRUE")
print("CERTIFICATE_STATUS=PASS")
