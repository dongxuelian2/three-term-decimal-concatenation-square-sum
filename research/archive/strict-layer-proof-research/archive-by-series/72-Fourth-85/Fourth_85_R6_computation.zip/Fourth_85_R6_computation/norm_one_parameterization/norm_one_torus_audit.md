# Norm-One Torus Parameterization and Integralization Audit

Fix an integral Gaussian representation

\[
\Theta=P+iQ_0,\qquad P^2+Q_0^2=T.
\]

Every rational Gaussian point \(z\in\mathbf Q(i)\) with \(N(z)=T\) can be written

\[
z=\Theta\,\omega,\qquad N(\omega)=1.
\]

Write

\[
\omega=\frac{s+ir}{s-ir}
      =\frac{s^2-r^2+2irs}{s^2+r^2},
\qquad r,s\in\mathbf Z,\ \gcd(r,s)=1.
\]

Then

\[
u=\frac{P(s^2-r^2)-2Q_0rs}{s^2+r^2},
\]
\[
w=\frac{Q_0(s^2-r^2)+2Prs}{s^2+r^2}.
\]

Thus the rational norm fibre contains a full one-parameter norm-one torus, with a
moving denominator \(r^2+s^2\). Its prime support is not restricted to the prime
support of \(T\).

If \(z_{\rm src}\) is the rational Gaussian point attached to a source solution and
\(z_{\mathbf Z}\in\mathbf Z[i]\) is any integral representation of \(T\), then

\[
\varepsilon=z_{\mathbf Z}/z_{\rm src}
\]

has norm one. Conversely any norm-one \(\varepsilon\) making
\(\varepsilon z_{\rm src}\) integral is an admissible integralization.

Therefore:

```text
INTEGRAL_GAUSSIAN_REPRESENTATIVE_SOURCE_CANONICAL=NO
FINITE_GAUSSIAN_PRIME_ORIENTATION_SOURCE_CANONICAL=NO
GAUSSIAN_PHASE_AFTER_INTEGRALIZATION_SOURCE_INVARIANT=NO
```

An integral representation census is useful as a fibre diagnostic, but it is not a
provenance-preserving census of source images unless an additional theorem forces the
source-attached rational Gaussian point itself to be integral.
