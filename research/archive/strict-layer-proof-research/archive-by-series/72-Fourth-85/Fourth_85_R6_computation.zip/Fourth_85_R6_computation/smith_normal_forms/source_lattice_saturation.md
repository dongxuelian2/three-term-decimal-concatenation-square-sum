# Source-Lattice Saturation Identity

With
\[
C=\frac{2A a+B_1}{4K},\qquad
Z=\frac{D}{4K},\qquad
a=a_0+2Kn,
\]
one has
\[
C=c+An,\qquad c=\frac{2Aa_0+B_1}{4K}.
\]

The completion-square identity gives identically
\[
(2Aa_0+B_1)^2-D^2T=4A(Aa_0^2+B_1a_0+C_0).
\]
Hence
\[
c^2-TZ^2
=
A\frac{Aa_0^2+B_1a_0+C_0}{4K^2}.
\]

Therefore the obvious quotient congruence
\[
C^2\equiv TZ^2\pmod A
\]
is already built into the source coefficient construction. It is not a new
codimension condition produced by the Smith normal form.

Verdict:

```text
SOURCE_LATTICE_SNF=(1,A2)
SOURCE_LATTICE_CONGRUENCE_NEW_GATE=NO
SOURCE_LATTICE_CONGRUENCE_SATURATED_BY_COMPLETION_IDENTITY=YES
```
