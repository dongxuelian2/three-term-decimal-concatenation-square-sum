# Affine-Infinity Obstruction Certificate

Let \(F=\mathbf Q(G)\), \(A=A_2(G,K)\), \(T=T_4(G,K)\). Consider the standard affine conics

\[
C_A^{\mathrm{aff}}:\ x^2-A v^2=T,\qquad
C_i^{\mathrm{aff}}:\ u^2+w^2=T.
\]

Their smooth projective completions are

\[
X^2-A V^2=T Z^2,\qquad
U^2+W^2=T Z^2.
\]

The deleted infinity divisors are the degree-two schemes

\[
D_A:\ Z=0,\ X^2-A V^2=0,
\]
\[
D_i:\ Z=0,\ U^2+W^2=0.
\]

Their quadratic étale algebras are respectively \(F(\sqrt A)\) and \(F(i)\).
Any regular affine isomorphism extends uniquely to an isomorphism of the smooth projective
completions and must carry the boundary divisor to the boundary divisor. Hence a necessary
condition is

\[
F(\sqrt A)\simeq F(i),
\]

equivalently

\[
-A\in F^{\times 2}.
\]

For the present \(A_2(G,K)\), \(A_2\) is a nonconstant squarefree sextic. Hence \(-A_2\)
is not a square in \(F\). Therefore the two standard affine conics are not isomorphic
over \(F\).

Consequences:

1. An abstract projective conic isomorphism supplied by equality of Brauer classes cannot
   preserve the standard affine charts.
2. Its target affine denominator must depend nontrivially on the source point.
3. Thus a source affine lattice cannot be transported to a fixed affine lattice/coset
   in the standard Gaussian circle by such an isomorphism.
4. A large SNF index in pre-Gaussian source coordinates cannot be compared directly with
   the radius of \(u^2+w^2=T\) without first controlling this moving denominator.

Verdict:

```text
SOURCE_AFFINE_GAUSSIANIZATION_IMPOSSIBLE=YES
FIXED_AFFINE_GAUSSIAN_LATTICE_FROM_PROJECTIVE_DESCENT=NO
```
