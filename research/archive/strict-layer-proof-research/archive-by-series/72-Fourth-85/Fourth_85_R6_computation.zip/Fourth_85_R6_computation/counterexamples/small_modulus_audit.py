from math import gcd
from sympy import primerange

PAIRS=[(1,1),(1,3),(3,1),(1,7),(7,1),(1,9),(3,3),(9,1)]
RES={100:{1:129,3:187,7:103,9:161},1000:{1:129,3:387,7:903,9:1161}}
def coeffs(G,K,tau):
    A=(100*(K*K-1)*G**6+(280*K*K-380)*G**5+(236*K*K-545)*G**4+
       (16*K*K-362)*G**3-(52*K*K+93)*G**2-8*K*K*G+4*K*K)
    P=(20*G**5*K*K-20*G**5+48*G**4*K*K-68*G**4+
       32*G**3*K*K-85*G**3-46*G**2-4*G*K*K-4*G+3)
    B=-tau*G**2*P
    QK=4*G**3*K*K-4*G**3+8*G**2*K*K-12*G**2+4*G*K*K-13*G-6
    C=tau*tau*G**5*QK//4
    r=RES[K][tau]
    a0=tau*G//10+r
    # F(n)=A(a0+2Kn)^2+B(a0+2Kn)+C
    return A*(2*K)**2, (2*A*a0+B)*(2*K), A*a0*a0+B*a0+C
def is_square_mod(x,m):
    return any((y*y-x)%m==0 for y in range(m))
for K in (100,1000):
    G=10**5
    for d,tau in PAIRS:
        aa,bb,cc=coeffs(G,K,tau)
        killers=[]
        for p in primerange(2,500):
            legal=[]
            for n in range(p):
                rho=RES[K][tau]+2*K*n
                if gcd(rho,10*tau)==1:
                    legal.append(n)
            if legal and all(not is_square_mod((aa*n*n+bb*n+cc)%p,p) for n in legal):
                killers.append(p)
        print(f"K={K} pair=({d},{tau}) prime_killers_lt500={killers}")
print("CERTIFICATE_STATUS=PASS")
print("INTERPRETATION=finite negative audit only; no uniform theorem claimed")
