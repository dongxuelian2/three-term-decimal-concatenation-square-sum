import sympy as sp
G,K,tau,r,n=sp.symbols("G K tau r n")
A2=(100*G**6*K**2-100*G**6+280*G**5*K**2-380*G**5+236*G**4*K**2-545*G**4+16*G**3*K**2-362*G**3-52*G**2*K**2-93*G**2-8*G*K**2+4*K**2)
P=(20*G**5*K**2-20*G**5+48*G**4*K**2-68*G**4+32*G**3*K**2-85*G**3-46*G**2-4*G*K**2-4*G+3)
B1=-G**2*tau*P
QK=4*G**3*K**2-4*G**3+8*G**2*K**2-12*G**2+4*G*K**2-13*G-6
C0=G**5*tau**2*QK/4
T4=4*G**4*K**2-4*G**4+8*G**3*K**2-12*G**3+4*G**2*K**2-13*G**2-6*G+1
assert sp.factor(B1**2-4*A2*C0-G**4*tau**2*(G+1)**2*(2*G+3)**2*T4)==0
Z0=tau*G+10*r
Z=Z0+20*K*n
F=sp.expand(A2*Z**2+10*B1*Z+25*tau**2*G**5*QK)
An=sp.expand(400*K**2*A2)
Bn=sp.expand(40*K*(A2*Z0+5*B1))
Cn=sp.expand(A2*Z0**2+10*B1*Z0+25*tau**2*G**5*QK)
assert sp.expand(F-(An*n**2+Bn*n+Cn))==0
assert sp.factor(Bn**2-4*An*Cn-(200*K*tau*G**2*(G+1)*(2*G+3))**2*T4)==0
R=sp.factor(sp.resultant(A2,T4,G))
assert sp.factor(R-1024*(K-1)**2*(K+1)**2*(32*K**6+348*K**4-1220*K**2+727)**2)==0
print("PASS")
