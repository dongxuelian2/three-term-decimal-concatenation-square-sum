No Gröbner elimination was promoted: the exact quadratic completion already gives the minimal useful elimination.
