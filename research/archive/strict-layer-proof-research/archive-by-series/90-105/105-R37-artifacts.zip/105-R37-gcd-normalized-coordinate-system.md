# 105-R37 — GCD-Normalized Coordinate System

## 1. Authoritative selector semantics
The frozen pullback semantics are
\[
g_0=\gcd(u_0AW,P_1),\qquad g_1^*=\mu g_0,\qquad g_1^*\mid P_1.
\]
Put \(M_0=u_0AW\).

## 2. Exact gcd normalization theorem
For positive integers, the statement
\[
g_0=\gcd(M_0,P_1)
\]
is equivalent to the existence of positive integers \(a,r\) such that
\[
M_0=g_0a,\qquad P_1=g_0r,\qquad (a,r)=1.
\]
Proof: divide both arguments of the gcd by \(g_0\) in the forward direction; in the reverse direction
\(\gcd(g_0a,g_0r)=g_0(a,r)=g_0\).

Because \(g_1^*=\mu g_0\mid P_1=g_0r\), one has exactly
\[
\mu\mid r.
\]
Write
\[
r=\mu s.
\]
Hence the production coordinates are
\[
\boxed{u_0AW=g_0a,\quad P_1=g_0\mu s,\quad (a,\mu s)=1.}
\]
No frozen theorem implies \((\mu,s)=1\); that condition is NOT added.

## 3. Primitive strengthening
The frozen primitive selector gcd theorem gives \((u_0,P_1)=1\). Therefore
\[
g_0=\gcd(u_0AW,P_1)=\gcd(AW,P_1),\qquad g_0\mid AW.
\]
Define
\[
\alpha:=\frac{AW}{g_0}.
\]
Then
\[
\boxed{a=u_0\alpha,\qquad AW=g_0\alpha,\qquad P_1=g_0\mu s,\qquad (u_0\alpha,\mu s)=1.}
\]
This is the strongest production normalization used in R37. In particular \(g_0\) is never allowed to absorb a prime that enters only through \(u_0\).

## 4. A/W allocation
Under the frozen shape condition \((A,W)=1\), define
\[
g_A=(A,P_1),\qquad g_W=(W,P_1).
\]
Then
\[
g_0=g_Ag_W,
\]
and with \(A'=A/g_A,\ W'=W/g_W\),
\[
\alpha=A'W'.
\]
Thus the fully normalized primitive core may be written
\[
A=g_AA',\quad W=g_WW',\quad g_0=g_Ag_W,\quad a=u_0A'W',\quad P_1=g_Ag_W\mu s.
\]
