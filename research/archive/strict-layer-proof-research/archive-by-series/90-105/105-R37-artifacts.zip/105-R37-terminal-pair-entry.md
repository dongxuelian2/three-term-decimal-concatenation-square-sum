# 105-R37 — Terminal Pair Entry

The frozen rule is unchanged: once \(\mathfrak a\in\mathscr T\), set
\[
Q_*=\min(Q_+,Q_{master}),
\]
and search exactly
\[
q\in[Q_-,Q_*]\cap\mathbb Z_{>0},\qquad(q,FU)=1.
\]
On \(\mathscr T_1\), q=1 gives an immediate terminal-positive pair.

R37 produced no selector-consistent architecture in \(\mathscr T\). Hence terminal rectangle enumeration was not triggered and the terminal-pair registry is empty.

```text
MASTER_REFINED_TERMINAL_POSITIVE=NO
GENUINE_TERMINAL_PAIR_FOUND=NO
```

These are execution facts for R37, not global impossibility theorems.
