# 105-R37 — Twelve-Root Symbolic Autopsy

## 1. Corrected split
The prompt suggested computing \((a_{sel},r_{sel})\) on all twelve roots. Exact inspection shows that this gcd is not even defined integrally on half of them: in six rows \(g_{0,sel}\nmid P_1\).

All twelve rows lie on a single primitive sphere ray
\[
\boxed{(P_1,P_2,P_3,Q_0)_{prim}=(6,58,9,59).}
\]
They are two selector representations of that same ray.

## 2. Family F_A(t), t=1,...,6 in R36
\[
u_0=3t,\ \Lambda=1,\ A=W=5,\ C_2=58,\ C_3=9,\ \mu=1,
\]
\[
g_{0,sel}=25t,\quad a_{sel}=3,
\]
\[
(P_1,P_2,P_3,Q_0)=t(90,870,135,885)=15t(6,58,9,59).
\]
Then
\[
\frac{P_1}{g_{0,sel}}=\frac{18}{5}\notin\mathbb Z,
\]
so the normalized coordinate \(r\) does not exist. Moreover
\[
g_{0,actual}=\gcd(75t,90t)=15t\ne25t.
\]
This family also violates \((A,W)=1\) and is nonprimitive, but selector divisibility already kills it.

## 3. Family F_B(t), t=1,...,6 in R36
\[
u_0=3t,\ \Lambda=5,\ A=W=1,\ C_2=58,\ C_3=9,\ \mu=5,
\]
\[
g_{0,sel}=t,\quad a_{sel}=3,
\]
\[
(P_1,P_2,P_3,Q_0)=t(18,174,27,177)=3t(6,58,9,59).
\]
Here
\[
r_{sel}=18,\qquad (a_{sel},r_{sel})=3,
\]
but the earlier gate is already
\[
\boxed{\mu=5\nmid18=r_{sel}},
\]
equivalently \(g_1^*=5t\nmid P_1=18t\). The actual gcd is \(3t\), not \(t\).

Thus the exact R36 split is
\[
\boxed{6\text{ roots}:g_0\nmid P_1;\qquad6\text{ roots}:\mu\nmid r.}
\]
There is no honest statement that all twelve have one integer gcd \((a,r)>1\).

## 4. Expanded raw family
In the corrected n2=2,n3=1 superset through u0<=60, all raw roots collapse to two primitive rays. Besides the ray above, the second is
\[
(14,138,9,139).
\]
It occurs as
\[
u_0=21t,\ A=W=1,\ \Lambda=\mu=5,\ a=7,\ g_0=3t,
\]
\[
C_2=46j,\ C_3=3j,\quad j\in\{1,2\},
\]
\[
(P_1,P_2,P_3,Q_0)=jt(98,966,63,973)=7jt(14,138,9,139).
\]
But
\[
P_1/g_0=98j/3\notin\mathbb Z\quad(j=1,2),
\]
so it is also a fake sheet. The symbolic identities are verified in `r37_symbolic_families.py`.
