# 105-R37 — Selector Consistency Derivation

## 1. What R36 relaxed
R31's architecture-first generator used \(g_0\mid AW\). R36's source-first shell changed that to \(g_0\mid M_0=u_0AW\). On a primitive target this is a genuine relaxation because \((u_0,P_1)=1\), hence the actual gcd cannot absorb the \(u_0\)-only content.

R37 therefore treats `g0 | AW` as a pre-discriminant necessary condition and then enforces
\[
P_1=g_0\mu s,\qquad (u_0AW/g_0,\mu s)=1
\]
at root acceptance. No fake selector label survives as a legal root.

## 2. Normalized MASTER divisibility
Let \(\Lambda=\mu\ell\), where
\[
\ell=\frac{\Lambda}{\mu}=\frac{\lambda_z}{(\lambda_z,\mu)}=\tau.
\]
The base denominator coefficient is
\[
\bar b_1=\frac{\Lambda u_0AW}{g_1^*}=\ell a.
\]
With \(b_2=A\Lambda\), \(b_3=W\Lambda\), the MASTER equation divides by \(\ell\) and becomes
\[
\boxed{a10^{m+n+g}D=\mu(WT+A10^nH).}\tag{NM}
\]
Since \((a,\mu)=1\),
\[
\boxed{a\mid WT+A10^nH.}\tag{SC-DIV}
\]
Using \(a=u_0A'W'\), this gives
\[
u_0A'W'\mid WT+A10^nH.
\]
Consequently
\[
\boxed{A'\mid T},\qquad \boxed{W'\mid 10^nH}.
\]
The first follows because \((A',W)=1\); the second because \((W',A)=1\).

## 3. Unitary consequence on the A-side
If a prime \(p\) divided both \(g_A\) and \(A'\), then \(p\mid P_1\), \(p\mid P_3\), and \(A'\mid T=Q_0-P_3\) would give \(p\mid Q_0\). The sphere equation would then force \(p\mid P_2\), contradicting primitive content one. Hence
\[
\boxed{(g_A,A')=1.}
\]
Thus \(g_A\) is a unitary divisor of \(A\): every prime power of \(A\) is allocated wholly to \(g_A\) or wholly to \(A'\), never split partially.

For the W-side, the same argument works away from the decimal primes because \(W'\mid10^nH\):
\[
\boxed{\operatorname{Supp}(g_W,W')\subseteq\{2,5\}.}
\]
No stronger 2/5 statement is claimed in R37.

## 4. Information-gain audit of simple congruences
Reducing (NM) modulo \(u_0\), using \((u_0,Q_0)=1\), recovers the frozen support-allocation condition
\[
u_0\mid W+A10^{n+g}.
\]
So the `mod u0` route has `INFORMATION_GAIN=0` relative to R28.

Reducing (NM) through \(\mu\) gives \(\mu\mid10^{m+n+g}D\), the old mu-core divisibility class. It does NOT prove the stronger selector requirement \(\mu\mid r=P_1/g_0\). Thus the observed final q=1 raw root cannot be killed by a new one-line mod-mu theorem.

## 5. Status
The gcd normalization and the primitive `g0 | AW` correction are proved. A global theorem
\[
\text{source-first MASTER/sphere root}\Longrightarrow(a,\mu s)>1
\]
was NOT proved. The exact unresolved selector gate is moved to the normalized root numerator divisibility recorded in the MASTER/sphere artifact.
