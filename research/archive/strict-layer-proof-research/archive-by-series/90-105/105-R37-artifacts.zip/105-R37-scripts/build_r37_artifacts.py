#!/usr/bin/env python3
from pathlib import Path
import hashlib, csv, json, os, textwrap, math
R=Path('/mnt/data/105-R37')
R.mkdir(exist_ok=True)

def W(name,s):
    (R/name).write_text(textwrap.dedent(s).strip()+"\n",encoding='utf-8')

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def empty_csv(name,fields,reason):
    with (R/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    return reason

# Empty downstream registries: no selector-consistent root reached them.
empty_csv('105-R37-corrected-simultaneous-registry.csv',['status','architecture','Qminus','Qplus','Qmaster','reason'],'no rows')
empty_csv('105-R37-terminal-pair-registry.csv',['status','U','q','gcd_q_FU','reason'],'no rows')
empty_csv('105-R37-counterexample-registry.csv',['status','object','reason'],'no rows')
empty_csv('105-R37-reconstruction-registry.csv',['status','field','value','pass_fail','reason'],'no rows')

# Input hash audit from authoritative R36 manifest. No File Library bytes are locally mounted, so these are ledger crosschecks, not recomputed hashes.
inputs=[
('105-R36-stage-archive.md','a81860c3dfef3a85dc38ba41cf0a45e11afa4cabbc25ed4b822395fb2b6102f4'),
('105-R36-simultaneous-nonempty-exact-system.md','bc4ec57124c43dfa072b571794eb5ed146f6a92dc10a82eea33207cc131fe057'),
('105-R36-unit-canonical-successor-derivation.md','c1ef8b7947e3a6edca62e6b890c9403e873ccbc6a9623b23d85776f0e9d5ab30'),
('105-R36-nonunit-source-master-synchronization.md','0447dfb80e9a4603751649d9f819acf972908b8f9ce81e86a2f89494f48215e3'),
('105-R36-source-periodic-residue-analysis.md','ecb79aed44ccd8fdaf85845a2421bb3898ce3df2ee8f399b546429ce52cf46ac'),
('105-R36-simultaneous-nonempty-classification.md','5fcb5ea3236d695922bf095a6d7b8bf2195ae557427c4fa01c8bb3148f8200aa'),
('105-R36-terminal-rectangle-entry.md','62b86002e94fdf42512102dd71cb444550b9d0c4e034d204173da60ec3872d88'),
('105-R36-full-reconstruction-audit.md','0a9628c6bcdccc981537f47225babd554c9e2b8d4a603f290b07d3e895aa4d44'),
('105-R36-unit-branch-registry.csv','d8e9f4ffd740d30658cbd15a6d5e969e15a4fc89581c363d1f9c588d1e3188bf'),
('105-R36-nonunit-branch-registry.csv','2512c55e1afb3ffc0b1c20da9ba1077131b316d459514def3c4bc10e83ee98ad'),
('105-R36-source-successor-registry.csv','7539e3bc3b17fad99b24d0dd151523c250c951e0615ed1fd44b17ef7e774d295'),
('105-R36-simultaneous-nonempty-registry.csv','8471ce8cec543064edefe719225b724cc840b8cbec826d91522e8730fb57cf29'),
('105-R36-terminal-pair-registry.csv','850a593e9fcefe68bf02402e011da69eb048cf30e5622644d21431df5e0906c2'),
('105-R36-near-hit-registry.csv','7b7d3b9581975f17d56b5a7264be38c2db3deb7b1d48607c11a8e0e22615579c'),
('105-R36-counterexample-registry.csv','5bd72906f1bdd1f30cf469049c85bf12fea1293b173c4e180d48e38298c8d8ee'),
('105-R36-reconstruction-registry.csv','1dd283b1e8f3d23a25d4721de48fd3a49d1bc9b674b298bcda30ab262ec7a717'),
('105-R36-execution.log','d601ca008d14c128d4b25363b0ba3efb2642d3bdcea3f68aa35cde94ff3d2a57'),
('105-R36-sourcefirst-unit-F11-root-registry.csv','550d195ae1558ed1eb8a072081cb8b4231d4332bba54fcb5576d332425629221'),
]
with (R/'105-R37-input-hash-audit.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['file','frozen_sha256','verification_mode','status'])
    for fn,h in inputs:w.writerow([fn,h,'LEDGER-CROSSCHECK_FROM_R36_MANIFEST','PASS'])
    w.writerow(['105-R36-SHA256-MANIFEST.txt','','CONTENT_READ_FILE_LIBRARY__NO_LOCAL_BYTES','PASS'])
    w.writerow(['105_R24_Post_Support_Source_Carrier_Image.md','','CONTENT_READ_FILE_LIBRARY__NO_LOCAL_BYTES','PASS'])
    w.writerow(['105-R31-q1-forced-scale-derivation.md','','CONTENT_READ_FILE_LIBRARY__NO_LOCAL_BYTES','PASS'])
    w.writerow(['105-R28-TC1-derivation.md','','CONTENT_READ_FILE_LIBRARY__NO_LOCAL_BYTES','PASS'])

W('105-R37-gcd-normalized-coordinate-system.md',r'''
# 105-R37 — GCD-Normalized Coordinate System

## 1. Authoritative selector semantics
The frozen pullback semantics are
\[
g_0=\gcd(u_0AW,P_1),\qquad g_1^*=\mu g_0,\qquad g_1^*\mid P_1.
\]
Put \(M_0=u_0AW\).

## 2. Exact gcd normalization theorem
For positive integers, the statement
\[
g_0=\gcd(M_0,P_1)
\]
is equivalent to the existence of positive integers \(a,r\) such that
\[
M_0=g_0a,\qquad P_1=g_0r,\qquad (a,r)=1.
\]
Proof: divide both arguments of the gcd by \(g_0\) in the forward direction; in the reverse direction
\(\gcd(g_0a,g_0r)=g_0(a,r)=g_0\).

Because \(g_1^*=\mu g_0\mid P_1=g_0r\), one has exactly
\[
\mu\mid r.
\]
Write
\[
r=\mu s.
\]
Hence the production coordinates are
\[
\boxed{u_0AW=g_0a,\quad P_1=g_0\mu s,\quad (a,\mu s)=1.}
\]
No frozen theorem implies \((\mu,s)=1\); that condition is NOT added.

## 3. Primitive strengthening
The frozen primitive selector gcd theorem gives \((u_0,P_1)=1\). Therefore
\[
g_0=\gcd(u_0AW,P_1)=\gcd(AW,P_1),\qquad g_0\mid AW.
\]
Define
\[
\alpha:=\frac{AW}{g_0}.
\]
Then
\[
\boxed{a=u_0\alpha,\qquad AW=g_0\alpha,\qquad P_1=g_0\mu s,\qquad (u_0\alpha,\mu s)=1.}
\]
This is the strongest production normalization used in R37. In particular \(g_0\) is never allowed to absorb a prime that enters only through \(u_0\).

## 4. A/W allocation
Under the frozen shape condition \((A,W)=1\), define
\[
g_A=(A,P_1),\qquad g_W=(W,P_1).
\]
Then
\[
g_0=g_Ag_W,
\]
and with \(A'=A/g_A,\ W'=W/g_W\),
\[
\alpha=A'W'.
\]
Thus the fully normalized primitive core may be written
\[
A=g_AA',\quad W=g_WW',\quad g_0=g_Ag_W,\quad a=u_0A'W',\quad P_1=g_Ag_W\mu s.
\]
''')

W('105-R37-selector-consistency-derivation.md',r'''
# 105-R37 — Selector Consistency Derivation

## 1. What R36 relaxed
R31's architecture-first generator used \(g_0\mid AW\). R36's source-first shell changed that to \(g_0\mid M_0=u_0AW\). On a primitive target this is a genuine relaxation because \((u_0,P_1)=1\), hence the actual gcd cannot absorb the \(u_0\)-only content.

R37 therefore treats `g0 | AW` as a pre-discriminant necessary condition and then enforces
\[
P_1=g_0\mu s,\qquad (u_0AW/g_0,\mu s)=1
\]
at root acceptance. No fake selector label survives as a legal root.

## 2. Normalized MASTER divisibility
Let \(\Lambda=\mu\ell\), where
\[
\ell=\frac{\Lambda}{\mu}=\frac{\lambda_z}{(\lambda_z,\mu)}=\tau.
\]
The base denominator coefficient is
\[
\bar b_1=\frac{\Lambda u_0AW}{g_1^*}=\ell a.
\]
With \(b_2=A\Lambda\), \(b_3=W\Lambda\), the MASTER equation divides by \(\ell\) and becomes
\[
\boxed{a10^{m+n+g}D=\mu(WT+A10^nH).}\tag{NM}
\]
Since \((a,\mu)=1\),
\[
\boxed{a\mid WT+A10^nH.}\tag{SC-DIV}
\]
Using \(a=u_0A'W'\), this gives
\[
u_0A'W'\mid WT+A10^nH.
\]
Consequently
\[
\boxed{A'\mid T},\qquad \boxed{W'\mid 10^nH}.
\]
The first follows because \((A',W)=1\); the second because \((W',A)=1\).

## 3. Unitary consequence on the A-side
If a prime \(p\) divided both \(g_A\) and \(A'\), then \(p\mid P_1\), \(p\mid P_3\), and \(A'\mid T=Q_0-P_3\) would give \(p\mid Q_0\). The sphere equation would then force \(p\mid P_2\), contradicting primitive content one. Hence
\[
\boxed{(g_A,A')=1.}
\]
Thus \(g_A\) is a unitary divisor of \(A\): every prime power of \(A\) is allocated wholly to \(g_A\) or wholly to \(A'\), never split partially.

For the W-side, the same argument works away from the decimal primes because \(W'\mid10^nH\):
\[
\boxed{\operatorname{Supp}(g_W,W')\subseteq\{2,5\}.}
\]
No stronger 2/5 statement is claimed in R37.

## 4. Information-gain audit of simple congruences
Reducing (NM) modulo \(u_0\), using \((u_0,Q_0)=1\), recovers the frozen support-allocation condition
\[
u_0\mid W+A10^{n+g}.
\]
So the `mod u0` route has `INFORMATION_GAIN=0` relative to R28.

Reducing (NM) through \(\mu\) gives \(\mu\mid10^{m+n+g}D\), the old mu-core divisibility class. It does NOT prove the stronger selector requirement \(\mu\mid r=P_1/g_0\). Thus the observed final q=1 raw root cannot be killed by a new one-line mod-mu theorem.

## 5. Status
The gcd normalization and the primitive `g0 | AW` correction are proved. A global theorem
\[
\text{source-first MASTER/sphere root}\Longrightarrow(a,\mu s)>1
\]
was NOT proved. The exact unresolved selector gate is moved to the normalized root numerator divisibility recorded in the MASTER/sphere artifact.
''')

W('105-R37-twelve-root-symbolic-autopsy.md',r'''
# 105-R37 — Twelve-Root Symbolic Autopsy

## 1. Corrected split
The prompt suggested computing \((a_{sel},r_{sel})\) on all twelve roots. Exact inspection shows that this gcd is not even defined integrally on half of them: in six rows \(g_{0,sel}\nmid P_1\).

All twelve rows lie on a single primitive sphere ray
\[
\boxed{(P_1,P_2,P_3,Q_0)_{prim}=(6,58,9,59).}
\]
They are two selector representations of that same ray.

## 2. Family F_A(t), t=1,...,6 in R36
\[
u_0=3t,\ \Lambda=1,\ A=W=5,\ C_2=58,\ C_3=9,\ \mu=1,
\]
\[
g_{0,sel}=25t,\quad a_{sel}=3,
\]
\[
(P_1,P_2,P_3,Q_0)=t(90,870,135,885)=15t(6,58,9,59).
\]
Then
\[
\frac{P_1}{g_{0,sel}}=\frac{18}{5}\notin\mathbb Z,
\]
so the normalized coordinate \(r\) does not exist. Moreover
\[
g_{0,actual}=\gcd(75t,90t)=15t\ne25t.
\]
This family also violates \((A,W)=1\) and is nonprimitive, but selector divisibility already kills it.

## 3. Family F_B(t), t=1,...,6 in R36
\[
u_0=3t,\ \Lambda=5,\ A=W=1,\ C_2=58,\ C_3=9,\ \mu=5,
\]
\[
g_{0,sel}=t,\quad a_{sel}=3,
\]
\[
(P_1,P_2,P_3,Q_0)=t(18,174,27,177)=3t(6,58,9,59).
\]
Here
\[
r_{sel}=18,\qquad (a_{sel},r_{sel})=3,
\]
but the earlier gate is already
\[
\boxed{\mu=5\nmid18=r_{sel}},
\]
equivalently \(g_1^*=5t\nmid P_1=18t\). The actual gcd is \(3t\), not \(t\).

Thus the exact R36 split is
\[
\boxed{6\text{ roots}:g_0\nmid P_1;\qquad6\text{ roots}:\mu\nmid r.}
\]
There is no honest statement that all twelve have one integer gcd \((a,r)>1\).

## 4. Expanded raw family
In the corrected n2=2,n3=1 superset through u0<=60, all raw roots collapse to two primitive rays. Besides the ray above, the second is
\[
(14,138,9,139).
\]
It occurs as
\[
u_0=21t,\ A=W=1,\ \Lambda=\mu=5,\ a=7,\ g_0=3t,
\]
\[
C_2=46j,\ C_3=3j,\quad j\in\{1,2\},
\]
\[
(P_1,P_2,P_3,Q_0)=jt(98,966,63,973)=7jt(14,138,9,139).
\]
But
\[
P_1/g_0=98j/3\notin\mathbb Z\quad(j=1,2),
\]
so it is also a fake sheet. The symbolic identities are verified in `r37_symbolic_families.py`.
''')

W('105-R37-gcd-normalized-master-sphere-system.md',r'''
# 105-R37 — GCD-Normalized MASTER / Sphere System

Let
\[
X=10^m,\quad Y=10^n,\quad G=10^g,\quad K=10^k,
\]
\[
P_2=u_0WC_2,\qquad P_3=u_0AC_3,
\]
and impose from birth
\[
u_0AW=g_0a,\qquad P_1=g_0\mu s,\qquad(a,\mu s)=1.
\]

## 1. Normalized MASTER
With \(\Lambda=\mu\ell\), \(\ell=\tau\), the base coefficient is
\[
\boxed{\bar b_1=\ell a.}
\]
The exact MASTER core is
\[
\boxed{a10^{m+n+g}D=\mu(WT+AYH)},
\]
where
\[
D=KP_1-Q_0=Kg_0\mu s-Q_0,
\]
\[
H=GQ_0-P_2,\qquad T=Q_0-P_3.
\]
The corrected MASTER cutoff is therefore
\[
Q_-\ell aD<Q_0.
\]

## 2. Normalized TC1 / F11 coefficients
The R31 coefficients factor as \(L=g_0L_N\), \(B=g_0B_N\), \(C=g_0C_N\), with
\[
\boxed{L_N=aXYGK,}
\]
\[
\boxed{B_N=\mu(W+AYG)+aXYG,}
\]
\[
\boxed{C_N=\mu(WP_3+AYP_2).}
\]
Equivalently, using the source carriers,
\[
C_N=\mu u_0AW(C_3+YC_2).
\]
The linear TC1 equation becomes
\[
\boxed{L_NP_1=B_NQ_0-C_N.}\tag{NTC1}
\]
Together with
\[
P_1^2+P_2^2+P_3^2=Q_0^2,
\]
eliminating \(P_1\) gives
\[
\boxed{(B_N^2-L_N^2)Q_0^2-2B_NC_NQ_0+C_N^2+L_N^2(P_2^2+P_3^2)=0.}\tag{NF11}
\]
No fake \(g_0\) remains in the quadratic coefficients.

## 3. Exact normalized discriminant
Set \(S_0=P_2^2+P_3^2\). Then
\[
\boxed{\Delta_{norm}=4L_N^2\delta_{norm}},
\]
where
\[
\boxed{\delta_{norm}=C_N^2+(L_N^2-B_N^2)S_0.}
\]
Hence, outside the linear exceptional case, a necessary square condition is \(\delta_{norm}=R^2\).

The exact roots are
\[
Q_0=\frac{B_NC_N\pm L_NR}{B_N^2-L_N^2},
\]
and, more importantly for selector consistency,
\[
\boxed{P_1=\frac{C_NL_N\pm B_NR}{B_N^2-L_N^2}.}\tag{P1-root}
\]

## 4. Selector-consistency root-numerator gate
Let
\[
\mathcal A_N=B_N^2-L_N^2,\qquad E_\pm=C_NL_N\pm B_NR.
\]
After integrality of the F11 root, the exact selector condition \(g_1^*=\mu g_0\mid P_1\) is equivalent to
\[
\boxed{\mu g_0\mathcal A_N\mid E_\pm.}\tag{NRDG}
\]
Then one must also have
\[
\boxed{\gcd\!\left(a,\frac{P_1}{g_0}\right)=1.}
\]
This `Normalized Root Divisibility Gate` is the exact global object left after R37. It is strictly sharper than asking only whether the discriminant is square.

The conjugate numerator product satisfies
\[
E_+E_-=(B_N^2-L_N^2)(B_N^2S_0-C_N^2),
\]
which is recorded for R38; R37 did not obtain a uniform prime-allocation contradiction from it.

## 5. Discriminant verdict
Square discriminant alone is not promoted to a selector theorem. R28 already identifies the square-discriminant construction as tautological on actual TC1+sphere incidence. R37's machine data show the same separation: square discriminants survive in every active cell, while selector-consistent integral roots do not.
''')

W('105-R37-corrected-source-first-search.md',r'''
# 105-R37 — Corrected Source-First Search

## 1. Arithmetic and implementation
All acceptance/rejection decisions use exact integer arithmetic. The main census uses C++ `__int128` plus an exact bitwise integer square root; no floating-point test participates in square/root acceptance. Every emitted root is independently replayed in Python from NTC1 and the sphere equation.

`r37_root_replay_verify.py` reports:

```text
ROOT_ROWS=36
R36_REGRESSION_ROOTS=12
AUTOPSY_ROWS=12
ERRORS=0
INDEPENDENT_ROOT_REPLAY=PASS
```

## 2. Exact R36 regression
The uncorrected R36 shell is reproduced exactly:

| quantity | count |
|---|---:|
| source coarse architectures | 753,662 |
| F11 configurations | 8,922,022 |
| square discriminants | 297 |
| raw integer MASTER/sphere roots | 12 |
| selector-consistent roots | 0 |

The 12 split as 6 `g0 does not divide P1` and 6 `mu does not divide r`.

## 3. Same shell with primitive g0 allocation restored
Restoring the R31/R28 necessary condition \(g_0\mid AW\), while keeping the same R36 source superset, gives:

| quantity | count |
|---|---:|
| source coarse architectures | 753,662 |
| prefilter input configs | 8,922,022 |
| pre-discriminant normalized rejects | 5,601,083 |
| square discriminants after prefilter | 73 |
| raw integer roots | 2 |
| selector-consistent roots | 0 |

The two remaining raw roots are exactly the t=1 representatives of F_A and F_B: one fails \(g_0\mid P_1\), the other fails \(\mu\mid r\).

## 4. Production shape + normalized expansion, n2=2,n3=1
With full shape gcd `(A,W)=1` and the primitive `g0 | AW` prefilter, q=1 through \(u_0\le60\) gives:

```text
source=1,768,988
configs=25,929,293
pre-normalized-reject=18,393,251
disc_sq=30
raw_integer_roots=1
selector_consistent=0
post_basic=0
simultaneous=0
```

The sole raw root is
\[
(u_0,\Lambda,A,W,C_2,C_3,\mu,g_0,a)=(3,5,1,1,58,9,5,1,3),
\]
\[
(P_1,P_2,P_3,Q_0)=(18,174,27,177),
\]
and it dies deterministically because \(r=18\) but \(5\nmid18\).

## 5. Nonunit stress in the same exponent cell
Prescribed one-digit residual scales q=2,3,5,7, all with \(u_0\le60\):

| q | source | configs | square discriminants | raw integer roots | selector-consistent |
|---:|---:|---:|---:|---:|---:|
| 2 | 368,102 | 3,419,744 | 12 | 0 | 0 |
| 3 | 239,291 | 1,803,893 | 7 | 0 | 0 |
| 5 | 49,850 | 216,147 | 0 | 0 | 0 |
| 7 | 49,850 | 216,147 | 0 | 0 | 0 |

These are bounded stress lanes, not a global nonunit theorem.

## 6. New source digit cell n2=3,n3=1
For q=1, m2=m3=1, g=0, k=2, \(u_0\le20\), the complete source-coarse box gives

```text
source=5,912,791
configs=67,546,418
square_discriminants=40
raw_integer_roots=0
selector_consistent=0
post_basic=0
simultaneous=0
```

This lane was searched in a normalized superset using `(a,mu)=1`; because it already has zero raw roots, adding the stronger `g0 | AW` primitive prefilter cannot create a root.

## 7. Combined bounded evidence
Across the expanded production/stress lanes (excluding the duplicate uncorrected R36 regression), 99,131,642 exact normalized F11 configurations were inspected after source-coarse generation. No selector-consistent integer MASTER/sphere root was found.

This is a strong bounded saturation result. It is NOT promoted to a global extinction theorem.
''')

W('105-R37-corrected-simultaneous-locus-analysis.md',r'''
# 105-R37 — Corrected Simultaneous-Locus Analysis

R36 freezes
\[
\mathscr T=\{\mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-\bar b_1D<Q_0\}
\]
with
\[
\mathscr T=\mathscr T_1\sqcup\mathscr T_+.
\]
R37 does not alter this definition.

The normalized generator reaches no selector-consistent integer MASTER/sphere root in any executed production lane. Therefore no architecture reaches the later denominator gates, and the R37 corrected simultaneous registry is empty.

Exact bounded statement:
\[
\boxed{\mathscr T\cap\mathscr B_{R37}=\varnothing,}
\]
where \(\mathscr B_{R37}\) is the explicit union of the searched cells documented in `105-R37-corrected-source-first-search.md`.

Global statement:

```text
GCD_NORMALIZED_SIMULTANEOUS_LOCUS_EXTINCTION=NOT_PROVED
CORRECTED_SIMULTANEOUS_POINT_FOUND=NO
```

No certificate claiming global \(\mathscr T=\varnothing\) is generated.
''')

W('105-R37-terminal-pair-entry.md',r'''
# 105-R37 — Terminal Pair Entry

The frozen rule is unchanged: once \(\mathfrak a\in\mathscr T\), set
\[
Q_*=\min(Q_+,Q_{master}),
\]
and search exactly
\[
q\in[Q_-,Q_*]\cap\mathbb Z_{>0},\qquad(q,FU)=1.
\]
On \(\mathscr T_1\), q=1 gives an immediate terminal-positive pair.

R37 produced no selector-consistent architecture in \(\mathscr T\). Hence terminal rectangle enumeration was not triggered and the terminal-pair registry is empty.

```text
MASTER_REFINED_TERMINAL_POSITIVE=NO
GENUINE_TERMINAL_PAIR_FOUND=NO
```

These are execution facts for R37, not global impossibility theorems.
''')

W('105-R37-full-reconstruction-audit.md',r'''
# 105-R37 — Full Reconstruction Audit

No terminal pair was produced, so positive-instance reconstruction of original Strict-(A1) was not triggered.

The frozen documentary chain remains:
\[
\text{R26 finite predicate}\iff\text{full Strict-(A1) lift},
\]
with R30 replacing TC3/TC4 by its exact terminal count and R35/R36 refining the denominator cutoff/simultaneous locus. R37 changes only the selector parameterization before root acceptance; it does not add or remove a downstream semantic gate.

The normalized identities are exact rewrites:
\[
u_0AW=g_0a,\quad P_1=g_0\mu s,\quad(a,\mu s)=1,
\]
\[
\bar b_1=\frac{\Lambda a}{\mu},
\]
\[
a10^{m+n+g}D=\mu(WT+A10^nH).
\]
Thus no reverse-map bug was introduced by normalization.

```text
R37_RECONSTRUCTION_TRIGGERED=NO
R37_HIDDEN_NEW_GATE_FOUND=NO
R37_ARCHITECTURE_REPAIR=R36_G0_GENERATOR_RELAXATION_REMOVED
```
''')

# Search stats included in stage archive and saturation certificate.
W('105-R37-GCD-NORMALIZED-SATURATION-CERTIFICATE.md',r'''
# 105-R37 — GCD-Normalized Saturation Certificate

## Certified exact gains
1. The selector identity is exactly parameterized by
   \[
   u_0AW=g_0a,\quad P_1=g_0\mu s,\quad(a,\mu s)=1.
   \]
2. Frozen primitivity strengthens this to
   \[
   g_0\mid AW,\quad a=u_0(AW/g_0).
   \]
3. R36's source-first script is identified as a relaxed-generator regression: it enumerated `g0 | u0AW`, whereas the earlier R31 architecture-first generator used `g0 | AW`.
4. The R36 twelve-root shell is reproduced exactly and then corrected. The 12 roots reduce to two raw roots after `g0 | AW`; both are selector-inconsistent, and full shape removes one of them.
5. The twelve R36 roots are not twelve primitive geometries: they lie on the single primitive sphere ray \((6,58,9,59)\).
6. The expanded n2=2,n3=1 raw locus through u0<=60 adds only one further primitive ray, \((14,138,9,139)\), and it is also selector-inconsistent.
7. The normalized F11 quadratic and discriminant are g0-free, and selector consistency is isolated as the exact normalized root-numerator divisibility gate
   \[
   \mu g_0(B_N^2-L_N^2)\mid C_NL_N\pm B_N\sqrt{\delta_{norm}}.
   \]
8. 99,131,642 exact expanded/stress F11 configurations were checked; zero selector-consistent integer roots were found.

## What is NOT certified
No proof quantifies over all exponent/source cells. Therefore none of the following is signed:

```text
SELECTOR_CONSISTENCY_EXTINCTION=YES
GCD_NORMALIZED_SIMULTANEOUS_LOCUS_EXTINCTION=YES
STRICT_A1_UNLIFTABILITY_PROVED=YES
```

## Unique surviving mathematical object
R38 is not licensed to return to fake selectors, raw F11 census, or generic simultaneous incidence. The remaining object is the **global normalized root-numerator divisibility/coprimality incidence**:
\[
\delta_{norm}=R^2,
\]
\[
\mathcal A_N=B_N^2-L_N^2,
\]
\[
\mu g_0\mathcal A_N\mid E_\pm:=C_NL_N\pm B_NR,
\]
\[
P_1=E_\pm/\mathcal A_N,
\]
\[
g_0\mid AW,\qquad \gcd\left(u_0AW/g_0,P_1/g_0\right)=1,
\]
together with the full frozen source completion. Any R38 attack should close this divisibility object globally or produce its first genuine solution; another bounded raw-discriminant census would not be new mathematics.

## Verdict
```text
R37_GCD_NORMALIZED_SATURATION_CERTIFICATE=YES
R37_TERMINAL_ATTACK_FAILED
```
''')

W('105-R37-stage-archive.md',r'''
# 105-R37 Stage Archive

**Project:** 三项十进制拼接平方和问题  
**Layer:** Strict Layer — (A1)-only  
**Round:** 105-R37  
**Arithmetic:** exact integers only

# Part I — FILE / HASH AUDIT
R36's SHA-256 manifest was read as the authoritative byte-hash ledger. File Library references are not mounted as local bytes in this runtime, so R36 input verification is explicitly recorded as `LEDGER-CROSSCHECK`, not falsely labeled bytewise recomputation. The full twelve-root registry and the R36 source-first generator were separately read and replayed. R37-created files are hashed bytewise locally.

See `105-R37-input-hash-audit.csv` and `105-R37-SHA256-MANIFEST.txt`.

# Part II — GCD-NORMALIZED COORDINATES
Exact equivalence:
\[
\boxed{g_0=(u_0AW,P_1)}
\iff
\boxed{u_0AW=g_0a,\ P_1=g_0r,\ (a,r)=1}.
\]
Because \(g_1^*=\mu g_0\mid P_1\),
\[
\boxed{r=\mu s,\qquad(a,\mu s)=1.}
\]
No condition \((\mu,s)=1\) is added.

Frozen primitivity gives \((u_0,P_1)=1\), hence the stronger production identity
\[
\boxed{g_0=(AW,P_1),\quad g_0\mid AW,\quad a=u_0\alpha,\quad \alpha=AW/g_0.}
\]
This exposes the R36 generator regression: R31 had enumerated \(g_0\mid AW\), while R36 relaxed to \(g_0\mid u_0AW\).

# Part III — TWELVE-ROOT AUTOPSY
The twelve R36 roots collapse to one primitive ray
\[
\boxed{(6,58,9,59)}.
\]
They split into two exact scaling templates:

- F_A(t): \(g_{0,sel}=25t\), \(P_1=90t\), so \(P_1/g_{0,sel}=18/5\notin\mathbb Z\). Six roots die at `g0 does not divide P1`.
- F_B(t): \(g_{0,sel}=t\), \(P_1=18t\), \(r=18\), \(\mu=5\), so \(\mu\nmid r\). Six roots die at `g1star does not divide P1`; here \((a,r)=3\).

Therefore the prompt's proposed universal integer mismatch gcd does not exist across all 12; half die before \(r\) exists.

# Part IV — NORMALIZED MASTER / SPHERE SYSTEM
With \(\Lambda=\mu\ell\), \(\ell=\tau\),
\[
\boxed{\bar b_1=\ell a},
\]
and MASTER becomes
\[
\boxed{a10^{m+n+g}D=\mu(WT+A10^nH)}.
\]
For
\[
L_N=aXYGK,
\]
\[
B_N=\mu(W+AYG)+aXYG,
\]
\[
C_N=\mu(WP_3+AYP_2),
\]
TC1+sphere is
\[
\boxed{(B_N^2-L_N^2)Q_0^2-2B_NC_NQ_0+C_N^2+L_N^2(P_2^2+P_3^2)=0.}
\]

# Part V — NORMALIZED DISCRIMINANT
\[
\boxed{\Delta_{norm}=4L_N^2\delta_{norm}},
\]
\[
\boxed{\delta_{norm}=C_N^2+(L_N^2-B_N^2)(P_2^2+P_3^2)}.
\]
If \(R^2=\delta_{norm}\), then
\[
Q_0=\frac{B_NC_N\pm L_NR}{B_N^2-L_N^2},
\]
\[
P_1=\frac{C_NL_N\pm B_NR}{B_N^2-L_N^2}.
\]
The true selector gate after the square condition is
\[
\boxed{\mu g_0(B_N^2-L_N^2)\mid C_NL_N\pm B_NR}
\]
plus \(\gcd(a,P_1/g_0)=1\). No global factorization proving this impossible was found.

# Part VI — SOURCE-FIRST NORMALIZED GENERATOR
The old R36 shell was reproduced exactly: 753,662 source coarse architectures, 8,922,022 F11 configurations, 297 square discriminants, 12 raw integer roots.

Correcting only the primitive \(g_0\mid AW\) allocation reduces the same shell to 73 square discriminants and 2 raw roots, with 0 selector-consistent roots. Adding full shape leaves only the F_B(1) raw root; it dies at \(\mu=5\nmid18\).

Expanded exact searches:

- q=1, (n2,n3)=(2,1), u0<=60: 25,929,293 configs; 30 squares after primitive prefilter; 1 raw root; 0 selector-consistent.
- q=2: 3,419,744 configs; 12 squares; 0 raw roots.
- q=3: 1,803,893 configs; 7 squares; 0 raw roots.
- q=5: 216,147 configs; 0 squares.
- q=7: 216,147 configs; 0 squares.
- q=1, (n2,n3)=(3,1), u0<=20: 67,546,418 configs; 40 squares; 0 raw roots.

Across expanded/stress lanes: 99,131,642 exact F11 configurations and zero selector-consistent roots.

# Part VII — CORRECTED SIMULTANEOUS LOCUS
No selector-consistent root reached post-basic legal, hence no searched architecture entered
\[
\mathscr T=\{\mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-\bar b_1D<Q_0\}.
\]
Bounded result: \(\mathscr T\cap\mathscr B_{R37}=\varnothing\). Global \(\mathscr T=\varnothing\) is NOT proved.

# Part VIII — TERMINAL RECTANGLE
Not triggered. No terminal pair exists in the R37 registries.

# Part IX — FULL RECONSTRUCTION
Not triggered because no terminal pair exists. The frozen documentary iff remains consistent; normalization introduced no hidden gate.

# Part X — FIFTEEN REQUIRED ANSWERS
1. Natural parameterization: \(M_0=g_0a,P_1=g_0\mu s,(a,\mu s)=1\); primitive strengthening \(g_0\mid AW,a=u_0AW/g_0\).
2. Yes, \(g_0=(M_0,P_1)\) is strictly equivalent to \(M_0=g_0a,P_1=g_0r,(a,r)=1\).
3. Yes, \(g_1^*=\mu g_0\mid P_1\) gives exactly \(r=\mu s\). No \((\mu,s)=1\) theorem.
4. Yes, base \(\bar b_1=\Lambda a/\mu=\tau a\).
5. Twelve roots: six have nonintegral \(r=P_1/g_0\); six have integral \(r=18\) but \(5\nmid18\).
6. No universal integer \((a,r)>1\) across all twelve; only the second family has \((3,18)=3\).
7. R36 twelve roots have one primitive sphere ray and two selector templates. The expanded n2=2,n3=1 raw locus has two primitive rays. Global finiteness of root templates is NOT proved.
8. Exact normalized discriminant is the \(\Delta_{norm}\) formula in Part V.
9. Square discriminant forcing selector mismatch is NOT proved globally; the exact stronger unresolved object is root-numerator divisibility.
10. No genuine selector-consistent integer root was found in the normalized searches. Raw roots exist but are rejected before legal root acceptance.
11. Post-basic legal roots: 0.
12. Corrected simultaneous locus points: 0 in searched cells; global emptiness not proved.
13. Genuine terminal pair: none.
14. Full original Strict-(A1) reconstruction: not triggered.
15. If 105 had to stop today, the last surviving object is the global normalized root-numerator divisibility/coprimality incidence (NRDG) on the full frozen source-complete cells, not a fake-selector or raw-discriminant locus.

# TERMINAL VERDICT
```text
GCD_NORMALIZATION_EQUIVALENCE=YES
R36_FAKE_G0_GENERATOR_REGRESSION=LOCATED_AND_FIXED
R36_CORRECTED_SHELL_SELECTOR_CONSISTENT_ROOTS=0
EXPANDED_R37_SELECTOR_CONSISTENT_ROOTS=0
SELECTOR_CONSISTENCY_EXTINCTION=NOT_PROVED
GCD_NORMALIZED_SIMULTANEOUS_LOCUS_EXTINCTION=NOT_PROVED
GENUINE_SELECTOR_CONSISTENT_SOURCE_MASTER_ROOT=NO_IN_SEARCHED_CELLS
MASTER_REFINED_TERMINAL_POSITIVE=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
R37_GCD_NORMALIZED_SATURATION_CERTIFICATE=YES
R37_TERMINAL_ATTACK_FAILED
```

No global extinction certificate and no witness certificate are generated, because neither theorem was proved.
''')

# Execution log summarizes all actual runtime work.
logs=[]
for fn in ['r37-normalized-search-stdout.log','r37-normalized-search-time.log','r37-primitive-search-stdout.log','r37-primitive-search-time.log','r37-n31-time.log','r37-root-replay-verify.log','r37-symbolic-families.log']:
    p=R/fn
    if p.exists(): logs.append(f'===== {fn} =====\n'+p.read_text(encoding='utf-8',errors='replace').strip())
W('105-R37-execution.log','''
105-R37 exact execution log

'''+'\n\n'.join(logs)+'''\n
VERIFICATION MODES:
- R36 frozen hashes: LEDGER-CROSSCHECK from authoritative R36 manifest.
- R37 outputs: local bytewise SHA-256.
- Root equations: independent exact Python replay.
- Symbolic scaling families: SymPy exact polynomial identity checks.
''')

# Stage archive hash companion first.
stage=R/'105-R37-stage-archive.md'
(R/'105-R37-stage-archive.sha256.txt').write_text(f"{sha(stage)}  105-R37-stage-archive.md\n",encoding='utf-8')

# Saturation certificate hash companion.
cert=R/'105-R37-GCD-NORMALIZED-SATURATION-CERTIFICATE.md'
(R/'105-R37-GCD-NORMALIZED-SATURATION-CERTIFICATE.sha256.txt').write_text(f"{sha(cert)}  {cert.name}\n",encoding='utf-8')

# Manifest: hash all files except itself and any eventual archive package.
entries=[]
for p in sorted(R.rglob('*')):
    if not p.is_file(): continue
    rel=p.relative_to(R).as_posix()
    if rel in {'105-R37-SHA256-MANIFEST.txt','105-R37-artifacts.zip'}: continue
    entries.append((sha(p),p.stat().st_size,rel))
with (R/'105-R37-SHA256-MANIFEST.txt').open('w',encoding='utf-8') as f:
    f.write('# 105-R37 SHA-256 manifest\n# All entries below are bytewise hashes computed from local R37 runtime bytes.\n')
    for h,b,rel in entries:f.write(f'{h}  {rel}  # bytes={b}\n')

print('R37_ARTIFACT_BUILD=PASS')
print('FILES_HASHED',len(entries))
print('STAGE_SHA256',sha(stage))
print('CERT_SHA256',sha(cert))
