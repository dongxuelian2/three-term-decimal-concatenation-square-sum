#include <bits/stdc++.h>
using namespace std;
using i128 = __int128_t;
using u128 = __uint128_t;

static long long gcdll(long long a,long long b){ return std::gcd(a,b); }
static long long ceil_div(long long a,long long b){ return (a+b-1)/b; }
static vector<long long> divisors(long long n){ vector<long long>d; for(long long x=1;x*x<=n;x++) if(n%x==0){d.push_back(x); if(x*x!=n)d.push_back(n/x);} sort(d.begin(),d.end()); return d; }
static long long first_coprime(long long lo,long long hi,long long m){ for(long long u=lo;u<=hi;u++) if(gcdll(u,m)==1) return u; return -1; }
static u128 isqrt_u128(u128 op){
    u128 res=0;
    u128 one=((u128)1)<<126;
    while(one>op) one>>=2;
    while(one!=0){
        if(op>=res+one){ op-=res+one; res=(res>>1)+one; }
        else res>>=1;
        one>>=2;
    }
    return res;
}
static bool is_square_i128(i128 n, u128 &root){ if(n<0)return false; u128 un=(u128)n; root=isqrt_u128(un); return root*root==un; }
static string s128(i128 x){ if(x==0)return "0"; bool neg=x<0; u128 y=neg?(u128)(-x):(u128)x; string s; while(y){ int d=y%10; s.push_back('0'+d); y/=10;} if(neg)s.push_back('-'); reverse(s.begin(),s.end()); return s; }

struct Counts{
    unsigned long long source=0, configs=0, pre_gcd_rej=0, disc_sq=0, raw_roots=0,
        sel_g0rej=0, sel_murej=0, sel_gcdrej=0, sel_pass=0, post_basic=0, simultaneous=0;
};

struct LaneParams{ string name; int u0max; int qscale; bool shape; bool pre_gcd; };

static void write_header(ofstream &f){
 f<<"lane,u0,Lambda_candidate,q_scale,A,W,C2,C3,Ulo,Uhi,Umin,mu,M0,a,g0,P1,P2,P3,Q0,r,s,D,H,T3,actual_g0,primitive,lambda_z,Lambda_recovered,shape_pass,support_pass,post_basic_legal,Zminus,Zplus,Qminus,Qplus,b1,Qmaster,corrected_simultaneous,first_failure\n";
}

static Counts run_lane(const LaneParams &lp, ofstream &raw, ofstream &norm, ofstream &near){
 Counts c; const long long X=10,Y=10,G=1,K=10; int lammax=9/lp.qscale;
 for(int u0=1;u0<=lp.u0max;u0++){
  for(int Lam=1;Lam<=lammax;Lam++){
   int maxaw=9/(Lam*lp.qscale);
   auto muds=divisors(Lam);
   for(int A=1;A<=maxaw;A++) for(int W=1;W<=maxaw;W++){
    if(lp.shape && gcdll(A,W)!=1) continue;
    long long M0=1LL*u0*A*W; auto adivs=divisors(M0);
    for(int C2=2;C2<100;C2++){
     if(gcdll(1LL*Lam*A,C2)!=1) continue;
     long long ulo2=ceil_div(10,C2), uhi2=99/C2; if(ulo2>uhi2) continue;
     for(int C3=1;C3<10;C3++){
      if(gcdll(1LL*Lam*W,C3)!=1) continue;
      long long ulo=max<long long>({1,ulo2,ceil_div(1,C3)}), uhi=min<long long>(uhi2,9/C3); if(ulo>uhi) continue;
      long long V0=1LL*Lam*M0, umin=first_coprime(ulo,uhi,V0); if(umin<0) continue;
      c.source++;
      long long P2=1LL*u0*W*C2, P3=1LL*u0*A*C3;
      for(long long mu:muds) for(long long a:adivs){
       long long g0=M0/a; c.configs++;
       if(lp.pre_gcd && gcdll(a,mu)!=1){ c.pre_gcd_rej++; continue; }
       i128 Ln=(i128)a*X*Y*G*K;
       i128 Bn=(i128)mu*(W+A*Y*G)+(i128)a*X*Y*G;
       i128 Cn=(i128)mu*((i128)W*P3+(i128)A*Y*P2);
       i128 aa=Bn*Bn-Ln*Ln, bb=-2*Bn*Cn, cc=Cn*Cn+Ln*Ln*((i128)P2*P2+(i128)P3*P3);
       vector<i128> roots;
       if(aa==0){ if(bb!=0 && (-cc)%bb==0) roots.push_back((-cc)/bb); }
       else{
         i128 disc=bb*bb-4*aa*cc; u128 sd;
         if(!is_square_i128(disc,sd)) continue;
         c.disc_sq++;
         i128 den=2*aa; i128 ns[2]={-bb+(i128)sd,-bb-(i128)sd};
         for(i128 num:ns) if(den!=0 && num%den==0){ i128 q0=num/den; if(q0>0) roots.push_back(q0); }
       }
       sort(roots.begin(),roots.end()); roots.erase(unique(roots.begin(),roots.end()),roots.end());
       for(i128 Q0x:roots){
        i128 num=Bn*Q0x-Cn; if(num%Ln)continue; i128 P1x=num/Ln; if(P1x<=0)continue;
        if(P1x*P1x+(i128)P2*P2+(i128)P3*P3!=Q0x*Q0x)continue;
        if(P1x>LLONG_MAX || Q0x>LLONG_MAX) continue;
        long long P1=(long long)P1x,Q0=(long long)Q0x; c.raw_roots++;
        string fail; long long r=0,s=0;
        if(P1%g0){ c.sel_g0rej++; fail="G0_NOT_DIVIDING_P1"; }
        else { r=P1/g0; if(r%mu){ c.sel_murej++; fail="MU_NOT_DIVIDING_R"; }
          else {s=r/mu; if(gcdll(a,r)!=1){c.sel_gcdrej++; fail="GCD_A_R";} else {c.sel_pass++; fail="SELECTOR_PASS";} }
        }
        long long D=10*P1-Q0,H=Q0-P2,T3=Q0-P3, actual=gcdll(M0,P1);
        long long primc=gcdll(gcdll(gcdll(P1,P2),P3),Q0); bool primitive=(primc==1);
        long long lamz=(T3>0?10/gcdll(10,1LL*W*T3):0); bool lrec=(T3>0 && std::lcm((long long)mu,lamz)==Lam);
        bool shp=(gcdll(A,C2)==1&&gcdll(W,C3)==1&&gcdll(A,W)==1); bool support=(lrec&&gcdll(Lam,1LL*C2*C3)==1);
        bool sel=(fail=="SELECTOR_PASS"); bool post=(sel&&D>0&&H>0&&T3>0&&actual==g0&&P1%(mu*g0)==0&&primitive&&shp&&support);
        long long Zm=0,Zp=0,Qm=0,Qp=0,b1=0,Qmaster=-1; bool sim=false;
        if(post){ c.post_basic++; Zm=max(ceil_div(1,A),ceil_div(1,W)); Zp=min(9/A,9/W); Qm=ceil_div(Zm,Lam); Qp=Zp/Lam; b1=Lam*a/mu; Qmaster=(b1*D>0?(Q0-1)/(b1*D):-1); sim=(Qm<=Qp && (i128)Qm*b1*D<Q0); if(sim)c.simultaneous++; fail="POST_BASIC_LEGAL"; }
        else if(sel){ if(!primitive)fail="NONPRIMITIVE"; else if(D<=0)fail="D_NONPOSITIVE"; else if(H<=0)fail="H_NONPOSITIVE"; else if(T3<=0)fail="T3_NONPOSITIVE"; else if(!lrec)fail="LAMBDA_RECOVERY_MISMATCH"; else if(!shp)fail="SHAPE_GCD"; else if(!support)fail="SUPPORT_GCD"; else fail="POST_BASIC_OTHER"; }
        auto emit=[&](ofstream &f){
          f<<lp.name<<','<<u0<<','<<Lam<<','<<lp.qscale<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<ulo<<','<<uhi<<','<<umin<<','<<mu<<','<<M0<<','<<a<<','<<g0<<','<<P1<<','<<P2<<','<<P3<<','<<Q0<<',';
          if(r)f<<r; f<<','; if(s)f<<s; f<<','<<D<<','<<H<<','<<T3<<','<<actual<<','<<(primitive?1:0)<<','<<lamz<<','<<(lrec?1:0)<<','<<(shp?1:0)<<','<<(support?1:0)<<','<<(post?1:0)<<',';
          if(post)f<<Zm; f<<','; if(post)f<<Zp; f<<','; if(post)f<<Qm; f<<','; if(post)f<<Qp; f<<','; if(post)f<<b1; f<<','; if(post)f<<Qmaster; f<<','<<(sim?1:0)<<','<<fail<<'\n';
        };
        emit(raw); if(sel){ if(post)emit(norm); else emit(near); }
       }
      }
     }
    }
   }
  }
 }
 return c;
}

static void print_counts(const string &name,const Counts &c){
 cout<<name
 <<" source="<<c.source<<" configs="<<c.configs<<" pre_gcd_rej="<<c.pre_gcd_rej
 <<" disc_sq="<<c.disc_sq<<" raw_roots="<<c.raw_roots
 <<" sel_g0rej="<<c.sel_g0rej<<" sel_murej="<<c.sel_murej<<" sel_gcdrej="<<c.sel_gcdrej
 <<" sel_pass="<<c.sel_pass<<" post_basic="<<c.post_basic<<" simultaneous="<<c.simultaneous<<"\n";
}

int main(){
 string base="/mnt/data/105-R37/";
 ofstream raw(base+"105-R37-gcd-normalized-root-registry.csv"), norm(base+"105-R37-selector-consistent-source-registry.csv"), near(base+"105-R37-near-hit-registry.csv");
 write_header(raw);write_header(norm);write_header(near);
 vector<pair<LaneParams,Counts>> results;
 vector<LaneParams> lanes={
  {"R36_EXACT_REGRESSION",20,1,false,false},
  {"Q1_N21_U60_NORMALIZED",60,1,true,true},
  {"Q2_N21_U60_NORMALIZED",60,2,true,true},
  {"Q3_N21_U60_NORMALIZED",60,3,true,true},
  {"Q5_N21_U60_NORMALIZED",60,5,true,true},
  {"Q7_N21_U60_NORMALIZED",60,7,true,true}
 };
 for(auto &lp:lanes){ auto c=run_lane(lp,raw,norm,near); results.push_back({lp,c}); print_counts(lp.name,c); }
 ofstream js(base+"105-R37-search-summary.txt");
 for(auto &x:results){auto &p=x.first;auto &c=x.second; js<<p.name<<"|source="<<c.source<<"|configs="<<c.configs<<"|pre_gcd_rej="<<c.pre_gcd_rej<<"|disc_sq="<<c.disc_sq<<"|raw_roots="<<c.raw_roots<<"|sel_g0rej="<<c.sel_g0rej<<"|sel_murej="<<c.sel_murej<<"|sel_gcdrej="<<c.sel_gcdrej<<"|sel_pass="<<c.sel_pass<<"|post_basic="<<c.post_basic<<"|simultaneous="<<c.simultaneous<<"\n";}
}
