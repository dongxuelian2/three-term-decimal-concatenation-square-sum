#include <bits/stdc++.h>
using namespace std; using i128=__int128_t; using u128=__uint128_t;
static long long cd(long long a,long long b){return (a+b-1)/b;} static vector<long long> divs(long long n){vector<long long>d;for(long long x=1;x*x<=n;x++)if(n%x==0){d.push_back(x);if(x*x!=n)d.push_back(n/x);}sort(d.begin(),d.end());return d;}
static long long firstcop(long long l,long long h,long long m){for(long long x=l;x<=h;x++)if(gcd(x,m)==1)return x;return -1;}
static u128 isq(u128 n){u128 r=0,o=(u128)1<<126;while(o>n)o>>=2;while(o){if(n>=r+o){n-=r+o;r=(r>>1)+o;}else r>>=1;o>>=2;}return r;}
struct C{unsigned long long src=0,cfg=0,pre=0,ds=0,raw=0,g0r=0,mur=0,gr=0,sp=0,post=0,sim=0;};
int main(){
 const int n2=3,n3=1,m2=1,m3=1,g=0,k=2; const long long X=10,Y=10,G=1,K=100; const int u0max=20,qscale=1; C c;
 ofstream f("/mnt/data/105-R37/105-R37-n31-root-registry.csv"); f<<"u0,Lambda,A,W,C2,C3,Ulo,Uhi,Umin,mu,M0,a,g0,P1,P2,P3,Q0,r,s,primitive,lambda_z,Lambda_recovered,first_failure\n";
 for(int u0=1;u0<=u0max;u0++)for(int Lam=1;Lam<=9;Lam++){int maw=9/Lam;auto mus=divs(Lam);for(int A=1;A<=maw;A++)for(int W=1;W<=maw;W++){
  if(gcd(A,W)!=1)continue; long long M0=1LL*u0*A*W;auto as=divs(M0);
  for(int C2=2;C2<1000;C2++){if(gcd(1LL*Lam*A,C2)!=1)continue;long long l2=cd(100,C2),h2=999/C2;if(l2>h2)continue;
   for(int C3=1;C3<10;C3++){if(gcd(1LL*Lam*W,C3)!=1)continue;long long lo=max<long long>({1,l2,cd(1,C3)}),hi=min<long long>(h2,9/C3);if(lo>hi)continue;long long um=firstcop(lo,hi,1LL*Lam*M0);if(um<0)continue;c.src++;
    long long P2=1LL*u0*W*C2,P3=1LL*u0*A*C3;
    for(long long mu:mus)for(long long a:as){long long g0=M0/a;c.cfg++;if(gcd(a,mu)!=1){c.pre++;continue;}i128 L=(i128)a*X*Y*G*K,B=(i128)mu*(W+A*Y*G)+(i128)a*X*Y*G,Cc=(i128)mu*((i128)W*P3+(i128)A*Y*P2);i128 aa=B*B-L*L,bb=-2*B*Cc,cc=Cc*Cc+L*L*((i128)P2*P2+(i128)P3*P3);vector<i128>rr;
      if(aa==0){if(bb&&(-cc)%bb==0)rr.push_back((-cc)/bb);}else{i128 di=bb*bb-4*aa*cc;if(di<0)continue;u128 sd=isq((u128)di);if(sd*sd!=(u128)di)continue;c.ds++;i128 den=2*aa;for(i128 nu:{-bb+(i128)sd,-bb-(i128)sd})if(den&&nu%den==0&&nu/den>0)rr.push_back(nu/den);}sort(rr.begin(),rr.end());rr.erase(unique(rr.begin(),rr.end()),rr.end());
      for(i128 Qx:rr){i128 nu=B*Qx-Cc;if(nu%L)continue;i128 Px=nu/L;if(Px<=0||Px*Px+(i128)P2*P2+(i128)P3*P3!=Qx*Qx||Px>LLONG_MAX||Qx>LLONG_MAX)continue;c.raw++;long long P1=(long long)Px,Q=(long long)Qx,r=0,s=0;string fail;if(P1%g0){c.g0r++;fail="G0_NOT_DIVIDING_P1";}else{r=P1/g0;if(r%mu){c.mur++;fail="MU_NOT_DIVIDING_R";}else{s=r/mu;if(gcd(a,r)!=1){c.gr++;fail="GCD_A_R";}else{c.sp++;fail="SELECTOR_PASS";}}}long long pc=gcd(gcd(gcd(P1,P2),P3),Q);long long T=Q-P3,lz=T>0?10/gcd(10LL,1LL*W*T):0;bool lr=T>0&&lcm(mu,lz)==Lam;if(fail=="SELECTOR_PASS"){long long D=100*P1-Q,H=Q-P2;bool shp=gcd(A,C2)==1&&gcd(W,C3)==1&&gcd(A,W)==1;bool sup=lr&&gcd(1LL*Lam,C2*1LL*C3)==1;bool post=D>0&&H>0&&T>0&&pc==1&&shp&&sup&&gcd(M0,P1)==g0;if(post){c.post++;fail="POST_BASIC_LEGAL";long long b1=Lam*a/mu,Qm=1,Qp=min(9/A,9/W)/Lam;if(Qm<=Qp&&(i128)Qm*b1*D<Q)c.sim++;}else if(pc!=1)fail="NONPRIMITIVE";else if(!lr)fail="LAMBDA_RECOVERY_MISMATCH";else fail="POST_BASIC_OTHER";}
       f<<u0<<','<<Lam<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<lo<<','<<hi<<','<<um<<','<<mu<<','<<M0<<','<<a<<','<<g0<<','<<P1<<','<<P2<<','<<P3<<','<<Q<<',';if(r)f<<r;f<<',';if(s)f<<s;f<<','<<pc<<','<<lz<<','<<(lr?1:0)<<','<<fail<<'\n';
      }
    }
   }
  }
 }}
 cerr<<"N31_Q1_U20 source="<<c.src<<" configs="<<c.cfg<<" pre="<<c.pre<<" disc_sq="<<c.ds<<" raw="<<c.raw<<" g0rej="<<c.g0r<<" murej="<<c.mur<<" gcdrej="<<c.gr<<" selpass="<<c.sp<<" post="<<c.post<<" sim="<<c.sim<<"\n";
 ofstream s("/mnt/data/105-R37/105-R37-n31-search-summary.txt");s<<"N31_Q1_U20|source="<<c.src<<"|configs="<<c.cfg<<"|pre="<<c.pre<<"|disc_sq="<<c.ds<<"|raw="<<c.raw<<"|g0rej="<<c.g0r<<"|murej="<<c.mur<<"|gcdrej="<<c.gr<<"|selpass="<<c.sp<<"|post="<<c.post<<"|sim="<<c.sim<<"\n";
}
