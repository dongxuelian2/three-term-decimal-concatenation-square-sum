#!/usr/bin/env python3
import sympy as sp

t,j=sp.symbols('t j', integer=True, positive=True)

def check_family(name,u0,A,W,C2,C3,mu,g0,a,P1,P2,P3,Q0):
    X=Y=K=10; G=1
    Ln=a*X*Y*G*K
    Bn=mu*(W+A*Y*G)+a*X*Y*G
    Cn=mu*(W*P3+A*Y*P2)
    f=sp.expand((Bn**2-Ln**2)*Q0**2-2*Bn*Cn*Q0+Cn**2+Ln**2*(P2**2+P3**2))
    lin=sp.expand(Ln*P1-(Bn*Q0-Cn))
    sph=sp.expand(P1**2+P2**2+P3**2-Q0**2)
    print(name,'F11=',sp.factor(f),'TC1=',sp.factor(lin),'SPHERE=',sp.factor(sph))
    assert f==lin==sph==0

# R36 selector template A: one primitive ray, but g0sel does not divide P1.
check_family('F_A',3*t,5,5,58,9,1,25*t,3,90*t,870*t,135*t,885*t)
# R36 selector template B: same primitive ray, r=18 but mu=5 does not divide r.
check_family('F_B',3*t,1,1,58,9,5,t,3,18*t,174*t,27*t,177*t)
# Expanded second primitive ray, j=1,2 in the n2=2,n3=1 source digit cell.
check_family('F_C',21*t,1,1,46*j,3*j,5,3*t,7,98*j*t,966*j*t,63*j*t,973*j*t)

print('FA_r_sel=18/5; actual_g0=15*t; primitive_ray=(6,58,9,59)')
print('FB_r=18; mu=5 does_not_divide_18; actual_g0=3*t; primitive_ray=(6,58,9,59)')
print('FC_r=98*j/3; for j in {1,2} nonintegral; actual_g0=7*t; primitive_ray=(14,138,9,139)')
print('SYMBOLIC_FAMILY_IDENTITIES=PASS')
