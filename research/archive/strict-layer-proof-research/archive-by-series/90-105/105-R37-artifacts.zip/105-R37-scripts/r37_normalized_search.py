#!/usr/bin/env python3
from math import gcd, isqrt, lcm
from csv import DictWriter
from json import dump
from pathlib import Path
from collections import Counter

OUT=Path('/mnt/data/105-R37')
OUT.mkdir(parents=True, exist_ok=True)

R36_ROWS = [
 dict(index=0,u0=3,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=75,mu=1,g0_selector=25,g1star=25,P1=90,P2=870,P3=135,Q0=885,D=15,H=15,T3=750,lambda_z=1,actual_g0=15),
 dict(index=1,u0=3,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=15,mu=5,g0_selector=1,g1star=5,P1=18,P2=174,P3=27,Q0=177,D=3,H=3,T3=150,lambda_z=1,actual_g0=3),
 dict(index=2,u0=6,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=150,mu=1,g0_selector=50,g1star=50,P1=180,P2=1740,P3=270,Q0=1770,D=30,H=30,T3=1500,lambda_z=1,actual_g0=30),
 dict(index=3,u0=6,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=30,mu=5,g0_selector=2,g1star=10,P1=36,P2=348,P3=54,Q0=354,D=6,H=6,T3=300,lambda_z=1,actual_g0=6),
 dict(index=4,u0=9,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=225,mu=1,g0_selector=75,g1star=75,P1=270,P2=2610,P3=405,Q0=2655,D=45,H=45,T3=2250,lambda_z=1,actual_g0=45),
 dict(index=5,u0=9,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=45,mu=5,g0_selector=3,g1star=15,P1=54,P2=522,P3=81,Q0=531,D=9,H=9,T3=450,lambda_z=1,actual_g0=9),
 dict(index=6,u0=12,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=300,mu=1,g0_selector=100,g1star=100,P1=360,P2=3480,P3=540,Q0=3540,D=60,H=60,T3=3000,lambda_z=1,actual_g0=60),
 dict(index=7,u0=12,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=60,mu=5,g0_selector=4,g1star=20,P1=72,P2=696,P3=108,Q0=708,D=12,H=12,T3=600,lambda_z=1,actual_g0=12),
 dict(index=8,u0=15,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=375,mu=1,g0_selector=125,g1star=125,P1=450,P2=4350,P3=675,Q0=4425,D=75,H=75,T3=3750,lambda_z=1,actual_g0=75),
 dict(index=9,u0=15,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=75,mu=5,g0_selector=5,g1star=25,P1=90,P2=870,P3=135,Q0=885,D=15,H=15,T3=750,lambda_z=1,actual_g0=15),
 dict(index=10,u0=18,Lambda=1,A=5,W=5,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=450,mu=1,g0_selector=150,g1star=150,P1=540,P2=5220,P3=810,Q0=5310,D=90,H=90,T3=4500,lambda_z=1,actual_g0=90),
 dict(index=11,u0=18,Lambda=5,A=1,W=1,C2=58,C3=9,Ulo=1,Uhi=1,Umin=1,V0=90,mu=5,g0_selector=6,g1star=30,P1=108,P2=1044,P3=162,Q0=1062,D=18,H=18,T3=900,lambda_z=1,actual_g0=18),
]

def divisors(n):
    ds=[]
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            ds.append(d)
            if d*d!=n: ds.append(n//d)
    return sorted(ds)

def ceil_div(a,b): return (a+b-1)//b

def first_coprime(lo,hi,m):
    for u in range(lo,hi+1):
        if gcd(u,m)==1: return u
    return None

def digitlen(n): return len(str(n))

def write_csv(path, rows, fields):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

# 1. Exact twelve-root autopsy with rational r_sel represented by numerator/denominator.
aut=[]
for row in R36_ROWS:
    M0=row['u0']*row['A']*row['W']
    gs=row['g0_selector']; P1=row['P1']; mu=row['mu']
    assert M0%gs==0
    a=M0//gs
    d=gcd(P1,gs)
    r_num=P1//d; r_den=gs//d
    r_integral=(r_den==1)
    if r_integral:
        r=r_num
        ar_gcd=gcd(a,r)
        mu_div_r=(r%mu==0)
        s_num=r//gcd(r,mu); s_den=mu//gcd(r,mu)
    else:
        r=None; ar_gcd='NA'; mu_div_r=False
        # s=P1/(g0*mu), reduced
        den=gs*mu; dd=gcd(P1,den); s_num=P1//dd; s_den=den//dd
    primitive_g=gcd(gcd(gcd(row['P1'],row['P2']),row['P3']),row['Q0'])
    if not r_integral:
        normalized_reject='G0_SELECTOR_NOT_DIVIDING_P1'
    elif not mu_div_r:
        normalized_reject='MU_NOT_DIVIDING_R__G1STAR_NOT_DIVIDING_P1'
    elif ar_gcd!=1:
        normalized_reject='COPRIMALITY_FAIL_GCD_A_R'
    else:
        normalized_reject='SELECTOR_SEMANTICS_PASS'
    family='F_A' if row['Lambda']==1 else 'F_B'
    t=row['u0']//3
    aut.append({
        'index':row['index'],'family':family,'t':t,'u0':row['u0'],'Lambda':row['Lambda'],'A':row['A'],'W':row['W'],
        'mu':mu,'M0':M0,'g0_selector':gs,'actual_g0':row['actual_g0'],'P1':P1,
        'a_sel':a,'r_sel_num':r_num,'r_sel_den':r_den,'r_sel_integral':int(r_integral),
        'gcd_a_r_if_integral':ar_gcd,'mu_divides_r':int(mu_div_r),
        's_sel_num':s_num,'s_sel_den':s_den,
        'g1star':row['g1star'],'g1star_divides_P1':int(P1%row['g1star']==0),
        'primitive_content':primitive_g,'normalized_reject':normalized_reject,
        'root_acceptance':'REJECT'
    })
aut_fields=list(aut[0].keys())
write_csv(OUT/'105-R37-twelve-root-autopsy.csv',aut,aut_fields)
write_csv(OUT/'105-R37-r36-fake-root-regression.csv',aut,aut_fields)

# 2. Generic normalized F11 runner for n2=2,n3=1,m2=m3=1,g=0,k=1 bounded shells.
def run_n21_lane(name,u0_max,q_scale=1, production_shape=True):
    # q_scale controls forced denominator one-digit condition: A*Lambda*q,W*Lambda*q <=9.
    # Root equation itself depends only on recovered m2=m3=1,g=0,k=1.
    counts=Counter()
    raw_roots=[]; norm_roots=[]; near=[]
    X=10;Y=10;G=1;K=10
    lam_max=9//q_scale
    for u0 in range(1,u0_max+1):
      for Lam in range(1,lam_max+1):
        maxaw=9//(Lam*q_scale)
        for A in range(1,maxaw+1):
          for W in range(1,maxaw+1):
            if production_shape and gcd(A,W)!=1:
                continue
            M0=u0*A*W
            adivs=divisors(M0)  # a | M0; g0=M0/a
            muds=divisors(Lam)
            for C2 in range(2,100):
              if gcd(Lam*A,C2)!=1: continue
              ulo2=ceil_div(10,C2); uhi2=99//C2
              if ulo2>uhi2: continue
              for C3 in range(1,10):
                if gcd(Lam*W,C3)!=1: continue
                ulo=max(1,ulo2,ceil_div(1,C3)); uhi=min(uhi2,9//C3)
                if ulo>uhi: continue
                V0=Lam*M0
                umin=first_coprime(ulo,uhi,V0)
                if umin is None: continue
                counts['source_coarse_pass']+=1
                P2=u0*W*C2; P3=u0*A*C3
                for mu in muds:
                  for a in adivs:
                    g0=M0//a
                    counts['normalized_f11_configs']+=1
                    if gcd(a,mu)!=1:
                        counts['pre_disc_gcd_a_mu_reject']+=1
                        continue
                    Ln=a*X*Y*G*K
                    Bn=mu*(W+A*Y*G)+a*X*Y*G
                    Cn=mu*(W*P3+A*Y*P2)
                    aa=Bn*Bn-Ln*Ln; bb=-2*Bn*Cn; cc=Cn*Cn+Ln*Ln*(P2*P2+P3*P3)
                    roots=[]
                    if aa==0:
                        if bb!=0 and (-cc)%bb==0: roots=[(-cc)//bb]
                    else:
                        disc=bb*bb-4*aa*cc
                        if disc<0: continue
                        sd=isqrt(disc)
                        if sd*sd!=disc: continue
                        counts['master_discriminant_square']+=1
                        den=2*aa
                        for num in (-bb+sd,-bb-sd):
                            if den and num%den==0:
                                q0=num//den
                                if q0>0: roots.append(q0)
                    for Q0 in sorted(set(roots)):
                        num=Bn*Q0-Cn
                        if num%Ln: continue
                        P1=num//Ln
                        if P1<=0: continue
                        if P1*P1+P2*P2+P3*P3!=Q0*Q0: continue
                        counts['raw_integer_master_sphere_root']+=1
                        rec={'lane':name,'u0':u0,'Lambda_candidate':Lam,'q_scale':q_scale,'A':A,'W':W,'C2':C2,'C3':C3,'Ulo':ulo,'Uhi':uhi,'Umin':umin,'mu':mu,'M0':M0,'a':a,'g0':g0,'P1':P1,'P2':P2,'P3':P3,'Q0':Q0}
                        # From-birth normalized semantics at root acceptance.
                        if P1%g0:
                            counts['selector_reject_g0_not_dividing_P1']+=1; rec['first_failure']='G0_NOT_DIVIDING_P1'; raw_roots.append(rec); continue
                        r=P1//g0
                        if r%mu:
                            counts['selector_reject_mu_not_dividing_r']+=1; rec.update(r=r,first_failure='MU_NOT_DIVIDING_R'); raw_roots.append(rec); continue
                        s=r//mu
                        if gcd(a,r)!=1:
                            counts['selector_reject_gcd_a_r']+=1; rec.update(r=r,s=s,first_failure='GCD_A_R'); raw_roots.append(rec); continue
                        counts['normalized_selector_semantics_pass']+=1
                        D=10*P1-Q0; H=Q0-P2; T3=Q0-P3
                        actual=gcd(M0,P1)
                        prim=gcd(gcd(gcd(P1,P2),P3),Q0)==1
                        lamz=10//gcd(10,W*T3) if T3>0 else 0
                        lrec=(T3>0 and lcm(mu,lamz)==Lam)
                        shape=(gcd(A,C2)==1 and gcd(W,C3)==1 and gcd(A,W)==1)
                        support=(lrec and gcd(Lam,C2*C3)==1)
                        post=(D>0 and H>0 and T3>0 and actual==g0 and P1%(mu*g0)==0 and prim and shape and support)
                        rec.update(r=r,s=s,D=D,H=H,T3=T3,actual_g0=actual,primitive=int(prim),lambda_z=lamz,Lambda_recovered=int(lrec),shape_pass=int(shape),support_pass=int(support),post_basic_legal=int(post))
                        if post:
                            counts['post_basic_legal']+=1; rec['first_failure']='POST_BASIC_LEGAL'
                            # denominator window/cutoff for corrected simultaneous classification
                            Zm=max(ceil_div(1,A),ceil_div(1,W))
                            Zp=min(9//A,9//W)
                            Qm=ceil_div(Zm,Lam); Qp=Zp//Lam
                            b1=(Lam*a)//mu
                            Qmaster=(Q0-1)//(b1*D) if b1*D>0 else -1
                            rec.update(Zminus=Zm,Zplus=Zp,Qminus=Qm,Qplus=Qp,b1=b1,Qmaster=Qmaster)
                            sim=(Qm<=Qp and Qm*b1*D<Q0)
                            rec['corrected_simultaneous']=int(sim)
                            if sim: counts['corrected_simultaneous']+=1
                            norm_roots.append(rec)
                        else:
                            if not prim: rec['first_failure']='NONPRIMITIVE'
                            elif D<=0: rec['first_failure']='D_NONPOSITIVE'
                            elif H<=0: rec['first_failure']='H_NONPOSITIVE'
                            elif T3<=0: rec['first_failure']='T3_NONPOSITIVE'
                            elif not lrec: rec['first_failure']='LAMBDA_RECOVERY_MISMATCH'
                            elif not shape: rec['first_failure']='SHAPE_GCD'
                            elif not support: rec['first_failure']='SUPPORT_GCD'
                            else: rec['first_failure']='POST_BASIC_OTHER'
                            near.append(rec)
                        raw_roots.append(rec)
    return counts,raw_roots,norm_roots,near

# Exact regression reproduces R36 superset: no A/W shape pruning, u0<=20,q=1.
reg_counts,reg_raw,reg_norm,reg_near=run_n21_lane('R36_EXACT_REGRESSION',20,1,production_shape=False)
# Production expansion: from-birth shape + selector semantics; larger u0 q=1.
exp_counts,exp_raw,exp_norm,exp_near=run_n21_lane('Q1_N21_U60_NORMALIZED',60,1,production_shape=True)
# Nonunit stress: prescribed one-digit q scales 2,3,5,7, u0<=60, same n2=2,n3=1 exponent cell.
smallq_results={}
for q in (2,3,5,7):
    smallq_results[q]=run_n21_lane(f'Q{q}_N21_U60_NORMALIZED',60,q,production_shape=True)

# Combine registries.
all_raw=reg_raw+exp_raw
all_norm=reg_norm+exp_norm
all_near=reg_near+exp_near
for q,(c,rr,nr,nn) in smallq_results.items():
    all_raw += rr; all_norm += nr; all_near += nn

root_fields=sorted({k for r in all_raw for k in r}) if all_raw else ['lane']
write_csv(OUT/'105-R37-gcd-normalized-root-registry.csv',all_raw,root_fields)
sel_fields=sorted({k for r in all_norm for k in r}) if all_norm else root_fields
write_csv(OUT/'105-R37-selector-consistent-source-registry.csv',all_norm,sel_fields)
near_fields=sorted({k for r in all_near for k in r}) if all_near else root_fields
write_csv(OUT/'105-R37-near-hit-registry.csv',all_near,near_fields)

summ={
 'r36_regression':dict(reg_counts),
 'q1_expanded_u60':dict(exp_counts),
 'smallq':{str(q):dict(v[0]) for q,v in smallq_results.items()},
 'notes':{
  'arithmetic':'exact integers only',
  'regression_scope':'R36 source-first regular generic superset, n2=2,n3=1,m2=m3=1,g=0,k=1,u0<=20,Lambda<=9,C2=2..99,C3=1..9',
  'expanded_scope':'same exponent/source cell, production shape gcd enforced, q=1 u0<=60; prescribed q=2,3,5,7 u0<=60 with one-digit denominator cell',
  'global_inference':False
 }
}
with (OUT/'105-R37-search-summary.json').open('w',encoding='utf-8') as f: dump(summ,f,indent=2,sort_keys=True)

# Empty downstream registries created explicitly if no normalized roots reach them.
for fn,fields in [
 ('105-R37-corrected-simultaneous-registry.csv',['lane','status','reason']),
 ('105-R37-terminal-pair-registry.csv',['lane','status','reason']),
 ('105-R37-reconstruction-registry.csv',['lane','status','reason']),
 ('105-R37-counterexample-registry.csv',['lane','status','reason'])]:
    rows=[]
    if fn=='105-R37-corrected-simultaneous-registry.csv':
        for r in all_norm:
            if r.get('corrected_simultaneous')==1: rows.append({k:r.get(k,'') for k in fields})
    write_csv(OUT/fn,rows,fields)

print('REG',dict(reg_counts),'raw',len(reg_raw),'norm',len(reg_norm),'near',len(reg_near))
print('EXP',dict(exp_counts),'raw',len(exp_raw),'norm',len(exp_norm),'near',len(exp_near))
for q,(c,rr,nr,nn) in smallq_results.items(): print('Q',q,dict(c),'raw',len(rr),'norm',len(nr),'near',len(nn))
