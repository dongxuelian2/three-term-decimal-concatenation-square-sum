#!/usr/bin/env python3
import csv, math, sys
from pathlib import Path
ROOT=Path('/mnt/data/105-R37')
rows=list(csv.DictReader((ROOT/'105-R37-gcd-normalized-root-registry.csv').open()))

expected_reg={
(3,1,5,5,58,9,1,25,90,870,135,885),(3,5,1,1,58,9,5,1,18,174,27,177),
(6,1,5,5,58,9,1,50,180,1740,270,1770),(6,5,1,1,58,9,5,2,36,348,54,354),
(9,1,5,5,58,9,1,75,270,2610,405,2655),(9,5,1,1,58,9,5,3,54,522,81,531),
(12,1,5,5,58,9,1,100,360,3480,540,3540),(12,5,1,1,58,9,5,4,72,696,108,708),
(15,1,5,5,58,9,1,125,450,4350,675,4425),(15,5,1,1,58,9,5,5,90,870,135,885),
(18,1,5,5,58,9,1,150,540,5220,810,5310),(18,5,1,1,58,9,5,6,108,1044,162,1062),
}
reg=set()
errors=[]
for i,r in enumerate(rows):
    I=lambda k:int(r[k]) if r[k] else None
    u0,La,A,W,C2,C3,mu,a,g0,P1,P2,P3,Q0=[I(k) for k in ['u0','Lambda_candidate','A','W','C2','C3','mu','a','g0','P1','P2','P3','Q0']]
    M0=u0*A*W
    if M0!=I('M0') or M0!=a*g0: errors.append((i,'M0 factorization'))
    # Recompute normalized F11 for n2=2,n3=1,m2=m3=1,g=0,k=1.
    X=Y=K=10; G=1
    Ln=a*X*Y*G*K
    Bn=mu*(W+A*Y*G)+a*X*Y*G
    Cn=mu*(W*P3+A*Y*P2)
    val=(Bn*Bn-Ln*Ln)*Q0*Q0-2*Bn*Cn*Q0+Cn*Cn+Ln*Ln*(P2*P2+P3*P3)
    if val!=0: errors.append((i,'F11'))
    if P1*P1+P2*P2+P3*P3!=Q0*Q0: errors.append((i,'sphere'))
    if Ln*P1!=Bn*Q0-Cn: errors.append((i,'linear TC1'))
    actual=math.gcd(M0,P1)
    if actual!=I('actual_g0'): errors.append((i,'actual_g0'))
    fail=r['first_failure']
    if fail=='G0_NOT_DIVIDING_P1' and P1%g0==0: errors.append((i,'bad g0 rejection'))
    if fail=='MU_NOT_DIVIDING_R':
        if P1%g0!=0 or (P1//g0)%mu==0: errors.append((i,'bad mu rejection'))
    if fail=='GCD_A_R':
        if P1%g0 or math.gcd(a,P1//g0)==1: errors.append((i,'bad gcd rejection'))
    if r['lane']=='R36_EXACT_REGRESSION':
        reg.add((u0,La,A,W,C2,C3,mu,g0,P1,P2,P3,Q0))

if reg!=expected_reg:
    errors.append(('regression multiset',len(reg),len(expected_reg),sorted(reg^expected_reg)))

# Verify autopsy semantics from frozen twelve rows.
aut=list(csv.DictReader((ROOT/'105-R37-twelve-root-autopsy.csv').open()))
if len(aut)!=12: errors.append(('autopsy count',len(aut)))
for r in aut:
    P1=int(r['P1']); gs=int(r['g0_selector']); mu=int(r['mu']); a=int(r['a_sel'])
    d=math.gcd(P1,gs)
    if int(r['r_sel_num'])!=P1//d or int(r['r_sel_den'])!=gs//d: errors.append((r['index'],'r rational reduction'))
    if gs%P1==0: pass

print(f'ROOT_ROWS={len(rows)}')
print(f'R36_REGRESSION_ROOTS={len(reg)}')
print(f'AUTOPSY_ROWS={len(aut)}')
print(f'ERRORS={len(errors)}')
for e in errors[:20]: print('ERROR',e)
if errors: sys.exit(1)
print('INDEPENDENT_ROOT_REPLAY=PASS')
