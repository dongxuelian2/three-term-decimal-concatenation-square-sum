#!/usr/bin/env python3
from fractions import Fraction
from math import gcd

def ceildiv(a,b): return (a+b-1)//b
r={'ID': 'R17_FIRST_FULL_MASTER_CORRIDOR', 'U0': 1, 'C2': 60, 'C3': 13683, 'A': 1, 'W': 35, 'n2': 2, 'n3': 5, 'g': 0, 'k': 1, 'm2': 1, 'm3': 5, 'G': 1, 'K': 10, 'X': 10, 'Y': 100000, 'P1': 5600, 'P2': 2100, 'P3': 13683, 'Q0': 14933, 'D': 41067, 'T3': 1250, 'Omega': 1283343750, 'NM': 1437345000000}
h=gcd(r["P1"],r["Q0"]); p=r["P1"]//h; delta=r["D"]//h
L=r["U0"]*r["A"]*r["W"]*r["X"]*r["Y"]*r["G"]
s=gcd(L,p); Esrc=L//s; OmegaD=r["Omega"]//delta; msrc=OmegaD//Esrc
dM=gcd(r["NM"],r["P1"]); EM=r["NM"]//dM
g0=gcd(r["U0"]*r["A"]*r["W"],r["P1"]); RM=dM//g0
gstar=r["NM"]//r["Omega"]; mu=gstar//g0
assert r["Omega"]==EM*msrc
assert gstar==dM//msrc
assert mu==RM//msrc==32
R1=r["P1"]//gstar
lambda_z=r["Y"]//gcd(r["Y"],r["W"]*r["T3"])
tau=lambda_z//gcd(lambda_z,mu); Lambda=mu*tau
assert (R1,lambda_z,tau,Lambda)==(5,16,1,32)
assert gcd(mu,r["C2"]*r["C3"])==4
ZL=max(ceildiv(10**(r["m2"]-1),r["A"]),ceildiv(10**(r["m3"]-1),r["W"]))
ZU=min((10**r["m2"]-1)//r["A"],(10**r["m3"]-1)//r["W"])
assert (ZL,ZU)==(286,9)
d=r["m3"]-r["m2"]
assert d==r["n3"]-r["n2"]+2*r["g"]+r["k"]==4
assert not (10**(d-1)*r["A"] < r["W"] < 10**(d+1)*r["A"])
print("105-R18 exact witness/theorem regression: PASS")
