#include <bits/stdc++.h>
using namespace std;
using i128 = __int128_t;
using ll = long long;

int digits(ll x){ int d=0; do{d++;x/=10;}while(x); return d; }
ll p10(int d){ ll x=1; while(d--) x*=10; return x; }
ll ceildiv(ll a,ll b){ return (a+b-1)/b; }
vector<ll> divisors(ll n){
    vector<ll>a,b;
    for(ll d=1;d*d<=n;d++) if(n%d==0){ a.push_back(d); if(d*d!=n)b.push_back(n/d); }
    reverse(b.begin(),b.end()); a.insert(a.end(),b.begin(),b.end()); return a;
}
ll rad(ll n){ ll r=1; for(ll p=2;p*p<=n;p+=(p==2?1:2)) if(n%p==0){r*=p;while(n%p==0)n/=p;} if(n>1)r*=n; return r; }

int main(int argc,char**argv){
    int PS=atoi(argv[1]), PE=atoi(argv[2]);
    long long trip=0,full=0; map<string,ll> cnt; int deep=-1;
    cout << "depth,fail,m,n,p,A,W,C2,C3,P1,P2,P3,Q0,gstar,g0,mu,R1,lambda_z,tau,Lambda,m2,m3,d,MS,TG,TS,REAL,ZL,ZU,INTEGER,FIT\n";
    for(ll p=PS;p<=PE;p++){
      for(ll m=1;m<=20*p;m++){
        ll P1=2*m*p; auto gsds=divisors(P1);
        i128 base=(i128)20*m*p-m*m-p*p;
        if(base<=1) continue;
        ll nmax=sqrt((long double)(base-1));
        while((i128)(nmax+1)*(nmax+1)<base) nmax++;
        while((i128)nmax*nmax>=base) nmax--;
        for(ll n=1;n<=nmax;n++){
          trip++;
          ll P2=2*n*p, P3=m*m+n*n-p*p, Q=m*m+n*n+p*p;
          if(P3<=0 || gcd(gcd(gcd(P1,P2),P3),Q)!=1) continue;
          ll qmp=Q-P2; if(qmp<=0) continue;
          ll D=10*P1-Q; if(D<=0) continue;
          ll T3=Q-P3;
          for(ll A=1;A<=9;A++){
            if(P3%A) continue;
            ll C3=P3/A; int n3=digits(C3); ll Y=p10(n3);
            for(ll gs:gsds){
              i128 den=(i128)A*10*Y*D-(i128)gs*T3;
              if(den<=0) continue;
              i128 num=(i128)gs*A*Y*qmp;
              if(num%den) continue;
              i128 wi=num/den; if(wi<=0 || wi>LLONG_MAX) continue;
              ll W=(ll)wi; if(P2%W) continue;
              ll C2=P2/W; if(C2<10||C2>99) continue;
              if(W>=Y) continue;
              if(gcd(A,C2)!=1 || gcd(W,C3)!=1 || gcd(A,W)!=1) continue;
              i128 Om=(i128)W*T3+(i128)A*Y*qmp;
              i128 NM=(i128)A*W*10*Y*D;
              if(NM!=(i128)gs*Om) continue;
              ll g0=gcd(A*W,P1); if(gs%g0 || P1%gs) continue;
              ll mu=gs/g0, R1=P1/gs;
              ll lam=Y/gcd(Y,W*T3), tau=lam/gcd(lam,mu), L=mu*tau;
              ll C=C2*C3;
              bool MS=gcd(mu,C)==1, TG=gcd(tau,R1)==1, TS=gcd(tau,C)==1;
              int m2=1,m3=n3,d=m3-m2;
              bool real=((i128)W > (i128)A*p10(d-1) && (i128)W < (i128)A*p10(d+1));
              ll ZL=max(ceildiv(1LL,A),ceildiv(p10(m3-1),W));
              ll ZU=min((10-1)/A,(p10(m3)-1)/W);
              bool integ=ZL<=ZU, fit=L<=ZU;
              int dep=0; string fail="MU_SMITH";
              if(MS){ dep=1; fail="TAU_G1";
                if(TG){ dep=2; fail="TAU_SMITH";
                  if(TS){ dep=3; fail="REAL_RATIO";
                    if(real){ dep=4; fail="INTEGER_WINDOW";
                      if(integ){ dep=5; fail="FORCED_SCALE";
                        if(fit){ dep=6; fail="RESIDUAL";
                          ll lo=ceildiv(ZL,L), hi=ZU/L, F=rad(R1*C);
                          for(ll r=lo;r<=hi;r++) if(gcd(r,F)==1){ dep=8; fail="PASS"; break; }
                        }
                      }
                    }
                  }
                }
              }
              full++; cnt[fail]++;
              if(dep>deep){ deep=dep; cerr<<"NEW d="<<dep<<" p="<<p<<" m="<<m<<" n="<<n<<" A="<<A<<" W="<<W<<" C2="<<C2<<" C3="<<C3<<" mu="<<mu<<" tau="<<tau<<" real="<<real<<" Z="<<ZL<<".."<<ZU<<" fail="<<fail<<"\n"; }
              cout<<dep<<','<<fail<<','<<m<<','<<n<<','<<p<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<P1<<','<<P2<<','<<P3<<','<<Q<<','<<gs<<','<<g0<<','<<mu<<','<<R1<<','<<lam<<','<<tau<<','<<L<<','<<m2<<','<<m3<<','<<d<<','<<MS<<','<<TG<<','<<TS<<','<<real<<','<<ZL<<','<<ZU<<','<<integ<<','<<fit<<'\n';
            }
          }
        }
      }
    }
    cerr<<"trip="<<trip<<" full="<<full<<" deep="<<deep<<" ";
    for(auto &kv:cnt) cerr<<kv.first<<'='<<kv.second<<' ';
    cerr<<"\n";
}
