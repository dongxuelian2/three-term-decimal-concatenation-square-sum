# 105-R18 scripts

All arithmetic is integer/rational. No floating-point value is used to certify any gate. C++ `sqrt(long double)` is used only for an initial loop-bound guess in one discovery scanner and is corrected by exact `__int128` inequalities before use; it never certifies a mathematical predicate.

- `105_R18_exact_verifier.py`: exact witness, mu-source identity, window and ratio regression.
- `105_R18_structured_standard_search.cpp`: exhaustive restricted standard-orientation master-inversion search used for S1.
- `105_R18_all_permutations_local_search.cpp`: S2.
- `105_R18_general_chart_local_search.cpp`: S3.
- `105_R18_odd_P1_general_search.cpp`: S4.

Finite search results are discovery evidence only and are never promoted to a universal theorem.
