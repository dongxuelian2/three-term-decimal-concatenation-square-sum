#include <bits/stdc++.h>
using namespace std; using ll=long long; using i128=__int128_t;
int dig(ll x){int d=0;do{d++;x/=10;}while(x);return d;}ll p10(int d){ll x=1;while(d--)x*=10;return x;}ll cd(ll a,ll b){return(a+b-1)/b;}
vector<ll> divs(ll n){vector<ll>a,b;for(ll d=1;d*d<=n;d++)if(n%d==0){a.push_back(d);if(d*d!=n)b.push_back(n/d);}reverse(b.begin(),b.end());a.insert(a.end(),b.begin(),b.end());return a;}
ll rad(ll n){ll r=1;for(ll p=2;p*p<=n;p+=(p==2?1:2))if(n%p==0){r*=p;while(n%p==0)n/=p;}if(n>1)r*=n;return r;}
int main(){long long full=0,trip=0;int deep=-1;map<string,ll>cnt;cout<<"depth,fail,orient,m,n,p,A,W,C2,C3,P1,P2,P3,Q0,gstar,g0,mu,R1,lambda_z,tau,Lambda,REAL,ZL,ZU\n";
for(ll p=1;p<=50;p++)for(ll m=1;m<=200;m++)for(ll n=1;n<=100;n++){
 ll odd=m*m+n*n-p*p;if(odd<=0)continue;ll Q=m*m+n*n+p*p;ll legs[3]={2*m*p,2*n*p,odd};if(gcd(gcd(gcd(legs[0],legs[1]),legs[2]),Q)!=1)continue;trip++;
 int idx[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 for(int o=0;o<6;o++){ll P1=legs[idx[o][0]],P2=legs[idx[o][1]],P3=legs[idx[o][2]];ll D=10*P1-Q;if(D<=0)continue;auto gsds=divs(P1);ll qmp=Q-P2;if(qmp<=0)continue;ll T3=Q-P3;if(T3<=0)continue;
  for(ll A=1;A<=9;A++){if(P3%A)continue;ll C3=P3/A;int n3=dig(C3);ll Y=p10(n3);
   for(ll gs:gsds){i128 den=(i128)A*10*Y*D-(i128)gs*T3;if(den<=0)continue;i128 num=(i128)gs*A*Y*qmp;if(num%den)continue;i128 wi=num/den;if(wi<=0||wi>LLONG_MAX)continue;ll W=(ll)wi;if(P2%W)continue;ll C2=P2/W;if(C2<10||C2>99)continue;if(W>=Y||gcd(A,C2)!=1||gcd(W,C3)!=1||gcd(A,W)!=1)continue;i128 Om=(i128)W*T3+(i128)A*Y*qmp,NM=(i128)A*W*10*Y*D;if(NM!=(i128)gs*Om)continue;ll g0=gcd(A*W,P1);if(gs%g0||P1%gs)continue;ll mu=gs/g0,R1=P1/gs,lam=Y/gcd(Y,W*T3),tau=lam/gcd(lam,mu),L=mu*tau,C=C2*C3;bool MS=gcd(mu,C)==1,TG=gcd(tau,R1)==1,TS=gcd(tau,C)==1;int d=n3-1;bool real=((i128)W>(i128)A*p10(d-1)&&(i128)W<(i128)A*p10(d+1));ll ZL=max(cd(1,A),cd(p10(n3-1),W)),ZU=min((9LL)/A,(Y-1)/W);bool integ=ZL<=ZU,fit=L<=ZU;int dep=0;string fail="MU_SMITH";if(MS){dep=1;fail="TAU_G1";if(TG){dep=2;fail="TAU_SMITH";if(TS){dep=3;fail="REAL_RATIO";if(real){dep=4;fail="INTEGER_WINDOW";if(integ){dep=5;fail="FORCED_SCALE";if(fit){dep=6;fail="RESIDUAL";ll lo=cd(ZL,L),hi=ZU/L,F=rad(R1*C);for(ll r=lo;r<=hi;r++)if(gcd(r,F)==1){dep=8;fail="PASS";break;}}}}}}}full++;cnt[fail]++;if(dep>deep){deep=dep;cerr<<"NEW depth="<<dep<<" orient="<<o<<" mnp="<<m<<','<<n<<','<<p<<" P="<<P1<<','<<P2<<','<<P3<<" A="<<A<<" W="<<W<<" C="<<C2<<','<<C3<<" mu="<<mu<<" tau="<<tau<<" real="<<real<<" Z="<<ZL<<".."<<ZU<<" fail="<<fail<<"\n";}cout<<dep<<','<<fail<<','<<o<<','<<m<<','<<n<<','<<p<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<P1<<','<<P2<<','<<P3<<','<<Q<<','<<gs<<','<<g0<<','<<mu<<','<<R1<<','<<lam<<','<<tau<<','<<L<<','<<real<<','<<ZL<<','<<ZU<<'\n';
   }
  }
 }
}
cerr<<"trip="<<trip<<" full="<<full<<" deep="<<deep<<' ';for(auto&kv:cnt)cerr<<kv.first<<'='<<kv.second<<' ';cerr<<"\n";
}
