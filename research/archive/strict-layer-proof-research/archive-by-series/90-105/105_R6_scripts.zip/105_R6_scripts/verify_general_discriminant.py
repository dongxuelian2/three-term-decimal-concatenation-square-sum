#!/usr/bin/env python3
"""105-R6 exact symbolic verification.

Scope:
  * sphere-linear-master discriminant identity;
  * alternative elimination consistency;
  * R5C canonical specialization;
  * canonical 5-adic and 2-adic local-square checks.

This script is a verification companion, not a search proof.
All critical arithmetic is exact (sympy integers/rationals / Python integers).
"""
from math import gcd
import sympy as sp

A,B,C,N,P,Q = sp.symbols('A B C N P Q', nonzero=True)
D_ess = sp.expand(C**2 + (B**2-A**2)*N)

# General elimination equations.
poly_Q = sp.expand((B**2-A**2)*Q**2 + 2*A*C*Q - (C**2+B**2*N))
poly_P = sp.expand((B**2-A**2)*P**2 + 2*B*C*P + (C**2-A**2*N))
Disc_Q = sp.factor(sp.discriminant(poly_Q, Q))
Disc_P = sp.factor(sp.discriminant(poly_P, P))
assert sp.factor(Disc_Q - 4*B**2*D_ess) == 0
assert sp.factor(Disc_P - 4*A**2*D_ess) == 0

# Complementary-form identity modulo Q^2-P^2=N.
identity = sp.expand((A*Q-B*P)**2 + (B**2-A**2)*(Q**2-P**2) - (B*Q-A*P)**2)
assert sp.factor(identity) == 0

# R5C canonical specialization.
G = sp.symbols('G', integer=True, positive=True)
A5 = sp.Integer(111)
B5 = sp.Integer(1000)
C5 = 100*G + 1
N5 = 100*G**4 + 1
D5 = sp.factor(C5**2 + (B5**2-A5**2)*N5)
R5 = 4938395*G**4 + 500*G**2 + 10*G + 49384
assert sp.factor(D5 - 20*R5) == 0
assert sp.factor(4*B5**2*D5 - 80000000*R5) == 0


def vp(n, p):
    n = abs(int(n))
    if n == 0:
        return 10**9, 0
    e = 0
    while n % p == 0:
        e += 1
        n //= p
    return e, n


def q5_square(n):
    e,u = vp(n,5)
    return e % 2 == 0 and (u % 5) in (1,4)


def q2_square(n):
    e,u = vp(n,2)
    return e % 2 == 0 and (u % 8) == 1

# R5C depth is g>=2 (G=10^g).
rows=[]
for g in range(2,8):
    GG=10**g
    val=int(D5.subs(G,GG))
    e5,u5=vp(val,5)
    e2,u2=vp(val,2)
    assert e5 == 1
    assert not q5_square(val)
    assert not q2_square(val)
    rows.append((g,e5,u5%5,e2,u2%8))

print('GENERAL_D_ESS=', D_ess)
print('DISC_Q=', Disc_Q)
print('DISC_P=', Disc_P)
print('R5C_D_ESS=', D5)
print('R5C_DISC=', sp.factor(4*B5**2*D5))
print('CANONICAL_LOCAL_ROWS(g,v5,u5mod5,v2,u2mod8)=')
for row in rows:
    print(row)
print('STATUS=PASS')
