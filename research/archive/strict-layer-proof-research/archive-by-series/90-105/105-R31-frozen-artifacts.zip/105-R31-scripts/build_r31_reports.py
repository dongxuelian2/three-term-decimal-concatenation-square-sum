#!/usr/bin/env python3
from pathlib import Path
import json,csv,hashlib,zipfile,os
R=Path('/mnt/data/105-R31')
S=json.loads((R/'105-R31-search-summary.json').read_text())
search_lines='\n'.join(f"- `{x['search']}`: {x['configurations_tested']:,} exact configurations; integer TC1-conic solutions = {x['integer_tc1_conic_solutions']}; pre-TC4 survivors = {x['pre_TC4_survivors']}." for x in S['active_searches'])
q1_packets=', '.join('`'+p+'`' for p in S['R28_q1_hit_packets'])

q1=r'''# 105-R31 — q=1 Forced-Scale Derivation

**Layer:** Strict Layer — \(A_1\)-only  
**Round:** 105-R31  
**Status:** exact symbolic derivation + scoped exact counterexample search; no global q=1 extinction theorem is claimed.

## 1. Frozen definitions recovered

From the frozen R30 TC3 shell, for one fixed legal post-support architecture,

\[
Z_-=
\max\!\left(
\left\lceil\frac{10^{m_2-1}}A\right\rceil,
\left\lceil\frac{10^{m_3-1}}W\right\rceil
\right),
\]

\[
Z_+=
\min\!\left(
\left\lfloor\frac{10^{m_2}-1}A\right\rfloor,
\left\lfloor\frac{10^{m_3}-1}W\right\rfloor
\right),
\]

\[
Q_- = \left\lceil\frac{Z_-}{\Lambda}\right\rceil,
\qquad
Q_+ = \left\lfloor\frac{Z_+}{\Lambda}\right\rfloor,
\]

\[
\Lambda=\operatorname{lcm}(\mu,\lambda_z),\quad
\mu=\frac{g_1^*}{g_0},\quad
\lambda_z=\frac{10^{n_3}}{\gcd(10^{n_3},W(Q_0-P_3))},
\]

\[
F=\operatorname{rad}\!\left(\frac{P_1}{g_1^*}C_2C_3\right),
\qquad z=\Lambda q,
\qquad (q,F)=1.
\]

R30 also proved that the decontented source fibre is independent of the residual denominator \(q\); residual \(q\) enters TC4 only through \((U,q)=1\).

## 2. Exact unit-denominator theorem

Because \(Z_-,Z_+,\Lambda\) are positive integers,

\[
1\in[Q_-,Q_+]
\iff Q_-=1\text{ and }Q_+\ge1.
\]

Moreover,

\[
\left\lceil\frac{Z_-}{\Lambda}\right\rceil=1
\iff Z_-\le\Lambda,
\]

and

\[
\left\lfloor\frac{Z_+}{\Lambda}\right\rfloor\ge1
\iff \Lambda\le Z_+.
\]

Therefore

\[
\boxed{
q=1\text{ is TC3-admissible}
\iff
Z_-\le\Lambda\le Z_+.
}
\tag{R31-Q1}
\]

Equivalently, the four exact digit inequalities are

\[
10^{m_2-1}\le A\Lambda\le10^{m_2}-1,
\]

\[
10^{m_3-1}\le W\Lambda\le10^{m_3}-1.
\]

A cleared two-function form is

\[
L_\Lambda:=\max(10^{m_2-1}-A\Lambda,\ 10^{m_3-1}-W\Lambda)\le0,
\]

\[
R_\Lambda:=\min(10^{m_2}-1-A\Lambda,\ 10^{m_3}-1-W\Lambda)\ge0.
\]

This is an exact forced-scale statement, not a ratio approximation.

## 3. Universal multiplicative width theorem

Each individual decimal block satisfies

\[
\left\lfloor\frac{10^m-1}{A}\right\rfloor
<10\left\lceil\frac{10^{m-1}}A\right\rceil.
\]

Taking an intersection can only decrease the upper endpoint and increase the lower endpoint. Hence, whenever the \(Z\)-window is nonempty,

\[
\boxed{Z_+<10Z_-.}
\]

If the residual q-window is nonempty,

\[
\boxed{
\Gamma_q:=\frac{Q_+}{Q_-}<10.
}
\tag{R31-GAMMA}
\]

Since \(Q_\pm\in\mathbb Z\), this gives \(Q_+\le10Q_--1\). In the unit chamber \(Q_-=1\), necessarily \(1\le Q_+\le9\).

## 4. Full opening of the q-independent source set

On a regular completed source stratum, R8 gives the real interval

\[
I_{23}=[L,R),
\]

\[
L=\max\left(\frac{10^{n_2-1}}{C_2},\frac{10^{n_3-1}}{C_3}\right),
\qquad
R=\min\left(\frac{10^{n_2}}{C_2},\frac{10^{n_3}}{C_3}\right).
\]

The equivalent closed integer block bounds are

\[
U_{\rm lo}=\max\left(
\left\lceil\frac{10^{n_2-1}}{C_2}\right\rceil,
\left\lceil\frac{10^{n_3-1}}{C_3}\right\rceil
\right),
\]

\[
U_{\rm hi}=\min\left(
\left\lfloor\frac{10^{n_2}-1}{C_2}\right\rfloor,
\left\lfloor\frac{10^{n_3}-1}{C_3}\right\rfloor
\right).
\]

Let the frozen chart-native periodic selector be \(U\bmod P_0\in\mathcal R_0\). Let

\[
V_0=\Lambda u_0AW.
\]

Then the exact R30 q-independent source set is

\[
\boxed{
\mathcal U_0=
\{U\in\mathbb Z_{>0}:U_{\rm lo}\le U\le U_{\rm hi},\ U\bmod P_0\in\mathcal R_0,\ (U,V_0)=1,\ \mathsf{SrcComp}(U)\},
}
\]

where \(\mathsf{SrcComp}\) denotes the already-frozen source-completed/PSDG cell predicates. In generic completed strata R8 proves \(h_U=1\), so the source-native progression contributes no extra step; chart-local exceptional source strata keep their own frozen finite-index progression and strict-boundary correction.

Equivalently define

\[
M_U^{\rm rad}=\operatorname{lcm}(P_0,\operatorname{rad}(V_0)),
\]

\[
\mathcal R_{\rm adm}=
\{r\bmod M_U^{\rm rad}:r\bmod P_0\in\mathcal R_0,\ (r,V_0)=1\}.
\]

For a closed lower endpoint,

\[
U_{\min}=
\min_{r\in\mathcal R_{\rm adm}}
\left[r+M_U^{\rm rad}
\left\lceil\frac{\max(L,1)-r}{M_U^{\rm rad}}\right\rceil\right],
\]

with the frozen strict-lower correction on open decorated branches. Then \(\mathcal U_0\ne\varnothing\iff U_{\min}<R\), together with the frozen source-completed predicate.

**Notation firewall.** The historical chart label formerly called `q=1` in R2/R8 is a source-chart label, not the R15 residual denominator q. Its affine progression must not be imported into every residual-q=1 architecture.

## 5. U=1 exact iff

On a generic regular completed stratum, \(U=1\) automatically satisfies every coprimality condition. Its digit-room condition is exactly

\[
\boxed{
10^{n_2-1}\le C_2\le10^{n_2}-1,
\qquad
10^{n_3-1}\le C_3\le10^{n_3}-1,
}
\tag{R31-U1}
\]

plus the fixed chart-native completed-source predicate. Thus `U=1 automatic` is false globally, but its arithmetic test is completely explicit.

For residual \(q=1\), if any \(U\in\mathcal U_0\) exists then

\[
(1,FU)=1
\]

and therefore

\[
\boxed{Q_-=1\ \&\ \mathcal U_0\ne\varnothing\Longrightarrow N_{30}>0.}
\]

Conversely, in the unit chamber \(Q_-=1\) with nonempty q-window, q=1 is available, so

\[
\boxed{N_{30}>0\iff\mathcal U_0\ne\varnothing.}
\tag{R31-UNIT-DECISION}
\]

This is stronger than merely saying q=1 is dangerous: in the entire unit chamber, the prime cover disappears and the terminal decision is purely source-fibre nonemptiness.

## 6. q=1 denominator specialization

Set q=1. Then

\[
z=\Lambda,\qquad
V=V_0=\Lambda u_0AW,
\]

\[
b_2=\Lambda A,\qquad b_3=\Lambda W,
\qquad b_1=\frac{\Lambda u_0AW}{g_1^*}.
\]

The tail divisibility is already absorbed because \(\lambda_z\mid\Lambda\). The Smith conditions become exactly

\[
(\Lambda A,C_2)=1,
\qquad
(\Lambda W,C_3)=1,
\]

with the frozen shape gcds. No extra q-content remains.

## 7. q=1, U=1: exact F11 reconstruction equation

Let

\[
X=10^m,\quad Y=10^n,\quad G=10^g,\quad K=10^k,
\]

\[
P_2=u_0WC_2,\qquad P_3=u_0AC_3.
\]

Define

\[
L=AWu_0XYGK,
\]

\[
B=g_1^*(W+AYG)+AWu_0XYG,
\]

\[
C=g_1^*(WP_3+AYP_2).
\]

The frozen TC1 normal form is exactly the linear relation

\[
\boxed{LP_1=BQ_0-C.}
\]

Substitution into the primitive sphere equation yields the single quadratic

\[
\boxed{
F_{11}(Q_0):=(B^2-L^2)Q_0^2-2BCQ_0+C^2+L^2(P_2^2+P_3^2)=0.
}
\tag{R31-F11}
\]

Its discriminant factors as

\[
\Delta_{11}=4L^2\Big(C^2+(L^2-B^2)(P_2^2+P_3^2)\Big).
\]

This is the exact architecture-first generator used in R31: enumerate the finite digit blocks forced by q=1 and prescribed U, demand a nonnegative square discriminant, reconstruct \(Q_0,P_1\), then replay primitive/master/tail/Smith. It is a search generator, not a new global discriminant obstruction; on an actual TC1+sphere point the square is tautologically witnessed.

## 8. TC2 audit under q=1

TC2/source-room itself does not contain the residual q. Therefore q=1 does not turn TC2 into a new equality. Its effect is indirect: q=1 forces \(A\Lambda\) and \(W\Lambda\) into their denominator digit blocks, after which the source carrier \((C_2,C_3)\) must still admit an integer U in the independent numerator digit room.

The complete R28 corpus up to \(Q_0\le3000\) shows exactly this collision: every raw-TC1 q=1 forced-scale hit has \(U_{\rm lo}=1>0=U_{\rm hi}\).

## 9. Exact bounded theorem and active falsification search

R28's complete E27 search through \(Q_0\le3000\) contains 37 raw TC1 hits. R31 exact replay finds exactly **7** satisfying (R31-Q1). They are:

''' + q1_packets + r'''.

All seven have first failure `POSITIVE_RADIAL_BOX`; all seven satisfy

\[
U_{\rm lo}=1>0=U_{\rm hi}.
\]

Hence

```text
Q1_FORCED_SCALE_SOURCE_COLLISION_Q0_LE_3000=PROVED
```

This is a complete-in-bound theorem because R27 already proved every full survivor lies in E27 and R28 completely enumerated E27 raw-TC1 incidence in that height range. It is not promoted to an unbounded theorem.

R31 also ran architecture-first exact reverse searches using (R31-F11), so the machine lane was not merely a replay of the old packet-height census:

''' + search_lines + r'''

No search scope produced even an integer TC1-conic solution. These are exact finite classifications of the stated architecture boxes only.

## 10. q=1 verdict

```text
Q1_EXACT_FORCED_SCALE_EQUIVALENCE=PROVED
UNIT_CHAMBER_N30_IFF_U0_NONEMPTY=PROVED
Q1_SOURCE_COLLISION_Q0_LE_3000=PROVED
Q1_FORCED_SCALE_EXTINCTION_GLOBAL=NOT_PROVED_NOT_FALSIFIED
GENUINE_POST_SUPPORT_Q1_ARCHITECTURE_FOUND=NO
```

The global missing theorem in the unit chamber is now literally:

\[
\boxed{
Q_-=1\Longrightarrow\mathcal U_0=\varnothing
}
\]

on every legal post-support architecture. No weaker prime-cover statement is relevant there.
'''
(R/'105-R31-q1-forced-scale-derivation.md').write_text(q1,encoding='utf-8')

minimal=r'''# 105-R31 — Minimal-q Descent

**Status:** exact prime-stripping theorem proved; descent-to-one not proved.

## 1. Setup

Fix a legal post-support architecture \(\mathfrak a\) and a source candidate \(U\in\mathcal U_0\). Let

\[
M:=FU,
\]

and, if nonempty, define

\[
q_{\min}=\min\{q\in[Q_-,Q_+]\cap\mathbb Z_{>0}:(q,M)=1\}.
\]

Then \(N_{30}>0\) exactly when this minimum exists for at least one \(U\).

## 2. Prime-stripping lower-edge theorem

Let \(p\mid q_{\min}\). Since \((q_{\min},M)=1\), also

\[
(q_{\min}/p,M)=1.
\]

If \(q_{\min}/p\ge Q_-\), then

\[
Q_-\le q_{\min}/p<q_{\min}\le Q_+,
\]

contradicting minimality. Therefore, for **every** prime divisor \(p\mid q_{\min}\),

\[
\boxed{q_{\min}/p<Q_-.}
\tag{R31-STRIP}
\]

In the original scale \(Z=\Lambda q\),

\[
\boxed{Z/p<Z_-}
\]

because \(Q_-\) is the first integer q whose scale can reach the lower digit boundary. Thus every failed prime stripping exits only through the lower edge, never the upper edge.

Let \(p_{\min}=p_{\min}(q_{\min})\). Then

\[
\boxed{Q_-\le q_{\min}<p_{\min}Q_-.}
\tag{R31-EDGE}
\]

This is the exact minimal-q exceptional strip requested in R31.

## 3. Prime-or-quadratic-strip theorem

If \(q_{\min}\) is composite, then \(q_{\min}\ge p_{\min}^2\). Combining with (R31-EDGE),

\[
p_{\min}^2\le q_{\min}<p_{\min}Q_-,
\]

so

\[
p_{\min}<Q_-.
\]

Consequently

\[
\boxed{
q_{\min}\text{ is prime, or }q_{\min}<Q_-^2.
}
\tag{R31-PQ}
\]

This is a genuine descent compression. It does **not** say q is a prime power, and it does **not** imply q=1.

Examples obtained by exact enumeration of the necessary composite strip:

- \(Q_-=1\): \(q_{\min}=1\) automatically if the source set is nonempty;
- \(Q_-=2\): no composite satisfies the strip, hence \(q_{\min}\) must be prime;
- \(Q_-=3\): the only composite possibility is \(4\);
- \(Q_-=4\): composite possibilities are \(4,6,9\);
- \(Q_-=5\): composite possibilities are \(6,8,9\).

The full exact table for \(Q_-=1,\ldots,10\) is `105-R31-minimal-q-registry.csv`.

## 4. Unit / prime / finite-composite trichotomy

For one fixed U, existence of any compatible q is equivalent to one of:

1. **Unit branch:** \(Q_-=1\), in which case q=1 is automatically compatible;
2. **Prime branch:** a prime \(p\in[Q_-,Q_+]\) with \(p\nmid FU\);
3. **Finite composite strip:** a composite
   \[
   q\in[Q_-,\min(Q_+,Q_-^2-1)]
   \]
   with \((q,FU)=1\).

Proof: choose the minimal compatible q. If it is composite, (R31-PQ) applies; if prime, branch 2; if \(Q_-=1\), q=1 precedes everything. The converse directions are immediate.

Thus all composite q at or above \(Q_-^2\) are mathematically redundant for **existence testing**: if one were compatible, a smaller compatible q of branch 1, 2, or 3 would already exist.

## 5. Universal multiplicative q-window bound

From the decimal-window geometry,

\[
\boxed{Q_+<10Q_-}
\]

whenever the q-window is nonempty. Hence \(Q_+\le10Q_--1\).

This gives a universal multiplicative constant \(C=10\), but not the stronger \(C=2\) or \(3\) contemplated in the attack prompt.

## 6. Why descent-to-one is not proved

Prime stripping proves only that every proper prime quotient of a minimal q falls below the lower edge. It gives no legal operation that moves the lower edge itself. A prime minimal q can therefore survive the stripping argument untouched, and a composite minimal q can survive inside the explicit quadratic strip.

Accordingly R31 does **not** sign

```text
MINIMAL_Q_DESCENT_TO_ONE=YES
```

and it also does not sign it false by a genuine legal counterexample, because no genuine \(N_{30}>0\) architecture was found. The exact status is

```text
MINIMAL_Q_DESCENT_TO_ONE=NOT_PROVED
PRIME_STRIPPING_LOWER_EDGE_RIGIDITY=PROVED
MINIMAL_Q_PRIME_OR_QUADRATIC_STRIP=PROVED
Q_WINDOW_MULTIPLICATIVE_BOUND_LT_10=PROVED
```

The remaining nonunit difficulty is the prime branch plus the finite composite strip, evaluated with the actual architecture-specific support \(FU\).
'''
(R/'105-R31-minimal-q-descent.md').write_text(minimal,encoding='utf-8')

n30=r'''# 105-R31 — N30 Positive Analysis and Active Witness Hunt

## 1. Exact terminal predicate retained from R30

For a fixed legal post-support architecture,

\[
N_{30}(\mathfrak a)=\sum_{U\in\mathcal U_0}\Phi_{\mathfrak a}(U),
\]

\[
\Phi_{\mathfrak a}(U)=
\#\{q\in[Q_-,Q_+]\cap\mathbb Z_{>0}:(q,FU)=1\}.
\]

R31 does not re-prove this count theorem; it opens its smallest atoms.

## 2. Unit chamber

If \(Q_-=1\) and the q-window is nonempty, then q=1 is always coprime to \(FU\). Therefore

\[
\boxed{N_{30}>0\iff\mathcal U_0\ne\varnothing.}
\]

Prime cover is completely powerless in this chamber.

## 3. Nonunit chamber

For each U, let qmin be the first integer at or above \(Q_-\) that is coprime to \(FU\). R31 proves

\[
q_{\min}\text{ prime}\quad\text{or}\quad q_{\min}<Q_-^2.
\]

Therefore the exact positive test can be reorganized as:

- scan primes in the actual q-window and test whether each divides \(FU\);
- scan only composites below \(Q_-^2\);
- ignore all larger composite candidates for existential purposes.

This is architecture-specific and exact; no generic Jacobsthal bound is introduced.

## 4. Active q=1 falsification search

The R28 complete raw-TC1 corpus through \(Q_0\le3000\) contains seven q=1 forced-scale hits, but all seven die at the source radial box with \(U_{lo}=1>U_{hi}=0\). Three of the seven already pass the q-independent shape/Smith/tail compatibility before this source-room death:

- `(48,436,75,445)` with `A=3,W=4,g1*=24,Lambda=2,C2=109,C3=25`;
- `(120,900,691,1141)` with `A=1,W=12,g1*=24,Lambda=2,C2=75,C3=691`;
- `(298,2514,1485,2935)` with `A=5,W=1,g1*=1,Lambda=1,C2=2514,C3=297`.

Each has exact q=1 denominator fit, and each still has source integer upper endpoint zero. Thus the bounded first-failure is source-room, not prime cover.

## 5. Architecture-first reverse generation

R31 then inverted the search order. For prescribed q and U, digit conditions give finite intervals for A,W,C2,C3. TC1 is linear in P1; sphere substitution yields the exact quadratic `R31-F11`. The search enumerates \(\mu\mid\Lambda\), \(g_0\mid AW\), puts \(g_1^*=\mu g_0\), solves the exact square discriminant, then replays primitive, D/H/T positivity, lambda/tau/Lambda, Smith and g1-firewall checks.

''' + search_lines + r'''

No scope produced an integer TC1-conic solution, hence none can contain an N30-positive full architecture. These are complete finite statements only for the explicitly listed architecture boxes.

## 6. Historical R29 support survivor

For

\[
(P_1,P_2,P_3,Q_0)=(640,1420,4727,4977),
\]

\[
(A,W,u_0,g_1^*)=(1,20,1,80),
\]

R30/R31 recover

\[
\Lambda=4,\qquad Z_-=50,\qquad Z_+=9,
\]

so

\[
Q_-=13>2=Q_+.
\]

Thus its N30 value is zero before source activation.

## 7. Genuine positive status

```text
GENUINE_N30_POSITIVE_FOUND=NO
FULL_C26_PACKET_FOUND=NO
Q1_GENUINE_POST_SUPPORT_ARCHITECTURE_FOUND=NO
GLOBAL_N30_ZERO_THEOREM=NOT_PROVED
```

No positive architecture exists in the frozen replay corpus or the new exact reverse-generation scopes. This absence is not promoted to a global theorem.

## 8. Exact remaining object

For each legal TC1/TC2/post-support architecture and each \(U\in\mathcal U_0\), define the deterministic lower-edge coprime successor

\[
\boxed{
q_{\min}(\mathfrak a,U)
=
\min\{q\ge Q_-:(q,FU)=1\}.
}
\]

Then

\[
\boxed{
N_{30}(\mathfrak a)>0
\iff
\exists U\in\mathcal U_0:\ q_{\min}(\mathfrak a,U)\le Q_+.
}
\]

R31 reduces this deterministic object to the unit/prime/finite-composite trichotomy. The prime branch is the only unbounded-shaped arithmetic class that remains.
'''
(R/'105-R31-N30-positive-analysis.md').write_text(n30,encoding='utf-8')

recon=r'''# 105-R31 — Reconstruction Audit

## 1. Why the audit was required

R31 was instructed that any genuine \(N_{30}>0\) architecture must be pushed all the way back to original Strict-\(A_1\), and that a reconstruction failure after the R26 complete finite predicate would indicate an architecture bug rather than justify adding a new `TC5`.

No genuine \(N_{30}>0\) architecture was found in R31, so positive-instance reconstruction was never triggered. The documentary reverse implication was nevertheless audited.

## 2. R26 authoritative iff

R26 freezes

\[
\pi\text{ admits a full Strict-}A_1\text{ lift}
\iff
\mathcal C_{26}(\pi)=1,
\]

where \(\mathcal C_{26}\) existentially enumerates the finite divisor/exponent selectors and then checks TC1--TC4. R30 replaces only the last pair by the exact equivalence

\[
TC3\wedge TC4\iff N_{30}>0.
\]

Therefore on a legal TC1/TC2-ready architecture

\[
TC1\wedge TC2\wedge[N_{30}>0]
\]

is logically the same R26 certificate, not a relaxation.

## 3. Reverse reconstruction chain audited

The inherited R14/R24 reconstruction data include:

\[
z=\Lambda q,
\qquad
V=zu_0AW,
\]

\[
b_2=zA,
\qquad b_3=zW,
\qquad b_1=\frac{zu_0AW}{g_1^*},
\]

\[
P_2=u_0WC_2,
\qquad
P_3=u_0AC_3,
\]

and the source decontenting restores numerator blocks from the legal source integer U. The frozen minimal lift system additionally checks exponent chart, denominator digit windows, primitive sphere, D/T positivity, master equation, tail divisibility, Smith reconstruction, g1 shell/firewall, frozen cell and PSDG regression.

R30's common-dilation theorem changes no decontented source equation; it only writes \(z=\Lambda q\) and splits

\[
(U,V_0q)=1
\iff
(U,V_0)=1\wedge(U,q)=1.
\]

Thus q-elimination introduces no missing semantic condition.

## 4. q=1 specialization audit

For q=1,

\[
z=\Lambda,\qquad V=V_0,
\]

and no residual denominator content remains. The master/tail/Smith shell is still checked through the same frozen conditions; q=1 does not delete primitive, source-native, digit or PSDG predicates.

## 5. Audit verdict

```text
R26_IFF_DOCUMENTARY_AUDIT=PASS
R30_Q_ELIMINATION_REVERSE_EQUIVALENCE=PASS
HIDDEN_TC5_FOUND=NO
POSITIVE_INSTANCE_REVERSE_RECONSTRUCTION=NOT_TRIGGERED_NO_N30_POSITIVE
ARCHITECTURE_BUG_FOUND=NO
```

This does not constitute an independent re-proof of every R24/R26 theorem. It verifies that the frozen reverse map and the R30 replacement line up without an omitted condition. A future genuine N30-positive point must still be replayed numerically/symbolically through every frozen semantic gate before a witness certificate is signed.
'''
(R/'105-R31-reconstruction-audit.md').write_text(recon,encoding='utf-8')

sat=r'''# 105-R31 — N30 Positive Saturation Certificate

## Frozen status

R30 already eliminated residual q as an independent existential coordinate. R31 opens the resulting count at its lower edge.

## New exact theorems

```text
Q1_EXACT_FORCED_SCALE_EQUIVALENCE=PROVED
UNIT_CHAMBER_N30_IFF_U0_NONEMPTY=PROVED
Q_WINDOW_MULTIPLICATIVE_BOUND_LT_10=PROVED
PRIME_STRIPPING_LOWER_EDGE_RIGIDITY=PROVED
MINIMAL_Q_PRIME_OR_QUADRATIC_STRIP=PROVED
UNIT_PRIME_FINITE_COMPOSITE_TRICHOTOMY=PROVED
Q1_SOURCE_COLLISION_Q0_LE_3000=PROVED
```

The core formulas are

\[
q=1\iff Z_-\le\Lambda\le Z_+,
\]

\[
Q_-=1\le Q_+\Longrightarrow (N_{30}>0\iff\mathcal U_0\ne\varnothing),
\]

and for a minimal admissible q>1,

\[
\forall p\mid q:\quad q/p<Q_-,
\]

hence

\[
q\text{ prime}\quad\text{or}\quad q<Q_-^2.
\]

## Search saturation

R28 complete q1 autopsy through \(Q_0\le3000\): 7 forced-scale raw-TC1 hits, all source-room dead.

New architecture-first exact reverse searches: no integer TC1-conic solution in the recorded scopes.

No genuine N30-positive architecture was found.

## What is not proved

```text
Q1_FORCED_SCALE_EXTINCTION_GLOBAL=NOT_PROVED_NOT_FALSIFIED
MINIMAL_Q_DESCENT_TO_ONE=NOT_PROVED
GLOBAL_N30_ZERO_THEOREM=NOT_PROVED
STRICT_A1_UNLIFTABILITY=NOT_PROVED
FULL_STRICT_A1_WITNESS_FOUND=NO
```

## Minimal remaining object

The remaining object is no longer a free denominator integer. It is the deterministic **architecture-uniform lower-edge coprime successor**:

\[
q_{\min}(\mathfrak a,U)=\min\{q\ge Q_-:(q,FU)=1\},
\]

subject to \(q_{\min}\le Q_+\), split exactly into:

1. the unit chamber \(Q_-=1\), where only source-fibre nonemptiness remains;
2. a prime q in the real architecture window not dividing FU;
3. a finite composite strip below \(Q_-^2\).

Any further attack that does not use one of these three exact classes is information-regressive relative to R31.
'''
(R/'105-R31-N30-POSITIVE-SATURATION-CERTIFICATE.md').write_text(sat,encoding='utf-8')

stage=r'''# 105-R31 Stage Archive — q=1 Forced-Scale Assault × Minimal-q Descent × N30 Positive Hunt × Strict-A1 Reconstruction Audit

**Project:** 三项十进制拼接平方和问题  
**Layer:** Strict Layer — \(A_1\)-only  
**Round:** 105-R31  
**Campaign position:** 最后十五轮终局总攻第 6 轮  
**Status:** FROZEN / ARCHIVED

# Executive Verdict

R31 did **not** prove global Strict-\(A_1\) extinction and did not find a full witness. It also did not honestly force every N30-positive survivor down to q=1.

It did, however, open the R30 count at the two places where it is actually rigid:

1. **Unit chamber:**
   \[
   q=1\iff Z_-\le\Lambda\le Z_+,
   \]
   and on any legal architecture with \(Q_-=1\le Q_+\),
   \[
   N_{30}>0\iff\mathcal U_0\ne\varnothing.
   \]
   Prime-cover arithmetic disappears completely.
2. **Minimal nonunit chamber:** for the minimal admissible residual denominator,
   \[
   q/p<Q_-\quad\forall p\mid q,
   \]
   hence a composite minimal q must satisfy
   \[
   q<Q_-^2.
   \]
   Therefore minimal q is **prime or in a finite quadratic strip**.
3. The exact q-window has universal multiplicative width
   \[
   Q_+<10Q_-.
   \]
4. In the complete R28 E27 corpus through \(Q_0\le3000\), exactly seven raw-TC1 rows admit q=1 forced scale; every one has empty source digit room. This gives a rigorous bounded q1 source-collision theorem.
5. New architecture-first searches based on the q=1/U-prescribed TC1×sphere quadratic tested over 3.9 million additional exact configurations and found zero integer TC1-conic solutions in the stated boxes.

The strongest honest terminal verdict is therefore

```text
R31_TERMINAL_ATTACK_FAILED
R31_N30_POSITIVE_SATURATION_CERTIFICATE=PROVED
```

with a strictly smaller remaining object: `ARCHITECTURE_UNIFORM_LOWER_EDGE_COPRIME_SUCCESSOR`, split into unit / prime / finite-composite branches.

---

# Part I — FILE / HASH AUDIT

## I.1 Frozen inputs actually recovered

The following authoritative inputs were read from File Library references. Raw bytes were not mounted in the active runtime, so verification is **LEDGER-CROSSCHECK**, not a new cryptographic rehash.

| file | frozen SHA-256 | method | status |
|---|---|---|---|
| `105-R26-stage-archive.md` | `41f4e2aad7720862a98349d61d22c482b7f5045b6c54bfea56651d4032d97680` | LEDGER-CROSSCHECK | FROZEN |
| `105-R30-stage-archive.md` | `ce9c0be6cf52201ef99605ea4a67b414fc14327554b51a0c58d5000f84b25ade` | LEDGER-CROSSCHECK | FROZEN |
| `105-R30-TC3-TC4-exact-definitions.md` | `4fb3b68afbd9a95b7ff8067f5a93c78d1416f82b7c4b606912fb344163fc18f3` | LEDGER-CROSSCHECK | FROZEN |
| `105-R30-q-elimination-derivation.md` | `ca536b3764ef49d593019ad7c24b3874f6b2f3b10d0f42af8218b3a966722f6e` | LEDGER-CROSSCHECK | FROZEN |
| `105-R30-Q-SUCCESSOR-SATURATION-CERTIFICATE.md` | `4137beba338eba099012337ac2e2473e2d865bb706c3a05a336783c0ea7d3dcd` | LEDGER-CROSSCHECK | FROZEN |
| `105-R30-execution.log` | `854a82ebd5b30611228ea771e992e82ff5a943be21457ab450dc98f47fba8afb` | LEDGER-CROSSCHECK | FROZEN |
| `105-R28-TC1-hit-registry.csv` | `0b325db25e2305022ac0aaae92c70cc504210f2ce5fe1ce003c01a0318f2df3e` | LEDGER-CROSSCHECK | FROZEN |
| `105-R28-stage-archive.md` | `ee1bf90f78f4317eefc3e3c341c3f15828e7e69724e2b5fa393765ab106f14a1` | LEDGER-CROSSCHECK | FROZEN |

The R30 manifest itself explicitly records the same old-artifact limitation. R31 does not pretend otherwise.

## I.2 Additional theorem sources recovered

- `105_R8_Common_U_Integer_Source_Fibre.md` for the exact rank-one source interval and canonical successor;
- `105_R14_Positive_Radial_Core_Lift_Fibre.md` for the reverse reconstruction variables and Smith/master/tail predicates;
- R28 bounded hit and fixed-architecture registries for q=1 autopsy.

## I.3 R31 generated artifacts

Required artifacts are generated under this directory. All new bytes are hashed locally after generation. No extinction or full-witness certificate is generated because neither result was proved.

---

# Part II — R30 N30 RECOVERY

For one fixed legal post-support architecture,

\[
g_0=(u_0AW,P_1),\quad \mu=g_1^*/g_0,\quad R_1=P_1/g_1^*,
\]

\[
\lambda_z=\frac{10^{n_3}}{(10^{n_3},W(Q_0-P_3))},
\qquad
\Lambda=\operatorname{lcm}(\mu,\lambda_z),
\]

\[
F=\operatorname{rad}(R_1C_2C_3).
\]

The denominator chamber is

\[
z=\Lambda q,\qquad(q,F)=1,
\]

with the exact \(Z\)- and q-windows recorded in `105-R31-q1-forced-scale-derivation.md`.

The q-independent source set is the completed periodic source selector inside the exact block interval, with \((U,V_0)=1\), where \(V_0=\Lambda u_0AW\).

R30's exact fusion remains

\[
N_{30}(\mathfrak a)=\sum_{U\in\mathcal U_0}
\#\{q\in[Q_-,Q_+]:(q,FU)=1\},
\]

\[
TC3\wedge TC4\iff N_{30}>0.
\]

No new free q coordinate is introduced in R31.

---

# Part III — q=1 FORCED SCALE

R31 proves

\[
\boxed{q=1\text{ TC3-admissible}\iff Z_-\le\Lambda\le Z_+.}
\]

The exact cleared conditions are

\[
10^{m_2-1}\le A\Lambda\le10^{m_2}-1,
\qquad
10^{m_3-1}\le W\Lambda\le10^{m_3}-1.
\]

A second new exact theorem is

\[
\boxed{Q_+<10Q_-}
\]

on every nonempty q-window. Thus the unit chamber has \(1\le Q_+\le9\).

Most importantly, because q=1 is automatically coprime to FU,

\[
\boxed{Q_-=1\le Q_+\Longrightarrow(N_{30}>0\iff\mathcal U_0\ne\varnothing).}
\]

This is the true terminal simplification of the q=1 branch.

---

# Part IV — SOURCE FIBRE OPENING

On regular completed strata,

\[
L=\max(10^{n_2-1}/C_2,10^{n_3-1}/C_3),
\]

\[
R=\min(10^{n_2}/C_2,10^{n_3}/C_3),
\]

with exact integer bounds \(U_{lo},U_{hi}\) and finite native residue selector as fully written in the q1 derivation companion.

Generic R8 completed strata have source step \(h_U=1\); special historical source-chart progression is chart-local and is not identified with residual q=1.

For U=1 the exact digit condition is simply that C2 and C3 themselves occupy their prescribed numerator digit blocks, plus the frozen source-completed predicate.

---

# Part V — q=1,U=1 ATTACK

R31 derives the exact architecture-first equation

\[
F_{11}(Q_0)=
(B^2-L^2)Q_0^2-2BCQ_0+C^2+L^2(P_2^2+P_3^2)=0,
\]

with explicit L,B,C in `105-R31-q1-forced-scale-derivation.md`.

This allows reverse generation from digit blocks instead of scanning primitive sphere packets first.

The new searches report:

''' + search_lines + r'''

No integer TC1-conic solution was found in these exact finite boxes. This is not a global q1 extinction theorem.

The complete R28 height corpus gives the stronger bounded fact: exactly 7 raw-TC1 q1 hits exist through \(Q_0\le3000\), and every one has \(U_{lo}=1>U_{hi}=0\). Hence

```text
Q1_FORCED_SCALE_SOURCE_COLLISION_Q0_LE_3000=PROVED
```

---

# Part VI — MINIMAL-q DESCENT

For a minimal admissible q and every p dividing it,

\[
\boxed{q/p<Q_-.}
\]

Hence

\[
\boxed{Q_-\le q<p_{\min}(q)Q_-.}
\]

If q is composite,

\[
\boxed{q<Q_-^2.}
\]

Thus a minimal survivor is prime or in an explicit finite quadratic strip. This is the exact limit of prime stripping reached in R31.

It is not legitimate to sign `MINIMAL_Q_DESCENT_TO_ONE=YES`: a prime q has no nontrivial prime quotient inside the positive integers, and the lower edge itself does not move under the frozen geometry.

---

# Part VII — ACTIVE COUNTEREXAMPLE SEARCH

The machine campaign was explicitly falsification-oriented:

1. recover all q1 hits in the complete R28 bounded raw-TC1 registry;
2. identify their first q-independent source/support death;
3. reverse-generate q1/U-prescribed architectures by exact TC1×sphere quadratic;
4. include a small-q lane q in {1,2,3,5,7}.

Results are machine-readable in the q1, N30-positive and exceptional-branch registries. No genuine post-support N30-positive architecture was found.

---

# Part VIII — FULL RECONSTRUCTION AUDIT

No N30-positive point existed to trigger a full numerical reverse reconstruction.

The frozen theorem chain was nevertheless audited:

\[
\mathcal C_{26}=1\iff\text{full Strict-}A_1\text{ lift},
\]

and R30 replaces only TC3×TC4 by an exact equivalent N30 predicate. R14's reverse map retains exponent chart, denominator windows, primitive sphere, D/T positivity, master, tail, Smith reconstruction, g1 firewall, frozen cell and PSDG regression.

Therefore

```text
R26_IFF_DOCUMENTARY_AUDIT=PASS
HIDDEN_TC5_FOUND=NO
POSITIVE_INSTANCE_RECONSTRUCTION=NOT_TRIGGERED
```

No proof-architecture bug was detected.

---

# Part IX — GLOBAL RESULT

## IX.1 Proved

```text
Q1_EXACT_FORCED_SCALE_EQUIVALENCE=PROVED
UNIT_CHAMBER_N30_IFF_U0_NONEMPTY=PROVED
Q_WINDOW_MULTIPLICATIVE_BOUND_LT_10=PROVED
PRIME_STRIPPING_LOWER_EDGE_RIGIDITY=PROVED
MINIMAL_Q_PRIME_OR_QUADRATIC_STRIP=PROVED
UNIT_PRIME_FINITE_COMPOSITE_TRICHOTOMY=PROVED
Q1_FORCED_SCALE_SOURCE_COLLISION_Q0_LE_3000=PROVED
R26_IFF_DOCUMENTARY_AUDIT=PASS
```

## IX.2 Not proved / not found

```text
Q1_FORCED_SCALE_EXTINCTION_GLOBAL=NOT_PROVED_NOT_FALSIFIED
MINIMAL_Q_DESCENT_TO_ONE=NOT_PROVED
GLOBAL_N30_ZERO_THEOREM=NOT_PROVED
STRICT_A1_UNLIFTABILITY_PROVED=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
GENUINE_N30_POSITIVE_FOUND=NO
```

## IX.3 Twelve mandatory answers

1. **q=1 denominator condition:** exactly \(Z_-\le\Lambda\le Z_+\), equivalently the two denominator blocks \(A\Lambda,W\Lambda\) have the prescribed digit lengths.
2. **Why equivalent:** direct ceiling/floor equivalence for positive integral \(Z_\pm,\Lambda\).
3. **q-free source condition:** finite source interval + fixed native residue selector + completed-source predicates + \((U,V_0)=1\), with canonical successor formula fully recovered.
4. **When U=1 is legal:** C2,C3 lie in their prescribed digit blocks and the fixed chart-native completed predicate accepts U=1; gcd conditions are automatic.
5. **Genuine q=1 architecture?** No genuine post-support one found; global existence remains unresolved. Seven bounded raw-TC1 q1 rows all die at TC2/source room.
6. **If q1 and U0 exists, N30 positive?** Yes, automatically and exactly.
7. **R26 iff reconstruction complete?** Documentary audit passes; no positive-instance reconstruction was triggered.
8. **Shortest q1 death mechanism?** In the complete \(Q_0\le3000\) q1 raw-TC1 corpus it is source-room emptiness. No global symbolic version is yet proved.
9. **Can minimal q descend?** Every prime stripping exits below Q-. Descent all the way to 1 is not proved.
10. **Prime / prime power / bounded?** Minimal q is prime or composite below \(Q_-^2\). Prime power is not forced; no architecture-independent absolute C is proved.
11. **Any full C26 packet?** None known/found in R31.
12. **Smallest remaining mathematical object:** the architecture-uniform lower-edge coprime successor, split into unit, prime, and finite composite branches.

---

# TERMINAL VERDICT

```text
R31_TERMINAL_ATTACK_FAILED
R31_N30_POSITIVE_SATURATION_CERTIFICATE=PROVED

Q1_GLOBAL_TRUTH=UNDECIDED
Q1_GENUINE_POST_SUPPORT_WITNESS_FOUND=NO
U0_FREEDOM=FINITE_PERIODIC_SOURCE_SUCCESSOR
MINIMAL_Q_DESCENT_TO_ONE=NOT_PROVED
MINIMAL_Q_PRIME_OR_QUADRATIC_STRIP=PROVED
GENUINE_N30_POSITIVE_FOUND=NO
R26_IFF_AUDIT=PASS_DOCUMENTARY

MINIMAL_REMAINING_OBJECT=ARCHITECTURE_UNIFORM_LOWER_EDGE_COPRIME_SUCCESSOR__UNIT_PRIME_FINITE_COMPOSITE_SPLIT
```

R31 therefore does not end 105, but it does prevent the next round from returning to generic q-floor arithmetic: the only honest nonunit obstruction left is prime support in the real q-window plus the finite composite strip; the unit chamber is purely a source-fibre problem.
'''
(R/'105-R31-stage-archive.md').write_text(stage,encoding='utf-8')

# Hash all generated artifacts except manifest/manifest companion and zip, then create manifest.
def sha(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

# stage companion
st_sha=sha(R/'105-R31-stage-archive.md')
(R/'105-R31-stage-archive.sha256.txt').write_text(f'{st_sha}  105-R31-stage-archive.md\n',encoding='utf-8')

files=[]
for p in sorted(R.rglob('*')):
    if p.is_file() and p.name not in {'105-R31-SHA256-MANIFEST.txt','105-R31-SHA256-MANIFEST.sha256.txt','105-R31-frozen-artifacts.zip','105-R31-frozen-artifacts.zip.sha256.txt'}:
        files.append(p)
manifest='# 105-R31 SHA-256 manifest\n# Paths relative to /mnt/data/105-R31. All entries below are bytewise hashes computed in the active runtime.\n'
for p in files:
    manifest+=f'{sha(p)}  {p.relative_to(R).as_posix()}\n'
(R/'105-R31-SHA256-MANIFEST.txt').write_text(manifest,encoding='utf-8')
man_sha=sha(R/'105-R31-SHA256-MANIFEST.txt')
(R/'105-R31-SHA256-MANIFEST.sha256.txt').write_text(f'{man_sha}  105-R31-SHA256-MANIFEST.txt\n',encoding='utf-8')

# Frozen zip (exclude itself only)
zip_path=R/'105-R31-frozen-artifacts.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(R.rglob('*')):
        if p.is_file() and p.name not in {'105-R31-frozen-artifacts.zip','105-R31-frozen-artifacts.zip.sha256.txt'}:
            z.write(p,p.relative_to(R).as_posix())
zip_sha=sha(zip_path)
(R/'105-R31-frozen-artifacts.zip.sha256.txt').write_text(f'{zip_sha}  105-R31-frozen-artifacts.zip\n',encoding='utf-8')
print('STAGE_SHA256',st_sha)
print('MANIFEST_SHA256',man_sha)
print('ZIP_SHA256',zip_sha)
print('FILES',len(list(R.rglob('*'))))
