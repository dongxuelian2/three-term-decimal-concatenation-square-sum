#!/usr/bin/env python3
from math import gcd, ceil, floor, isqrt
from pathlib import Path
import csv, json, hashlib, time

ROOT=Path('/mnt/data/105-R31')
ROOT.mkdir(parents=True,exist_ok=True)

# Complete-in-bound raw TC1 hits copied exactly from the frozen R28 registry.
# Columns: P1,P2,P3,Q0,A,W,u0,g1,n,delta,m,k,g,bounded_death
R28_ROWS=[
(20,120,123,173,1,2,1,10,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(48,436,75,445,3,4,1,24,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(435,160,168,493,3,2,2,435,1,1,1,1,0,'SHAPE_GCD'),
(435,160,168,493,6,4,1,435,1,1,1,1,0,'SHAPE_GCD'),
(120,780,467,917,1,1,1,20,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(200,776,755,1101,1,1,1,25,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(120,900,691,1141,1,12,1,24,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(240,1155,56,1181,1,1,7,80,2,1,1,1,1,'MU_SMITH'),
(240,1155,56,1181,7,7,1,80,2,1,1,1,1,'SHAPE_GCD'),
(136,1152,441,1241,1,2,3,68,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(136,1152,441,1241,3,6,1,68,2,0,1,1,0,'SHAPE_GCD'),
(140,1240,491,1341,1,2,1,10,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(894,1158,739,1639,1,1,1,149,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(230,330,1593,1643,1,2,1,10,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(390,1390,801,1651,1,1,1,65,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(260,1680,531,1781,1,2,1,130,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(300,1580,837,1813,3,5,1,150,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(816,1288,1053,1853,3,2,1,204,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(200,1820,431,1881,1,4,1,40,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(225,1840,504,1921,3,2,2,75,1,1,1,1,0,'SHAPE_GCD'),
(225,1840,504,1921,6,4,1,75,1,1,1,1,0,'SHAPE_GCD'),
(210,1330,1563,2063,1,14,1,7,3,-1,1,1,0,'POSITIVE_RADIAL_BOX'),
(520,2180,1007,2457,1,1,1,65,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(832,404,2431,2601,13,2,1,52,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(1200,2295,316,2609,4,15,1,1200,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(288,2584,585,2665,3,4,1,24,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(276,2268,1463,2713,1,2,1,2,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(480,1040,2499,2749,3,2,1,24,3,-1,1,1,0,'POSITIVE_RADIAL_BOX'),
(480,1040,2499,2749,3,2,1,240,3,0,2,1,0,'MU_SMITH'),
(480,1040,2499,2749,3,20,1,240,4,-2,1,1,0,'POSITIVE_RADIAL_BOX'),
(375,2480,1368,2857,3,2,2,75,1,1,1,1,0,'SHAPE_GCD'),
(375,2480,1368,2857,3,20,1,375,2,0,1,1,0,'SHAPE_GCD'),
(375,2480,1368,2857,6,4,1,75,1,1,1,1,0,'SHAPE_GCD'),
(312,2584,1317,2917,3,1,1,6,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(298,2514,1485,2935,1,2,1,2,2,0,1,1,0,'POSITIVE_RADIAL_BOX'),
(298,2514,1485,2935,5,1,1,1,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
(2958,394,255,2995,51,1,1,102,1,1,1,1,0,'POSITIVE_RADIAL_BOX'),
]

def divisors(n):
    out=[]
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            out.append(d)
            if d*d!=n: out.append(n//d)
    return sorted(out)

def rad(n):
    n=abs(n); r=1; p=2
    while p*p<=n:
        if n%p==0:
            r*=p
            while n%p==0:n//=p
        p += 1 if p==2 else 2
    if n>1:r*=n
    return r

def ceildiv(a,b): return -((-a)//b)

def eval_r28(i,row):
    P1,P2,P3,Q0,A,W,u0,g1,n,delta,m,k,g,death=row
    assert P2%(u0*W)==0 and P3%(u0*A)==0
    C2=P2//(u0*W); C3=P3//(u0*A)
    n2=n+delta; n3=n; m2=m; m3=n+g
    g0=gcd(u0*A*W,P1)
    corridor=(g1%g0==0 and P1%g1==0)
    mu=g1//g0 if corridor else None
    R1=P1//g1 if corridor else None
    T=Q0-P3; Y=10**n3
    lz=Y//gcd(Y,W*T)
    tau=lz//gcd(lz,mu) if mu else None
    Lam=(mu*lz)//gcd(mu,lz) if mu else None
    shape=(gcd(A,C2)==gcd(W,C3)==gcd(A,W)==1)
    smith=(mu is not None and gcd(mu,C2*C3)==1)
    compat=(corridor and shape and gcd(tau,R1)==1 and gcd(Lam,C2*C3)==1)
    Zm=max(ceildiv(10**(m2-1),A),ceildiv(10**(m3-1),W))
    Zp=min((10**m2-1)//A,(10**m3-1)//W)
    Qm=ceildiv(Zm,Lam) if Lam else None
    Qp=Zp//Lam if Lam else None
    q1=(Lam is not None and Zm<=Lam<=Zp)
    Ulo=max(ceildiv(10**(n2-1),C2),ceildiv(10**(n3-1),C3))
    Uhi=min((10**n2-1)//C2,(10**n3-1)//C3)
    radial=(Ulo<=Uhi)
    # U0 is meaningful only after all q-independent pre-source gates. Here R28 first-death tells us no row reaches that stage.
    if death=='POSITIVE_RADIAL_BOX':
        U0_count='0_PRE_SOURCE_ROOM'; Uvals=''; q1tc4='NO_TC2_ROOM'
    else:
        U0_count='NOT_REACHED'; Uvals=''; q1tc4='NOT_REACHED'
    first=death
    return dict(
        packet=f'{P1}:{P2}:{P3}:{Q0}',
        selectors=f'A={A};W={W};u0={u0};g1={g1}',
        exponents=f'n={n};delta={delta};m={m};k={k};g={g};n2={n2};m3={m3}',
        Lambda=Lam,Zminus=Zm,Zplus=Zp,Qminus=Qm,Qplus=Qp,
        U0_count=U0_count,U_values=Uvals,
        q1_TC3_pass='YES' if q1 else 'NO',q1_TC4_pass=q1tc4 if q1 else 'NOT_ACTIVATED',
        N30='NOT_APPLICABLE_PRE_SUPPORT',reconstruction_status='NOT_ACTIVATED',first_failure=first,
        C2=C2,C3=C3,Ulo=Ulo,Uhi=Uhi,shape_pass=shape,mu_smith_pass=smith,compat_pass=compat,
        bounded_scope='R28_COMPLETE_E27_Q0_LE_3000'
    )

def solve_tc1_conic(P2,P3,A,W,u0,g1,m,n,g,k):
    X=10**m; Y=10**n; G=10**g; K=10**k
    L=A*W*u0*X*Y*G*K
    B=g1*(W+A*Y*G)+A*W*u0*X*Y*G
    C=g1*(W*P3+A*Y*P2)
    aa=B*B-L*L; bb=-2*B*C; cc=C*C+L*L*(P2*P2+P3*P3)
    sols=[]
    if aa==0:
        if bb and (-cc)%bb==0:
            Q0=(-cc)//bb
            if Q0>0 and (B*Q0-C)%L==0:
                P1=(B*Q0-C)//L
                if P1>0: sols.append((P1,Q0))
        return sols
    disc=bb*bb-4*aa*cc
    if disc<0:return []
    sd=isqrt(disc)
    if sd*sd!=disc:return []
    den=2*aa
    for s in (-sd,sd):
        num=-bb+s
        if num%den==0:
            Q0=num//den
            if Q0>0 and (B*Q0-C)%L==0:
                P1=(B*Q0-C)//L
                if P1>0: sols.append((P1,Q0))
    return list(dict.fromkeys(sols))

def reverse_search(name,qs,Lmax,Umax,u0max,scopes):
    t0=time.time(); tested=0; tc1_integer=0; survivors=[]
    for q in qs:
      for m,n,g,k in scopes:
        n2=m+g+k; n3=n; m3=n+g
        for Lam in range(1,Lmax+1):
          z=Lam*q
          Alo=ceildiv(10**(m-1),z); Ahi=(10**m-1)//z
          Wlo=ceildiv(10**(m3-1),z); Whi=(10**m3-1)//z
          if Alo>Ahi or Wlo>Whi: continue
          for U in range(1,Umax+1):
            C2lo=ceildiv(10**(n2-1),U); C2hi=(10**n2-1)//U
            C3lo=ceildiv(10**(n3-1),U); C3hi=(10**n3-1)//U
            if C2lo>C2hi or C3lo>C3hi: continue
            for u0 in range(1,u0max+1):
              for A in range(Alo,Ahi+1):
                for W in range(Wlo,Whi+1):
                  if gcd(A,W)!=1: continue
                  V0=Lam*u0*A*W
                  if gcd(U,V0)!=1: continue
                  for mu in divisors(Lam):
                    for g0 in divisors(A*W):
                      g1=mu*g0
                      for C2 in range(C2lo,C2hi+1):
                        P2=u0*W*C2
                        for C3 in range(C3lo,C3hi+1):
                          if gcd(A,C2)!=1 or gcd(W,C3)!=1: continue
                          P3=u0*A*C3; tested+=1
                          for P1,Q0 in solve_tc1_conic(P2,P3,A,W,u0,g1,m,n,g,k):
                            tc1_integer+=1
                            if gcd(gcd(gcd(P1,P2),P3),Q0)!=1: continue
                            if gcd(u0,P1)!=1: continue
                            gg0=gcd(u0*A*W,P1)
                            if gg0!=g0 or P1%g1: continue
                            T=Q0-P3; H=10**g*Q0-P2; D=10**k*P1-Q0
                            if min(T,H,D)<=0:continue
                            Y=10**n; lz=Y//gcd(Y,W*T)
                            mu2=g1//g0; tau=lz//gcd(lz,mu2); Lam2=mu2*lz//gcd(mu2,lz)
                            if Lam2!=Lam:continue
                            R1=P1//g1
                            if gcd(tau,R1)!=1 or gcd(Lam,C2*C3)!=1:continue
                            if gcd(q,R1*C2*C3)!=1:continue
                            if gcd(z*u0*A*W,P1)!=g1:continue
                            # This is a genuine TC1/TC2/TC3-ready necessary-source candidate. Full source-native TC4 predicates would be audited next.
                            survivors.append(dict(search=name,q=q,U=U,Lambda=Lam,z=z,m=m,n=n,g=g,k=k,u0=u0,A=A,W=W,
                                                  C2=C2,C3=C3,P1=P1,P2=P2,P3=P3,Q0=Q0,g1=g1,R1=R1,
                                                  status='PRE_TC4_CANDIDATE'))
    return dict(search=name,qs=list(qs),Lmax=Lmax,Umax=Umax,u0max=u0max,scopes=scopes,
                configurations_tested=tested,integer_tc1_conic_solutions=tc1_integer,
                pre_TC4_survivors=len(survivors),elapsed_sec=round(time.time()-t0,3)),survivors

def pmin(n):
    for p in range(2,isqrt(n)+1):
        if n%p==0:return p
    return n

def composite_strip(r):
    if r<=1:return []
    return [q for q in range(r,r*r) if pmin(q)<q and q//pmin(q)<r]

# 1) Frozen bounded q=1 autopsy
rows=[eval_r28(i,r) for i,r in enumerate(R28_ROWS)]
q1rows=[r for r in rows if r['q1_TC3_pass']=='YES']
fields=['packet','selectors','exponents','Lambda','Zminus','Zplus','Qminus','Qplus','U0_count','U_values','q1_TC3_pass','q1_TC4_pass','N30','reconstruction_status','first_failure','C2','C3','Ulo','Uhi','shape_pass','mu_smith_pass','compat_pass','bounded_scope']
with open(ROOT/'105-R31-q1-candidate-registry.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

# 2) Active reverse generation. These are architecture-first searches, not packet-height scans.
searches=[]; allsurv=[]
for args in [
    ('Q1_U1_TO_U3_L8_K1',[1],8,3,2,[(1,1,0,1)]),
    ('Q1_U1_L8_K2',[1],8,1,2,[(1,1,0,2)]),
    ('SMALL_Q_U1_L6_K1',[1,2,3,5,7],6,1,2,[(1,1,0,1)]),
]:
    s,sv=reverse_search(*args); searches.append(s); allsurv.extend(sv)

# 3) Minimal-q prime-stripping registry
with open(ROOT/'105-R31-minimal-q-registry.csv','w',newline='',encoding='utf-8') as f:
    fs=['Qminus','composite_prime_stripping_compatible','count','theorem_consequence']
    w=csv.DictWriter(f,fieldnames=fs);w.writeheader()
    for r in range(1,11):
        cs=composite_strip(r)
        consequence=('q_min=1' if r==1 else 'q_min_must_be_prime' if not cs else 'composite_q_min_confined_to_list; prime branch remains')
        w.writerow(dict(Qminus=r,composite_prime_stripping_compatible=';'.join(map(str,cs)),count=len(cs),theorem_consequence=consequence))

# 4) N30 positive registry: only genuine architecture-level positives count.
with open(ROOT/'105-R31-N30-positive-registry.csv','w',newline='',encoding='utf-8') as f:
    fs=['scope','status','configurations_tested','integer_tc1_conic_solutions','pre_TC4_survivors','genuine_N30_positive','note']
    w=csv.DictWriter(f,fieldnames=fs);w.writeheader()
    w.writerow(dict(scope='R28_COMPLETE_E27_Q0_LE_3000',status='NO_POST_SUPPORT_ARCHITECTURE',configurations_tested='R28:80352953 exponent records',integer_tc1_conic_solutions=37,pre_TC4_survivors=0,genuine_N30_positive='NO',note=f'q1_forced_scale_raw_hits={len(q1rows)}; all die before post-support'))
    w.writerow(dict(scope='R29_HISTORICAL_SUPPORT_SURVIVOR',status='N30_ZERO_EMPTY_Q_WINDOW',configurations_tested=1,integer_tc1_conic_solutions=1,pre_TC4_survivors=0,genuine_N30_positive='NO',note='Lambda=4; Z-=50>Z+=9; Q-=13>Q+=2'))
    for s in searches:
        w.writerow(dict(scope=s['search'],status='NO_PRE_TC4_SURVIVOR_IN_EXACT_REVERSE_SCOPE',configurations_tested=s['configurations_tested'],integer_tc1_conic_solutions=s['integer_tc1_conic_solutions'],pre_TC4_survivors=s['pre_TC4_survivors'],genuine_N30_positive='NO',note='architecture-first exact quadratic-discriminant generation'))
    for sv in allsurv:
        w.writerow(dict(scope=sv['search'],status='PRE_TC4_SURVIVOR',configurations_tested='',integer_tc1_conic_solutions='',pre_TC4_survivors=1,genuine_N30_positive='NOT_YET',note=json.dumps(sv,sort_keys=True)))

# 5) Reconstruction registry
with open(ROOT/'105-R31-reconstruction-registry.csv','w',newline='',encoding='utf-8') as f:
    fs=['candidate','trigger','status','first_failure','audit']
    w=csv.DictWriter(f,fieldnames=fs);w.writeheader()
    w.writerow(dict(candidate='R29_SUPPORT_SURVIVOR',trigger='TC1+TC2/support historical',status='RECONSTRUCTION_NOT_TRIGGERED',first_failure='TC3_EMPTY_Q_WINDOW_13_GT_2',audit='R26 iff wrapper remains consistent'))
    w.writerow(dict(candidate='R31_GENUINE_N30_POSITIVE',trigger='N30>0',status='NONE_FOUND',first_failure='N/A',audit='positive-instance reverse reconstruction not triggered'))

# 6) Exceptional branch registry
branches=[
('Q1_EXACT_FORCED_SCALE','q=1','Zminus<=Lambda<=Zplus','PROVED_EQUIVALENCE'),
('Q1_SOURCE_CORNER','q=1 and legal post-support','U0 nonempty iff source selector has a point','GLOBAL_TRUTH_UNRESOLVED'),
('R28_BOUNDED_Q1','Q0<=3000 complete raw-TC1 census',f'{len(q1rows)} q1 forced-scale raw hits','ALL_PRE_SUPPORT_DEAD'),
('MINIMAL_Q_PRIME_STRIP','q=qmin, p|q','q/p<Qminus for every p|q','PROVED'),
('COMPOSITE_MINIMAL_Q','qmin composite','qmin<Qminus^2','PROVED'),
('QMINUS_2','Qminus=2','minimal admissible q must be prime','PROVED'),
('QMINUS_3','Qminus=3','composite minimal q only 4','PROVED'),
('MINIMAL_Q_TO_ONE','global legal architectures','not implied by interval/prime stripping alone','NOT_PROVED'),
('R26_IFF_AUDIT','documentary theorem chain','R26 says iff; R14 minimal lift equivalence; R30 exact q reparam','PASS_DOCUMENTARY_NO_POSITIVE_INSTANCE'),
]
with open(ROOT/'105-R31-exceptional-branch-registry.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['branch','scope','exact_condition','status']);w.writerows(branches)

# 7) Save active survivors, if any, to a JSON forensic file.
(ROOT/'105-R31-active-search-survivors.json').write_text(json.dumps(allsurv,indent=2,sort_keys=True),encoding='utf-8')

summary={
 'R28_raw_TC1_rows':len(rows),
 'R28_q1_forced_scale_raw_hits':len(q1rows),
 'R28_q1_hit_packets':[r['packet'] for r in q1rows],
 'R28_q1_first_failures':{d:sum(r['first_failure']==d for r in q1rows) for d in sorted(set(r['first_failure'] for r in q1rows))},
 'active_searches':searches,
 'active_pre_TC4_survivors':len(allsurv),
 'genuine_N30_positive_found':False,
 'q1_global_extinction_proved':False,
 'q1_global_extinction_falsified':False,
 'minimal_q_descent_to_one_proved':False,
 'minimal_q_prime_stripping_theorem':True,
 'composite_minimal_q_bound':'q_min < Qminus^2',
}
(ROOT/'105-R31-search-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True),encoding='utf-8')
(ROOT/'105-R31-execution.log').write_text('\n'.join([
 'R31_UNIT_DENOMINATOR_SEARCH=COMPLETED',
 f'R28_RAW_TC1_ROWS={len(rows)}',
 f'R28_Q1_FORCED_SCALE_RAW_HITS={len(q1rows)}',
 f'R28_Q1_FIRST_FAILURES={summary["R28_q1_first_failures"]}',
 *[f'ACTIVE_SEARCH_{i+1}={json.dumps(s,sort_keys=True)}' for i,s in enumerate(searches)],
 f'ACTIVE_PRE_TC4_SURVIVORS={len(allsurv)}',
 'GENUINE_N30_POSITIVE_FOUND=NO',
 'Q1_FORCED_SCALE_EXTINCTION_GLOBAL=NOT_PROVED_NOT_FALSIFIED',
 'MINIMAL_Q_DESCENT_TO_ONE=NOT_PROVED',
 'MINIMAL_Q_PRIME_STRIPPING=PROVED',
 'COMPOSITE_MINIMAL_Q_BOUND=q_min<Qminus^2',
])+'\n',encoding='utf-8')
print(json.dumps(summary,indent=2,sort_keys=True))
