105-R22 scripts

- 105_R22_exact_audit.py: exact Fraction regression of MAE, loads, direct-W recovery, reverse-Mr, Y-divisibility, ANG-SQ.
- 105_R22_h_first_search.cpp: exact six-orientation H-first finite discovery search for the minimal A=u0=U=G=1,k=1 chart. No floating-point ranking; deficit classification uses integer inequalities.
- 105_R22_h_first_all_A_search.cpp: exact all-A|P3 extension of the H-first reverse search; no floating-point ranking.
- 105_R22_direct_W_recovery.cpp: minimal exact regression of the pre-radial direct-W quotient theorem.

Representative discovery commands used for the archived census were split by p-range; finite no-hit results are evidence only, never universal theorems.
