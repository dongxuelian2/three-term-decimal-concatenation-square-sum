#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
static i64 gcd4(i64 a,i64 b,i64 c,i64 d){return gcd(gcd(a,b),gcd(c,d));}
static int digits10(i64 x){int d=0;do{++d;x/=10;}while(x);return d;}
static i128 pow10i(int e){i128 r=1;while(e--)r*=10;return r;}
static string s128(i128 x){if(x==0)return"0";bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back(char('0'+x%10));x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
static vector<i64> divisors(i64 n){vector<i64>a,b;for(i64 d=1;d*d<=n;++d)if(n%d==0){a.push_back(d);if(d*d!=n)b.push_back(n/d);}reverse(b.begin(),b.end());a.insert(a.end(),b.begin(),b.end());return a;}
static bool near_delta_lt5(i128 H,i128 N){
    if(H*10>N && H<10*N) return false; // already a pass
    if(H>=10*N) return H<50*N;         // Delta=H/(10N)
    return N<50*H;                     // Delta=N/(10H)
}
static pair<i128,i128> delta(i128 H,i128 N){
    if(H*10>N && H<10*N) return {1,1};
    if(H>=10*N) return {H,10*N};
    return {N,10*H};
}
int main(int argc,char**argv){
 int pmin=1,pmax=60,mmax=200,nmax=300;if(argc>1)pmin=atoi(argv[1]);if(argc>2)pmax=atoi(argv[2]);if(argc>3)mmax=atoi(argv[3]);if(argc>4)nmax=atoi(argv[4]);
 const i64 K=10; // search chart A=u0=U=G=1, g=0,k=1
 long long triples=0,orients=0,dpos=0,g1vis=0,ydiv=0,c2int=0,master=0,corr=0,support=0,near=0,ratio=0;
 int perm[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 for(int p=pmin;p<=pmax;++p)for(int m=1;m<=mmax;++m)for(int n=1;n<=nmax;++n){
  i64 r1=2LL*m*p,r2=2LL*n*p,r3=1LL*m*m+1LL*n*n-1LL*p*p,q=1LL*m*m+1LL*n*n+1LL*p*p;if(r3<=0)continue;++triples;i64 z=gcd4(llabs(r1),llabs(r2),llabs(r3),q);r1/=z;r2/=z;r3/=z;q/=z;i64 legs[3]={r1,r2,r3};
  for(int oi=0;oi<6;++oi){i64 P1=legs[perm[oi][0]],P2=legs[perm[oi][1]],P3=legs[perm[oi][2]],Q0=q;if(gcd(gcd(P1,P2),gcd(P3,Q0))!=1)continue;++orients;i64 D=K*P1-Q0;if(D<=0)continue;++dpos;i64 T3=Q0-P3;if(T3<=0)continue;i64 C3=P3;int n3=digits10(C3);i128 Y=pow10i(n3);auto gs=divisors(P1);int maxn2=digits10(P2);
   for(i64 g1:gs){++g1vis;i128 pgt=(i128)P2*g1*T3;if(pgt%Y)continue;++ydiv;i128 tail=pgt/Y;
    for(int n2=2;n2<=maxn2;++n2){i128 X=pow10i(n2-1);i128 num=(i128)P2*X*D-tail;if(num<=0)continue;i128 den=(i128)g1*(Q0-P2);if(den<=0||num%den)continue;i128 cq=num/den;if(cq<=0||cq>LLONG_MAX)continue;i64 C2=(i64)cq;if(digits10(C2)!=n2||P2%C2)continue;++c2int;i64 W=P2/C2;if(gcd(W,C3)!=1)continue;i64 g0=gcd(W,P1);if(g1%g0)continue;
      i128 Om=(i128)W*T3+Y*(Q0-P2), NM=(i128)W*X*Y*D;if(Om<=0||(i128)g1*Om!=NM)continue;++master;++corr;i64 mu=g1/g0;if(gcd(mu,C2*C3)!=1)continue;i64 R1=P1/g1; i64 Y64=(i64)Y; i64 lambda=Y64/gcd(Y64,W*T3); i64 tau=lambda/gcd(lambda,mu);if(gcd(tau,R1)!=1||gcd(tau,C2*C3)!=1)continue;++support;
      i128 H=Y*(X*D+(i128)g1*C2)-(i128)g1*T3,N=(i128)g1*X*Q0;if(H<=0||(i128)W*H!=(i128)g1*Y*Q0){cerr<<"MAE_FAIL\n";return 2;}bool rp=(H*10>N&&H<10*N);if(rp)++ratio;else if(near_delta_lt5(H,N))++near;auto de=delta(H,N);
      cout<<"SUPPORT,"<<p<<","<<m<<","<<n<<","<<oi<<","<<P1<<","<<P2<<","<<P3<<","<<Q0<<","<<C2<<","<<W<<","<<g1<<","<<n2<<","<<n3<<","<<s128(H)<<","<<s128(N)<<","<<s128(de.first)<<"/"<<s128(de.second)<<","<<(rp?1:0)<<"\n";
    }
   }
  }
 }
 cerr<<"SUMMARY triples="<<triples<<" primitive_orients="<<orients<<" dpos="<<dpos<<" g1vis="<<g1vis<<" ydiv="<<ydiv<<" c2int="<<c2int<<" master="<<master<<" corridor="<<corr<<" support="<<support<<" near="<<near<<" ratio="<<ratio<<"\n";
}
