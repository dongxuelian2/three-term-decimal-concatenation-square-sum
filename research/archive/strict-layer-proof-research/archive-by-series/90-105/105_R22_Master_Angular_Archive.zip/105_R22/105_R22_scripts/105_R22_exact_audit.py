#!/usr/bin/env python3
from fractions import Fraction
from math import gcd

A=W=u0=G=1
# overwrite W after compact initialization
W=20
C2,C3=71,4727
P1,P2,P3,Q0=640,1420,4727,4977
X,Y,K,D,T3,g1,Mr=10,10000,10,1423,250,80,71
Omega=W*T3+A*Y*(G*Q0-P2)
NM=u0*A*W*X*Y*G*D
assert Omega==35575000 and NM==2846000000 and NM//Omega==g1
H=u0*A*X*Y*G*D-g1*(T3-A*Y*Mr)
assert H==199080000
assert W*H==g1*A*Y*G*Q0
N=g1*X*Q0
assert N==3981600 and Fraction(H,N)==50
Hp=A*Y*(u0*X*G*D+g1*Mr); Hm=g1*T3
assert (Hp,Hm)==(199100000,20000) and H==Hp-Hm
Lrad=Fraction(A*Y*Mr,X*Q0)
LD=Fraction(u0*A*Y*G*D,g1*Q0)
eps=Fraction(T3,X*Q0)
L3=Fraction(P3,X*Q0)
assert Lrad==Fraction(71000,4977)
assert LD==Fraction(177875,4977)
assert eps==Fraction(25,4977) and 0<eps<Fraction(1,X)
assert Lrad+LD-eps==50
assert Lrad+LD+L3==Fraction(501,10)
assert A*Y*Mr==710000 > (10*X+1)*Q0==502677
xi2=Fraction(71,10); xi3=Fraction(4727,1000)
assert Fraction(P3,Q0)*G*K*(xi2/xi3)==Lrad
J=u0*A*X*Y*G*D-g1*T3
assert J==142280000
assert g1*A*Y*(G*Q0-P2)%J==0
assert g1*A*Y*(G*Q0-P2)//J==W
assert (P2*g1*T3)%Y==0
Mr2=Fraction(P2*J,g1*A*Y*(G*Q0-P2))
assert Mr2==Mr
S=Q0*Q0-P1*P1-P3*P3
assert S==P2*P2
assert H*H*S==(g1*A*Y*G*Q0*Mr)**2
print('105-R22 exact current-witness audit: PASS')
print('H/N=',Fraction(H,N))
print('Lrad=',Lrad,'LD=',LD,'eps=',eps,'L3=',L3)
print('completed_positive_load=',Lrad+LD+L3)
print('J_angle=',J,'W=',W,'Mr=',Mr2)
