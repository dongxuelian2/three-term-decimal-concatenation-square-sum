#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
static string s128(i128 x){if(x==0)return"0";bool n=x<0;if(n)x=-x;string s;while(x){s.push_back(char('0'+x%10));x/=10;}if(n)s.push_back('-');reverse(s.begin(),s.end());return s;}
int main(){
  // Frozen R20/R21 witness regression.
  i64 A=1,u0=1,X=10,Y=10000,G=1,D=1423,T3=250,g1=80,P2=1420,Q0=4977;
  i128 J=(i128)u0*A*X*Y*G*D-(i128)g1*T3;
  i128 RHS=(i128)g1*A*Y*(G*Q0-P2);
  if(J<=0 || RHS%J){cerr<<"DIRECT_W_FAIL\n";return 2;}
  i128 W=RHS/J;
  if(W!=20 || P2%(i64)W){cerr<<"REGRESSION_FAIL\n";return 3;}
  i128 Mr=P2/W;
  if(Mr!=71){cerr<<"MR_FAIL\n";return 4;}
  cout<<"J_ANGLE="<<s128(J)<<"\nW="<<s128(W)<<"\nMR="<<s128(Mr)<<"\nDIRECT_W_RECOVERY=PASS\n";
}
