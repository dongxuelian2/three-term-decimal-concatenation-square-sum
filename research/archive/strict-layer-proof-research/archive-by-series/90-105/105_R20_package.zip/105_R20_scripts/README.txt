105-R20 scripts
===============

105_R20_exact_audit.py
  Deterministic exact certificate for F1/F2, local valuations, the first
  empty-live-set mu-Smith witness, support stack, and denominator-ratio failure.

105_R20_live_set_search.py
  Structured discovery search that reproduces the first empty-live-set witness.
  It is explicitly discovery evidence, not a global exhaustive theorem.

Both scripts use Python arbitrary-precision integers only.  No floating-point
valuation or ratio test is used.
