#!/usr/bin/env python3
"""R20 structured exact discovery search for an empty live-prime set.

Search family: normalized standard Pythagorean-quadruple source shapes,
A=1, U=u0=1, g=0, k=1, C2 ten-unit.  The generated raw quadruple is
allowed to have global content; it is divided out before the primitive-sphere
checks.  This is a construct/discovery search, not a global completeness claim.

The loop stops at the first full master-corridor shape with gcd(mu,C2*C3)=1.
All arithmetic is integer arithmetic.
"""
from math import gcd,isqrt


def divisors(n):
    a=[]
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            a.append(d)
            if d*d!=n:a.append(n//d)
    return sorted(a)


def digits(n): return len(str(abs(n)))

stats={k:0 for k in [
    'TRIPLES','POSITIVE_RAW','NORMALIZED_SPHERE','W_DIVISOR_VISITS',
    'TENUNIT_C2','SHAPE_LEVEL','D_T3','MASTER_INTEGER','CORRIDOR_PASS','MU_SMITH_PASS']}

for p in range(1,26):
  for m in range(1,65):
    for n in range(1,143):
      stats['TRIPLES']+=1
      P1,P2=2*m*p,2*n*p
      P3=m*m+n*n-p*p
      Q0=m*m+n*n+p*p
      if P3<=0: continue
      stats['POSITIVE_RAW']+=1
      cont=gcd(gcd(P1,P2),gcd(P3,Q0))
      P1//=cont;P2//=cont;P3//=cont;Q0//=cont
      assert gcd(gcd(P1,P2),gcd(P3,Q0))==1
      stats['NORMALIZED_SPHERE']+=1
      A=1; C3=P3; n3=digits(C3)
      for W in divisors(P2):
        stats['W_DIVISOR_VISITS']+=1
        C2=P2//W
        if gcd(C2,10)!=1: continue
        stats['TENUNIT_C2']+=1
        if gcd(W,C3)!=1: continue
        n2=digits(C2); g=0; k=1; m2=n2-1; m3=n3
        if m2<1 or W>=10**m3: continue
        stats['SHAPE_LEVEL']+=1
        X=10**m2;Y=10**n3;G=1;K=10
        D=K*P1-Q0;T3=Q0-P3
        if D<=0 or T3<=0: continue
        stats['D_T3']+=1
        Omega=W*T3-Y*(P2-Q0)
        if Omega<=0:continue
        NM=W*X*Y*D
        if NM%Omega:continue
        stats['MASTER_INTEGER']+=1
        g1star=NM//Omega
        g0=gcd(W,P1)
        if g1star%g0 or P1%g1star:continue
        stats['CORRIDOR_PASS']+=1
        mu=g1star//g0
        if gcd(mu,C2*C3)!=1:continue
        stats['MU_SMITH_PASS']+=1
        live=[ell for ell in (2,5) if C2%ell==0 and P1%ell==0]
        assert live==[]
        print('SEARCH_STATS='+repr(stats))
        print('FIRST_HIT='+repr(dict(
            p=p,m=m,n=n,raw_content=cont,
            P1=P1,P2=P2,P3=P3,Q0=Q0,
            C2=C2,C3=C3,A=A,W=W,g=g,k=k,m2=m2,n3=n3,
            D=D,T3=T3,Omega=Omega,NM=NM,g0=g0,g1star=g1star,mu=mu,
            LIVE_SET='EMPTY')))
        raise SystemExit(0)

print('NO_HIT')
print('SEARCH_STATS='+repr(stats))
raise SystemExit(1)
