#!/usr/bin/env python3
"""105-R20 exact-integer verifier.

No floating-point arithmetic is used.  The script verifies the frozen F1/F2
regressions, the R20 local valuation formulas on those witnesses, and the first
empty-live-set / mu-Smith / support-stack witness found by the companion search.
"""
from math import gcd


def vp(n: int, p: int) -> int:
    n = abs(int(n))
    if n == 0:
        raise ValueError("vp(0,p) is not used in this certificate")
    v = 0
    while n % p == 0:
        n //= p
        v += 1
    return v


def ceil_div(a: int, b: int) -> int:
    return -((-a) // b)


def witness(name, C2, C3, A, W, P1, P2, P3, Q0, g, k, m2, n3):
    G = 10**g
    K = 10**k
    X = 10**m2
    Y = 10**n3
    assert P1*P1 + P2*P2 + P3*P3 == Q0*Q0
    assert gcd(gcd(P1, P2), gcd(P3, Q0)) == 1
    assert P2 == W*C2
    assert P3 == A*C3
    D = K*P1-Q0
    T3 = Q0-P3
    H2 = G*Q0-P2
    Omega = W*T3 + A*Y*H2
    Omega2 = Q0*(W+A*Y*G)-A*W*(C3+Y*C2)
    assert Omega == Omega2 > 0
    NM = A*W*X*Y*G*D
    assert NM % Omega == 0
    g1s = NM//Omega
    g0 = gcd(A*W, P1)
    corridor = (g1s % g0 == 0 and P1 % g1s == 0)
    mu = g1s//g0 if corridor else None
    R1 = P1//g1s if corridor else None
    return locals()


F1 = witness("F1", 60,13683,1,35,5600,2100,13683,14933,0,1,1,5)
F2 = witness("F2", 310,71549,1,60,54000,18600,71549,91549,1,1,1,5)
P0 = witness("P0", 71,4727,1,20,640,1420,4727,4977,0,1,1,4)

# Frozen full-corridor values.
assert F1["g0"] == 35 and F1["g1s"] == 1120 and F1["mu"] == 32 and F1["R1"] == 5
assert F2["g0"] == 60 and F2["g1s"] == 3000 and F2["mu"] == 50 and F2["R1"] == 18
assert P0["g0"] == 20 and P0["g1s"] == 80 and P0["mu"] == 4 and P0["R1"] == 8

# R19 absorbed-content quantities for P0.
N = P0["NM"]; P1 = P0["P1"]; Om = P0["Omega"]
h = gcd(P1, P0["Q0"])
d = gcd(N, P1)
RM = d // P0["g0"]
L = P0["A"]*P0["W"]*P0["X"]*P0["Y"]*P0["G"]
p_red = P1//h
s = gcd(L, p_red)
Esrc = L//s
delta = P0["D"]//h
assert Om % delta == 0
OmegaD = Om//delta
assert OmegaD % Esrc == 0
msrc = OmegaD//Esrc
assert (RM, msrc, RM//msrc) == (32, 8, 4)
assert RM//msrc == P0["mu"]

# Shape-level CF certificate for P0.
X0 = P0["Q0"] + P0["P1"]
Y0 = P0["Q0"] - P0["P1"]
c = 1
assert (X0, Y0) == (5617,4337)
assert gcd(X0,Y0) == 1 and X0 > Y0 > 0 and X0 % 2 == Y0 % 2 == 1
assert c*c*X0*Y0 == P0["P2"]**2 + P0["P3"]**2
assert P0["P1"] == c*(X0-Y0)//2
assert P0["Q0"] == c*(X0+Y0)//2

# Decimal ledgers and exact F1/F2 budgets.
def local_row(W,P1,T3,H2,eY,eG,eX,ell):
    w=vp(W,ell); p=vp(P1,ell); t=vp(T3,ell); hh=vp(H2,ell)
    eYG=eY+eG; e10=eX+eYG
    B=e10+w-min(w,p)
    a=w+t; b=eY+hh
    return dict(ell=ell,w=w,p=p,t=t,h=hh,eYG=eYG,e10=e10,B=B,a=a,b=b)

f1_2=local_row(35,5600,1250,12833,5,0,1,2)
f1_5=local_row(35,5600,1250,12833,5,0,1,5)
f2_2=local_row(60,54000,20000,896890,5,1,1,2)
f2_5=local_row(60,54000,20000,896890,5,1,1,5)
assert (f1_2["w"],f1_2["p"],f1_2["a"],f1_2["b"],f1_2["B"],vp(F1["Omega"],2)) == (0,5,1,5,6,1)
assert (f1_5["w"],f1_5["p"],f1_5["a"],f1_5["b"],f1_5["B"],vp(F1["Omega"],5)) == (1,2,5,5,6,6)
assert (f2_2["w"],f2_2["p"],f2_2["a"],f2_2["b"],f2_2["B"],vp(F2["Omega"],2)) == (2,4,7,6,7,6)
assert (f2_5["w"],f2_5["p"],f2_5["a"],f2_5["b"],f2_5["B"],vp(F2["Omega"],5)) == (1,3,5,6,7,5)

# Exact F1/5 secondary equal-order cancellation.
assert 35*1250 == 5**5 * 14
assert 10**5*12833 == 5**5 * 410656
assert 14+410656 == 410670
assert vp(410670,5) == 1

# P0 live set is empty, hence full mu-Smith support passes directly.
live = [ell for ell in (2,5) if P0["C2"]%ell==0 and P0["P1"]%ell==0]
assert live == []
assert gcd(P0["mu"], P0["C2"]*P0["C3"]) == 1
assert vp(P0["Omega"],2)==3 and vp(P0["Omega"],5)==5
assert vp(P0["W"],2)==2 and vp(P0["W"],5)==1
assert vp(P0["P1"],2)==7 and vp(P0["P1"],5)==1

# Tail/support stack on P0.
Y=P0["Y"]
lambda_z = Y//gcd(Y,P0["W"]*P0["T3"])
tau = lambda_z//gcd(lambda_z,P0["mu"])
Lambda = P0["mu"]*tau
assert (lambda_z,tau,Lambda)==(2,1,4)
assert gcd(tau,P0["R1"])==1
assert gcd(tau,P0["C2"]*P0["C3"])==1
assert gcd(Lambda,P0["C2"]*P0["C3"])==1

# Denominator ratio / integer window: first downstream failure.
m3=P0["n3"]+P0["g"]
dexp=m3-P0["m2"]
assert dexp==3
assert not (10**(dexp-1)*P0["A"] < P0["W"] < 10**(dexp+1)*P0["A"])
Zminus=max(ceil_div(10**(P0["m2"]-1),P0["A"]),ceil_div(10**(m3-1),P0["W"]))
Zplus=min((10**P0["m2"]-1)//P0["A"],(10**m3-1)//P0["W"])
assert (Zminus,Zplus)==(50,9)
assert Zminus>Zplus

print("R20_EXACT_AUDIT=PASS")
print(f"P0_CF=(c,X0,Y0)=({c},{X0},{Y0})")
print(f"P0_MASTER=(Omega,NM,g0,g1star,RM,msrc,mu)=({Om},{N},{P0['g0']},{P0['g1s']},{RM},{msrc},{P0['mu']})")
print(f"P0_SUPPORT=(lambda_z,tau,Lambda,R1)=({lambda_z},{tau},{Lambda},{P0['R1']})")
print(f"P0_RATIO=(d,W,A)=({dexp},{P0['W']},{P0['A']});PASS=NO")
print(f"P0_Z_WINDOW=({Zminus},{Zplus});PASS=NO")
