#!/usr/bin/env python3
from __future__ import annotations
import csv, math, re
from pathlib import Path
from collections import OrderedDict

ROOT=Path(__file__).resolve().parents[1]
FASTLOG=ROOT/'105-R28-fast-B3000.log'

def gcd4(a,b,c,d): return math.gcd(math.gcd(a,b),math.gcd(c,d))
def ceildiv(a,b): return (a+b-1)//b

def primitive_hyperplane(A,W,u,g1,n,m,k,g):
    X,Y,G,K=10**m,10**n,10**g,10**k
    c1=A*W*u*X*Y*G*K
    c2=A*Y*g1
    c3=W*g1
    B=g1*W+A*Y*G*g1+A*W*u*X*Y*G
    h=math.gcd(math.gcd(c1,c2),math.gcd(c3,B))
    return c1//h,c2//h,c3//h,B//h

def first_support_death(P1,P2,P3,Q,A,W,u,g1,n,delta,C2,C3,Ulo,Uhi):
    if math.gcd(A,C2)!=1 or math.gcd(W,C3)!=1 or math.gcd(A,W)!=1:
        return 'SHAPE_GCD',None,None
    if Ulo>Uhi: return 'POSITIVE_RADIAL_BOX',None,None
    g0=math.gcd(u*A*W,P1)
    if g1%g0: return 'MASTER_G0',g0,None
    mu=g1//g0
    if math.gcd(mu,C2*C3)!=1: return 'MU_SMITH',g0,mu
    T=Q-P3;Y=10**n
    lam=Y//math.gcd(Y,W*T); tau=lam//math.gcd(lam,mu);R1=P1//g1
    if math.gcd(tau,R1)!=1:return 'TAIL_G1',g0,mu
    if math.gcd(tau,C2*C3)!=1:return 'TAIL_SMITH',g0,mu
    return 'R24_SUPPORT_PASS',g0,mu

def classify_arch(arch):
    A,W,u,g1,n,delta,m,k,g=(arch[x] for x in ('A','W','u','g1','n','delta','m','k','g'))
    c1,c2,c3,B=primitive_hyperplane(A,W,u,g1,n,m,k,g)
    # Scale-free hyperplane is primitive; use it directly.
    n2=n+delta
    radial_solutions=[]
    # If a positive radial U exists, C2<10^n2 and C3<10^n, hence this box is complete.
    for C2 in range(1,10**n2):
        P2=u*W*C2
        for C3 in range(1,10**n):
            P3=u*A*C3
            Ulo=max(ceildiv(10**(n2-1),C2),ceildiv(10**(n-1),C3))
            Uhi=min((10**n2-1)//C2,(10**n-1)//C3)
            if Ulo>Uhi: continue
            L=c2*P2+c3*P3
            qa=c1*c1-B*B
            qb=2*c1*L
            qc=L*L-B*B*(P2*P2+P3*P3)
            if qa==0: raise RuntimeError('degenerate qa not handled')
            disc=qb*qb-4*qa*qc
            if disc<0:continue
            sd=math.isqrt(disc)
            if sd*sd!=disc:continue
            for num in (-qb+sd,-qb-sd):
                den=2*qa
                if num%den:continue
                P1=num//den
                if P1<=0 or P1%g1:continue
                nq=c1*P1+c2*P2+c3*P3
                if nq%B:continue
                Q=nq//B
                if Q<=max(P1,P2,P3):continue
                if P1*P1+P2*P2+P3*P3!=Q*Q:continue
                if gcd4(P1,P2,P3,Q)!=1:continue
                # Original fixed-TC1 audit.
                X,Y,G,K=10**m,10**n,10**g,10**k
                T=Q-P3;D=K*P1-Q;H=G*Q-P2
                if D<=0:continue
                if g1*(W*T+A*Y*H)!=A*W*u*X*Y*G*D:continue
                reason,g0,mu=first_support_death(P1,P2,P3,Q,A,W,u,g1,n,delta,C2,C3,Ulo,Uhi)
                radial_solutions.append(dict(P1=P1,P2=P2,P3=P3,Q0=Q,C2=C2,C3=C3,Ulo=Ulo,Uhi=Uhi,
                    first_support_death=reason,g0='' if g0 is None else g0,mu='' if mu is None else mu))
    # dedupe exact packet rows (quadratic +/- can duplicate at discriminant zero)
    seen=set();out=[]
    for r in radial_solutions:
        key=(r['P1'],r['P2'],r['P3'],r['Q0'])
        if key not in seen: seen.add(key);out.append(r)
    return (c1,c2,c3,B),out

def parse_b3000():
    pat=re.compile(r'^(\d+),(\d+),(\d+),(\d+) A(\d+) W(\d+) u(\d+) g1(\d+) n(\d+) d(-?\d+) m(\d+) k(\d+) g(\d+) (\S+)$')
    rows=[]
    for line in FASTLOG.read_text(encoding='utf-8').splitlines():
        mm=pat.match(line)
        if not mm: continue
        v=list(map(int,mm.groups()[:13]))
        P1,P2,P3,Q,A,W,u,g1,n,delta,m,k,g=v
        rows.append(dict(P1=P1,P2=P2,P3=P3,Q0=Q,A=A,W=W,u=u,g1=g1,n=n,delta=delta,m=m,k=k,g=g,bounded_death=mm.group(14)))
    return rows

def write_csv(path,rows):
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields:fields.append(k)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

# R27 historical hit #2 is outside E27 but mandatory for five-hit autopsy.
HIST2=dict(P1=200,P2=365,P3=104,Q0=429,A=13,W=1,u=1,g1=40,n=1,delta=2,m=1,k=1,g=1,bounded_death='MU_SMITH',source='R27_HISTORICAL_OUTSIDE_E27')

def main():
    bounded=parse_b3000()
    if len(bounded)!=37: raise AssertionError(len(bounded))
    # Exact B3000 hit registry.
    hitrows=[]
    for i,r in enumerate(bounded):
        rr=dict(index=i,scope='E27_Q0_LE_3000_COMPLETE_IN_BOUND');rr.update(r);hitrows.append(rr)
    write_csv(ROOT/'105-R28-TC1-hit-registry.csv',hitrows)

    # Unique architecture list from B3000, plus historical H2.
    keys=('A','W','u','g1','n','delta','m','k','g')
    archmap=OrderedDict()
    for r in bounded+[HIST2]:
        key=tuple(r[k] for k in keys)
        archmap.setdefault(key,[]).append(r)
    reg=[];pointreg=[]
    for idx,(key,obs) in enumerate(archmap.items()):
        arch=dict(zip(keys,key)); hp,sol=classify_arch(arch)
        c1,c2,c3,B=hp
        rid=f'ARCH_{idx:02d}'
        reg.append(dict(architecture_id=rid,A=arch['A'],W=arch['W'],u0=arch['u'],g1star=arch['g1'],n=arch['n'],delta=arch['delta'],m=arch['m'],k=arch['k'],g=arch['g'],
            hyperplane_c1=c1,hyperplane_c2=c2,hyperplane_c3=c3,hyperplane_B=B,
            observed_bounded_hits=len(obs),global_positive_radial_conic_points=len(sol),global_R24_support_points=sum(s['first_support_death']=='R24_SUPPORT_PASS' for s in sol),
            verdict='GLOBAL_FIXED_ARCH_SUPPORT_EXTINCT' if not any(s['first_support_death']=='R24_SUPPORT_PASS' for s in sol) else 'FIXED_ARCH_SUPPORT_SURVIVOR'))
        for j,s in enumerate(sol):
            q=dict(architecture_id=rid,point_index=j);q.update(s);pointreg.append(q)
    write_csv(ROOT/'105-R28-observed-architecture-registry.csv',reg)
    write_csv(ROOT/'105-R28-observed-architecture-support-points.csv',pointreg)

    # Exact rejection aggregate for bounded B3000 hits.
    cnt={}
    for r in bounded:cnt[r['bounded_death']]=cnt.get(r['bounded_death'],0)+1
    write_csv(ROOT/'105-R28-TC1-rejection-registry.csv',[dict(reason=k,count=v,scope='E27_Q0_LE_3000_COMPLETE_IN_BOUND') for k,v in sorted(cnt.items())])

    # Mandatory five-history autopsy exact signatures.
    hist=[
      dict(id='R27_H1',P1=20,P2=120,P3=123,Q0=173,A=1,W=2,u=1,g1=10,n=2,delta=0,m=1,k=1,g=0,death='POSITIVE_RADIAL_BOX'),
      dict(id='R27_H2',P1=200,P2=365,P3=104,Q0=429,A=13,W=1,u=1,g1=40,n=1,delta=2,m=1,k=1,g=1,death='MU_SMITH'),
      dict(id='R27_H3',P1=48,P2=436,P3=75,Q0=445,A=3,W=4,u=1,g1=24,n=1,delta=1,m=1,k=1,g=0,death='POSITIVE_RADIAL_BOX'),
      dict(id='R27_H4',P1=435,P2=160,P3=168,Q0=493,A=3,W=2,u=2,g1=435,n=1,delta=1,m=1,k=1,g=0,death='SHAPE_GCD'),
      dict(id='R27_H5',P1=435,P2=160,P3=168,Q0=493,A=6,W=4,u=1,g1=435,n=1,delta=1,m=1,k=1,g=0,death='SHAPE_GCD'),
    ]
    aut=[]
    for h in hist:
        P1,P2,P3,Q,A,W,u,g1,n,delta,m,k,g=(h[x] for x in ('P1','P2','P3','Q0','A','W','u','g1','n','delta','m','k','g'))
        X,Y,G,K=10**m,10**n,10**g,10**k;T=Q-P3;D=K*P1-Q;H=G*Q-P2
        R=(W*g1*T)//(A*Y)-g1*P2
        S=W*u*P1*10**(m+k)-Q*(W*u*10**m+g1)
        hp=primitive_hyperplane(A,W,u,g1,n,m,k,g)
        L=W+A*Y*G
        if L%u: raise AssertionError
        ell=L//u
        C2=P2//(u*W);C3=P3//(u*A);g0=math.gcd(u*A*W,P1);mu=g1//g0
        a0=A*W//g0; omega=Q*ell-A*W*(C3+Y*C2); mu_rhs=a0*X*Y*G*D
        if mu*omega!=mu_rhs: raise AssertionError
        aut.append(dict(id=h['id'],P1=P1,P2=P2,P3=P3,Q0=Q,A=A,W=W,u0=u,g1star=g1,n=n,delta=delta,m=m,k=k,g=g,rho=m+k,
            D=D,H=H,Tminus=T,R=R,S=S,TC1_exact=int(R==G*S),selector_ratio_gcd=math.gcd(g1,u),
            u_divides_W_plus_AYG=int(L%u==0),ell=ell,C2=C2,C3=C3,g0=g0,mu=mu,a0=a0,Omega_mu=omega,mu_core_rhs=mu_rhs,mu_core_exact=int(mu*omega==mu_rhs),mu_C2C3_gcd=math.gcd(mu,C2*C3),
            hyperplane=f'{hp[0]}*P1+{hp[1]}*P2+{hp[2]}*P3={hp[3]}*Q0',first_death=h['death']))
    write_csv(ROOT/'105-R28-historical-hit-autopsy.csv',aut)

    # hard assertions central to certificate
    assert sum(r['global_R24_support_points'] for r in reg)==0
    assert len(pointreg)==4  # H2 outside E27 adds its one point; B3000 contributes 3 points.
    print(f'B3000_RAW_HITS={len(bounded)}')
    print(f'UNIQUE_ARCHITECTURES_WITH_HISTORICAL_H2={len(reg)}')
    print(f'GLOBAL_POSITIVE_RADIAL_CONIC_POINTS_ACROSS_THESE_ARCHITECTURES={len(pointreg)}')
    print(f'GLOBAL_R24_SUPPORT_POINTS_ACROSS_THESE_ARCHITECTURES={sum(r["global_R24_support_points"] for r in reg)}')
    print('ALL_ASSERTIONS=PASS')

if __name__=='__main__':main()
