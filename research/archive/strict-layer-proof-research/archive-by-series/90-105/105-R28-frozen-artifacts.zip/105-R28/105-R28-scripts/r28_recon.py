#!/usr/bin/env python3
from __future__ import annotations
import csv, math, time, argparse
from collections import defaultdict, Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DIVCACHE={}
def vp(n,p):
    if n==0:return 10**9
    e=0
    while n%p==0:n//=p;e+=1
    return e

def divisors(n):
    if n in DIVCACHE:return DIVCACHE[n]
    lo=[];hi=[]
    r=math.isqrt(n)
    for d in range(1,r+1):
        if n%d==0:
            lo.append(d)
            if d*d!=n:hi.append(n//d)
    out=lo+hi[::-1];DIVCACHE[n]=out;return out

def gcd4(a,b,c,d):return math.gcd(math.gcd(a,b),math.gcd(c,d))
def ceildiv(a,b):return (a+b-1)//b

def primitive_packets(B):
    sums=defaultdict(list)
    for x in range(1,B):
        xx=x*x
        for y in range(1,B):
            s=xx+y*y
            if s<B*B:sums[s].append((x,y))
    for q in range(2,B+1):
        qq=q*q
        for z in range(1,q):
            s=qq-z*z
            for x,y in sums.get(s,()):
                if x<q and y<q and gcd4(x,y,z,q)==1:
                    yield x,y,z,q

def cap(P1,P2,P3,Q,p):
    T=Q-P3;x,y,z,t=vp(P1,p),vp(P2,p),vp(P3,p),vp(T,p)
    if y>=z:return t+x+y-z
    return t+min(x,y)+max(0,x-z)

def arch(pi):
    P1,P2,P3,Q=pi;return P1*P2*(Q-P3)>10*P3

def delta_set(M,N):
    # exact; at most 2 integers
    L=max(len(str(M)),len(str(N)))+3
    out=[]
    for d in range(-L,L+1):
        if d-1>=0: low=M>N*10**(d-1)
        else: low=M*10**(1-d)>N
        if d+1>=0: high=M<N*10**(d+1)
        else: high=M*10**(-d-1)<N
        if low and high:out.append(d)
    return out

def support(pi,A,W,u0,g1,n,delta,m,k,g):
    P1,P2,P3,Q=pi;X=10**m;Y=10**n;G=10**g;K=10**k;T=Q-P3
    D=K*P1-Q;H=G*Q-P2
    J=u0*A*X*Y*G*D-g1*T
    NW=g1*A*Y*H
    base=dict(D=D,H=H,J=J,NW=NW)
    # TC1 guarantees W*J=NW and hence these three gates.
    if J<=0 or W*J!=NW:return False,'TC1_RECON_INTERNAL_FAIL',base
    C2=P2//(u0*W);C3=P3//(u0*A);Mr=P2//W;Nr=P3//A
    base.update(C2=C2,C3=C3,Mr=Mr,Nr=Nr)
    if math.gcd(A,C2)!=1 or math.gcd(W,C3)!=1 or math.gcd(A,W)!=1:
        return False,'SHAPE_GCD',base
    n2=m+k+g
    Ulo=max(ceildiv(10**(n2-1),C2),ceildiv(10**(n-1),C3))
    Uhi=min((10**n2-1)//C2,(10**n-1)//C3)
    base.update(n2=n2,Ulo=Ulo,Uhi=Uhi)
    if Ulo>Uhi:return False,'POSITIVE_RADIAL_BOX',base
    g0=math.gcd(u0*A*W,P1);base['g0']=g0
    if g1%g0:return False,'MASTER_G0',base
    mu=g1//g0;base['mu']=mu
    if math.gcd(mu,C2*C3)!=1:return False,'MU_SMITH',base
    lam=Y//math.gcd(Y,W*T);tau=lam//math.gcd(lam,mu);R1=P1//g1
    base.update(lambda_z=lam,tau=tau,R1=R1)
    if math.gcd(tau,R1)!=1:return False,'TAIL_G1',base
    if math.gcd(tau,C2*C3)!=1:return False,'TAIL_SMITH',base
    return True,'R24_SUPPORT_PASS',base

def csvwrite(path,rows):
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields:fields.append(k)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--bound',type=int,default=500);ap.add_argument('--all-tc1',action='store_true');args=ap.parse_args();B=args.bound
    t0=time.time();packs=0;e27=0;awlabels=0;exprec=0;raw=[];supporthits=[];deaths=Counter();gapctr=Counter();ratioctr=Counter()
    for pi in primitive_packets(B):
        packs+=1;P1,P2,P3,Q=pi;T=Q-P3
        is_e27=(cap(*pi,2)>=1 and cap(*pi,5)>=1 and arch(pi))
        if is_e27:e27+=1
        if (not args.all_tc1) and (not is_e27):continue
        for A in divisors(P3):
            # safe n upper uses g1<=P1; if A p-content exceeds numerator no n.
            for W in divisors(P2):
                awlabels+=1
                M=P2//W;N=P3//A;ds=delta_set(M,N)
                if not ds:continue
                nmax=min(vp(W*P1*T,2)-vp(A,2),vp(W*P1*T,5)-vp(A,5))
                if nmax<1:continue
                common=math.gcd(M,N)
                for n in range(1,nmax+1):
                    Y=10**n
                    for delta in ds:
                        s=n+delta
                        if s<2:continue
                        # m+k+g=s, m,k>=1,g>=0
                        for m in range(1,s):
                            X=10**m
                            for k in range(1,s-m+1):
                                g=s-m-k
                                if g<0:continue
                                exprec+=1;G=10**g;K=10**k
                                D=K*P1-Q
                                if D<=0:continue
                                H=G*Q-P2 # >0 for G>=1 since Q>P2
                                num=A*W*X*Y*G*D
                                den=W*T+A*Y*H
                                c=math.gcd(num,den);g1=num//c;u0=den//c
                                # Primitive selector theorem: gcd(g1,u0)=1 and these are unique.
                                if P1%g1 or common%u0:continue
                                # TC1 exact audit and frozen n-divisibility implied but assert.
                                if g1*(W*T+A*Y*H)!=A*W*u0*X*Y*G*D:raise AssertionError
                                if (W*g1*T)%(A*Y):raise AssertionError
                                ok,reason,data=support(pi,A,W,u0,g1,n,delta,m,k,g)
                                rho=m+k
                                E=(W*g1*T)//(A*Y)
                                R=E-g1*P2
                                S=W*u0*P1*10**rho-Q*(W*u0*10**m+g1)
                                if R!=G*S:raise AssertionError
                                row=dict(P1=P1,P2=P2,P3=P3,Q0=Q,A=A,W=W,u0=u0,g1star=g1,
                                    n=n,delta=delta,rho=rho,m=m,g=g,k=k,E=E,R=R,S=S,
                                    ratio_num=g1,ratio_den=u0,R24_support_pass=int(ok),rejection_or_pass=reason)
                                row.update(data);raw.append(row);deaths[reason]+=1;gapctr[(m,k,g,n,delta)]+=1
                                ratioctr[(g1,u0)]+=1
                                if ok:supporthits.append(row)
    csvwrite(ROOT/f'105-R28-TC1-hit-registry-B{B}.csv',raw)
    rej=[dict(reason=k,count=v) for k,v in deaths.most_common()]
    csvwrite(ROOT/f'105-R28-TC1-rejection-registry-B{B}.csv',rej)
    gaps=[dict(m=k[0],k=k[1],g=k[2],n=k[3],delta=k[4],count=v) for k,v in gapctr.most_common()]
    csvwrite(ROOT/f'105-R28-gap-signatures-B{B}.csv',gaps)
    log=(f'BOUND_Q0={B}\nORIENTED_PRIMITIVE_PACKETS={packs}\nE27_PACKETS={e27}\nAW_LABELS={awlabels}\nEXPONENT_RECORDS={exprec}\nRAW_TC1_HITS={len(raw)}\nRAW_TC1_HIT_PACKETS={len({(r["P1"],r["P2"],r["P3"],r["Q0"]) for r in raw})}\nR24_SUPPORT_PLUS_TC1={len(supporthits)}\nDEATHS={dict(deaths)}\nELAPSED_SECONDS={time.time()-t0:.6f}\nSELECTOR_RATIO_ELIMINATION_USED=YES\nG1_U0_UNIQUE_BY_PRIMITIVITY=YES\n')
    (ROOT/f'105-R28-execution-B{B}.log').write_text(log,encoding='utf-8')
    print(log)
    for r in raw[:30]:print(r)

if __name__=='__main__':main()
