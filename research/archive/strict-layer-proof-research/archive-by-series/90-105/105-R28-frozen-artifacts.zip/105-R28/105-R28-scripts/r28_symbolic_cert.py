#!/usr/bin/env python3
from __future__ import annotations
import csv, math
from pathlib import Path
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]

# Symbols
P1,P2,P3,Q,A,W,u,g1,X,Y,G,K,T=sp.symbols('P1 P2 P3 Q A W u g1 X Y G K T')
Tm=Q-P3;D=K*P1-Q;H=G*Q-P2
F=sp.expand(A*W*u*X*Y*G*D-g1*(W*Tm+A*Y*H))
Fexpanded=sp.expand(A*W*u*P1*X*Y*G*K-A*W*u*Q*X*Y*G-A*g1*Q*Y*G+A*g1*P2*Y-W*g1*(Q-P3))
assert sp.expand(F-Fexpanded)==0

# Hyperplane: BQ=c.P
c1=A*W*u*X*Y*G*K;c2=A*Y*g1;c3=W*g1
B=g1*W+A*Y*G*g1+A*W*u*X*Y*G
HYP=sp.expand(c1*P1+c2*P2+c3*P3-B*Q)
assert sp.expand(F-HYP)==0
# resultant with sphere
sphere=P1**2+P2**2+P3**2-Q**2
resQ=sp.factor(sp.resultant(HYP,sphere,Q))
expected=sp.expand((c1*P1+c2*P2+c3*P3)**2-B**2*(P1**2+P2**2+P3**2))
assert sp.expand(resQ+expected)==0

# Solve for Tminus using Q=P3+T and sphere in (P1,P2,T,Q) form.
L0=A*Y*G*(g1+W*u*X)
N0=A*W*u*X*Y*G*K*P1+g1*A*Y*P2
quad=sp.expand((L0+2*g1*W)*T**2-2*N0*T+L0*(P1**2+P2**2))
Nsym,Psym=sp.symbols('N0 Psum')
disc_core_symbolic=sp.factor(Nsym**2-L0*(L0+2*g1*W)*Psym)
disc_core=sp.factor(N0**2-L0*(L0+2*g1*W)*(P1**2+P2**2))
# On TC1+Q=P3+T, N0=(L0+g1W)T+L0P3, so discriminant core is a known square.
disc_square_witness=sp.expand(L0*P3-g1*W*T)
relation=sp.expand(N0-(L0+g1*W)*T-L0*P3)
# Verify algebraic identity modulo relation + sphere T(2Q-T)=P1²+P2² via substitution N0 relation.
check=sp.factor(disc_core_symbolic.subs({Nsym:(L0+g1*W)*T+L0*P3,Psym:T*(2*P3+T)})-disc_square_witness**2)
assert check==0

# F1 rational conic parameterization (line through R27 hit H1).
r,s=sp.symbols('r s', integer=True)
f1P1=60*(6767*r**2-80999*r*s+529833*s**2)
f1P2=-20*(21191*r**2-1966698*r*s+5863194*s**2)
f1P3=123*(20301*r**2-100000*r*s-977199*s**2)
f1Q=2565073*r**2-19242000*r*s+170904573*s**2
assert sp.expand(f1P1**2+f1P2**2+f1P3**2-f1Q**2)==0
assert sp.expand(1000*f1P1+50*f1P2+f1P3-151*f1Q)==0
f1T=sp.factor(f1Q-f1P3)
assert sp.expand(f1T-50*(1361*r**2-138840*r*s+5822001*s**2))==0

# Explicit infinite subsequence N=10j+3, r=16998N+1,s=947N+1.
N=sp.symbols('N', integer=True, positive=True)
rN=16998*N+1;sN=947*N+1
seq=[sp.expand(z.subs({r:rN,s:sN})) for z in (f1P1,f1P2,f1P3,f1Q)]
ineq1=sp.expand((5*f1P2-f1P3).subs({r:rN,s:sN}))  # P2/(2P3)>.1
ineq2=sp.expand((20*f1P3-f1P2).subs({r:rN,s:sN})) # P2/(2P3)<10
# Certificate text
lines=[]
lines.append('R28 SYMBOLIC ELIMINATION CERTIFICATE')
lines.append('F_TC1_EXPANDED='+str(Fexpanded))
lines.append('HYPERPLANE_IDENTITY='+str(HYP))
lines.append('RESULTANT_Q='+str(resQ))
lines.append('RESULTANT_INFORMATION_GAIN=0__EXACT_CONIC_ELIMINATION_ONLY')
lines.append('TMINUS_QUADRATIC='+str(quad))
lines.append('TMINUS_DISCRIMINANT_CORE='+str(disc_core))
lines.append('TMINUS_DISCRIMINANT_SQUARE_WITNESS='+str(disc_square_witness))
lines.append('DISCRIMINANT_INFORMATION_GAIN=0__SQUARE_WITNESS_FORCED_BY_TC1_PLUS_SPHERE')
lines.append('F1_P1='+str(f1P1));lines.append('F1_P2='+str(f1P2));lines.append('F1_P3='+str(f1P3));lines.append('F1_Q='+str(f1Q));lines.append('F1_TMINUS='+str(f1T))
lines.append('F1_SEQUENCE_N_RULE=N=10j+3;r=16998N+1;s=947N+1')
for nm,z in zip(('P1','P2','P3','Q'),seq):lines.append('F1_SEQUENCE_'+nm+'='+str(z))
lines.append('F1_DELTA_LOWER_POLY_5P2_MINUS_P3='+str(ineq1));lines.append('F1_DELTA_UPPER_POLY_20P3_MINUS_P2='+str(ineq2))
lines.append('ALL_SYMBOLIC_IDENTITIES=PASS')
(ROOT/'105-R28-symbolic-elimination.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# registries
with (ROOT/'105-R28-resultant-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['elimination','result','factorization','information_gain','status']);w.writeheader();
    w.writerow(dict(elimination='Res_Q(F_TC1,F_sphere)',result='(c.P)^2-B^2(P1^2+P2^2+P3^2)',factorization='generic ternary conic; no universal new factor',information_gain='0',status='EXACT_EQUIVALENT_ELIMINATION'))
with (ROOT/'105-R28-factorization-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['object','factorization','use','status']);w.writeheader();
    w.writerow(dict(object='F1_Tminus',factorization=str(f1T),use='proves 10^2 divides W*g1*T/A after primitive normalization with decimal-coprime gcd',status='PROVED'))
    w.writerow(dict(object='TC1_grouped',factorization='g1[W*T+A*Y*(GQ-P2)]=A*W*u*X*Y*G*(K*P1-Q)',use='positive-factor normal form; D>0',status='PROVED'))
print('ALL_SYMBOLIC_IDENTITIES=PASS')
