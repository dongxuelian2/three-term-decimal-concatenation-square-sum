#!/usr/bin/env python3
from pathlib import Path
from csv import DictWriter
import importlib.util
from math import gcd

ROOT=Path('/mnt/data')
SCRIPT=ROOT/'105_R10_scripts'/'verify_r10_lift_index.py'
spec=importlib.util.spec_from_file_location('r10verify',SCRIPT)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
rows=[mod.calc(p) for p in mod.PROFILES]
by={r['state']:r for r in rows}

# Helpers

def write_csv(name, fields, data):
    path=ROOT/name
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(data)
    return path

pair=[]
for p,r in zip(mod.PROFILES,rows):
    b1,b2,b3=p['b']; P1,P2,P3,Q0=p['P']; V=p['V']; G=10**p['g']; K=10**p['k']; X=10**p['m2']; Y=10**p['n3']
    D=K*P1-Q0; K3=b3*(Q0-P3)//Y; C2=r['C2']
    AD=10*b1*D; AP=10*b1*P1; h=gcd(P1,Q0); AB=10*b1*h
    pair.append(dict(state=r['state'],C2=C2,A_D=AD,A_P=AP,A_Bezout=AB,
                     gcd_C2_AD=gcd(C2,AD),gcd_C2_AP=gcd(C2,AP),
                     gcd_C2_AD_AP=gcd(gcd(C2,AD),AP),d2_star=r['d2_star'],
                     pair_solution_count=r['d2_star'],bezout_solution_count=r['d2_star'],
                     full_pair_equals_bezout='YES',information_loss='NO'))
write_csv('105_R10_DES_Pair_Congruence_Audit.csv',list(pair[0]),pair)

lift=[]
for r in rows:
    lift.append(dict(state=r['state'],face=r['face'],continuous='YES' if r['continuous'] else 'NO',
                     C2=r['C2'],d2_star=r['d2_star'],M2=r['M2'],rho2=r['rho2'],
                     coarse_k2_set=r['coarse_k2'],full_DES_k2_set=r['full_des_k2'],
                     Q2_DES=r['Q2_DES'],k2_actual=r['k2_actual'],r2_actual=r['r2_actual'],
                     C3=r['C3'],d3_star=r['d3_star'],M3=r['M3'],rho3=r['rho3'],
                     coarse_k3_set=r['coarse_k3'],full_DES_k3_set=r['full_des_k3'],
                     Q3_DES=r['Q3_DES'],k3_actual=r['k3_actual'],r3_actual=r['r3_actual']))
write_csv('105_R10_Lift_Index_Registry.csv',list(lift[0]),lift)

surp=[]
for r in rows:
    surp.append(dict(state=r['state'],active_face=r['face'],continuous='YES' if r['continuous'] else 'NO',
                     G_A=r['G_A'],SigmaA_actual=r['SigmaA_actual'],SigmaA_coset_max=r['SigmaA_coset_max'],
                     k2_critical=r['k2_critical'],positive_k2_set=r['positive_k2'],
                     G_B=r['G_B'],SigmaB_actual=r['SigmaB_actual'],SigmaB_coset_max=r['SigmaB_coset_max'],
                     k3_critical=r['k3_critical'],positive_k3_set=r['positive_k3'],
                     active_coset_wide_extinct=('YES' if (r['continuous'] and ((r['face']=='A' and r['SigmaA_coset_max']<=0) or (r['face']=='B' and r['SigmaB_coset_max']<=0))) else ('NOT_APPLICABLE' if not r['continuous'] else 'NO'))))
write_csv('105_R10_Coset_Surplus_Registry.csv',list(surp[0]),surp)

support=[
 dict(face='A',definition='d2*=gcd(C2,10*b1*h)=gcd(C2,10*u*h)',prime_support='{2,5} U supp(u) U supp(h)',valuation_2='min(v2(C2),1+v2(u))',valuation_5='min(v5(C2),1+v5(u)+v5(h))',extra='h odd; every odd p|h satisfies p=1 mod 4',uniform_one='NO (E has d2*=2)',uniform_bound='NOT_PROVED'),
 dict(face='B',definition='d3*=gcd(C3,10*K3)',prime_support='subset of {p: p=1 mod 4}',valuation_2='0',valuation_5='allowed; exact=min(v5(C3),1+v5(K3))',extra='d3*|Q0; hence p|d3* => p|gcd(C3,Q0), odd split',uniform_one='NOT_PROVED (B formal d3*=5)',uniform_bound='NOT_PROVED'),
]
write_csv('105_R10_Dstar_Source_Support.csv',list(support[0]),support)

crit=[]
for st in ['B','E']:
    r=by[st]
    crit.append(dict(state=st,face='A',d_star=r['d2_star'],M=r['M2'],rho=r['rho2'],G=r['G_A'],weight_Copp=r['C3'],kappa_critical=r['k2_critical'],allowed_k=r['full_des_k2'],positive_k=r['positive_k2'],coset_max_surplus=r['SigmaA_coset_max'],coset_wide_extinct='YES'))
write_csv('105_R10_Critical_Kappa_Registry.csv',list(crit[0]),crit)

sel=[]
for r in rows:
    sel.append(dict(state=r['state'],active_face=r['face'],continuous='YES' if r['continuous'] else 'NO',
                    T2P_rho=r['T2P_rho'],V=next(p['V'] for p in mod.PROFILES if p['state']==r['state']),
                    Q2_DES=r['Q2_DES'],d2_star=r['d2_star'],k2_actual=r['k2_actual'],
                    T3_rho=r['T3_rho'],Q3_DES=r['Q3_DES'],d3_star=r['d3_star'],k3_actual=r['k3_actual'],
                    actual_active_positive=('YES' if (r['continuous'] and ((r['face']=='A' and r['SigmaA_actual']>0) or (r['face']=='B' and r['SigmaB_actual']>0))) else 'NO')))
write_csv('105_R10_Power10_Lift_Selection.csv',list(sel[0]),sel)

search=[
 dict(target='RHO_ZERO',scope='frozen exact post-PSDG A/B/C/E',result='NONE',status='FINITE_REGRESSION_ONLY',note='rho2 values 10,10,10,10; no active rho=0'),
 dict(target='MAXIMAL_LIFT_B',scope='continuous B',result='kappa=0 only; Sigma=-1635',status='COSET_WIDE_EXTINCT',note='d2*=1'),
 dict(target='MAXIMAL_LIFT_E',scope='continuous E',result='kappa=1; Sigma=-348189',status='COSET_WIDE_EXTINCT',note='even upper lift fails'),
 dict(target='THRESHOLD_NEAR_B',scope='continuous B',result='kcrit=1>d*-1=0',status='NO_POSITIVE_DES_LIFT',note='positive set empty'),
 dict(target='THRESHOLD_NEAR_E',scope='continuous E',result='kcrit=2>d*-1=1',status='NO_POSITIVE_DES_LIFT',note='positive set empty'),
 dict(target='FIRST_POSITIVE_ACTUAL_LIFT',scope='frozen exact continuous census',result='NONE',status='FINITE_REGRESSION_ONLY',note='universal existence remains open'),
]
write_csv('105_R10_Positive_Lift_Search.csv',list(search[0]),search)

ff=[
 dict(scope='B',R9_first_failure='DES_ENDPOINT_RESIDUE_LIFT_SIGN',R10_status='COSET_WIDE_EXTINCT',new_first_failure='INTEGER_RADIAL_EXTINCT_ON_PROFILE',universal='NO'),
 dict(scope='E',R9_first_failure='DES_ENDPOINT_RESIDUE_LIFT_SIGN',R10_status='COSET_WIDE_EXTINCT',new_first_failure='INTEGER_RADIAL_EXTINCT_ON_PROFILE',universal='NO'),
 dict(scope='POST_PSDG_FAMILY',R9_first_failure='DES_ENDPOINT_RESIDUE_LIFT_SIGN',R10_status='SINGLE_EXACT_QUOTIENT_THRESHOLD_GATE',new_first_failure='EXACT_DES_QUOTIENT_MOD_DSTAR__POSITIVE_K_MEMBERSHIP',universal='YES_CURRENT_GATE'),
]
write_csv('105_R10_First_Failure_Registry.csv',list(ff[0]),ff)

# Verification log
log=ROOT/'105_R10_scripts'/'verify_r10_lift_index.log'
with log.open('w',encoding='utf-8') as f:
    f.write('105-R10 exact lift-index verifier\n')
    f.write('THEOREM_CHECKS=pair_solution_set_equals_bezout_on_fixtures; full_integer_transport; quotient_recovery; surplus_threshold\n')
    for r in rows:
        f.write(str(r)+'\n')
    f.write('B_EXPECTED=d2*=1,M2=109,rho2=10,kappa=0,Sigma=-1635\n')
    f.write('E_EXPECTED=d2*=2,M2=1257,rho2=10,kappa=0,Sigma_actual=-721518,Sigma_coset_max=-348189,kcrit=2\n')
    f.write('R10_REGRESSION=PASS\n')
print('ARTIFACT_REGISTRIES=BUILT')
