#!/usr/bin/env python3
from math import gcd
from fractions import Fraction
from csv import DictWriter
from pathlib import Path

OUT=Path('/mnt/data')

PROFILES=[
    dict(state='A', b=(1,6,8), P=(24,52,159,169), V=24, n2=2,n3=1,m2=1,m3=1,k=1,g=0),
    dict(state='B', b=(1,6,8), P=(48,436,75,445), V=24, n2=2,n3=1,m2=1,m3=1,k=1,g=0),
    dict(state='C', b=(1,6,8), P=(456,292,2907,2957), V=24, n2=2,n3=1,m2=1,m3=1,k=1,g=0),
    dict(state='E', b=(5,5,1), P=(298,2514,1485,2935), V=5, n2=2,n3=1,m2=1,m3=1,k=1,g=0),
]

def egcd(a,b):
    if b==0: return (abs(a), 1 if a>=0 else -1, 0)
    g,x1,y1=egcd(b,a%b)
    return g,y1,x1-(a//b)*y1

def invmod(a,m):
    if m==1: return 0
    g,x,_=egcd(a,m)
    assert g==1
    return x%m

def cong_solutions(a,e,C):
    return [x for x in range(C) if (a*x-e)%C==0]

def crit_rho_positive(Gap,W,d,M,rho):
    assert rho>0
    N=W*(d*M-rho)-Gap
    return N//(W*M)+1

def calc(p):
    st=p['state']; b1,b2,b3=p['b']; P1,P2,P3,Q0=p['P']; V=p['V']
    n2,n3,m2,k,g=p['n2'],p['n3'],p['m2'],p['k'],p['g']
    G,K,X,Y=10**g,10**k,10**m2,10**n3
    C1=P1//gcd(V,P1); C2=P2//gcd(V,P2); C3=P3//gcd(V,P3)
    D=K*P1-Q0
    H=b2*Q0-b1*X*D
    K3=b3*(Q0-P3)//Y
    assert b2*P2==G*H+K3==V*C2
    assert b3*P3==V*C3
    x2=10**(n2-1); x3=10**(n3-1)

    # Face A pair transports, exact integer versions.
    A_D=10*b1*D
    E_D=K*(G*b2*Q0+K3)
    assert A_D*x2==E_D-K*V*C2
    A_P=10*b1*P1
    E_P=G*(b1*X+b2)*Q0+K3
    assert A_P*x2==E_P-V*C2
    h=gcd(P1,Q0)
    assert h==gcd(P1,D)
    gh,s,t=egcd(D,P1)
    assert gh==h and s*D+t*P1==h
    A_B=10*b1*h
    E_B=s*E_D+t*E_P
    assert A_B*x2==E_B-(s*K+t)*V*C2
    d2=gcd(C2,A_B); M2=C2//d2
    assert E_B%d2==0
    rho2=((E_B//d2)*invmod(A_B//d2,M2))%M2 if M2>1 else 0
    assert (x2-rho2)%M2==0
    pair=set(cong_solutions(A_D,E_D,C2)) & set(cong_solutions(A_P,E_P,C2))
    bez=set(cong_solutions(A_B,E_B,C2))
    assert pair==bez and len(pair)==d2
    coarse2={rho2+j*M2 for j in range(d2)}
    assert pair==coarse2
    kset2=list(range(d2))
    k2=((x2-rho2)//M2)%d2 if d2>1 else 0
    r2=x2%C2
    assert r2==rho2+k2*M2
    T2P=(E_P-A_P*rho2)//C2
    assert E_P-A_P*rho2==T2P*C2
    assert (T2P-V)%(A_P//d2)==0
    Q2=(T2P-V)//(A_P//d2)
    assert Q2==(x2-rho2)//M2 and k2==Q2%d2
    T2D=(E_D-A_D*rho2)//C2
    assert (T2D-K*V)%(A_D//d2)==0
    assert (T2D-K*V)//(A_D//d2)==Q2

    # Face B single transport, exact integer version.
    A3=10*K3; E3=b3*Q0
    assert A3*x3==E3-V*C3
    d3=gcd(C3,A3); M3=C3//d3
    assert E3%d3==0
    rho3=((E3//d3)*invmod(A3//d3,M3))%M3 if M3>1 else 0
    assert (x3-rho3)%M3==0
    s3=set(cong_solutions(A3,E3,C3))
    coarse3={rho3+j*M3 for j in range(d3)}
    assert s3==coarse3 and len(s3)==d3
    k3=((x3-rho3)//M3)%d3 if d3>1 else 0
    r3=x3%C3
    assert r3==rho3+k3*M3
    T3=(E3-A3*rho3)//C3
    assert (T3-V)%(A3//d3)==0
    Q3=(T3-V)//(A3//d3)
    assert Q3==(x3-rho3)//M3 and k3==Q3%d3

    L2=Fraction(x2,C2); L3=Fraction(x3,C3)
    L=max(L2,L3); R=min(10*L2,10*L3)
    face='A' if L2>=L3 else 'B'
    continuous=L<R
    GA=C2*10**n3-C3*x2
    GB=C3*10**n2-C2*x3
    delta2=0 if r2==0 else C2-r2
    delta3=0 if r3==0 else C3-r3
    sigA=GA-C3*delta2
    sigB=GB-C2*delta3

    if rho2==0:
        maxsigA=GA
        minjump2=0
        pos2=[0]+[kk for kk in range(1,d2) if GA-C3*((d2-kk)*M2)>0]
        kcrit2='RHO_ZERO_PIECEWISE'
    else:
        maxsigA=GA-C3*(M2-rho2)
        minjump2=M2-rho2
        kc2=crit_rho_positive(GA,C3,d2,M2,rho2)
        pos2=[kk for kk in range(d2) if kk>=max(kc2,0) and GA-C3*(d2*M2-rho2-kk*M2)>0]
        kcrit2=kc2
    if rho3==0:
        maxsigB=GB
        minjump3=0
        pos3=[0]+[kk for kk in range(1,d3) if GB-C2*((d3-kk)*M3)>0]
        kcrit3='RHO_ZERO_PIECEWISE'
    else:
        maxsigB=GB-C2*(M3-rho3)
        minjump3=M3-rho3
        kc3=crit_rho_positive(GB,C2,d3,M3,rho3)
        pos3=[kk for kk in range(d3) if kk>=max(kc3,0) and GB-C2*(d3*M3-rho3-kk*M3)>0]
        kcrit3=kc3

    return dict(
        state=st,C2=C2,C3=C3,face=face,continuous=continuous,
        x2=x2,D=D,H=H,K3=K3,h=h,
        d2_star=d2,M2=M2,rho2=rho2,coarse_k2=str(kset2),full_des_k2=str(kset2),
        k2_actual=k2,Q2_DES=Q2,T2P_rho=T2P,r2_actual=r2,delta2=delta2,G_A=GA,
        SigmaA_actual=sigA,SigmaA_coset_max=maxsigA,k2_critical=str(kcrit2),positive_k2=str(pos2),
        d3_star=d3,M3=M3,rho3=rho3,coarse_k3=str(list(range(d3))),full_des_k3=str(list(range(d3))),
        k3_actual=k3,Q3_DES=Q3,T3_rho=T3,r3_actual=r3,delta3=delta3,G_B=GB,
        SigmaB_actual=sigB,SigmaB_coset_max=maxsigB,k3_critical=str(kcrit3),positive_k3=str(pos3),
        L=str(L),R=str(R),
        pair_eq_bezout=True,
    )

if __name__=='__main__':
    rows=[calc(p) for p in PROFILES]
    for r in rows:
        print(r)
    # exact regression expectations
    B=next(r for r in rows if r['state']=='B')
    E=next(r for r in rows if r['state']=='E')
    assert (B['d2_star'],B['M2'],B['rho2'],B['k2_actual'],B['SigmaA_actual'],B['SigmaA_coset_max'],B['k2_critical'])==(1,109,10,0,-1635,-1635,'1')
    assert (E['d2_star'],E['M2'],E['rho2'],E['k2_actual'],E['SigmaA_actual'],E['SigmaA_coset_max'],E['k2_critical'])==(2,1257,10,0,-721518,-348189,'2')
    assert B['positive_k2']=='[]' and E['positive_k2']=='[]'
    print('R10_REGRESSION=PASS')
