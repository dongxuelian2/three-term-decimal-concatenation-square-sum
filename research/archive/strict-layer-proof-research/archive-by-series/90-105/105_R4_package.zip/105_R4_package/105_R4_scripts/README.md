# 105-R4 scripts

## verify_r4_fixed_incidence.py

Exact symbolic checks for four R4 claims:

1. `(2,3,6,7)` gives the normalized primitive sphere point `(2/7,3/7,6/7)`.
2. The explicit denominator coordinate
   `b3 = X*Y*G*(2*K-7) + Y*(3-7*G)`
   annihilates the normalized master identically when `b1=b2=1`.
3. The outer exponent map `(g,k,d,n3)->(g,k,g+d,n3)` has determinant 1.
4. `(G-1)(X-G)(X-10G)` is a nonzero Laurent polynomial and therefore defines a proper fixed union.

The script does **not** infer source-semantic conclusions from finite computation.
