#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
static string s128(i128 x){if(x==0)return"0";string s;bool neg=x<0;if(neg)x=-x;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
static vector<i64> divisors(i64 n){vector<i64>a,b;for(i64 d=1;d*d<=n;d++)if(n%d==0){a.push_back(d);if(d*d!=n)b.push_back(n/d);}reverse(b.begin(),b.end());a.insert(a.end(),b.begin(),b.end());return a;}
static int digits(i64 n){int d=0;do{d++;n/=10;}while(n);return d;} static i64 p10(int e){i64 x=1;while(e--)x*=10;return x;}
static i64 gcd128(i128 a,i64 b){i64 r=(i64)(a%b);if(r<0)r=-r;return gcd(r,b);} 
static map<i64,int> factor(i64 n){map<i64,int>f;for(i64 d=2;d*d<=n;d+=(d==2?1:2))while(n%d==0){f[d]++;n/=d;}if(n>1)f[n]++;return f;}
static i64 radial_part(i64 n,i64 c){i64 out=1;for(auto [p,e]:factor(n))if(c%p==0)while(e--)out*=p;return out;}
int main(int argc,char**argv){int pmin=51,pmax=100,mmax=400,nmax=200;if(argc>1)pmin=stoi(argv[1]);if(argc>2)pmax=stoi(argv[2]);if(argc>3)mmax=stoi(argv[3]);if(argc>4)nmax=stoi(argv[4]);
cout<<"P_PARAM,M,N,PERM,P1,P2,P3,Q0,A,W,C2,C3,N3,D,GSTAR,G0,MU,H,DM,RM,MSRC,OMEGA,NM,DELTA_RAD,MU_SMITH_PASS\n";
unsigned long long triples=0,orients=0,full=0,smith=0,oddP1full=0;
for(i64 pp=pmin;pp<=pmax;pp++)for(i64 m=1;m<=mmax;m++){i64 e1=2*m*pp;auto d1=divisors(e1);for(i64 n=1;n<=nmax;n++){triples++;i64 l[3]={e1,2*n*pp,m*m+n*n-pp*pp}; if(l[2]<=0)continue;i64 q=m*m+n*n+pp*pp;if(gcd(gcd(l[0],l[1]),gcd(l[2],q))!=1)continue;int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
for(int pi=0;pi<6;pi++){i64 P1=l[perms[pi][0]],P2=l[perms[pi][1]],P3=l[perms[pi][2]];i64 D=10*P1-q;if(D<=0)continue;orients++;auto tdiv=(perms[pi][0]==0?d1:divisors(P1));i64 T2=q-P2,T3=q-P3;if(T2<=0||T3<=0)continue;
for(i64 A=1;A<=12;A++){if(P3%A)continue;i64 C3=P3/A;int n3=digits(C3);i64 Y=p10(n3);for(i64 t:tdiv){i128 den=(i128)A*10*Y*D-(i128)t*T3;if(den<=0)continue;i128 num=(i128)t*A*Y*T2;if(num%den)continue;i128 wi=num/den;if(wi<=0||wi>LLONG_MAX)continue;i64 W=(i64)wi;if(P2%W)continue;i64 C2=P2/W;if(C2<10||C2>99)continue;if(gcd(A,C2)!=1||gcd(W,C3)!=1||gcd(A,W)!=1)continue;i64 g0=gcd(A*W,P1);if(t%g0||P1%t)continue;i128 Om=(i128)W*T3+(i128)A*Y*T2;i128 NM=(i128)A*W*10*Y*D;if(Om<=0||NM%Om||NM/Om!=t)continue;i64 h=gcd(P1,q),delta=D/h;if(Om%delta)continue;i64 dM=gcd128(NM,P1);if(dM%t||dM%g0)continue;i64 RM=dM/g0,ms=dM/t,mu=t/g0;if(RM%ms||RM/ms!=mu)continue;i128 L=(i128)A*W*10*Y;i64 p=P1/h,s=gcd((i64)(L%p),p);i128 E=L/s,OD=Om/delta;if(OD%E||OD/E!=ms)continue;full++;if(P1%2)oddP1full++;i64 cp=C2*C3,dr=radial_part(mu,cp);bool pass=gcd(mu,cp)==1;if(pass)smith++;cout<<pp<<','<<m<<','<<n<<','<<pi<<','<<P1<<','<<P2<<','<<P3<<','<<q<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<n3<<','<<D<<','<<t<<','<<g0<<','<<mu<<','<<h<<','<<dM<<','<<RM<<','<<ms<<','<<s128(Om)<<','<<s128(NM)<<','<<dr<<','<<(pass?1:0)<<"\n";}
}
}
}}
cerr<<"p="<<pmin<<".."<<pmax<<" m<="<<mmax<<" n<="<<nmax<<" triples="<<triples<<" Dpos_orients="<<orients<<" full="<<full<<" oddP1full="<<oddP1full<<" smith="<<smith<<"\n";
}
