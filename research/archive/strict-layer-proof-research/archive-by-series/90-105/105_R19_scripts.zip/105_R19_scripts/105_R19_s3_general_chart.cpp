#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
static vector<i64> divs(i64 n){vector<i64>a,b;for(i64 d=1;d*d<=n;d++)if(n%d==0){a.push_back(d);if(d*d!=n)b.push_back(n/d);}reverse(b.begin(),b.end());a.insert(a.end(),b.begin(),b.end());return a;}
static int digs(i64 n){int d=0;do{d++;n/=10;}while(n);return d;} static i64 p10(int e){i64 x=1;while(e--)x*=10;return x;}
static i64 gcd128(i128 a,i64 b){i64 r=(i64)(a%b);if(r<0)r=-r;return gcd(r,b);} static string s128(i128 x){if(!x)return"0";string s;bool neg=x<0;if(neg)x=-x;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
static i64 radpart(i64 n,i64 c){i64 out=1;for(i64 d=2;d*d<=n;d+=(d==2?1:2)){int e=0;while(n%d==0){n/=d;e++;}if(e&&c%d==0)while(e--)out*=d;}if(n>1&&c%n==0)out*=n;return out;}
int main(int argc,char**argv){int pmin=51,pmax=100,mmax=500,nmax=300,n2max=4;if(argc>1)pmin=stoi(argv[1]);if(argc>2)pmax=stoi(argv[2]);if(argc>3)mmax=stoi(argv[3]);if(argc>4)nmax=stoi(argv[4]);if(argc>5)n2max=stoi(argv[5]);
cout<<"P_PARAM,M,N,N2,N3,G_EXP,K_EXP,M2,M3,A,W,C2,C3,P1,P2,P3,Q0,D,GSTAR,G0,MU,H,DM,RM,MSRC,OMEGA,NM,DELTA_RAD,MU_SMITH_PASS\n";
unsigned long long triples=0, prim=0, full=0, smith=0;
for(i64 pp=pmin;pp<=pmax;pp++)for(i64 m=1;m<=mmax;m++){i64 P1=2*m*pp;auto td=divs(P1);for(i64 n=1;n<=nmax;n++){triples++;i64 P2=2*n*pp,P3=m*m+n*n-pp*pp;if(P3<=0)continue;i64 Q0=m*m+n*n+pp*pp;if(gcd(gcd(P1,P2),gcd(P3,Q0))!=1)continue;prim++;auto Ad=divs(P3);
for(int n2=2;n2<=n2max;n2++)for(int ge=0;ge<=n2-2;ge++)for(int ke=1;ke<=n2-ge-1;ke++){int m2=n2-ge-ke;if(m2<1)continue;i64 G=p10(ge),K=p10(ke),X=p10(m2);i64 D=K*P1-Q0;if(D<=0)continue;for(i64 A:Ad){if(A>=p10(m2))break;i64 C3=P3/A;int n3=digs(C3),m3=n3+ge;i64 Y=p10(n3);i64 T3=Q0-P3,T2=G*Q0-P2;if(T2<=0)continue;for(i64 t:td){i128 den=(i128)A*X*Y*G*D-(i128)t*T3;if(den<=0)continue;i128 num=(i128)t*A*Y*T2;if(num%den)continue;i128 wi=num/den;if(wi<=0||wi>LLONG_MAX)continue;i64 W=(i64)wi;if(W>=p10(m3)||P2%W)continue;i64 C2=P2/W;if(digs(C2)!=n2)continue;if(gcd(A,C2)!=1||gcd(W,C3)!=1||gcd(A,W)!=1)continue;i64 g0=gcd(A*W,P1);if(t%g0||P1%t)continue;i128 Om=(i128)W*T3+(i128)A*Y*T2; i128 NM=(i128)A*W*X*Y*G*D;if(Om<=0||NM%Om||NM/Om!=t)continue;i64 h=gcd(P1,Q0),del=D/h;if(Om%del)continue;i64 dM=gcd128(NM,P1);if(dM%t||dM%g0)continue;i64 RM=dM/g0,ms=dM/t,mu=t/g0;if(RM/ms!=mu)continue;i128 L=(i128)A*W*X*Y*G;i64 pr=P1/h,s=gcd((i64)(L%pr),pr);i128 E=L/s,OD=Om/del;if(OD%E||OD/E!=ms)continue;full++;i64 cp=C2*C3,dr=radpart(mu,cp);bool pass=gcd(mu,cp)==1;if(pass)smith++;cout<<pp<<','<<m<<','<<n<<','<<n2<<','<<n3<<','<<ge<<','<<ke<<','<<m2<<','<<m3<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<P1<<','<<P2<<','<<P3<<','<<Q0<<','<<D<<','<<t<<','<<g0<<','<<mu<<','<<h<<','<<dM<<','<<RM<<','<<ms<<','<<s128(Om)<<','<<s128(NM)<<','<<dr<<','<<(pass?1:0)<<"\n";}
}
}
}}
cerr<<"p="<<pmin<<".."<<pmax<<" m<="<<mmax<<" n<="<<nmax<<" n2<= "<<n2max<<" triples="<<triples<<" primitive="<<prim<<" full="<<full<<" smith="<<smith<<"\n";
}
