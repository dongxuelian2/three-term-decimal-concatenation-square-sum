#include <bits/stdc++.h>
using namespace std;
using i64=long long; using i128=__int128_t;

static string s128(i128 x){ if(x==0) return "0"; bool neg=x<0; if(neg)x=-x; string s; while(x){s.push_back('0'+x%10);x/=10;} if(neg)s.push_back('-'); reverse(s.begin(),s.end()); return s; }
static i64 gcd128(i128 a,i64 b){ i64 r=(i64)(a%b); if(r<0)r=-r; return std::gcd(r,b); }
static vector<i64> divisors(i64 n){ vector<i64>a,b; for(i64 d=1;d*d<=n;d++) if(n%d==0){a.push_back(d); if(d*d!=n)b.push_back(n/d);} reverse(b.begin(),b.end()); a.insert(a.end(),b.begin(),b.end()); return a; }
static int digits(i64 n){int d=0; do{d++;n/=10;}while(n); return d;}
static i64 pow10i(int e){i64 x=1; while(e--)x*=10; return x;}
static map<i64,int> factor(i64 n){map<i64,int>f; for(i64 d=2;d*d<=n;d+=(d==2?1:2)){while(n%d==0){f[d]++;n/=d;}} if(n>1)f[n]++; return f;}
static i64 radial_part(i64 n, i64 cprod){ i64 out=1; auto f=factor(n); for(auto [p,e]:f) if(cprod%p==0) for(int j=0;j<e;j++) out*=p; return out; }

int main(int argc,char**argv){
  int pmin=81,pmax=160; if(argc>1)pmin=stoi(argv[1]); if(argc>2)pmax=stoi(argv[2]);
  cout << "P_PARAM,M,N,A,W,C2,C3,N3,P1,P2,P3,Q0,D,T2,T3,GSTAR,G0,MU,H,DM,RM,MSRC,OMEGA,NM,RM_RADIAL,MSRC_RADIAL,DELTA_RAD,MU_SMITH_PASS\n";
  unsigned long long triples=0, primitive=0, solved=0, full=0, mu1=0, smith=0;
  for(i64 pp=pmin;pp<=pmax;pp++){
    i64 maxm=20*pp; // D>0 forces m<~20p.
    for(i64 m=1;m<=maxm;m++){
      i64 rhs=20*m*pp-m*m-pp*pp-1; // need n^2 <= rhs.
      if(rhs<1) continue;
      i64 nmax=sqrt((long double)rhs); while((nmax+1)*(nmax+1)<=rhs)nmax++; while(nmax*nmax>rhs)nmax--;
      auto tdiv=divisors(2*m*pp);
      for(i64 n=1;n<=nmax;n++){
        triples++;
        i64 P1=2*m*pp, P2=2*n*pp;
        i64 P3=m*m+n*n-pp*pp; if(P3<=0) continue;
        i64 Q0=m*m+n*n+pp*pp;
        i64 D=10*P1-Q0; if(D<=0) continue;
        if(std::gcd(std::gcd(P1,P2),std::gcd(P3,Q0))!=1) continue;
        primitive++;
        i64 T2=Q0-P2, T3=Q0-P3; if(T2<=0||T3<=0) continue;
        for(i64 A=1;A<=9;A++){
          if(P3%A) continue;
          i64 C3=P3/A; int n3=digits(C3); i64 Y=pow10i(n3); i64 X=10;
          for(i64 t:tdiv){
            // Inverted master: W*(A*X*Y*D - t*T3) = t*A*Y*T2.
            i128 den=(i128)A*X*Y*D-(i128)t*T3; if(den<=0) continue;
            i128 num=(i128)t*A*Y*T2; if(num%den) continue;
            i128 W128=num/den; if(W128<=0 || W128>LLONG_MAX) continue;
            i64 W=(i64)W128; if(P2%W) continue;
            i64 C2=P2/W; if(C2<10||C2>99) continue; // n2=2, U=1 radial box.
            if(std::gcd(A,C2)!=1 || std::gcd(W,C3)!=1 || std::gcd(A,W)!=1) continue;
            i64 g0=std::gcd(A*W,P1); if(t%g0) continue;
            // exact master verification.
            i128 Om=(i128)W*T3+(i128)A*Y*T2;
            i128 NM=(i128)A*W*X*Y*D;
            if(Om<=0 || NM%Om || NM/Om!=t) continue;
            if(P1%t) continue;
            solved++;
            i64 h=std::gcd(P1,Q0); i64 delta=D/h;
            if((i64)(Om%delta)!=0) continue;
            i64 dM=gcd128(NM,P1);
            if(dM%g0 || dM%t) continue;
            i64 RM=dM/g0, msrc=dM/t, mu=t/g0;
            if(RM%msrc || RM/msrc!=mu) continue;
            // source lower decomposition regression.
            i128 L=(i128)A*W*X*Y;
            i64 p=P1/h; i64 Lmodp=(i64)(L%p); i64 s=std::gcd(Lmodp,p);
            i128 Esrc=L/s; i128 OD=Om/delta;
            if(OD%Esrc || OD/Esrc!=msrc) continue;
            full++;
            if(mu==1)mu1++;
            i64 cprod=C2*C3;
            i64 RMr=radial_part(RM,cprod), MSr=radial_part(msrc,cprod), Dr=RMr/MSr;
            bool pass=std::gcd(mu,cprod)==1;
            if(pass) smith++;
            cout<<pp<<','<<m<<','<<n<<','<<A<<','<<W<<','<<C2<<','<<C3<<','<<n3<<','<<P1<<','<<P2<<','<<P3<<','<<Q0<<','<<D<<','<<T2<<','<<T3<<','<<t<<','<<g0<<','<<mu<<','<<h<<','<<dM<<','<<RM<<','<<msrc<<','<<s128(Om)<<','<<s128(NM)<<','<<RMr<<','<<MSr<<','<<Dr<<','<<(pass?1:0)<<"\n";
          }
        }
      }
    }
  }
  cerr<<"p_range="<<pmin<<".."<<pmax<<" triples="<<triples<<" primitive="<<primitive<<" inverted_hits="<<solved<<" full="<<full<<" mu1="<<mu1<<" smith="<<smith<<"\n";
}
