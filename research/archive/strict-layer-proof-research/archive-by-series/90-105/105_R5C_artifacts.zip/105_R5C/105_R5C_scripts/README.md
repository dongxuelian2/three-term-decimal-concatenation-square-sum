# 105-R5C scripts

`verify_transfer_first_failure.py` checks the exact symbolic and integer identities used in the R5C first-failure theorem.

Proof-relevant computational claims:
- reduction of full master to `111*Q0 - 1000*P1 = 100*G + 1`;
- sphere/master eliminant;
- exact discriminant factorization;
- `v5(discriminant)=7` for every `G=10^g`;
- the explicit R3 sphere/source-digit completion and its master residual.

The finite sample loops are regression only. The theorem is symbolic and applies to all `g>=1` (the R5 family itself uses `g>=2`).
