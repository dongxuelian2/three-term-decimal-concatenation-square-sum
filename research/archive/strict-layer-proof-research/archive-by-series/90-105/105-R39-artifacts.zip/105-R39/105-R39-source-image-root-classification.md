# 105-R39 — Source-Image Root Classification

R39 distinguishes:

1. `EXPONENT-SYNCHRONIZED ROOT`: production-normalized NTC1+sphere root inside \(\mathscr E_{\exp}\).
2. `ACTUAL-SOURCE ROOT`: such a root also lying in \(\mathscr E_{\rm src}\), i.e. with a legal source integer \(U\).

The first class is nonempty. The second class remains globally undecided.

The seven authoritative q=1 TC1/master hits from R32 are all exponent-synchronized by deterministic recovery. Their coarse source rooms all satisfy

\[
U_{\rm lo}=1,\qquad U_{\rm hi}=0.
\]

Thus they are exponent-image roots but not actual-source points.

The first R39 certificate uses

\[
(48,436,75,445),
\]

because it additionally passes production normalization, primitive sphere, shape, \(\mu\)-support, and exact \(\Lambda\) recovery before dying at source room.

```text
AMBIENT_EXPONENT_FREEDOM=FULLY_DELETED_FOR_PRESCRIBED_Q
EXPONENT_SYNCHRONIZED_ROOTS_EXIST=YES
ACTUAL_SOURCE_ROOT_EXISTS=UNDECIDED_GLOBALLY
```
