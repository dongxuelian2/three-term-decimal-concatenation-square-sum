# 105-R39 — Quadratic Branch Analysis

R39 proves globally on the exponent image that

\[
\mathcal A_N=B_{\rm src}^2-L_{\rm src}^2<0.
\]

Therefore every source-native production root belongs to the strictly negative quadratic branch.

## First genuine exponent-synchronized root

\[
(P_1,P_2,P_3,Q_0)=(48,436,75,445),
\]

\[
(A,W,u_0,g_1^*,\Lambda,q)=(3,4,1,24,2,1),
\]

\[
(g_0,\mu,a,s)=(12,2,1,2),
\]

\[
(n_2,n_3,m_2,m_3,g,k)=(2,1,1,1,0,1),
\]

\[
(X,Y,G,K)=(10,10,1,10).
\]

The source-native coefficients are

\[
(L,B,C)=(1000,168,26760),
\quad
\mathcal A_N=-971776<0.
\]

Exact checks:

\[
LP_1=48000=BQ_0-C.
\]

\[
P_1^2+P_2^2+P_3^2=Q_0^2=198025.
\]

The normalized square quantity is

\[
\delta_{\rm norm}=190913068096=436936^2,
\]

with incidence radical

\[
BP_1-LQ_0=-436936.
\]

Thus

```text
SOURCE_EXPONENT_SYNCHRONIZATION_EXTINCTION=FALSE
GENUINE_EXPONENT_SYNCHRONIZED_ROOT=YES
SOURCE_NATIVE_QUADRATIC_BRANCH_NONEMPTY=YES
```

Its next first-failure is not support. It is the actual source integer room:

\[
U_{\rm lo}=1>0=U_{\rm hi}.
\]
