# 105-R39 — Source-Exponent Image Exact System

## 1. Two nested source images

To remove the historical ambiguity between “exponent synchronized” and “actual source-generated”, R39 freezes two nested images.

### Exponent image \(\mathscr E_{\exp}\)

A tuple is in \(\mathscr E_{\exp}\) iff, for a prescribed legal \(q\ge1\),

\[
z=\Lambda q,\qquad
10^{m_2-1}\le Az\le10^{m_2}-1,\qquad
10^{m_3-1}\le Wz\le10^{m_3}-1,
\]

\[
m_2=\operatorname{dig}(A\Lambda q),\qquad
m_3=\operatorname{dig}(W\Lambda q),
\]

\[
g=m_3-n_3\ge0,\qquad
k=n_2-m_2-g\ge1,
\]

and

\[
X=10^{m_2},\qquad Y=10^{n_3},\qquad G=10^g,\qquad K=10^k.
\]

Equivalently,

\[
n_2=m_2+g+k,\qquad m_3=n_3+g.
\]

Thus \(X,Y,G,K,m_2,m_3,g,k\) are not independent root variables.

### Full source image \(\mathscr E_{\rm src}\)

\(\mathscr E_{\rm src}\subset\mathscr E_{\exp}\) additionally requires a positive source integer \(U\) satisfying

\[
10^{n_2-1}\le C_2U\le10^{n_2}-1,\qquad
10^{n_3-1}\le C_3U\le10^{n_3}-1,
\]

the frozen native residue/completed-source predicates, and \((U,\Lambda u_0AW)=1\).

The coarse integer-room iff is \(U_{\rm lo}\le U_{\rm hi}\), where

\[
U_{\rm lo}=\max\left(
\left\lceil\frac{10^{n_2-1}}{C_2}\right\rceil,
\left\lceil\frac{10^{n_3-1}}{C_3}\right\rceil
\right),
\]

\[
U_{\rm hi}=\min\left(
\left\lfloor\frac{10^{n_2}-1}{C_2}\right\rfloor,
\left\lfloor\frac{10^{n_3}-1}{C_3}\right\rfloor
\right).
\]

## 2. Packet-dependent scale

\[
g_0=(u_0AW,P_1),\qquad \mu=g_1^*/g_0,
\]

\[
\lambda_z=\frac{10^{n_3}}{(10^{n_3},W(Q_0-P_3))},\qquad
\Lambda=\operatorname{lcm}(\mu,\lambda_z).
\]

Therefore the exact dependency order cannot be “compute \(\Lambda\) without a packet”.
The production system is packet/source-carrier native, then chooses prescribed \(q\), then deterministically recovers exponents, then constructs root coefficients.

```text
Q_MUST_PRECEDE_ROOT_COEFFICIENTS=YES
Q_IS_NOT_AN_AMBIENT_ROOT_VARIABLE=YES
EXPONENT_FREEDOM_DELETED=YES
```
