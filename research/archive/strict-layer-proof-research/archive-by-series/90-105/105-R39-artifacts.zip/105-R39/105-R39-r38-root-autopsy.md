# 105-R39 — R38 Root Autopsy / Generation Regression

R38 exact ambient root:
\[
(u_0,A,W,g_0,a,\mu,s)=(1,3,2,6,1,1,1),
\]
\[
(X,Y,G,K,C_2,C_3)=(1,10,1,10,11,7),
\]
\[
(P_1,P_2,P_3,Q_0)=(6,22,21,31).
\]

The source semantics force

\[
n_2=2,\quad g=0,\quad k=1,\quad m_2=1,
\]

so

\[
X_{\rm prod}=10.
\]

Hence the R38 point is rejected before coefficient construction.

```text
R38_ROOT_GENERATION_STATUS=REJECTED_PRE_ROOT
REASON=X_AMBIENT_1_NE_X_SOURCE_10
```

For regression only, if the same remaining data are re-evaluated at \(X=10\),

\[
(L,B,C)=(1000,132,702),
\]

and the resulting F11 discriminant is

\[
3637502416000000,
\]

with square flag `0`.

This recomputation is not the production rejection rule; production rejects the tuple before any root solve.
