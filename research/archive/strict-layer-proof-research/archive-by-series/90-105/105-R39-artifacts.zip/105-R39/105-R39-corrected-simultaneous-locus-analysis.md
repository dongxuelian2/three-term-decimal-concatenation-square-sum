# 105-R39 — Corrected Simultaneous Locus Analysis

The corrected locus inherited from R36/R37 is

\[
\mathscr T=
\{\mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.
\]

The first exponent-synchronized production root

\[
(P_1,P_2,P_3,Q_0)=(48,436,75,445)
\]

fails strictly before \(\mathscr T\), because its coarse source room is empty:

\[
U_{\rm lo}=1,\qquad U_{\rm hi}=0.
\]

Therefore it produces no corrected-simultaneous point and no terminal pair.

R39 does not infer global emptiness of \(\mathscr T\).

```text
CORRECTED_SIMULTANEOUS_LOCUS_POSITIVE=NOT_FOUND
CORRECTED_SIMULTANEOUS_LOCUS_EXTINCTION=NOT_PROVED
```
