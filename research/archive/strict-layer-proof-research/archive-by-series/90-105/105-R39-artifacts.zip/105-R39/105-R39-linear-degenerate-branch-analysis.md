# 105-R39 — Linear / Degenerate Branch Analysis

The R38 degenerate condition is

\[
\mathcal A_N=0\iff B_N=L_N.
\]

R39 source synchronization proves globally

\[
B_{\rm src}<L_{\rm src}
\]

for every legal prescribed-\(q\) exponent point. Therefore

\[
\boxed{\mathcal A_N=0\text{ has no source-native legal point}.}
\]

The historical R38 normalized row

\[
(P_1,P_2,P_3,Q_0)=(2000,384,135,2041)
\]

used \(X=1,Y=10,G=10,K=10\), hence \(m_2=0\) from \(X=10^{m_2}\), already incompatible with a positive denominator word. Independently, its support also had

\[
\gcd(\mu,C_2C_3)=5.
\]

R39 does not use the support failure as the global kill: the stronger production theorem is \(B_{\rm src}<L_{\rm src}\).

```text
SOURCE_NATIVE_LINEAR_BRANCH_EXTINCTION=PROVED
```
