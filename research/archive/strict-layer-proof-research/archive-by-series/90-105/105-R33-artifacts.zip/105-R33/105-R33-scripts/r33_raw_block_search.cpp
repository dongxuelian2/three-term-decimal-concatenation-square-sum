#include <bits/stdc++.h>
using namespace std;
using i128=__int128_t;
using u128=__uint128_t;

long long gcdll(long long a,long long b){return std::gcd(a,b);} 
long long lcmll(long long a,long long b){return a/gcdll(a,b)*b;}
vector<long long> divisors(long long n){vector<long long>d;for(long long x=1;x*x<=n;x++)if(n%x==0){d.push_back(x);if(x*x!=n)d.push_back(n/x);}sort(d.begin(),d.end());return d;}
long long pow10i(int n){long long x=1;while(n--)x*=10;return x;}
long long isqrt128(i128 x){ if(x<0) return -1; long double xd=(long double)x; unsigned long long r=(unsigned long long)sqrt(xd); while((i128)r*r>x)--r; while((i128)(r+1)*(r+1)<=x)++r; return (long long)r;}
string s128(i128 x){if(x==0)return"0";bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}

int main(int argc,char**argv){
 int m=1,n=2,g=0,k=1,U=1; if(argc>=6){m=stoi(argv[1]);n=stoi(argv[2]);g=stoi(argv[3]);k=stoi(argv[4]);U=stoi(argv[5]);}
 long long b2lo=pow10i(m-1), b2hi=pow10i(m)-1;
 int m3=n+g; long long b3lo=pow10i(m3-1), b3hi=pow10i(m3)-1;
 int n2=m+g+k; long long c2lo=(pow10i(n2-1)+U-1)/U, c2hi=(pow10i(n2)-1)/U;
 long long c3lo=(pow10i(n-1)+U-1)/U, c3hi=(pow10i(n)-1)/U;
 if(argc>=8){ c2lo=1; c2hi=stoll(argv[6]); c3lo=1; c3hi=stoll(argv[7]); }
 long long rpow=pow10i(m+n+g), lpow=pow10i(m+n+g+k), ngpow=pow10i(n+g), npow=pow10i(n), G=pow10i(g), K=pow10i(k);
 unsigned long long configs=0, coresq=0, integerq=0, masterroom=0, exactlambda=0, support=0;
 cout<<"m,n,g,k,U="<<m<<","<<n<<","<<g<<","<<k<<","<<U<<"\n";
 cout<<"b2="<<b2lo<<".."<<b2hi<<" b3="<<b3lo<<".."<<b3hi<<" c2="<<c2lo<<".."<<c2hi<<" c3="<<c3lo<<".."<<c3hi<<"\n";
 for(long long b2=b2lo;b2<=b2hi;b2++) for(long long b3=b3lo;b3<=b3hi;b3++){
   long long Lam=gcdll(b2,b3), A=b2/Lam, W=b3/Lam; if(gcdll(A,W)!=1) abort();
   long long V=Lam*A*W; // u0=1
   auto ds=divisors(V); // b1 divides V; g1=V/b1
   for(long long C2=c2lo;C2<=c2hi;C2++){
     if(gcdll(b2,C2)!=1) continue; // q1 Smith implies shape
     long long P2=W*C2;
     for(long long C3=c3lo;C3<=c3hi;C3++){
       if(gcdll(b3,C3)!=1) continue;
       long long P3=A*C3;
       i128 S2=(i128)P2*P2+(i128)P3*P3;
       for(long long b1:ds){
         configs++;
         long long g1=V/b1;
         i128 L=(i128)b1*lpow;
         i128 B=(i128)b1*rpow+(i128)b2*ngpow+b3;
         if(L<=B) continue;
         i128 C=(i128)b2*npow*P2+(i128)b3*P3;
         i128 h=L*L-B*B;
         i128 core=C*C+h*S2;
         long long rt=isqrt128(core); if(rt<0 || (i128)rt*rt!=core) continue; coresq++;
         i128 num=-(B*C)+L*rt; if(num<=0 || num%h) continue;
         i128 Q128=num/h; if(Q128>LLONG_MAX) continue; long long Q=(long long)Q128; integerq++;
         i128 pnum=B*Q128-C; if(pnum<=0 || pnum%L) continue; long long P1=(long long)(pnum/L);
         if((i128)P1*P1+S2!=(i128)Q*Q) continue;
         if(gcdll(gcdll(gcdll(P1,P2),P3),Q)!=1) continue;
         if(P1%g1) continue;
         long long D=K*P1-Q, T=Q-P3, H=G*Q-P2; if(D<=0||T<=0||H<=0) continue;
         // verify block master
         if((i128)b1*rpow*D!=(i128)b3*T+(i128)b2*npow*H) abort();
         masterroom++;
         long long g0=gcdll(A*W,P1), mu=g1/g0; if(g1%g0) continue;
         long long lamz=npow/gcdll(npow,W*T); long long Lam2=lcmll(mu,lamz);
         if(Lam2!=Lam) continue; exactlambda++;
         if(gcdll(mu,C2*C3)!=1) continue;
         // inherited tail Smith quick checks: tau=lamz/gcd(lamz,mu), R1=P1/g1
         long long tau=lamz/gcdll(lamz,mu), R1=P1/g1;
         if(gcdll(tau,R1)!=1 || gcdll(tau,C2*C3)!=1) continue;
         support++;
         cout<<"HIT b="<<b1<<","<<b2<<","<<b3<<" Lam="<<Lam<<" A="<<A<<" W="<<W<<" g1="<<g1
             <<" C2="<<C2<<" C3="<<C3<<" P="<<P1<<","<<P2<<","<<P3<<","<<Q
             <<" DTH="<<D<<","<<T<<","<<H<<" mu="<<mu<<" lamz="<<lamz<<" tau="<<tau<<"\n";
       }
     }
   }
 }
 cerr<<"configs="<<configs<<" coresq="<<coresq<<" integerq="<<integerq<<" masterroom="<<masterroom<<" exactlambda="<<exactlambda<<" support="<<support<<"\n";
}
