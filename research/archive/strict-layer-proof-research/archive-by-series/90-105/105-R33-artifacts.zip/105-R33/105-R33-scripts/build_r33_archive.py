from pathlib import Path
import csv, hashlib, json, math, re, shutil, zipfile

ROOT=Path('/mnt/data/105-R33')
SCRIPTS=ROOT/'105-R33-scripts'
ROOT.mkdir(parents=True, exist_ok=True); SCRIPTS.mkdir(exist_ok=True)

def sha(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()

def ceildiv(a,b): return (a+b-1)//b

def room(C2,C3,n2,n3):
    L2=ceildiv(10**(n2-1),C2); L3=ceildiv(10**(n3-1),C3)
    H2=(10**n2-1)//C2; H3=(10**n3-1)//C3
    return L2,L3,H2,H3,max(L2,L3),min(H2,H3)

def eqr(C,n):
    p=10**(n-1); a,r=divmod(p,C)
    eta=(10*r-1)//C
    s=(10*r-1)-eta*C
    return a,r,1 if r>0 else 0,10*a+eta,eta,s

# Frozen input ledger.
inputs=[
('105-R32-stage-archive.md','LEDGER-CROSSCHECK','28f7faaa8b382e4dc60537f7cf6300f2b6757c38679a03c9060dbe13da80f39c','PASS'),
('105-R32-unit-chamber-exact-system.md','LEDGER-CROSSCHECK','afb0ce10a906fbd3109f9dd31bc0db3fc185553a69af36c2f3397e54654da617','PASS'),
('105-R32-digit-room-collision-derivation.md','LEDGER-CROSSCHECK','f4754f5db78687282a806cb31ac9861f5df9907719bf949961d3adb9edf6bcae','PASS'),
('105-R32-q1-extinction-proof.md','LEDGER-CROSSCHECK','2df5eee2cca7ab5b001305d132f80b89359c5a311aeb77e24bfd737aff2a7779','PASS'),
('105-R32-prime-branch-derivation.md','LEDGER-CROSSCHECK','cc6204f27f497616aff6d75f1cd94a2084961410c95de9fb2ee77910c996ae1f','PASS'),
('105-R32-q1-seven-hit-autopsy.csv','LEDGER-CROSSCHECK','195a93582e81e9ac8b94a0ad8607dea1926da4beab975eedb046f5250223febe','PASS'),
('105-R32-exponent-identity-table.csv','LEDGER-CROSSCHECK','09203f814000e13a958da2b3ef04701380f7f4fb67621e5cd633bb14bfad7ed0','PASS'),
('105-R32-execution.log','LEDGER-CROSSCHECK','5311ce0a856d3623704f09343cc29ad434d23d7583b79a49150de6a559b0c4c0','PASS'),
('105-R32-SHA256-MANIFEST.txt','LEDGER-SOURCE-READ','N/A (manifest is the ledger source; no self-entry)','PASS'),
('105-R31-stage-archive.md','LEDGER-CROSSCHECK','4bcbe12605a46e69051b0bff435aa88637411bbb63ac9d644f7671254884804d','PASS'),
('105-R31-q1-forced-scale-derivation.md','LEDGER-CROSSCHECK','5dce481eb346bd2e67f4f46129248d1bfb9dc9f450c81f23ae4b033b7a7483ad','PASS'),
('105-R30-TC3-TC4-exact-definitions.md','LEDGER-CROSSCHECK','4fb3b68afbd9a95b7ff8067f5a93c78d1416f82b7c4b606912fb344163fc18f3','PASS'),
('105-R30-q-elimination-derivation.md','LEDGER-CROSSCHECK','ca536b3764ef49d593019ad7c24b3874f6b2f3b10d0f42af8218b3a966722f6e','PASS'),
('105-R29-stage-archive.md','LEDGER-CROSSCHECK','f21b69272157b02a810830e49c10e5a4649daf565ad24f1ff3a946275f21ec3d','PASS'),
('105-R28-stage-archive.md','LEDGER-CROSSCHECK','ee1bf90f78f4317eefc3e3c341c3f15828e7e69724e2b5fa393765ab106f14a1','PASS'),
('105-R28-TC1-derivation.md','LEDGER-CROSSCHECK','4dbeba031fdba7c9ead02c72a53e6300b306b5ca610aa8f9adc1931f43363f3a','PASS'),
('105-R26-stage-archive.md','LEDGER-CROSSCHECK','41f4e2aad7720862a98349d61d22c482b7f5045b6c54bfea56651d4032d97680','PASS'),
('105-R24 source-carrier image theorem companion','LEDGER-CROSSCHECK','e6768ee326b9796130e4ea63933ed72238f1c327c63759b70c9662e0590deedf','PASS'),
]
with (ROOT/'105-R33-input-hash-audit.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['filename','verification_mode','computed_or_ledger_hash','status']); w.writerows(inputs)

# Seven frozen q1 hits.
seven=[
 dict(P1=20,P2=120,P3=123,Q0=173,A=1,W=2,u0=1,g1star=10,C2=60,C3=123,Lambda=5,m=1,n=2,g=0,k=1),
 dict(P1=48,P2=436,P3=75,Q0=445,A=3,W=4,u0=1,g1star=24,C2=109,C3=25,Lambda=2,m=1,n=1,g=0,k=1),
 dict(P1=120,P2=900,P3=691,Q0=1141,A=1,W=12,u0=1,g1star=24,C2=75,C3=691,Lambda=2,m=1,n=2,g=0,k=1),
 dict(P1=140,P2=1240,P3=491,Q0=1341,A=1,W=2,u0=1,g1star=10,C2=620,C3=491,Lambda=5,m=1,n=2,g=0,k=1),
 dict(P1=230,P2=330,P3=1593,Q0=1643,A=1,W=2,u0=1,g1star=10,C2=165,C3=1593,Lambda=5,m=1,n=2,g=0,k=1),
 dict(P1=288,P2=2584,P3=585,Q0=2665,A=3,W=4,u0=1,g1star=24,C2=646,C3=195,Lambda=2,m=1,n=1,g=0,k=1),
 dict(P1=298,P2=2514,P3=1485,Q0=2935,A=5,W=1,u0=1,g1star=1,C2=2514,C3=297,Lambda=1,m=1,n=1,g=0,k=1),
]

aut_fields=['packet','A','W','u0','g1star','Lambda','b1','b2','b3','C2','C3','n2','n3','m2','m3','g','k','T','H','D','master_LHS','master_RHS','Ulo_face2','Ulo_face3','Uhi_face2','Uhi_face3','Ulo','Uhi','gap','which_face_sets_Ulo','which_face_sets_Uhi','C2_division_quotient','C2_division_remainder','C2_eta','C2_upper_remainder','C3_division_quotient','C3_division_remainder','C3_eta','C3_upper_remainder','face2_room_kill','face3_room_kill','gap_mechanism']
aut=[]
for x in seven:
    n2=x['m']+x['g']+x['k']; n3=x['n']; m2=x['m']; m3=x['n']+x['g']
    T=x['Q0']-x['P3']; H=10**x['g']*x['Q0']-x['P2']; D=10**x['k']*x['P1']-x['Q0']
    lhs=x['g1star']*(x['W']*T+x['A']*10**x['n']*H)
    rhs=x['A']*x['W']*x['u0']*10**(x['m']+x['n']+x['g'])*D
    b2=x['A']*x['Lambda']; b3=x['W']*x['Lambda']; b1=x['Lambda']*x['u0']*x['A']*x['W']//x['g1star']
    L2,L3,H2,H3,Ulo,Uhi=room(x['C2'],x['C3'],n2,n3)
    q2,r2,eps2,h2,eta2,s2=eqr(x['C2'],n2); q3,r3,eps3,h3,eta3,s3=eqr(x['C3'],n3)
    assert h2==H2 and h3==H3 and lhs==rhs and b1*10**(x['m']+x['n']+x['g'])*D == b3*T+b2*10**x['n']*H
    activeL='2' if L2>L3 else ('3' if L3>L2 else '2=3')
    activeH='2' if H2<H3 else ('3' if H3<H2 else '2=3')
    mechanism=[]
    if L2==1 and L3==1: mechanism.append('L2=L3=1')
    if H3==0: mechanism.append('H3=0 from C3>=10^n3')
    if H2==0: mechanism.append('H2=0 from C2>=10^n2')
    aut.append(dict(packet=f"({x['P1']},{x['P2']},{x['P3']},{x['Q0']})",A=x['A'],W=x['W'],u0=x['u0'],g1star=x['g1star'],Lambda=x['Lambda'],b1=b1,b2=b2,b3=b3,C2=x['C2'],C3=x['C3'],n2=n2,n3=n3,m2=m2,m3=m3,g=x['g'],k=x['k'],T=T,H=H,D=D,master_LHS=lhs,master_RHS=rhs,Ulo_face2=L2,Ulo_face3=L3,Uhi_face2=H2,Uhi_face3=H3,Ulo=Ulo,Uhi=Uhi,gap=Ulo-Uhi,which_face_sets_Ulo=activeL,which_face_sets_Uhi=activeH,C2_division_quotient=q2,C2_division_remainder=r2,C2_eta=eta2,C2_upper_remainder=s2,C3_division_quotient=q3,C3_division_remainder=r3,C3_eta=eta3,C3_upper_remainder=s3,face2_room_kill=int(H2<L2),face3_room_kill=int(H3<L3),gap_mechanism=' + '.join(mechanism)))
with (ROOT/'105-R33-seven-hit-master-room-autopsy.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=aut_fields); w.writeheader(); w.writerows(aut)

# New raw support hits from R33 search.
raw_hits=[
 dict(P1=24,P2=52,P3=159,Q0=169,A=3,W=4,u0=1,g1star=24,C2=13,C3=53,Lambda=2,m=1,n=1,g=0,k=1,b1=1,b2=6,b3=8,D=71,T=10,H=117,mu=2,lambda_z=1,tau=1),
 dict(P1=456,P2=292,P3=2907,Q0=2957,A=3,W=4,u0=1,g1star=24,C2=73,C3=969,Lambda=2,m=1,n=1,g=0,k=1,b1=1,b2=6,b3=8,D=1603,T=50,H=2665,mu=2,lambda_z=1,tau=1),
 dict(P1=48,P2=436,P3=75,Q0=445,A=3,W=4,u0=1,g1star=24,C2=109,C3=25,Lambda=2,m=1,n=1,g=0,k=1,b1=1,b2=6,b3=8,D=35,T=370,H=9,mu=2,lambda_z=1,tau=1),
 dict(P1=552,P2=3796,P3=2847,Q0=4777,A=3,W=4,u0=1,g1star=24,C2=949,C3=949,Lambda=2,m=1,n=1,g=0,k=1,b1=1,b2=6,b3=8,D=743,T=1930,H=981,mu=2,lambda_z=1,tau=1),
]
q1_fields=['source','packet','A','W','u0','g1star','Lambda','b1','b2','b3','C2','C3','m','n','g','k','n2','n3','T','H','D','Ulo','Uhi','gap','face2_room_kill','face3_room_kill','exact_lambda','mu_smith','tail_quick_support','status']
q1rows=[]
for x in aut:
    q1rows.append(dict(source='R32_COMPLETE_Q0_LE_3000',packet=x['packet'],A=x['A'],W=x['W'],u0=x['u0'],g1star=x['g1star'],Lambda=x['Lambda'],b1=x['b1'],b2=x['b2'],b3=x['b3'],C2=x['C2'],C3=x['C3'],m=x['m2'],n=x['n3'],g=x['g'],k=x['k'],n2=x['n2'],n3=x['n3'],T=x['T'],H=x['H'],D=x['D'],Ulo=x['Ulo'],Uhi=x['Uhi'],gap=x['gap'],face2_room_kill=x['face2_room_kill'],face3_room_kill=x['face3_room_kill'],exact_lambda='PASS',mu_smith='MIXED_PRE_SOURCE_NOT_NEEDED_FOR_ROOM_DEATH',tail_quick_support='FROZEN_REPLAY',status='MASTER_Q1_HIT__ROOM_EMPTY'))
for x in raw_hits:
    n2=x['m']+x['g']+x['k']; n3=x['n']; L2,L3,H2,H3,Ulo,Uhi=room(x['C2'],x['C3'],n2,n3)
    q1rows.append(dict(source='R33_RAW_M1_N1_G0_K1_C2C3_LE_1000',packet=f"({x['P1']},{x['P2']},{x['P3']},{x['Q0']})",A=x['A'],W=x['W'],u0=x['u0'],g1star=x['g1star'],Lambda=x['Lambda'],b1=x['b1'],b2=x['b2'],b3=x['b3'],C2=x['C2'],C3=x['C3'],m=x['m'],n=x['n'],g=x['g'],k=x['k'],n2=n2,n3=n3,T=x['T'],H=x['H'],D=x['D'],Ulo=Ulo,Uhi=Uhi,gap=Ulo-Uhi,face2_room_kill=int(H2<L2),face3_room_kill=int(H3<L3),exact_lambda='PASS',mu_smith='PASS',tail_quick_support='PASS',status='MASTER_Q1_SUPPORT_HIT__ROOM_EMPTY'))
with (ROOT/'105-R33-q1-master-hit-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=q1_fields); w.writeheader(); w.writerows(q1rows)

# Room-gap registry and near-hits.
gap_fields=['source','packet','L2','L3','H2','H3','Ulo','Uhi','gap','active_architecture','status']
gap_rows=[]
for r in q1rows:
    L2,L3,H2,H3,Ulo,Uhi=room(int(r['C2']),int(r['C3']),int(r['n2']),int(r['n3']))
    activeL='L2' if L2>L3 else ('L3' if L3>L2 else 'L2=L3')
    activeH='H2' if H2<H3 else ('H3' if H3<H2 else 'H2=H3')
    gap_rows.append(dict(source=r['source'],packet=r['packet'],L2=L2,L3=L3,H2=H2,H3=H3,Ulo=Ulo,Uhi=Uhi,gap=Ulo-Uhi,active_architecture=f'{activeL}/{activeH}',status='ROOM_EMPTY' if Ulo>Uhi else 'ROOM_PASS'))
with (ROOT/'105-R33-room-gap-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=gap_fields); w.writeheader(); w.writerows(gap_rows)
with (ROOT/'105-R33-near-hit-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=gap_fields); w.writeheader(); w.writerows(sorted(gap_rows,key=lambda z:(z['gap'],z['packet'])))

# Search registry from existing exact C++ logs.
search_rows=[]
for log in sorted(ROOT.glob('search_*.log'))+sorted(ROOT.glob('raw_*.log')):
    txt=log.read_text(); m=re.search(r'configs=(\d+) coresq=(\d+) integerq=(\d+) masterroom=(\d+) exactlambda=(\d+) support=(\d+)',txt)
    if not m: continue
    out=log.with_suffix('.out'); first=out.read_text().splitlines()[:2] if out.exists() else []
    name=log.stem
    kind='SOURCE_ROOM_FIRST' if name.startswith('search_') else 'RAW_MASTER_INCIDENCE'
    search_rows.append(dict(scope=name,kind=kind,parameters=' | '.join(first),configurations=int(m.group(1)),square_cores=int(m.group(2)),integer_Q=int(m.group(3)),master_positive_primitive=int(m.group(4)),exact_lambda=int(m.group(5)),support_hits=int(m.group(6)),global_inference='NO'))
search_fields=['scope','kind','parameters','configurations','square_cores','integer_Q','master_positive_primitive','exact_lambda','support_hits','global_inference']
with (ROOT/'105-R33-search-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=search_fields); w.writeheader(); w.writerows(search_rows)

# Counterexample/reconstruction registries.
with (ROOT/'105-R33-counterexample-registry.csv').open('w',newline='',encoding='utf-8') as f:
    fs=['kind','object','q1','master','source_room','completed_source','status','note']; w=csv.DictWriter(f,fieldnames=fs); w.writeheader()
    w.writerow(dict(kind='GLOBAL_TARGET',object='q=1 + all frozen preconditions',q1='REQUIRED',master='REQUIRED',source_room='SEARCHED',completed_source='NOT_REACHED',status='NO_GENUINE_COUNTEREXAMPLE_FOUND',note='No exact q1+MASTER+coarse-room survivor found in the attacked exact scopes; this is not a global nonexistence theorem.'))
    w.writerow(dict(kind='R32_STRUCTURAL_COUNTERMODEL',object='(50,10,1,51)',q1='PASS',master='FAIL_RESIDUAL_-4444',source_room='PASS',completed_source='NOT_APPLICABLE',status='NOT_GENUINE_FOR_R33_TARGET',note='Retained only as proof that pure digit geometry is insufficient.'))
with (ROOT/'105-R33-reconstruction-registry.csv').open('w',newline='',encoding='utf-8') as f:
    fs=['trigger','candidate','N30_positive','R26_iff_reconstruction','strict_A1','status']; w=csv.DictWriter(f,fieldnames=fs); w.writeheader()
    w.writerow(dict(trigger='q1+MASTER+source_room positive point',candidate='NONE',N30_positive='NOT_REACHED',R26_iff_reconstruction='NOT_TRIGGERED',strict_A1='NOT_REACHED',status='NO_ROOM_PASS_TO_RECONSTRUCT'))

# Prime continuation registry, including exact q-master cutoff theorem.
prime_fields=['kind','scope','formula','example','status']
prime_rows=[
 dict(kind='PRESCRIBED_PRIME_DETERMINIZATION',scope='all fixed post-support architectures',formula='m2=dig(A*Lambda*p); m3=dig(W*Lambda*p); g=m3-n3; k=n2-m2-g',example='',status='PROVED_IN_R32_INHERITED'),
 dict(kind='MASTER_Q_CUTOFF',scope='any admissible q after recovered digit lengths',formula='q*(Lambda*u0*A*W/g1star)*D < Q0; Qmaster=floor((Q0-1)/((Lambda*u0*A*W/g1star)*D))',example='',status='PROVED_R33'),
 dict(kind='MINIMAL_PRIME_WINDOW_WITH_MASTER',scope='minimal q=p prime',formula='Qminus <= p <= min(Qplus,Qmaster), p does not divide F*U',example='',status='EXACT_REDUCTION__GLOBAL_EXTINCTION_NOT_PROVED'),
 dict(kind='R29_SUPPORT_STACK_EXAMPLE',scope='packet (640,1420,4727,4977)',formula='Lambda=4,u0=1,A=1,W=20,g1star=80,D=1423 => b1bar=1,Qmaster=3',example='old Qminus=13,Qplus=2; MASTER cutoff independently gives q<=3',status='ARCHITECTURE_EXTINCT_BEFORE_PRIME_COVER'),
]
with (ROOT/'105-R33-prime-branch-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=prime_fields); w.writeheader(); w.writerows(prime_rows)

# Search summary JSON.
source_first=[r for r in search_rows if r['kind']=='SOURCE_ROOM_FIRST']
raw=[r for r in search_rows if r['kind']=='RAW_MASTER_INCIDENCE']
summary={
 'source_room_first_total_configurations':sum(r['configurations'] for r in source_first),
 'source_room_first_square_cores':sum(r['square_cores'] for r in source_first),
 'source_room_first_integer_Q':sum(r['integer_Q'] for r in source_first),
 'source_room_first_master_positive_primitive':sum(r['master_positive_primitive'] for r in source_first),
 'source_room_first_exact_lambda':sum(r['exact_lambda'] for r in source_first),
 'source_room_first_support_hits':sum(r['support_hits'] for r in source_first),
 'raw_total_configurations':sum(r['configurations'] for r in raw),
 'raw_square_cores':sum(r['square_cores'] for r in raw),
 'raw_integer_Q':sum(r['integer_Q'] for r in raw),
 'raw_support_hits':sum(r['support_hits'] for r in raw),
 'raw_support_unique_hits':4,
 'raw_support_room_pass_hits':0,
 'global_inference_from_search':False,
}
(ROOT/'105-R33-search-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')

# Formal markdown companions.
exact_system=r'''# 105-R33 — MASTER × Source Integer Room Exact System

## 1. Frozen variables

Use the R28/R32 authoritative notation

\[
T=Q_0-P_3>0,\qquad H=10^gQ_0-P_2>0,\qquad D=10^kP_1-Q_0>0,
\]

\[
P_2=u_0WC_2,\qquad P_3=u_0AC_3,
\]

and

\[
m_2=m,\quad m_3=n+g,\quad n_2=m+g+k,\quad n_3=n.
\]

The authoritative positive MASTER is

\[
\boxed{g_1^*\bigl(WT+A10^nH\bigr)=AWu_0\,10^{m+n+g}D.}
\tag{M}
\]

For q=1,

\[
\Lambda=\operatorname{lcm}\!\left(
\frac{g_1^*}{(u_0AW,P_1)},
\frac{10^n}{(10^n,W T)}
\right),
\]

and the denominator digit conditions are exact:

\[
10^{m-1}\le A\Lambda\le10^m-1,\qquad
10^{n+g-1}\le W\Lambda\le10^{n+g}-1.
\]

## 2. q1 denominator-block normal form

Define

\[
\boxed{b_2=A\Lambda,\qquad b_3=W\Lambda,\qquad
b_1=\frac{\Lambda u_0AW}{g_1^*}.}
\]

The last quantity is an integer because if
\(g_0=(u_0AW,P_1)\), then \(g_1^*=g_0\mu\), \(\mu\mid\Lambda\), and
\(g_0\mid u_0AW\).

Multiplying (M) by \(\Lambda/g_1^*\) gives the lowest-complexity q1 MASTER:

\[
\boxed{b_1 10^{m+n+g}D=b_3T+b_2 10^nH.}
\tag{DM}
\]

This is not a second TC1 equation; it is exactly MASTER in q1 block coordinates.

## 3. Exact MASTER remainder

Set upper denominator deficits

\[
e_2=10^m-b_2\ge1,\qquad e_3=10^{n+g}-b_3\ge1.
\]

Expanding (DM) yields

\[
\boxed{
10^{m+n+g}(Q_0-b_1D)
=Q_0(e_3+e_2 10^{n+g})+b_3P_3+b_2 10^nP_2.
}
\tag{REM}
\]

Every term on the right is positive. Hence

\[
\boxed{0<b_1D<Q_0.}
\tag{DEFECT}
\]

This is the q1/block-coordinate recovery of the earlier leading-defect fact.

## 4. Tail carry extraction

The frozen definition

\[
\lambda_z=\frac{10^n}{(10^n,WT)},\qquad \lambda_z\mid\Lambda
\]

implies

\[
10^n\mid W\Lambda T=b_3T.
\]

Thus

\[
\boxed{J_3:=\frac{b_3T}{10^n}\in\mathbb Z_{>0}}
\]

and division of (DM) by \(10^n\) gives the exact decimal carry equation

\[
\boxed{J_3+b_2H=b_1 10^{m+g}D.}
\tag{CARRY}
\]

In particular

\[
J_3+b_2H\equiv0\pmod{10^m}.
\]

This is stronger than a raw interval statement, but it controls the MASTER carry rather than the Euclidean remainders of \(10^{n_i-1}\) modulo \(C_i\).

## 5. Put MASTER inside an integer source room

Assume a coarse source integer \(U\ge1\) exists and set

\[
X_2=C_2U,\qquad X_3=C_3U.
\]

Then

\[
10^{n_2-1}\le X_2\le10^{n_2}-1,\qquad
10^{n-1}\le X_3\le10^n-1.
\]

Set source upper deficits

\[
f_2=10^{n_2}-X_2\ge1,\qquad f_3=10^n-X_3\ge1.
\]

Because \(b_3P_3=\Lambda u_0AW C_3\) and
\(b_2P_2=\Lambda u_0AW C_2\), multiplying (REM) by U gives

\[
\boxed{
10^{m+n+g}U(Q_0-b_1D)
=UQ_0(e_3+e_2 10^{n+g})
+V_0\bigl[(10^n-f_3)+10^n(10^{n_2}-f_2)\bigr],
}
\tag{BOX-REM}
\]

where \(V_0=\Lambda u_0AW\).

This is the requested MASTER-inside-source-box identity. It has no cancellation.
'''
(ROOT/'105-R33-master-source-room-exact-system.md').write_text(exact_system,encoding='utf-8')

roomgap=r'''# 105-R33 — Integer Room Gap Derivation

For each source face \(i\in\{2,3\}\), write the lower endpoint by Euclidean division

\[
10^{n_i-1}=\alpha_iC_i+r_i,\qquad 0\le r_i<C_i.
\]

Let

\[
\epsilon_i=\mathbf 1_{r_i>0}.
\]

Then exactly

\[
\boxed{L_i=\left\lceil\frac{10^{n_i-1}}{C_i}\right\rceil
=\alpha_i+\epsilon_i.}
\]

Multiplying the lower division by ten and subtracting one gives

\[
10^{n_i}-1=10\alpha_iC_i+(10r_i-1).
\]

Define

\[
\eta_i=\left\lfloor\frac{10r_i-1}{C_i}\right\rfloor,
\qquad
s_i=10r_i-1-\eta_iC_i.
\]

Then

\[
\boxed{H_i=\left\lfloor\frac{10^{n_i}-1}{C_i}\right\rfloor
=10\alpha_i+\eta_i,}
\]

with \(0\le s_i<C_i\). If \(r_i=0\), then \(\eta_i=-1\); if
\(r_i>0\), then \(\eta_i\in\{0,\dots,9\}\).

Therefore the exact integer-room gap is

\[
\boxed{
U_{\rm lo}-U_{\rm hi}
=\max(\alpha_2+\epsilon_2,\alpha_3+\epsilon_3)
-\min(10\alpha_2+\eta_2,10\alpha_3+\eta_3).
}
\tag{GAP-QR}
\]

The four active-face architectures are exactly the choices of the maximizing lower face and minimizing upper face. On a fixed architecture \((i,j)\), room extinction is the exact integer inequality

\[
\alpha_i+\epsilon_i\ge10\alpha_j+\eta_j+1.
\]

## Seven-hit mechanism

The seven complete R28 q1 raw-MASTER hits all satisfy

\[
L_2=L_3=1,
\]

while

\[
H_3=0
\]

because every one has \(C_3\ge10^{n_3}\). Hence

\[
U_{\rm lo}=1,\qquad U_{\rm hi}=0,
\]

so the observed one-unit gap is exactly

\[
\boxed{1-0=1.}
\]

Five of the seven also have \(H_2=0\). Thus the numerical pattern has a precise symbolic explanation, but this explanation does not establish that \(H_3=0\) is universal.
'''
(ROOT/'105-R33-room-gap-derivation.md').write_text(roomgap,encoding='utf-8')

qr=r'''# 105-R33 — Quotient / Remainder Analysis

## MASTER modulo C2

Using \(P_2=u_0WC_2\), hence \(H\equiv10^gQ_0\pmod{C_2}\), the exact MASTER gives

\[
\boxed{
g_1^*\bigl[W(Q_0-u_0AC_3)+A10^{n+g}Q_0\bigr]
\equiv AWu_0 10^{m+n+g}D\pmod{C_2}.
}
\tag{MC2}
\]

Equivalently, from R28 (3.1),

\[
g_1^*Q_0(W+A10^{n+g})
\equiv AWu_0\bigl(g_1^*C_3+10^{m+n+g}D\bigr)\pmod{C_2}.
\]

## MASTER modulo C3

Using \(P_3=u_0AC_3\),

\[
\boxed{
g_1^*\bigl[WQ_0+A10^n(10^gQ_0-u_0WC_2)\bigr]
\equiv AWu_0 10^{m+n+g}D\pmod{C_3}.
}
\tag{MC3}
\]

Equivalently,

\[
g_1^*Q_0(W+A10^{n+g})
\equiv AWu_0\bigl(g_1^*10^nC_2+10^{m+n+g}D\bigr)\pmod{C_3}.
\]

## What these congruences do and do not determine

The source-room remainders are

\[
10^{n_i-1}\bmod C_i.
\]

Neither MC2 nor MC3 contains an endpoint power \(10^{n_i-1}\) as an isolated invertible term, and the frozen shape/support conditions do not make every remaining coefficient invertible modulo \(C_i\). Consequently raw reduction modulo \(C_2\) or \(C_3\) does not, by itself, determine \(r_2\) or \(r_3\).

The genuinely stronger exact quotient extraction is instead the tail carry

\[
10^n\mid b_3T,
\qquad
J_3=\frac{b_3T}{10^n},
\qquad
J_3+b_2H=b_1 10^{m+g}D.
\]

This is the new useful remainder object of R33. It has not been converted into a universal source-room contradiction.
'''
(ROOT/'105-R33-quotient-remainder-analysis.md').write_text(qr,encoding='utf-8')

unit=r'''# 105-R33 — Unit Extinction Proof Audit

## Target

\[
q=1+\text{all frozen preconditions}+\mathrm{MASTER}
\Longrightarrow U_{\rm lo}>U_{\rm hi}.
\]

## Proved in R33

1. The q1 MASTER has the integral block form
   \[
   b_1 10^{m+n+g}D=b_3T+b_2 10^nH.
   \]
2. It yields the exact positive remainder identity (REM) and hence
   \[
   0<b_1D<Q_0.
   \]
3. Frozen tail minimality gives the exact carry
   \[
   J_3=b_3T/10^n\in\mathbb Z_{>0},\qquad
   J_3+b_2H=b_1 10^{m+g}D.
   \]
4. Assuming a source integer U gives the exact decimal box identity (BOX-REM).
5. The source room itself admits the exact Euclidean gap formula (GAP-QR).
6. MASTER modulo \(C_2,C_3\) was explicitly computed. Neither congruence alone determines the source endpoint remainders.

## Seven-hit theorem-discovery pattern

All seven complete R28 q1 raw-MASTER hits satisfy \(L_2=L_3=1\) and \(H_3=0\), hence gap exactly one. This proves the complete bounded statement through the frozen R28 \(Q_0\le3000\) corpus, not a global theorem.

## Active falsification

R33 used two exact C++ generators:

- `r33_block_search.cpp`: source-room-first; the requested U and both source digit blocks are imposed before solving the TC1×sphere quadratic.
- `r33_raw_block_search.cpp`: raw MASTER incidences; source room is not imposed, to search for MASTER hits outside the old packet census and then measure their gaps.

The machine-readable scopes and counts are in `105-R33-search-registry.csv`. The source-room-first attacked scopes produced **zero** primitive MASTER+room hits after exact \(\Lambda\)/support replay. The raw lane produced four exact q1 MASTER/support hits in its largest \((m,n,g,k)=(1,1,0,1)\), \(C_2,C_3\le1000\) box, but every one has empty source room and gap one.

No bounded search result is promoted to an unbounded theorem.

## Honest unit verdict

```text
MASTER_Q1_INTEGER_ROOM_ONE_UNIT_GAP=NOT_PROVED_NOT_FALSIFIED
MASTER_CONDITIONED_UNIT_SOURCE_ROOM_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
GENUINE_Q1_MASTER_ROOM_PASS_FOUND=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
```

Therefore the requested global unit extinction certificate is not generated.
'''
(ROOT/'105-R33-unit-extinction-proof.md').write_text(unit,encoding='utf-8')

prime=r'''# 105-R33 — Prime-Branch Continuation

R33 does not claim that the prime branch is the unique frontier, because q=1 was not globally killed. It nevertheless pushes the same MASTER arithmetic into prescribed q.

For any prescribed q,

\[
m_2=\operatorname{dig}(A\Lambda q),\quad
m_3=\operatorname{dig}(W\Lambda q),\quad
g=m_3-n_3,\quad k=n_2-m_2-g.
\]

Define base coefficients

\[
\bar b_1=\frac{\Lambda u_0AW}{g_1^*},\qquad
\bar b_2=A\Lambda,\qquad \bar b_3=W\Lambda.
\]

For the actual q-blocks

\[
B_i=q\bar b_i.
\]

Multiplying MASTER by \(\Lambda q/g_1^*\), and using the actual denominator digit upper bounds \(B_2<10^m\), \(B_3<10^{n+g}\), gives

\[
\boxed{q\bar b_1D<Q_0.}
\]

Hence every admissible q satisfies the new exact MASTER cutoff

\[
\boxed{
q\le Q_{\rm master}:=
\left\lfloor\frac{Q_0-1}{\bar b_1D}\right\rfloor.
}
\tag{MASTER-Q-CUTOFF}
\]

Therefore the q-window can be replaced by

\[
Q_-\le q\le\min(Q_+,Q_{\rm master}),\qquad (q,FU)=1.
\]

For a minimal prime branch

\[
\boxed{
Q_-\le p\le\min(Q_+,Q_{\rm master}),\qquad p\nmid FU.
}
\]

This is a genuine R33 continuation: MASTER itself can delete an architecture before any prime-cover computation whenever \(Q_{\rm master}<Q_-\).

For the historical R29 full support-stack point

\[
(P_1,P_2,P_3,Q_0)=(640,1420,4727,4977),
\]

\[
(A,W,u_0,g_1^*,\Lambda,D)=(1,20,1,80,4,1423),
\]

we have \(\bar b_1=1\) and

\[
Q_{\rm master}=\left\lfloor\frac{4976}{1423}\right\rfloor=3.
\]

Its frozen lower q-edge is \(Q_-=13\), so MASTER-Q-CUTOFF already places it below the admissible chamber. No global prime extinction follows.

```text
MASTER_Q_CUTOFF_THEOREM=PROVED
MINIMAL_PRIME_WINDOW_SHARPENED_BY_MASTER=YES
MINIMAL_PRIME_DENOMINATOR_EXTINCTION=NOT_PROVED
GENUINE_PRIME_Q_SURVIVOR_FOUND=NO
```
'''
(ROOT/'105-R33-prime-branch-continuation.md').write_text(prime,encoding='utf-8')

# Main saturation certificate.
cert=r'''# 105-R33 MASTER × Source Saturation Certificate

```text
R33_TERMINAL_ATTACK_FAILED
R33_MASTER_SOURCE_SATURATION_CERTIFICATE=PROVED

STRICT_A1_UNLIFTABILITY_PROVED=NO
GLOBAL_N30_ZERO_THEOREM=NOT_PROVED
FULL_STRICT_A1_WITNESS_FOUND=NO

MASTER_CONDITIONED_UNIT_SOURCE_ROOM_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
MASTER_Q1_INTEGER_ROOM_GAP_THEOREM=NOT_PROVED
MASTER_Q1_INTEGER_ROOM_ONE_UNIT_GAP=NOT_PROVED_NOT_FALSIFIED
GENUINE_Q1_MASTER_ROOM_PASS_FOUND=NO

Q1_MASTER_BLOCK_FORM=PROVED
MASTER_POSITIVE_REMAINDER_IDENTITY=PROVED
Q1_LEADING_DEFECT=0<b1*D<Q0
MASTER_TAIL_CARRY_EXTRACTION=PROVED
MASTER_SOURCE_BOX_IDENTITY=PROVED
EXACT_SOURCE_EUCLIDEAN_GAP_FORMULA=PROVED
MASTER_MOD_C2_CALCULATED=YES
MASTER_MOD_C3_CALCULATED=YES
RAW_MOD_CI_ENDPOINT_REMAINDER_DETERMINATION=NO

R28_Q0_LE_3000_Q1_MASTER_HITS=7
SEVEN_HIT_GAP_ONE_MECHANISM=L2=L3=1_AND_H3=0
SEVEN_HIT_FACE3_DEATH=7/7
SEVEN_HIT_FACE2_DEATH=5/7

R33_SOURCE_ROOM_FIRST_MASTER_HITS=0_IN_STATED_EXACT_SCOPES
R33_RAW_NEW_MASTER_SUPPORT_HITS=4_IN_LARGEST_M1_N1_G0_K1_C2C3_LE1000_SCOPE
R33_RAW_NEW_MASTER_SUPPORT_ROOM_PASS=0
GLOBAL_INFERENCE_FROM_BOUNDED_SEARCH=NO

MASTER_Q_CUTOFF_THEOREM=PROVED
MINIMAL_PRIME_WINDOW=Qminus<=p<=min(Qplus,Qmaster),p_not_divide_FU
MINIMAL_PRIME_DENOMINATOR_EXTINCTION=NOT_PROVED

UNIT_BRANCH_DEAD=NO
PRIME_BRANCH_UNIQUE_FRONTIER=NO
MINIMAL_UNRESOLVED_OBJECT=Q1_MASTER_BLOCK_CARRY_PLUS_SOURCE_ENDPOINT_REMAINDER_COMPATIBILITY
```

## Saturation statement

R33 has exhausted the literal attacks demanded in the round prompt at the level supported by the frozen equations: Euclidean quotient/remainder extraction, MASTER modulo both carrier faces, MASTER multiplied into a source digit box, explicit decimal carry extraction, active falsification, and prescribed-prime continuation.

The remaining obstruction is no longer “MASTER × source room” in a generic sense. It is narrower:

\[
\boxed{
\text{Can the MASTER carry class }J_3+b_2H\equiv0\pmod{10^m}
\text{ coexist with the two endpoint remainder classes }
10^{n_i-1}\bmod C_i
\text{ on a legal moving architecture?}
}
\]

No exact bridge forcing those endpoint remainder classes has been proved, and no genuine positive bridge-survivor has been found.
'''
certp=ROOT/'105-R33-MASTER-SOURCE-SATURATION-CERTIFICATE.md'; certp.write_text(cert,encoding='utf-8')
(ROOT/'105-R33-MASTER-SOURCE-SATURATION-CERTIFICATE.sha256.txt').write_text(f"{sha(certp)}  {certp.name}\n",encoding='utf-8')

# Execution log.
log_lines=['105-R33 execution log','=====================','','MODE=MASTER_CONDITIONED_INTEGER_ROOM_GAP__EXACT_QUOTIENT_REMAINDER__FALSIFICATION','','INPUT_AUDIT']
for r in inputs: log_lines.append('|'.join(r))
log_lines += ['','EXACT_DERIVATIONS',
'MASTER=g1star*(W*T+A*10^n*H)=A*W*u0*10^(m+n+g)*D',
'Q1_BLOCKS=b2=A*Lambda;b3=W*Lambda;b1=Lambda*u0*A*W/g1star in Z>0',
'DM=b1*10^(m+n+g)*D=b3*T+b2*10^n*H',
'REM=10^r*(Q0-b1*D)=Q0*(e3+e2*10^(n+g))+b3*P3+b2*10^n*P2',
'LEADING_DEFECT=0<b1*D<Q0',
'TAIL_CARRY=10^n|b3*T;J3=b3*T/10^n;J3+b2*H=b1*10^(m+g)*D',
'BOX_REM=MASTER multiplied by source U with X2=C2U,X3=C3U and upper deficits f2,f3',
'GAP_QR=Ulo-Uhi=max(alpha2+eps2,alpha3+eps3)-min(10alpha2+eta2,10alpha3+eta3)',
'MC2_AND_MC3=EXPLICITLY_CALCULATED__NO_UNIVERSAL_ENDPOINT_REMAINDER_EXTRACTION',
'MASTER_Q_CUTOFF=q*(Lambda*u0*A*W/g1star)*D<Q0',
'','SEVEN_HIT_AUTOPSY',
'SEVEN=7','ALL_L2_L3=1','ALL_H3=0','FACE3_KILL=7','FACE2_KILL=5','ALL_GAP=1',
'','EXACT_SEARCH_SCOPES']
for r in search_rows:
    log_lines.append(f"{r['scope']}|{r['kind']}|configs={r['configurations']}|coresq={r['square_cores']}|integerQ={r['integer_Q']}|master_positive_primitive={r['master_positive_primitive']}|exactlambda={r['exact_lambda']}|support={r['support_hits']}|GLOBAL_INFERENCE=NO")
log_lines += ['','TERMINAL',
'MASTER_CONDITIONED_UNIT_SOURCE_ROOM_EXTINCTION=NOT_PROVED_NOT_FALSIFIED',
'MASTER_Q1_INTEGER_ROOM_ONE_UNIT_GAP=NOT_PROVED_NOT_FALSIFIED',
'GENUINE_Q1_MASTER_ROOM_PASS_FOUND=NO',
'UNIT_BRANCH_DEAD=NO',
'MASTER_Q_CUTOFF_THEOREM=PROVED',
'MINIMAL_PRIME_DENOMINATOR_EXTINCTION=NOT_PROVED',
'R33_TERMINAL_ATTACK_FAILED',
'R33_MASTER_SOURCE_SATURATION_CERTIFICATE=PROVED']
(ROOT/'105-R33-execution.log').write_text('\n'.join(log_lines)+'\n',encoding='utf-8')

# Main stage archive, after companions exist.
stage=r'''# 105-R33 Stage Archive — MASTER-Conditioned Integer-Room Gap × Exact Quotient/Remainder

**Project:** 三项十进制拼接平方和问题  
**Layer:** Strict Layer — \(A_1\)-only  
**Round:** 105-R33  
**Campaign position:** 最后十五轮终局总攻第 8 轮  
**Status:** FROZEN / ARCHIVED

# Executive Verdict

R33 does **not** prove global q=1 extinction, global \(N_{30}=0\), Strict-\(A_1\) unliftability, or a full witness. Therefore no unit-extinction, Strict-extinction, or full-witness certificate is generated.

It does make the intended MASTER × integer-room interaction exact. With

\[
b_2=A\Lambda,\quad b_3=W\Lambda,\quad
b_1=\Lambda u_0AW/g_1^*,
\]

q=1 MASTER becomes

\[
\boxed{b_1 10^{m+n+g}D=b_3T+b_2 10^nH.}
\]

Two exact quotient/remainder consequences follow:

\[
\boxed{
10^{m+n+g}(Q_0-b_1D)
=Q_0(e_3+e_2 10^{n+g})+b_3P_3+b_2 10^nP_2>0,
}
\]

so \(0<b_1D<Q_0\), and frozen tail divisibility gives

\[
\boxed{
J_3=\frac{b_3T}{10^n}\in\mathbb Z_{>0},\qquad
J_3+b_2H=b_1 10^{m+g}D.
}
\]

Assuming a source integer \(U\), multiplying the first remainder identity by U converts \(P_2U,P_3U\) into an exact decimal-box identity. This realizes the requested command “PUT THE MASTER EQUATION INSIDE THE INTEGER ROOM.”

The source room itself is exactly

\[
U_{\rm lo}-U_{\rm hi}
=\max(\alpha_2+\epsilon_2,\alpha_3+\epsilon_3)
-\min(10\alpha_2+\eta_2,10\alpha_3+\eta_3),
\]

where \(10^{n_i-1}=\alpha_iC_i+r_i\) and \(\eta_i=\lfloor(10r_i-1)/C_i\rfloor\).

The seven historical q1 MASTER hits have gap one for an exact simple reason: all have \(L_2=L_3=1\), while all have \(H_3=0\); hence \(U_{\rm lo}=1,U_{\rm hi}=0\). Five also have \(H_2=0\). The one-unit pattern is explained but not globalized.

MASTER modulo \(C_2\) and modulo \(C_3\) was calculated explicitly. Neither congruence by itself determines \(10^{n_i-1}\bmod C_i\). Thus the 7/7 Face-3 death is **not** promoted to a universal theorem.

Active exact falsification attacked source-room-first blocks and raw MASTER incidence blocks. No genuine q1+MASTER+source-room point was found. New raw MASTER/support points were found outside the seven historical rows, but every one still has empty source room. These searches are bounded certificates only.

Finally, MASTER globalizes to a prescribed-q cutoff:

\[
\boxed{
q\frac{\Lambda u_0AW}{g_1^*}D<Q_0,
\qquad
Q_{\rm master}=\left\lfloor\frac{Q_0-1}{(\Lambda u_0AW/g_1^*)D}\right\rfloor.
}
\]

Thus a minimal prime must lie in

\[
\boxed{Q_-\le p\le\min(Q_+,Q_{\rm master}),\qquad p\nmid FU.}
\]

This advances the prime branch but does not kill it globally.

# Part I — FILE / HASH AUDIT

All R24–R32 inputs were recovered from frozen File Library references and historical manifests. Their old hashes are recorded only as `LEDGER-CROSSCHECK`; no new bytewise hash is claimed for unmounted historical bytes. See `105-R33-input-hash-audit.csv`.

Every new R33 file in the manifest is hashed from active-runtime bytes.

# Part II — MASTER × SOURCE EXACT SYSTEM

See `105-R33-master-source-room-exact-system.md` for DM, REM, CARRY, and BOX-REM.

# Part III — QUOTIENT / REMAINDER EXTRACTION

See `105-R33-room-gap-derivation.md`. The exact Euclidean identity is

\[
H_i=10\alpha_i+\eta_i,
\qquad
\eta_i=\left\lfloor\frac{10r_i-1}{C_i}\right\rfloor.
\]

# Part IV — MOD C2 / MOD C3

See `105-R33-quotient-remainder-analysis.md`. Both congruences were explicitly calculated; no endpoint-remainder determinization follows from them alone.

# Part V — INTEGER-ROOM GAP THEOREM

The global theorem remains neither proved nor falsified. The exact one-unit equality is also neither proved nor falsified. No genuine room-pass point satisfying all attacked q1 MASTER/support conditions was found.

# Part VI — SEVEN-HIT SYMBOLIC AUTOPSY

`105-R33-seven-hit-master-room-autopsy.csv` records T,H,D, both MASTER sides, all four source endpoints, active faces, and Euclidean quotient/remainder data for all seven rows. The gap-one mechanism is `L2=L3=1 + H3=0` in 7/7.

# Part VII — ACTIVE COUNTEREXAMPLE SEARCH

`105-R33-search-registry.csv` and the two C++ generators certify every stated finite scope. The source-room-first lanes produced no MASTER/support room hit. The raw lanes found four exact MASTER/support hits in the largest m=n=1,g=0,k=1,C2,C3<=1000 scope; all four are room-empty.

No finite count is used as a global theorem.

# Part VIII — FULL SOURCE / RECONSTRUCTION

No q1+MASTER+coarse-room positive point was found, so completed-source and R26 iff reconstruction were not triggered. `105-R33-reconstruction-registry.csv` records this explicitly.

# Part IX — PRIME BRANCH CONTINUATION

The new MASTER-Q-CUTOFF theorem sharpens the inherited prime window but does not prove minimal-prime extinction. See `105-R33-prime-branch-continuation.md`.

# Part X — FOURTEEN ANSWERS

1. Lowest q1 MASTER/source form: \(b_1 10^{m+n+g}D=b_3T+b_2 10^nH\).
2. Exact gap expression: GAP-QR in Euclidean quotients/remainders.
3. Seven gaps equal one because \(L_2=L_3=1,H_3=0\).
4. Gap=1 globally: **undecided**; no counterexample found.
5. MASTER mod C2: MC2, explicitly recorded.
6. MASTER mod C3: MC3, explicitly recorded.
7. Face-3 7/7 death: explained, **not universalized**.
8. Same-face death is unnecessary; all four cross-face architectures remain represented by GAP-QR.
9. Assuming U produces no universal positive-size contradiction; instead it yields BOX-REM with all positive terms.
10. MASTER×U does produce the natural decimal-box identity BOX-REM.
11. Genuine q1+MASTER+room-pass: **not found**.
12. Completed-source positive point: **not reached**.
13. Prime branch: advanced to `Qminus <= p <= min(Qplus,Qmaster), p∤FU`.
14. Final surviving object is **not yet smaller than prime branch**, because unit remains open; the unit object is now narrowed to MASTER-carry / source-endpoint-remainder compatibility.

# TERMINAL VERDICT

```text
R33_TERMINAL_ATTACK_FAILED
R33_MASTER_SOURCE_SATURATION_CERTIFICATE=PROVED

STRICT_A1_UNLIFTABILITY_PROVED=NO
GLOBAL_N30_ZERO_THEOREM=NOT_PROVED
MASTER_CONDITIONED_UNIT_SOURCE_ROOM_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
MASTER_Q1_INTEGER_ROOM_GAP_THEOREM=NOT_PROVED
MASTER_Q1_INTEGER_ROOM_ONE_UNIT_GAP=NOT_PROVED_NOT_FALSIFIED
FULL_STRICT_A1_WITNESS_FOUND=NO

GENUINE_Q1_MASTER_ROOM_PASS_FOUND=NO
UNIT_BRANCH_DEAD=NO
MASTER_Q_CUTOFF_THEOREM=PROVED
MINIMAL_PRIME_DENOMINATOR_EXTINCTION=NOT_PROVED

MINIMAL_UNRESOLVED_OBJECT=
MASTER_CARRY_CLASS_X_SOURCE_ENDPOINT_REMAINDER_COMPATIBILITY
```
'''
stagep=ROOT/'105-R33-stage-archive.md'; stagep.write_text(stage,encoding='utf-8')
(ROOT/'105-R33-stage-archive.sha256.txt').write_text(f"{sha(stagep)}  {stagep.name}\n",encoding='utf-8')

# Hash manifest (exclude manifest itself and zip; include all regular files except executables to avoid platform noise? User asked outputs/scripts/log; hash scripts incl source, binary too okay.)
manifest=ROOT/'105-R33-SHA256-MANIFEST.txt'
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.name in {manifest.name,'105-R33-artifacts.zip'}: continue
    files.append(p)
with manifest.open('w',encoding='utf-8') as f:
    f.write('# 105-R33 SHA-256 manifest\n')
    f.write('# All entries below are bytewise hashes computed in the active R33 runtime.\n')
    for p in files:
        f.write(f"{sha(p)}  {p.relative_to(ROOT).as_posix()}\n")

# Bundle after manifest.
zip_path=ROOT/'105-R33-artifacts.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p != zip_path:
            z.write(p,p.relative_to(ROOT.parent))

print(json.dumps(summary,indent=2))
print('stage_sha',sha(stagep))
print('cert_sha',sha(certp))
print('manifest_entries',len(files))
print('zip_sha',sha(zip_path))
