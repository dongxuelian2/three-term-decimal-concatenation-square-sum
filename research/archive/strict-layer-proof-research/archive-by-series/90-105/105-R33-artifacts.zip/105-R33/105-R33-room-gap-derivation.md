# 105-R33 — Integer Room Gap Derivation

For each source face \(i\in\{2,3\}\), write the lower endpoint by Euclidean division

\[
10^{n_i-1}=\alpha_iC_i+r_i,\qquad 0\le r_i<C_i.
\]

Let

\[
\epsilon_i=\mathbf 1_{r_i>0}.
\]

Then exactly

\[
\boxed{L_i=\left\lceil\frac{10^{n_i-1}}{C_i}\right\rceil
=\alpha_i+\epsilon_i.}
\]

Multiplying the lower division by ten and subtracting one gives

\[
10^{n_i}-1=10\alpha_iC_i+(10r_i-1).
\]

Define

\[
\eta_i=\left\lfloor\frac{10r_i-1}{C_i}\right\rfloor,
\qquad
s_i=10r_i-1-\eta_iC_i.
\]

Then

\[
\boxed{H_i=\left\lfloor\frac{10^{n_i}-1}{C_i}\right\rfloor
=10\alpha_i+\eta_i,}
\]

with \(0\le s_i<C_i\). If \(r_i=0\), then \(\eta_i=-1\); if
\(r_i>0\), then \(\eta_i\in\{0,\dots,9\}\).

Therefore the exact integer-room gap is

\[
\boxed{
U_{\rm lo}-U_{\rm hi}
=\max(\alpha_2+\epsilon_2,\alpha_3+\epsilon_3)
-\min(10\alpha_2+\eta_2,10\alpha_3+\eta_3).
}
\tag{GAP-QR}
\]

The four active-face architectures are exactly the choices of the maximizing lower face and minimizing upper face. On a fixed architecture \((i,j)\), room extinction is the exact integer inequality

\[
\alpha_i+\epsilon_i\ge10\alpha_j+\eta_j+1.
\]

## Seven-hit mechanism

The seven complete R28 q1 raw-MASTER hits all satisfy

\[
L_2=L_3=1,
\]

while

\[
H_3=0
\]

because every one has \(C_3\ge10^{n_3}\). Hence

\[
U_{\rm lo}=1,\qquad U_{\rm hi}=0,
\]

so the observed one-unit gap is exactly

\[
\boxed{1-0=1.}
\]

Five of the seven also have \(H_2=0\). Thus the numerical pattern has a precise symbolic explanation, but this explanation does not establish that \(H_3=0\) is universal.
