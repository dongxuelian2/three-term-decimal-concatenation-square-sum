#!/usr/bin/env python3
from fractions import Fraction
from math import gcd

def vp(n,p):
    e=0
    while n and n%p==0:
        n//=p; e+=1
    return e

def p10exp(x):
    if x.denominator != 1 or x.numerator < 10: return None
    z=x.numerator; m=0
    while z%10==0:
        z//=10; m+=1
    return m if z==1 else None

def audit(P1,P2,P3,Q0,A,g1,u0,g,k,w):
    G=10**g; K=10**k
    D=K*P1-Q0; H=G*Q0-P2; T3=Q0-P3
    assert min(D,H,T3)>0 and (w*g1*T3)%A==0
    NE=w*g1*T3//A
    Nmax=min(vp(NE,2),vp(NE,5))
    B=g1*H; CX=w*u0*G*D
    Ctheta=u0*w*g1*T3*G*G*D
    rows=[]
    for n in range(1,Nmax+1):
        E=NE//10**n
        X=Fraction(B+E,CX)
        theta=Fraction(E*(B+E),Ctheta)
        rows.append((n,E,X,p10exp(X),theta))
    return D,H,T3,NE,Nmax,B,CX,Ctheta,rows

cur=audit(640,1420,4727,4977,1,80,1,0,1,20)
assert cur[3]==400000 and cur[4]==5
assert cur[-1][3][1]==40 and cur[-1][3][2]==10 and cur[-1][3][4]==Fraction(1,50)

g10=audit(200,365,104,429,13,40,1,1,1,1)
assert g10[3]==1000 and g10[-1][0][1]==100 and g10[-1][0][2]==10
assert g10[-1][0][4]==Fraction(1,130)

g0=audit(480,1040,2499,2749,3,240,1,0,1,2)
assert g0[3]==40000 and g0[-1][2][1]==40 and g0[-1][2][2]==100
assert g0[-1][2][4]==Fraction(1,15)

# Raw two-hit bound is sharp at coefficient level.
B,NE,CX=100,10000,11
assert Fraction(B+NE//10,CX)==100
assert Fraction(B+NE//1000,CX)==10

print("R25 exact audit PASS")
