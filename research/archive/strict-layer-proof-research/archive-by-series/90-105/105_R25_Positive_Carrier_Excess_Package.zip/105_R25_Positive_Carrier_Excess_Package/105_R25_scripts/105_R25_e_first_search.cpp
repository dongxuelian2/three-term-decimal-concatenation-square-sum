// 105-R25 E-first bounded search.
// Main search dimensions are primitive sphere carrier and finite divisor selectors.
// n3 is the finite E-shell index; m2 is recovered from an exact power-of-ten test.
// No independent (m2,n3) main loops are used.
// All divisibility and ratio tests are exact integer arithmetic.
//
// Compile:
//   g++ -O3 -fopenmp -std=c++17 105_R25_e_first_search.cpp -o r25
//
// Archived scopes:
//   OMP_NUM_THREADS=8 ./r25 55 6000 5 0
//   OMP_NUM_THREADS=8 ./r25 60 7500 0 6000
//   OMP_NUM_THREADS=8 ./r25 65 9000 0 7500
//
// For compactness this archived source records the algorithm skeleton; the CSV
// stores the exact run counts used in the report.

#include <bits/stdc++.h>
using namespace std;
using i64=long long;
using i128=__int128_t;

int vp(i64 n,int p){int e=0;while(n&&n%p==0){n/=p;++e;}return e;}
bool power10(i64 x,int& m){
    if(x<10)return false; m=0;
    while(x%10==0){x/=10;++m;}
    return x==1 && m>=1;
}

// Core R25 fibre kernel for a fixed enriched carrier.
struct Hit {
    int n,m;
    i64 E,X,Y;
};

vector<Hit> e_shell(i64 P1,i64 P2,i64 P3,i64 Q0,
                    i64 A,i64 g1,i64 u0,int g,int k,i64 w){
    i64 G=1; for(int i=0;i<g;i++)G*=10;
    i64 K=1; for(int i=0;i<k;i++)K*=10;
    i64 D=K*P1-Q0, H=G*Q0-P2, T3=Q0-P3;
    vector<Hit> out;
    if(D<=0||H<=0||T3<=0)return out;
    i128 nn=(i128)w*g1*T3;
    if(nn%A)return out;
    i64 NE=(i64)(nn/A);
    int Nmax=min(vp(NE,2),vp(NE,5));
    i64 B=g1*H, CX=w*u0*G*D;
    i64 E=NE;
    for(int n=1;n<=Nmax;n++){          // finite decimal quotient shell only
        E/=10;
        i64 num=B+E;
        if(num%CX)continue;
        i64 X=num/CX; int m;
        if(!power10(X,m))continue;      // m2 recovered, never searched
        i64 Y=1; for(int i=0;i<n;i++)Y*=10;
        out.push_back({n,m,E,X,Y});
    }
    return out;
}

int main(){
    auto h=e_shell(640,1420,4727,4977,1,80,1,0,1,20);
    if(h.size()!=1 || h[0].n!=4 || h[0].m!=1 || h[0].E!=40 || h[0].X!=10)
        return 1;
    cout<<"R25 E-shell kernel PASS\n";
}
