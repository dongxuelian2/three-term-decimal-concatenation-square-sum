# 105-R25 scripts

- `105_R25_exact_audit.py`: exact regression for the three historical master rows.
- `105_R25_e_first_search.cpp`: exponent-loop-free E-shell kernel and archived search protocol.
- Run counts for the full bounded searches are in `105_R25_Bounded_EFirst_Search.csv`.
- No floating-point decision is used for powers of ten, divisibility, or the ratio corridor.
