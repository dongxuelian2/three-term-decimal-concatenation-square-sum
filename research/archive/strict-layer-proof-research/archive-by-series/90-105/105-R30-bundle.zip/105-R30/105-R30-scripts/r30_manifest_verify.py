#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'105-R30-SHA256-MANIFEST.txt'
if not manifest.exists():
    raise SystemExit('MANIFEST_MISSING')
count=0
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip() or line.startswith('#'):
        continue
    digest, rel = line.split('  ',1)
    p=ROOT/rel
    if not p.is_file():
        raise SystemExit(f'MISSING {rel}')
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got != digest:
        raise SystemExit(f'HASH_MISMATCH {rel} expected={digest} got={got}')
    count += 1
print(f'MANIFEST_VERIFY=PASS files={count}')
sha_file=ROOT/'105-R30-SHA256-MANIFEST.sha256.txt'
if sha_file.exists():
    expected=sha_file.read_text(encoding='utf-8').split()[0]
    got=hashlib.sha256(manifest.read_bytes()).hexdigest()
    if got!=expected:
        raise SystemExit(f'MANIFEST_SELF_HASH_MISMATCH expected={expected} got={got}')
    print(f'MANIFEST_SELF_HASH_VERIFY=PASS sha256={got}')
