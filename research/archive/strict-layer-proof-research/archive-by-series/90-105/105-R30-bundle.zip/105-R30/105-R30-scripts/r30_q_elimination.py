#!/usr/bin/env python3
from fractions import Fraction
from math import gcd, lcm
from pathlib import Path
import csv, hashlib, itertools, json

ROOT=Path('/mnt/data/105-R30')

def ceil_div(a,b):
    return -((-a)//b)

def factor_distinct(n):
    n=abs(n); ps=[]; p=2
    while p*p<=n:
        if n%p==0:
            ps.append(p)
            while n%p==0: n//=p
        p=3 if p==2 else p+2
    if n>1: ps.append(n)
    return ps

def rad(n):
    r=1
    for p in factor_distinct(n): r*=p
    return r

def squarefree_divisors_with_mu(n):
    ps=factor_distinct(n)
    out=[]
    for mask in range(1<<len(ps)):
        d=1; bits=0
        for i,p in enumerate(ps):
            if mask>>i&1: d*=p; bits+=1
        out.append((d,-1 if bits%2 else 1))
    return out

def coprime_count_mobius(L,R,N):
    if L>R: return 0
    rr=rad(N)
    return sum(mu*(R//d-(L-1)//d) for d,mu in squarefree_divisors_with_mu(rr))

def coprime_list(L,R,N):
    if L>R: return []
    return [q for q in range(max(1,L),R+1) if gcd(q,N)==1]

# 1) Exhaustive exact regression: Mobius count equals direct gcd enumeration.
reg_cases=0
for L in range(1,26):
    for R in range(L,31):
        for F in range(1,41):
            for U in range(1,31):
                a=coprime_count_mobius(L,R,F*U)
                b=len(coprime_list(L,R,F*U))
                assert a==b,(L,R,F,U,a,b)
                reg_cases+=1

# 2) Historical R29 support survivor / R26 unique candidate.
P1,P2,P3,Q0=640,1420,4727,4977
A,W,u0,g1=1,20,1,80
n,delta,rho,m=4,-2,2,1
n3=n; n2=n+delta; m2=m; k=rho-m; g=n+delta-rho; m3=2*n+delta-rho
T3=Q0-P3
C2=P2//(u0*W); C3=P3//(u0*A)
g0=gcd(u0*A*W,P1); mu=g1//g0; R1=P1//g1
lambda_z=10**n3//gcd(10**n3,W*T3)
tau=lambda_z//gcd(lambda_z,mu)
Lambda=lcm(mu,lambda_z)
F=rad(R1*C2*C3)
Zminus=max(ceil_div(10**(m2-1),A),ceil_div(10**(m3-1),W))
Zplus=min((10**m2-1)//A,(10**m3-1)//W)
Qminus=ceil_div(Zminus,Lambda); Qplus=Zplus//Lambda
raw_count=max(0,Qplus-Qminus+1)
tc3_list=coprime_list(Qminus,Qplus,F)
assert (C2,C3,g0,mu,lambda_z,tau,Lambda,F,Zminus,Zplus,Qminus,Qplus)==(71,4727,20,4,2,1,4,671234,50,9,13,2)
assert raw_count==0 and tc3_list==[]

# Source radial interval, for autopsy only; full TC4 not activated because TC3 is empty.
L2=Fraction(10**(n2-1),C2); R2=Fraction(10**n2,C2)
L3=Fraction(10**(n3-1),C3); R3=Fraction(10**n3,C3)
Lsrc=max(L2,L3); Rsrc=min(R2,R3)
assert (Lsrc,Rsrc)==(Fraction(1000,4727),Fraction(100,71))

# 3) Common-dilation normalized-row regression on frozen R7D witness B.
# Base b=(1,6,8), V=24, packet=(48,436,75,445), X=10,Y=10,G=1,K=10.
rb=[]
b1,b2,b3=1,6,8; V=24; PP1,PP2,PP3,QQ0=48,436,75,445; X=Y=10; G=1; K=10
base_g=(gcd(V,PP1),gcd(V,PP2),gcd(V,PP3))
assert base_g==(24,4,3)
base_norm=None
for q in [1,3,7,11,13,17,19,23,29,31]:
    # F for this frozen normalized profile is rad(C1*C2*C3)=rad(2*109*25); all chosen q avoid it.
    assert gcd(q,rad(2*109*25))==1
    Vq=V*q; bb1=b1*q; bb2=b2*q; bb3=b3*q
    gi=(gcd(Vq,PP1),gcd(Vq,PP2),gcd(Vq,PP3))
    assert gi==base_g
    A0=Y*G*(bb1*X+bb2)+bb3
    B0=bb1*X*Y*G*K
    C0=bb2*Y*PP2+bb3*PP3
    d=gcd(gcd(A0,B0),C0)
    norm=(A0//d,B0//d,C0//d)
    if base_norm is None: base_norm=norm
    assert norm==base_norm
    rb.append((q,Vq,*gi,*norm,d))

# 4) Prime-support rather than magnitude: source coprimality identity.
# gcd(U,V0*q)=1 iff gcd(U,V0)=gcd(U,q)=1.
source_reg=0
for V0 in range(1,50):
  for q in range(1,50):
    for U in range(1,50):
      assert (gcd(U,V0*q)==1)==(gcd(U,V0)==1 and gcd(U,q)==1)
      source_reg+=1

# q-interval registry
qrows=[{
 'scope':'R29_HISTORICAL_SUPPORT_SURVIVOR__R26_UNIQUE_TUPLE',
 'packet':'(640,1420,4727,4977)','selectors':'A=1;W=20;u0=1;g1*=80',
 'exponents':'n=4;delta=-2;rho=2;m=1;n2=2;n3=4;m2=1;m3=4;k=1;g=0',
 'Zminus':Zminus,'Zplus':Zplus,'Lambda':Lambda,'Qminus':Qminus,'Qplus':Qplus,
 'interval_width':Qplus-Qminus,'integer_q_count':raw_count,'F':F,
 'F_factorization':'2*29*71*163','coprime_q_count':len(tc3_list),'q_candidates':'',
 'TC3':'FAIL_EMPTY_INTERVAL','TC4':'NOT_ACTIVATED','first_failure':'TC3_Q_INTERVAL_EMPTY'
}]
with (ROOT/'105-R30-q-interval-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=qrows[0].keys()); w.writeheader(); w.writerows(qrows)

# Common dilation regression CSV
with (ROOT/'105-R30-common-dilation-regression.csv').open('w',newline='',encoding='utf-8') as f:
    cols=['q','Vq','g1','g2','g3','Ahat','Bhat','Chat','row_content']
    w=csv.writer(f); w.writerow(cols); w.writerows(rb)

# Survivor registry: no genuine TC3+TC4 pass found in frozen replay corpus.
with (ROOT/'105-R30-TC3-TC4-survivor-registry.csv').open('w',newline='',encoding='utf-8') as f:
    cols=['search_scope','genuine_TC3_TC4_pass_count','full_strict_A1_witness_count','status','evidence']
    w=csv.writer(f); w.writerow(cols)
    w.writerow(['FROZEN_REPLAY:R15_R17_R20_R26_R28_R29_PLUS_R8_PSDG_HITS',0,0,'NONE_FOUND_NOT_GLOBAL_PROOF','R15 no z-selector hit; R17 formal q interval empty; R20/R29 support survivor TC3 empty; R28 Q0<=3000 no post-support TC3-ready hit; R8 PSDG hits die before TC3'])

# Exceptional branch registry
exrows=[
 ['EMPTY_Q_WINDOW','Qminus>Qplus','EXTINCT','N30=0 identically'],
 ['SINGLETON_Q_WINDOW','Qminus=Qplus=q*','DETERMINISTIC','joint pass iff base-source U exists with gcd(q*,F*U)=1'],
 ['MULTI_Q_WINDOW','Qminus<Qplus','Q_ELIMINATED','replace q-existential by exact Mobius count over rad(FU)'],
 ['GENERIC_COMPLETED_SOURCE','historical source-q branch inactive','Q_DEPENDENCE_ONLY_BY_COPRIMALITY','fixed source geometry; actual V=V0*q'],
 ['HISTORICAL_SOURCE_Q1_DECORATED','old source-chart q_src=1, not R15 residual q','Q_DEPENDENCE_ONLY_BY_COPRIMALITY','retain fixed strict boundary/AP/native period; residual q still only enlarges V'],
 ['Q_SUPPORT_CLASS','same added prime support outside V0','SAME_TC4_SELECTOR','TC4 depends on residual q through gcd(U,q), not numerical magnitude'],
]
with (ROOT/'105-R30-exceptional-branch-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['branch','condition','status','certificate']); w.writerows(exrows)

certrows=[
 ['R26_FROZEN_HASH_LEDGER','PASS','41f4e2aad7720862a98349d61d22c482b7f5045b6c54bfea56651d4032d97680','ledger cross-check; raw File-Library bytes unavailable'],
 ['R29_FROZEN_MANIFEST_LEDGER','PASS','f21b6927... stage archive; e374454c... support saturation cert','ledger cross-check; raw File-Library bytes unavailable'],
 ['TC3_EXACT_RECOVERY','PASS','R15','z=Lambda q,(q,F)=1; Q endpoints exact integers'],
 ['TC4_EXACT_RECOVERY','PASS','R8','decorated source interval + periodic residue selector + gcd(U,V)=1; Umin<Rsrc'],
 ['COMMON_DILATION_INVARIANCE','PASS',str(len(rb))+' exact regressions','normalized row and g_i invariant for TC3-compatible common dilation'],
 ['MOBIUS_Q_ELIMINATION','PASS',str(reg_cases)+' exact count regressions','count formula equals direct q enumeration'],
 ['SOURCE_COPRIMALITY_SPLIT','PASS',str(source_reg)+' exact regressions','gcd(U,V0*q)=1 iff gcd(U,V0)=gcd(U,q)=1'],
 ['R29_SURVIVOR_TC3_AUTOPSY','PASS','Q=[13,2]','shortest death certificate: Qminus>Qplus'],
 ['GLOBAL_TC3_TC4_INCOMPATIBILITY','NOT_PROVED','no genuine pass found; no universal zero theorem','do not infer from finite search'],
 ['STRICT_A1_UNLIFTABILITY','NOT_PROVED','','remaining global primitive-packet/architecture locus'],
 ['Q_VARIABLE_ELIMINATION_EQUIVALENCE','PROVED','N30 architecture count','free q removed exactly'],
]
with (ROOT/'105-R30-complete-certificate-registry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['certificate','status','scope_or_value','detail']); w.writerows(certrows)

# machine-readable output / log support
out={
 'mobius_regression_cases':reg_cases,
 'source_coprimality_regression_cases':source_reg,
 'r29_historical':{
   'C2':C2,'C3':C3,'g0':g0,'mu':mu,'lambda_z':lambda_z,'tau':tau,'Lambda':Lambda,
   'R1':R1,'F':F,'F_primes':factor_distinct(F),'Zminus':Zminus,'Zplus':Zplus,
   'Qminus':Qminus,'Qplus':Qplus,'q_width':Qplus-Qminus,'raw_q_count':raw_count,
   'tc3_q_candidates':tc3_list,'source_L':str(Lsrc),'source_R':str(Rsrc)
 },
 'common_dilation_rows':len(rb),
 'common_dilation_normalized_row':base_norm,
 'verdicts':{
   'Q_VARIABLE_ELIMINATION_EQUIVALENCE':'PROVED',
   'GLOBAL_Q_ELIMINATION_TERMINAL_THEOREM':'NO_EXTINCTION_NOT_PROVED',
   'TC3_TC4_GLOBAL_INCOMPATIBILITY':'NOT_PROVED',
   'FULL_STRICT_A1_WITNESS_FOUND':'NO',
   'R30_TERMINAL_ATTACK_FAILED':'YES'
 }
}
(ROOT/'105-R30-execution-script-output.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2,ensure_ascii=False))
