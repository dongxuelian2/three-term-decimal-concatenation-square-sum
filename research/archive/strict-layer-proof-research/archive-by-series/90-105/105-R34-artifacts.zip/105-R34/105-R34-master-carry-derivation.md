# 105-R34 — MASTER Carry Derivation

The R33 authoritative positive MASTER is
\[
g_1^*\left(WT+A10^nH\right)=AWu_0\,10^{m+n+g}D.
\]

For q1, multiply by \(\Lambda/g_1^*\) and define
\[
b_1=\frac{\Lambda u_0AW}{g_1^*},\quad
b_2=A\Lambda,\quad b_3=W\Lambda.
\]
Then
\[
\boxed{b_1 10^{m+n+g}D=b_3T+b_2 10^nH.}
\]

The frozen tail factor
\[
\lambda_z=\frac{10^n}{(10^n,WT)},\qquad \lambda_z\mid\Lambda
\]
gives \(10^n\mid b_3T\). Put
\[
J_3=\frac{b_3T}{10^n}.
\]
Dividing MASTER by \(10^n\) yields
\[
\boxed{J_3+b_2H=b_1 10^{m+g}D.}
\]

No new carry theorem is introduced in R34. The decisive result is instead a dependency audit:
the two proposed source-word congruences are exact rewritings of this carry plus
\(10^n\mid b_3T\) after substituting \(X_i=C_iU\).
