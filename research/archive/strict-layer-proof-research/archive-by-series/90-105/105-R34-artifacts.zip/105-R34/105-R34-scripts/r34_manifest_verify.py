#!/usr/bin/env python3
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/"105-R34-SHA256-MANIFEST.txt"
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()
n=0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line or line.startswith("#"): continue
    digest, rel=line.split("  ",1)
    p=ROOT/rel
    assert p.exists(), rel
    assert sha(p)==digest, rel
    n+=1
print(f"R34 manifest verification PASS; files={n}")
