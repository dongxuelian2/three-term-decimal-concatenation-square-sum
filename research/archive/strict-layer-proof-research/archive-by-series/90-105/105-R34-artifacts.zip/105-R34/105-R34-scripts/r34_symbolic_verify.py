#!/usr/bin/env python3
from math import gcd

SEVEN = [
(20,120,123,173,1,2,1,10,60,123,5,1,2,2,2,0,1),
(48,436,75,445,3,4,1,24,109,25,2,1,1,2,1,0,1),
(120,900,691,1141,1,12,1,24,75,691,2,1,2,2,2,0,1),
(140,1240,491,1341,1,2,1,10,620,491,5,1,2,2,2,0,1),
(230,330,1593,1643,1,2,1,10,165,1593,5,1,2,2,2,0,1),
(288,2584,585,2665,3,4,1,24,646,195,2,1,1,2,1,0,1),
(298,2514,1485,2935,5,1,1,1,2514,297,1,1,1,2,1,0,1),
]

checks=0
for t in SEVEN:
    P1,P2,P3,Q0,A,W,u0,g1,C2,C3,Lam,m2,m3,n2,n3,g,k=t
    assert n2==m2+g+k; checks+=1
    assert n3==m3-g; checks+=1
    assert P2==u0*W*C2 and P3==u0*A*C3; checks+=1

    b1=Lam*u0*A*W//g1
    b2=A*Lam; b3=W*Lam; V0=Lam*u0*A*W
    T=Q0-P3; H=10**g*Q0-P2; D=10**k*P1-Q0

    assert b1*10**(m2+n3+g)*D == b3*T+b2*10**n3*H; checks+=1
    assert (b3*T)%(10**n3)==0; checks+=1
    J3=b3*T//10**n3
    assert J3+b2*H==b1*10**(m2+g)*D; checks+=1

    A2=J3+Q0*(b2*10**g+b1*10**(m2+g))
    A3=b3*Q0

    assert V0*C3-A3 == -10**n3*J3; checks+=1
    assert V0*C2-A2 == -10**n2*b1*P1; checks+=1

    S=A3*C2-A2*C3
    S2=10**n3*J3*C2-10**n2*b1*P1*C3
    assert S==S2; checks+=1
    r=min(n2,n3)
    assert S%(10**r)==0; checks+=1

    dV=gcd(V0,10**r); Mr=10**r//dV
    if S:
        assert abs(S)>=10**r>=Mr; checks+=1

print(f"R34 symbolic/seven-hit replay PASS; checks={checks}")
print("F2_INFORMATION_GAIN=ZERO")
print("F3_INFORMATION_GAIN=ZERO")
print("CROSS_REMAINDER_HAS_FULL_10^r_FACTOR=YES")
print("REQUESTED_0_LT_ABS_R_LT_MR_CERTIFICATE=STRUCTURALLY_IMPOSSIBLE")
