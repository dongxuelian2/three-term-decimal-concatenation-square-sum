
# 105-R38 — First Genuine Normalized Selector-Consistent Root

\[
(u_0,A,W,g_0,a,\mu,s)=(1,3,2,6,1,1,1),
\quad (X,Y,G,K,C_2,C_3)=(1,10,1,10,11,7),
\]
\[
(P_1,P_2,P_3,Q_0)=(6,22,21,31),
\quad (L_N,B_N,C_N)=(100,42,702).
\]
\[
\mathcal A_N=-8236,\quad R=2848,\quad
E_-=-49416=(\mu g_0\mathcal A_N)\cdot1.
\]
NRDG and COP pass. Replay fails at the frozen exponent identity:
\(n_2=2,g=0,k=1\Rightarrow X=10\), but the root has \(X=1\).
