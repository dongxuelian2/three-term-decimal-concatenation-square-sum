
# 105-R38 — Corrected Simultaneous-Locus Continuation

The exact normalized selector-consistent root dies before the corrected
simultaneous locus at
\[
X_{\rm root}=1\ne10=10^{n_2-g-k}.
\]
Thus it produces no point of \(\mathscr T\). This is a pointwise replay;
global emptiness of \(\mathscr T\) is not proved.
