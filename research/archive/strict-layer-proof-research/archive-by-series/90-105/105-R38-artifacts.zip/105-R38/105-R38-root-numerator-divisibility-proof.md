# 105-R38 — Root-Numerator Divisibility Saturation


On an actual NTC1+sphere incidence,
\[
C=BQ-LP,\qquad S_0=Q^2-P^2.
\]
Hence
\[
\delta_{\rm norm}
=(BQ-LP)^2-(B^2-L^2)(Q^2-P^2)
=\boxed{(BP-LQ)^2}.
\]
Choose the matching sign by \(\varepsilon R=BP-LQ\). Then
\[
\boxed{BC+\varepsilon LR=\mathcal A_NQ},\qquad
\boxed{CL+\varepsilon BR=\mathcal A_NP}. \tag{RI}
\]
Thus \(E_\varepsilon=\mathcal A_NP_1\). Under production normalization
\(P_1=g_0\mu s\),
\[
\boxed{E_\varepsilon=\mu g_0\mathcal A_Ns}.
\]
Therefore NRDG is exactly \(\mu g_0\mid P_1\), its quotient is exactly
\(s\), and COP is exactly the already-imposed \((a,\mu s)=1\).
For every prime \(p\),
\[
v_p(E_\varepsilon)=v_p(\mathcal A_N)+v_p(g_0)+v_p(\mu)+v_p(s).
\]
So no universal \(p\)-adic deficit, size gap, or extra factor allocation
can be extracted from NRDG alone on the production-normalized exact root locus.
