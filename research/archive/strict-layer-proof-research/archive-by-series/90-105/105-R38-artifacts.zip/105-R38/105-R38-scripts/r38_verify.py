
from math import gcd, isqrt
u0,A,W,g0,a,mu,s=1,3,2,6,1,1,1
X,Y,G,K,C2,C3=1,10,1,10,11,7
P1,P2,P3,Q0=6,22,21,31
L,B,C=100,42,702
AN=B*B-L*L
S0=P2*P2+P3*P3
delta=C*C-AN*S0
R=isqrt(delta)
eps=-1
E=C*L+eps*B*R
assert gcd(u0*A*W,P1)==g0
assert P1==g0*mu*s and gcd(a,mu*s)==1
assert P1*P1+P2*P2+P3*P3==Q0*Q0
assert L*P1==B*Q0-C
assert delta==R*R and R==2848
assert eps*R==B*P1-L*Q0
assert E==AN*P1 and E%(mu*g0*AN)==0
assert C+eps*R==(B-L)*(Q0+P1)
assert C-eps*R==(B+L)*(Q0-P1)
d=gcd(B,L); beta=B//d; lam=L//d
assert (Q0+P1)%abs(beta-lam)!=0
assert (Q0-P1)%abs(beta+lam)!=0
assert X!=10
print("ALL_EXACT_R38_CHECKS=PASS")
