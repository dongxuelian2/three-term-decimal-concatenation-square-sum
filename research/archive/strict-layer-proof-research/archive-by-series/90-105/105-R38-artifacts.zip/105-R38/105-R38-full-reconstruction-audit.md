
# 105-R38 — Full Reconstruction Audit

No terminal pair was produced. Full Strict-(A1) reconstruction is not
triggered. The R38 root dies earlier at source-exponent synchronization.
No extinction certificate and no full-witness certificate is issued.
