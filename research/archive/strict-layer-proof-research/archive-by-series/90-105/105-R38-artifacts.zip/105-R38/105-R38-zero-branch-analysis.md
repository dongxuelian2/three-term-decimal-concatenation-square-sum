
# 105-R38 — Zero / Degenerate Branch Analysis

- \(\mathcal A_N=0\iff B_N=L_N\); NF11 is linear and NRDG division is invalid.
  Exact primitive normalized NTC1+sphere example:
  \((P_1,P_2,P_3,Q_0)=(2000,384,135,2041)\),
  \(B_N=L_N=3000,C_N=123000\). It fails mu-Smith:
  \(\gcd(25,16\cdot45)=5\).
- \(R=0\iff B_NP_1=L_NQ_0\) on a nondegenerate exact root. This forces
  \(\mathcal A_N>0\), but creates no NRDG contradiction.
- \(C_N=R\Rightarrow\mathcal A_N=0\); \(C_N=-R\) is impossible for
  positive parameters.
