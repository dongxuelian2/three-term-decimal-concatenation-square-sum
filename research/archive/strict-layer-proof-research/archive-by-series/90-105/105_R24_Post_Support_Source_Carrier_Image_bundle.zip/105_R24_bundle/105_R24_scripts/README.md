# 105-R24 exact scripts

1. `105_R24_source_image.py` builds the core graph/pullback archive using exact integer/Fraction arithmetic.
2. `105_R24_sphere_chart_regression.py` exhaustively regression-checks the canonical sphere chart and `h` content laws on a finite exact parameter box.
3. `105_R24_finalize.py` is the final semantic/provenance pass: it replays all three R23 master rows, adds frozen genuine-positive pullback predicates, refines the chart-minimal carrier, verifies the auxiliary finite-divisor exponent recovery, synchronizes the terminal block, and regenerates hashes.

No floating-point arithmetic is used for theorem predicates.
