#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass, asdict
from fractions import Fraction
from math import gcd, lcm
from pathlib import Path
import csv, hashlib, json

ROOT = Path('/mnt/data/105_R24_bundle')
SCRIPTS = ROOT/'105_R24_scripts'


def vp(n:int,p:int)->int:
    n=abs(n)
    if n==0: raise ValueError('vp(0)')
    e=0
    while n%p==0:
        e+=1;n//=p
    return e


def divisors(n:int):
    out=[]
    i=1
    while i*i<=n:
        if n%i==0:
            out.append(i)
            if i*i!=n: out.append(n//i)
        i+=1
    return sorted(out)


def canonical_sphere_params(P1:int,P2:int,P3:int,Q:int):
    assert P1>0 and P2>0 and P3>0 and Q>0
    assert P1*P1+P2*P2+P3*P3==Q*Q
    den=Q+P3
    r=Fraction(P1,den); s=Fraction(P2,den)
    c=lcm(r.denominator,s.denominator)
    a=r.numerator*(c//r.denominator)
    b=s.numerator*(c//s.denominator)
    gg=gcd(gcd(abs(a),abs(b)),c)
    a//=gg;b//=gg;c//=gg
    raw=(2*a*c,2*b*c,c*c-a*a-b*b,c*c+a*a+b*b)
    h=gcd(gcd(abs(raw[0]),abs(raw[1])),gcd(abs(raw[2]),abs(raw[3])))
    got=tuple(x//h for x in raw)
    assert got==(P1,P2,P3,Q), (got,(P1,P2,P3,Q),(a,b,c,h))
    return dict(a=a,b=b,c=c,h=h,S=a*a+b*b,R=a*a+b*b+c*c,rawP1=raw[0],rawP2=raw[1],rawP3=raw[2],rawQ=raw[3])


def h_odd_formula(a,b,c,p):
    assert p%2==1
    S=a*a+b*b
    return min(vp(c,p),vp(S,p)) if c%p==0 and S%p==0 else 0


def h_v2_formula(a,b,c):
    odd=sum(x&1 for x in (a,b,c))
    return 1 if odd==2 else 0

@dataclass
class Beta:
    label:str
    P1:int;P2:int;P3:int;Q0:int
    A:int;g1:int;u0:int
    m2:int;n3:int;g:int;k:int


def recover(beta:Beta):
    b=beta
    assert b.P1*b.P1+b.P2*b.P2+b.P3*b.P3==b.Q0*b.Q0
    assert gcd(gcd(b.P1,b.P2),gcd(b.P3,b.Q0))==1
    X=10**b.m2;Y=10**b.n3;G=10**b.g;K=10**b.k
    n2=b.m2+b.g+b.k
    m3=b.n3+b.g
    D=K*b.P1-b.Q0
    T3=b.Q0-b.P3
    E=G*b.Q0-b.P2
    out=dict(X=X,Y=Y,G=G,K=K,n2=n2,m3=m3,D=D,T3=T3,E=E)
    # lower selectors / YDIV
    out['A_DIVIDES_P3']=(b.P3%b.A==0)
    out['G1_DIVIDES_P1']=(b.P1%b.g1==0)
    out['YDIV']=(b.P2*b.g1*T3)%Y==0
    out['J']=b.u0*b.A*X*Y*G*D-b.g1*T3
    out['Nw']=b.g1*b.A*Y*E
    J=out['J']; Nw=out['Nw']
    out['J_POSITIVE']=J>0
    out['W_RECOVERABLE']=J>0 and Nw%J==0
    out['W']=Nw//J if out['W_RECOVERABLE'] else None
    W=out['W']
    out['MR_RECOVERABLE']=W is not None and b.P2%W==0
    out['Mr']=b.P2//W if out['MR_RECOVERABLE'] else None
    Mr=out['Mr']
    out['C2_RECOVERABLE']=Mr is not None and Mr%b.u0==0
    out['C2']=Mr//b.u0 if out['C2_RECOVERABLE'] else None
    out['NR_RECOVERABLE']=out['A_DIVIDES_P3']
    out['Nr']=b.P3//b.A if out['NR_RECOVERABLE'] else None
    Nr=out['Nr']
    out['C3_RECOVERABLE']=Nr is not None and Nr%b.u0==0
    out['C3']=Nr//b.u0 if out['C3_RECOVERABLE'] else None
    C2,C3=out['C2'],out['C3']
    if W is not None:
        g0=gcd(b.u0*b.A*W,b.P1)
        out['g0']=g0
        out['MASTER_CORRIDOR']= (b.g1%g0==0 and b.P1%b.g1==0)
        out['mu']=b.g1//g0 if b.g1%g0==0 else None
    else:
        out['g0']=None;out['MASTER_CORRIDOR']=False;out['mu']=None
    mu=out['mu']
    if C2 is not None and C3 is not None and mu is not None:
        out['MU_SMITH']=gcd(mu,C2*C3)==1
    else: out['MU_SMITH']=False
    if W is not None and mu is not None:
        lam=Y//gcd(Y,W*T3)
        tau=lam//gcd(lam,mu)
        out['lambda_z']=lam;out['tau']=tau
    else:
        out['lambda_z']=None;out['tau']=None
    if b.P1%b.g1==0:
        out['R1']=b.P1//b.g1
    else: out['R1']=None
    tau=out['tau'];R1=out['R1']
    out['TAIL_G1']=tau is not None and R1 is not None and gcd(tau,R1)==1
    out['TAIL_SMITH']=tau is not None and C2 is not None and C3 is not None and gcd(tau,C2*C3)==1
    out['FULL_SUPPORT']= all([out['A_DIVIDES_P3'],out['G1_DIVIDES_P1'],out['YDIV'],out['J_POSITIVE'],out['W_RECOVERABLE'],out['MR_RECOVERABLE'],out['C2_RECOVERABLE'],out['C3_RECOVERABLE'],out['MASTER_CORRIDOR'],out['MU_SMITH'],out['TAIL_G1'],out['TAIL_SMITH']])
    if out['FULL_SUPPORT']:
        d=m3-b.m2
        # 10^(d-1) < W/A < 10^(d+1), use fractions and negative exponent handling
        ratio=Fraction(W,b.A)
        def tenpow(e): return Fraction(10**e,1) if e>=0 else Fraction(1,10**(-e))
        lo,hi=tenpow(d-1),tenpow(d+1)
        out['ratio']=ratio;out['ratio_lo']=lo;out['ratio_hi']=hi
        out['RATIO_PASS']=lo<ratio<hi
    else:
        out['ratio']=None;out['ratio_lo']=None;out['ratio_hi']=None;out['RATIO_PASS']=None
    # first failure in the R24 ordering
    order=[('A_DIVISOR',out['A_DIVIDES_P3']),('G1_DIVISOR',out['G1_DIVIDES_P1']),('Y_DIV',out['YDIV']),('J_POSITIVE',out['J_POSITIVE']),('DIRECT_W_INTEGRAL',out['W_RECOVERABLE']),('MR_INTEGRAL',out['MR_RECOVERABLE']),('RADIAL_INTEGRAL',out['C2_RECOVERABLE'] and out['C3_RECOVERABLE']),('MASTER_CORRIDOR',out['MASTER_CORRIDOR']),('MU_SMITH',out['MU_SMITH']),('TAIL_G1',out['TAIL_G1']),('TAIL_SMITH',out['TAIL_SMITH'])]
    out['FIRST_FAILURE']='FULL_SUPPORT_PASS'
    for name,ok in order:
        if not ok:
            out['FIRST_FAILURE']=name;break
    return out

CURRENT=Beta('CURRENT_FRONTIER',640,1420,4727,4977,1,80,1,1,4,0,1)
G10=Beta('G10_DIAGNOSTIC',200,365,104,429,13,40,1,1,1,1,1)

# ---- exact verification ----
for B in (CURRENT,G10):
    p=canonical_sphere_params(B.P1,B.P2,B.P3,B.Q0)
    assert gcd(gcd(p['a'],p['b']),p['c'])==1
    assert vp(p['h'],2)==h_v2_formula(p['a'],p['b'],p['c'])
    if p['h']%5==0:
        assert vp(p['h'],5)==h_odd_formula(p['a'],p['b'],p['c'],5)
    else:
        assert h_odd_formula(p['a'],p['b'],p['c'],5)==0

cur=recover(CURRENT); g10=recover(G10)
assert (cur['D'],cur['T3'],cur['J'],cur['W'],cur['Mr'],cur['C2'],cur['C3'],cur['g0'],cur['mu'],cur['lambda_z'],cur['tau'],cur['R1'])==(1423,250,142280000,20,71,71,4727,20,4,2,1,8)
assert cur['FULL_SUPPORT'] and not cur['RATIO_PASS']
assert (g10['D'],g10['T3'],g10['J'],g10['W'],g10['Mr'],g10['C2'],g10['C3'],g10['g0'],g10['mu'])==(1571,325,20410000,1,365,365,8,1,40)
assert g10['MASTER_CORRIDOR'] and not g10['MU_SMITH'] and g10['FIRST_FAILURE']=='MU_SMITH'

# parameter-native W formula / h cancellation regression
for B in (CURRENT,G10):
    p=canonical_sphere_params(B.P1,B.P2,B.P3,B.Q0)
    a,b,c,h,S,R=p['a'],p['b'],p['c'],p['h'],p['S'],p['R']
    X=10**B.m2;Y=10**B.n3;G=10**B.g;K=10**B.k
    Jraw=B.u0*B.A*X*Y*G*(2*K*a*c-R)-2*B.g1*S
    Nraw=B.g1*B.A*Y*(G*R-2*b*c)
    rr=recover(B)
    assert Jraw==h*rr['J']
    assert Nraw==h*rr['Nw']
    assert Fraction(Nraw,Jraw)==Fraction(rr['Nw'],rr['J'])

# current params exact expected
cp=canonical_sphere_params(CURRENT.P1,CURRENT.P2,CURRENT.P3,CURRENT.Q0)
gp=canonical_sphere_params(G10.P1,G10.P2,G10.P3,G10.Q0)
assert (cp['a'],cp['b'],cp['c'],cp['h'])==(160,355,2426,1213)
assert (gp['a'],gp['b'],gp['c'],gp['h'])==(200,365,533,1066)

# YDIV budget equality to direct valuations
def ybudget(B):
    p=canonical_sphere_params(B.P1,B.P2,B.P3,B.Q0)
    a,b,c,h,S=p['a'],p['b'],p['c'],p['h'],p['S']
    B2=2+vp(b,2)+vp(c,2)+vp(B.g1,2)+vp(S,2)-2*vp(h,2)
    # direct formula handles zeros? all nonzero
    B5=vp(b,5)+vp(c,5)+vp(B.g1,5)+vp(S,5)-2*vp(h,5)
    B5_simpl=vp(B.g1,5)+vp(b,5)+abs(vp(c,5)-vp(S,5))
    assert B5==B5_simpl
    T3=B.Q0-B.P3
    assert B2==vp(B.P2,2)+vp(B.g1,2)+vp(T3,2)
    assert B5==vp(B.P2,5)+vp(B.g1,5)+vp(T3,5)
    return B2,B5,p
cb2,cb5,_=ybudget(CURRENT)
gb2,gb5,_=ybudget(G10)
assert (cb2,cb5)==(7,5)
assert CURRENT.n3<=min(cb2,cb5)
assert G10.n3<=min(gb2,gb5)

# -------- artifacts --------
def write_csv(name, rows, fields=None):
    p=ROOT/name
    if fields is None:
        fields=[]
        for row in rows:
            for k in row:
                if k not in fields: fields.append(k)
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
        w.writeheader();w.writerows(rows)
    return p

def fmt_frac(x):
    if x is None:return ''
    if isinstance(x,Fraction): return f'{x.numerator}/{x.denominator}' if x.denominator!=1 else str(x.numerator)
    return str(x)

# 1 primitive sphere carrier
sphere_rows=[]
for B in (CURRENT,G10):
    p=canonical_sphere_params(B.P1,B.P2,B.P3,B.Q0)
    sphere_rows.append(dict(LABEL=B.label,P1=B.P1,P2=B.P2,P3=B.P3,Q0=B.Q0,a=p['a'],b=p['b'],c=p['c'],h=p['h'],gcd_abc=gcd(gcd(p['a'],p['b']),p['c']),S_a2_b2=p['S'],T3_factor=f"2*S/h={2*p['S']}/{p['h']}",P2_factor=f"2*b*c/h={2*p['b']*p['c']}/{p['h']}",v2_h=vp(p['h'],2),v5_h=vp(p['h'],5),COVERAGE='CANONICAL_ORIENTED_CHART_EXACT'))
write_csv('105_R24_Primitive_Sphere_Carrier.csv',sphere_rows)

# 2 lower carrier registry
lower_rows=[]
for B in (CURRENT,G10):
    r=recover(B);p=canonical_sphere_params(B.P1,B.P2,B.P3,B.Q0)
    lower_rows.append(dict(LABEL=B.label,a=p['a'],b=p['b'],c=p['c'],h=p['h'],A=B.A,G1_STAR=B.g1,U0=B.u0,M2=B.m2,N3=B.n3,G_EXP=B.g,K_EXP=B.k,N2=r['n2'],M3=r['m3'],X=r['X'],Y=r['Y'],G=r['G'],K=r['K'],D=r['D'],T3=r['T3'],Y_DIV_PASS=r['YDIV'],J_ANGLE=r['J'],W_RECOVERABLE=r['W_RECOVERABLE'],W=r['W'],MR_RECOVERABLE=r['MR_RECOVERABLE'],MR=r['Mr'],C2=r['C2'],C3=r['C3'],FULL_SUPPORT=r['FULL_SUPPORT'],FIRST_FAILURE=r['FIRST_FAILURE']))
write_csv('105_R24_Lower_Carrier_Registry.csv',lower_rows)

# 3 zero-one fibre audit
zof_rows=[
 dict(SCOPE='GENERAL',FIBRE='W',BOUND='<=1',RECOVERY='W=Nw/J; Nw=g1*A*Y*(GQ0-P2)',NONEMPTY='J>0 and J|Nw',STATUS='PROVED_ALGEBRAICALLY'),
 dict(SCOPE='GENERAL',FIBRE='(W,Mr)',BOUND='<=1',RECOVERY='Mr=P2/W',NONEMPTY='W fibre nonempty and W|P2',STATUS='PROVED_ALGEBRAICALLY'),
 dict(SCOPE='GENERAL',FIBRE='(W,Mr,C2,C3)',BOUND='<=1',RECOVERY='C2=Mr/u0; C3=P3/(A*u0)',NONEMPTY='u0|Mr and A*u0|P3',STATUS='PROVED_ALGEBRAICALLY'),
 dict(SCOPE='GENERAL',FIBRE='FULL_SUPPORT_STACK',BOUND='<=1',RECOVERY='deterministic g0,mu,lambda_z,tau,R1 plus gcd predicates',NONEMPTY='all lower-native predicates pass',STATUS='PROVED_ALGEBRAICALLY'),
]
for B,r in [(CURRENT,cur),(G10,g10)]:
    zof_rows.append(dict(SCOPE=B.label,FIBRE='FULL_SUPPORT_STACK',BOUND='observed 1' if r['FULL_SUPPORT'] else 'observed 0',RECOVERY=f"W={r['W']};Mr={r['Mr']};C2={r['C2']};C3={r['C3']}",NONEMPTY=str(r['FULL_SUPPORT']),STATUS=r['FIRST_FAILURE']))
write_csv('105_R24_Zero_One_Fibre_Audit.csv',zof_rows)

# 4 Y divisibility pullback
yrows=[
 dict(SCOPE='GENERAL',PRIME='2',PULLBACK='n3 <= 2+v2(b)+v2(c)+v2(g1*)+v2(a^2+b^2)-2*v2(h)',H_RULE='v2(h)=1 iff exactly two of a,b,c odd; else 0',NORMALIZED_CHAMBER='PARITY_TWO_ODD / PARITY_OTHER',STATUS='PROVED'),
 dict(SCOPE='GENERAL',PRIME='5',PULLBACK='n3 <= v5(g1*)+v5(b)+|v5(c)-v5(a^2+b^2)|',H_RULE='v5(h)=min(v5(c),v5(a^2+b^2))',NORMALIZED_CHAMBER='v5(c)<,=,>v5(a^2+b^2)',STATUS='PROVED'),
]
for B in (CURRENT,G10):
    b2,b5,p=ybudget(B)
    yrows += [dict(SCOPE=B.label,PRIME='2',PULLBACK=f'n3={B.n3} <= B2={b2}',H_RULE=f"v2(h)={vp(p['h'],2)}",NORMALIZED_CHAMBER='PASS',STATUS='PASS'),dict(SCOPE=B.label,PRIME='5',PULLBACK=f'n3={B.n3} <= B5={b5}',H_RULE=f"v5(h)={vp(p['h'],5)}",NORMALIZED_CHAMBER='PASS',STATUS='PASS')]
write_csv('105_R24_Y_Divisibility_Pullback.csv',yrows)

# 5 support pullback
support_rows=[
 dict(GATE='MASTER_CORRIDOR',LOWER_NATIVE_FORMULA='g0=gcd(u0*A*W(beta),P1); require g0|g1*|P1',STATUS='PROVED_PULLBACK'),
 dict(GATE='MU_SMITH',LOWER_NATIVE_FORMULA='mu=g1*/g0; require gcd(mu,C2(beta)*C3(beta))=1',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_SCALE',LOWER_NATIVE_FORMULA='lambda_z=Y/gcd(Y,W(beta)*T3); tau=lambda_z/gcd(lambda_z,mu)',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_G1',LOWER_NATIVE_FORMULA='R1=P1/g1*; require gcd(tau,R1)=1',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_SMITH',LOWER_NATIVE_FORMULA='require gcd(tau,C2(beta)*C3(beta))=1',STATUS='PROVED_PULLBACK'),
]
for B,r in [(CURRENT,cur),(G10,g10)]:
    support_rows += [dict(GATE=f'{B.label}:MASTER_CORRIDOR',LOWER_NATIVE_FORMULA=f"g0={r['g0']}, g1*={B.g1}, P1={B.P1}",STATUS='PASS' if r['MASTER_CORRIDOR'] else 'FAIL'),dict(GATE=f'{B.label}:MU_SMITH',LOWER_NATIVE_FORMULA=f"mu={r['mu']}, C2={r['C2']}, C3={r['C3']}",STATUS='PASS' if r['MU_SMITH'] else 'FAIL'),dict(GATE=f'{B.label}:TAIL_G1',LOWER_NATIVE_FORMULA=f"tau={r['tau']}, R1={r['R1']}",STATUS='PASS' if r['TAIL_G1'] else 'FAIL'),dict(GATE=f'{B.label}:TAIL_SMITH',LOWER_NATIVE_FORMULA=f"tau={r['tau']}, C2*C3={r['C2']*r['C3'] if r['C2'] and r['C3'] else ''}",STATUS='PASS' if r['TAIL_SMITH'] else 'FAIL')]
write_csv('105_R24_Support_Pullback.csv',support_rows)

# 6 lower carrier first failure
ffrows=[]
for B,r in [(CURRENT,cur),(G10,g10)]:
    ffrows.append(dict(LABEL=B.label,SPHERE_PACKET=f'{B.P1},{B.P2},{B.P3},{B.Q0}',A=B.A,G1_STAR=B.g1,G=B.g,K=B.k,M2=B.m2,N3=B.n3,Y_DIV_PASS=r['YDIV'],J_POSITIVE=r['J_POSITIVE'],DIRECT_W_INTEGRAL=r['W_RECOVERABLE'],MR_INTEGRAL=r['MR_RECOVERABLE'],RADIAL_INTEGRAL=r['C2_RECOVERABLE'] and r['C3_RECOVERABLE'],MASTER_CORRIDOR_PASS=r['MASTER_CORRIDOR'],MU_SMITH_PASS=r['MU_SMITH'],TAIL_G1_PASS=r['TAIL_G1'],TAIL_SMITH_PASS=r['TAIL_SMITH'],LOWER_CARRIER_FIRST_FAILURE=r['FIRST_FAILURE']))
write_csv('105_R24_Lower_Carrier_First_Failure.csv',ffrows)

# 7 source image points
image_rows=[dict(IMAGE_ID='IMG1_CURRENT',P1=CURRENT.P1,P2=CURRENT.P2,P3=CURRENT.P3,Q0=CURRENT.Q0,A=CURRENT.A,W=cur['W'],M2=CURRENT.m2,M3=cur['m3'],W_OVER_A=fmt_frac(cur['ratio']),RATIO_LO=fmt_frac(cur['ratio_lo']),RATIO_HI=fmt_frac(cur['ratio_hi']),RATIO_CHAMBER_PASS=cur['RATIO_PASS'],FULL_SUPPORT_STACK=True,PROVENANCE='CURRENT_FRONTIER_EXACT_RECOVERY')]
write_csv('105_R24_Source_Image_Points.csv',image_rows)

# 8 exponent image
exp_rows=[
 dict(SCOPE='GENERAL_FIXED_ORIENTED_SPHERE_AND_G1',N3_CONDITION='1 <= n3 <= min(B2,B5)',B2='2+v2(b)+v2(c)+v2(g1*)+v2(S)-2*v2(h)',B5='v5(g1*)+v5(b)+|v5(c)-v5(S)|',G_CONDITION='not classified globally',K_CONDITION='not classified globally',STATUS='PROVED_FINITE_N3_FIBRE'),
 dict(SCOPE='CURRENT_FRONTIER',N3_CONDITION='n3=4 <= min(7,5)=5',B2=7,B5=5,G_CONDITION='g=0',K_CONDITION='k=1',STATUS='FULL_SUPPORT'),
 dict(SCOPE='G10_DIAGNOSTIC',N3_CONDITION=f'n3=1 <= min({gb2},{gb5})',B2=gb2,B5=gb5,G_CONDITION='g=1',K_CONDITION='k=1',STATUS='DIES_MU_SMITH'),
]
write_csv('105_R24_Exponent_Image.csv',exp_rows)

# 9 image chambers 2x3 normalized schema
ch=[]
for parity in ['H2=0__NOT_EXACTLY_TWO_ODD','H2=1__EXACTLY_TWO_ODD']:
    for rel in ['V5C_LT_V5S','V5C_EQ_V5S','V5C_GT_V5S']:
        ch.append(dict(CHAMBER=f'{parity}__{rel}',PARITY_RULE=parity,FIVE_ADIC_RULE=rel,YDIV_2='n3<=2+v2(b)+v2(c)+v2(g1*)+v2(S)-2*v2(h)',YDIV_5='n3<=v5(g1*)+v5(b)+abs(v5(c)-v5(S))',FINITE_SCHEMA=True,GLOBAL_SUPPORT_CLASSIFICATION='OPEN'))
write_csv('105_R24_Image_Chambers.csv',ch)

# 10 ratio chamber intersection
ratio_rows=[
 dict(SCOPE='GLOBAL_IMAGE',IMAGE_POINTS_PROVED='partial graph theorem; B_legal not classified',INTERSECTION='UNRESOLVED',AVOIDANCE_THEOREM='NO',FIRST_HIT='NO'),
 dict(SCOPE='CURRENT_FRONTIER',IMAGE_POINTS_PROVED='(A,W,m2,m3)=(1,20,1,4)',INTERSECTION='NO: 100<20<10000 fails lower edge',AVOIDANCE_THEOREM='POINTWISE_ONLY',FIRST_HIT='NO'),
]
write_csv('105_R24_Ratio_Chamber_Intersection.csv',ratio_rows)

# 11 new image points
write_csv('105_R24_New_Image_Points.csv',[dict(SEARCH_SCOPE='R23_EXACT_BOUNDED_CENSUS_REUSED_AS_REGRESSION',SECOND_PRIMITIVE_POST_SUPPORT_IMAGE_POINT='NO_FOUND',NEW_IN_R24_SEARCH='NO_NEW_LARGE_CENSUS_RUN',THEOREM='NO_UNIQUENESS_CLAIM',NOTE='R24 information gain is structural pullback, not expanded brute force')])

# 12 first failure registry
registry=[
 dict(ORDER=1,GATE='CANONICAL_PRIMITIVE_SPHERE_CHART',STATUS='PROVED',EVIDENCE='stereographic inverse + gcd normalization',NEXT='YDIV pullback'),
 dict(ORDER=2,GATE='Y_DIV_PRODUCT_PULLBACK',STATUS='PROVED',EVIDENCE='P2=2bc/h, T3=2S/h',NEXT='decimal chambers'),
 dict(ORDER=3,GATE='DIRECT_W_ZERO_ONE_FIBRE',STATUS='PROVED',EVIDENCE='W=Nw/J',NEXT='WM recovery'),
 dict(ORDER=4,GATE='WM_ZERO_ONE_FIBRE',STATUS='PROVED',EVIDENCE='Mr=P2/W',NEXT='support pullback'),
 dict(ORDER=5,GATE='FULL_SUPPORT_ZERO_ONE_FIBRE',STATUS='PROVED',EVIDENCE='all support variables deterministic after W',NEXT='B_legal classification'),
 dict(ORDER=6,GATE='SOURCE_IMAGE_GRAPH_THEOREM',STATUS='PROVED',EVIDENCE='S_post=Graph(R) over B_legal',NEXT='classify B_legal'),
 dict(ORDER=7,GATE='GLOBAL_B_LEGAL_CLASSIFICATION',STATUS='OPEN',EVIDENCE='relative divisor incidence + gcd filters remain moving',NEXT='architecture review'),
 dict(ORDER=8,GATE='GLOBAL_IMAGE_RATIO_INTERSECTION',STATUS='NOT_DECIDED',EVIDENCE='only current exact image point known in bounded archive and it misses chamber',NEXT='not authorized without new architecture'),
]
write_csv('105_R24_First_Failure_Registry.csv',registry)

# terminal text will be generated after markdown below

# markdown main archive
md=r'''# 105-R24 — Post-Support Source Carrier Image × Primitive-Sphere Pullback × 0/1 Lift Fibre × Denominator-Chamber Intersection

**Project:** 三项十进制拼接平方和问题  
**Layer:** Strict Layer — A1-only  
**Round:** 105-R24  
**Arithmetic:** exact integers / exact rationals only  
**Terminal class:** **SOURCE-IMAGE GRAPH THEOREM + PARAMETER PULLBACK PROVED; GLOBAL IMAGE CLASSIFICATION STILL OPEN**

## 1. Executive Verdict

R24 接受 R23 的 angular/source-interface saturation，并严格执行 coordinate reversal。没有重新研究 `Theta`, `Sigma M`, `H`, completed-load inequality 或 J-angle ratio geometry。

本轮取得四个正式结构结果：

1. **Canonical primitive-sphere carrier theorem.** 每个有向 positive primitive sphere packet 有唯一的约化 stereographic carrier `(a,b,c)`；对 unordered packet 只剩至多六个 orientation labels。
2. **Full post-support 0/1 fibre theorem.** 固定 lower carrier 后，`W,Mr,C2,C3,mu,tau` 全部是 deterministic partial recovery，因此 full support-stack fibre 的大小至多为 1。
3. **Support-stack pullback / source-image graph theorem.** `S_post` 是 lower legal carrier locus `B_legal` 上一张 partial graph；所有 master/Smith/tail predicates 均可 lower-carrier-native 化。
4. **Y-DIV parameter factorization + exponent finite-fibre theorem.** `P2` 与 `T3` 在 sphere carrier 上分解成 products，导致固定 sphere+g1 selector 时 `n3` 只能落在一个有限区间，并形成 6-cell normalized decimal chamber schema。

但是，本轮**没有**证明 `B_legal` 的 global classification、global image thinness、global ratio-chamber avoidance，也没有找到第二个 independent full-support image point。因此不能签 denominator-ratio obstruction，也不能激活 integer-z window。

R24 的正确 terminal 是：

```text
R24_TERMINAL_VERDICT=POST_SUPPORT_ZERO_ONE_FIBRE_AND_SOURCE_IMAGE_GRAPH_PROVED__CANONICAL_SPHERE_PARAMETER_PULLBACK_AND_N3_FINITE_FIBRE_PROVED__GLOBAL_B_LEGAL_CLASSIFICATION_OPEN__NO_GLOBAL_RATIO_INTERSECTION_THEOREM
R25_AUTHORIZED=NO
```

这里 `R25_AUTHORIZED=NO` 不是因为本轮无信息增益；相反，本轮确有新的 factorization / graph / finite-fibre theorem。原因是用户给定的 R25 routes 中，尚未满足 image avoidance、single exact image gate、first ratio hit 或 downstream pass 中任一条。继续必须再次 architecture review，而不是机械延长 source-image round。

## 2. Frozen R1–R23 State

R1–R23 全部冻结。特别保留 full support-stack definition

\[
g_0\mid g_1^*\mid P_1,\qquad
(\mu,C_2C_3)=1,\qquad
(\tau,R_1)=1,\qquad
(\tau,C_2C_3)=1.
\]

R20 current frontier 与 R23 Direct-W/Y-DIV identities 只作为 upstream theorem inputs；R24 不重新证明其 angular consequences。

## 3. R23 Saturation Acceptance

正式接受

```text
MASTER_ANGULAR_SOURCE_INTERFACE_SATURATED=YES
```

并重新授权的对象仅为 source-image / pullback architecture。R24 中出现 `J_angle` 只作为 deterministic recovery denominator，不作为 angular inequality research variable。

## 4. R24 Coordinate-Reversal Authorization

旧方向：完整 shape -> ratio chamber。  
新方向：primitive-sphere lower carrier -> exact filters -> unique recovery -> support pullback -> denominator image。

## 5. Definition of Full Support-Stack Locus

定义 `S_post` 为所有 genuine positive source profiles satisfying frozen master corridor + mu-Smith + tail-g1 + tail-Smith。该定义保持 R20/R23 provenance，不把 finite census 当成 completeness theorem。

## 6. Denominator Projection

\[
\pi_{{den}}(s)=(A,W,m_2,m_3),\qquad
\mathscr I_{{supp}}=\operatorname{{Im}}\pi_{{den}}.
\]

## 7. Enriched Denominator Projection

R24 保留 `(P1,P2,P3,Q0,A,g1*,u0,m2,n3,g,k)` provenance；任何 image statement 先在 enriched graph 上证明，再投影到 denominator coordinates。

## 8. Primitive Sphere Carrier

冻结

\[
P_1^2+P_2^2+P_3^2=Q_0^2,
\qquad \gcd(P_1,P_2,P_3,Q_0)=1,
\]

并固定 coordinate roles；orientation 不可在 recovery 中静默交换。

## 9. Primitive Sphere Parameterization

对任意有向 positive packet 定义

\[
r=\frac{{P_1}}{{Q_0+P_3}},\qquad
s=\frac{{P_2}}{{Q_0+P_3}}.
\]

唯一写成

\[
r=\frac ac,\qquad s=\frac bc,
\qquad c>0,\quad \gcd(a,b,c)=1,
\]

其中 `(a,b,c)` 取共同最小分母。令

\[
\widehat P_1=2ac,\quad
\widehat P_2=2bc,\quad
\widehat P_3=c^2-a^2-b^2,\quad
\widehat Q=c^2+a^2+b^2,
\]

\[
h:=\gcd(\widehat P_1,\widehat P_2,\widehat P_3,\widehat Q).
\]

则 exact formulas 为

\[
\boxed{{P_1=\frac{{2ac}}h}},\qquad
\boxed{{P_2=\frac{{2bc}}h}},
\]

\[
\boxed{{P_3=\frac{{c^2-a^2-b^2}}h}},\qquad
\boxed{{Q_0=\frac{{c^2+a^2+b^2}}h}}.
\tag{{SPH-CHART}}
\]

该形式不需要另加 parity guess；公共 2-content 由 canonical `h` 自动除去。

## 10. Coverage / Multiplicity Audit

从 sphere identity 可直接验证 stereographic inverse，因此每个 positive labeled packet 都被覆盖。由于 `(r,s)` 唯一、共同最小分母唯一，**固定 orientation 的 `(a,b,c)` 唯一**。

若先把 sphere 当 unordered packet，再恢复 `(P1,P2,P3)` roles，则 multiplicity 至多为 `|S3|=6`；坐标相等时更少。故 parameter duplicates 可 canonical deduplicate，不会被冒充成多个 image points。

## 11. Minimal Lower Carrier

R24 的最小 sufficient lower carrier 取

\[
\boxed{{
\beta_{{min}}=
(P_1,P_2,P_3,Q_0;
A,g_1^*;u_0;m_2,n_3,g,k)
}}.
\tag{{BMIN}}
\]

`n2` 不需要独立保留，因为

\[
n_2=m_2+g+k.
\]

等价 parameter-native carrier 为

\[
\boxed{{
\beta_{{par}}=(a,b,c,h;A,g_1^*,u_0;m_2,n_3,g,k)
}}.
\]

给定它以后，`X,Y,G,K,D,T3,W,Mr,C2,C3,g0,mu,lambda_z,tau,R1` 全部是 deterministic partial functions。

因此签：

```text
POST_SUPPORT_MINIMAL_LOWER_CARRIER_THEOREM=PROVED_UP_TO_EQUIVALENT_SPHERE_COORDINATE_CHOICE
```

## 12. (A)-Divisor Selector

`A|P3` 是 finite divisor selector。给定 `(P3,A,u0)`：

\[
N_r=P_3/A,
\qquad C_3=P_3/(Au_0)
\]

当且仅当相应整除成立。

## 13. (g1*)-Divisor Selector

`g1*|P1` 同样是 finite divisor selector；定义

\[
R_1=P_1/g_1^*.
\]

固定 sphere packet 后两个 selector fibres 都有限；本轮不把 divisor-count 的大小冒充 global bounded multiplicity。

## 14. Face-3 Recovery

\[
A\mid P_3,\quad u_0\mid P_3/A
\Longrightarrow
\boxed{{C_3=P_3/(Au_0)}}.
\]

故 Face 3 完全 deterministic，fibre 至多一个。

## 15. Direct-(W) Recovery

定义

\[
X=10^{{m_2}},\quad Y=10^{{n_3}},\quad G=10^g,\quad K=10^k,
\]

\[
D=KP_1-Q_0,\qquad T_3=Q_0-P_3,
\]

\[
J_\angle=u_0AXYGD-g_1^*T_3,
\]

\[
N_W=g_1^*AY(GQ_0-P_2).
\]

则 frozen Direct-W theorem becomes the recovery law

\[
\boxed{{W=N_W/J_\angle}}.
\]

## 16. Direct-(W) 0/1 Fibre

对固定 `beta_min`，`J_angle,NW` 已确定。故

\[
|\operatorname{{Lift}}_W(\beta)|\le1.
\]

nonempty iff

\[
J_\angle>0,
\qquad J_\angle\mid N_W,
\]

并且 recovered quotient positive。`GQ0-P2>0` 由 positive sphere + `G>=1` 自动。

```text
DIRECT_W_ZERO_ONE_FIBRE_THEOREM=PROVED
```

## 17. Reverse-(Mr) Recovery

一旦 `W` recovered：

\[
\boxed{{M_r=P_2/W}}.
\]

与 R23 reverse fraction 完全等价，但在 lower-carrier graph 中最自然的 integrality gate 是 `W|P2`。

## 18. ((W,Mr)) 0/1 Fibre

\[
|\operatorname{{Lift}}_{{WM}}(\beta)|\le1.
\]

nonempty iff W-fibre nonempty、`W|P2`、`u0|Mr`。随后

\[
C_2=M_r/u_0
\]

唯一。

```text
WM_ZERO_ONE_FIBRE_PROVED=YES
```

## 19. (C2,C3) Recovery

\[
\boxed{{C_2=P_2/(u_0W)}},\qquad
\boxed{{C_3=P_3/(u_0A)}}
\]

在整除 gate 下同时唯一。

## 20. Y-Divisibility Pullback

SPH-CHART 给出真正 factorization：

\[
\boxed{{T_3=Q_0-P_3=\frac{{2(a^2+b^2)}}h}},
\]

\[
\boxed{{P_2=\frac{{2bc}}h}}.
\]

因此

\[
Y\mid P_2g_1^*T_3
\]

等价于

\[
\boxed{{
10^{{n_3}}\mid
\frac{{4bc\,g_1^*(a^2+b^2)}}{{h^2}}
}}.
\tag{{YDIV-PAR}}
\]

这不是把旧 census 改变量名；它暴露了 exact product allocation。

## 21. Decimal Valuation Chambers

令 `S=a^2+b^2`。canonical `h` 有：

- `v2(h) in {{0,1}}`；且 `v2(h)=1` 当且仅当 `(a,b,c)` 恰有两个 odd；
- 对任意 odd prime `p`，
  \[
  v_p(h)=\min(v_p(c),v_p(S)).
  \]

故 Y-DIV 对 `p=2` 给

\[
\boxed{{
n_3\le 2+v_2(b)+v_2(c)+v_2(g_1^*)+v_2(S)-2v_2(h)
}}.
\tag{{B2}}
\]

对 `p=5` 进一步简化成

\[
\boxed{{
n_3\le v_5(g_1^*)+v_5(b)+|v_5(c)-v_5(S)|
}}.
\tag{{B5}}
\]

这是本轮最重要的新 decimal pullback 之一。

## 22. Master Corridor Pullback

recover `W(beta)` 后定义

\[
g_0(\beta)=\gcd(u_0A W(\beta),P_1).
\]

master corridor 变成 lower-native Boolean：

\[
\boxed{{g_0(\beta)\mid g_1^*\mid P_1}}.
\]

## 23. (mu)-Smith Pullback

master corridor pass 后

\[
\mu(\beta)=g_1^*/g_0(\beta),
\]

于是

\[
\boxed{{\gcd(\mu(\beta),C_2(\beta)C_3(\beta))=1}}.
\]

不重开 R19/R20 valuation theorem；这里只做 exact substitution。

## 24. Tail-(g1) Pullback

\[
\lambda_z(\beta)=\frac Y{{\gcd(Y,W(\beta)T_3)}},
\]

\[
\tau(\beta)=\frac{{\lambda_z(\beta)}}{{\gcd(\lambda_z(\beta),\mu(\beta))}},
\qquad R_1(\beta)=P_1/g_1^*.
\]

Tail-g1 gate：

\[
\boxed{{\gcd(\tau(\beta),R_1(\beta))=1}}.
\]

## 25. Tail-Smith Pullback

\[
\boxed{{\gcd(\tau(\beta),C_2(\beta)C_3(\beta))=1}}.
\]

## 26. Full Support Pullback Theorem

令 `C1...Cr` 依次表示：sphere/primitivity、A selector、g1 selector、decimal exponents、Y-DIV、J positivity、W integrality、Mr/radial integrality、master corridor、mu-Smith、tail-g1、tail-Smith。

全部已经是 `beta_min` 的 explicit functions/predicates。因此

\[
\boxed{{
\beta\in\mathcal B_{{legal}}
\iff
\bigwedge_j \mathcal C_j(\beta)
}}.
\tag{{PULLBACK}}
\]

```text
SUPPORT_STACK_PULLBACK_THEOREM=PROVED
```

## 27. Post-Support 0/1 Fibre

一旦 lower carrier 固定，所有 support variables 都无剩余选择，因此

\[
\boxed{{|\operatorname{{Lift}}_{{supp}}(\beta)|\le1}}.
\]

```text
POST_SUPPORT_ZERO_ONE_LIFT_FIBRE_THEOREM=PROVED
```

这是 semantic dimension collapse，但尚不是 `B_legal` classification。

## 28. Legal Lower Carrier Locus

\[
\mathcal B_{{legal}}=
\{{\beta:\operatorname{{Lift}}_{{supp}}(\beta)\ne\varnothing}}\}.
\]

R24 已把 membership 变成 explicit exact predicate；**没有**证明其 global closed-form classification。

## 29. Semantic Dimension Ledger

| Stage | freedom |
|---|---|
| oriented primitive sphere | canonical `(a,b,c)` with one quadratic equation already solved by chart |
| orientation | finite, <=6 over unordered packet |
| A selector | finite divisor fibre of P3 |
| g1* selector | finite divisor fibre of P1 |
| exponent chart | `(m2,n3,g,k)`; fixed sphere+g1 gives finite n3 fibre by Y-DIV |
| W | 0/1 deterministic recovery |
| Mr,C2,C3 | 0/1 deterministic recovery |
| mu,tau,R1 | deterministic |
| support stack | Boolean cuts only |

因此 radial/transverse pair `(W,C2)` 已正式从 search dimension 退休。

## 30. Source Image Graph Theorem

定义 partial recovery map `R(beta)` 为上述 deterministic recovery。则

\[
\boxed{{
\mathfrak S_{{post}}
=\operatorname{{Graph}}(\mathcal R)
\quad\text{{over }}\mathcal B_{{legal}}.
}}
\]

同理 enriched denominator image 是该 graph 的投影。

```text
POST_SUPPORT_SOURCE_IMAGE_GRAPH_THEOREM=PROVED
```

## 31. Lower-Carrier Attrition Registry

R24 没有重新跑 8e7/6e8 级 census；它复用 R23 exact bounded counts 只作 regression。R23 bounded chart 中最剧烈的 deterministic thinning 出现在 Direct-W + `W|P2` incidence：最终只有 14 rows 穿过该 exact quotient/divisor gate；随后 3 rows 到 master corridor，1 row 到 full support。

这些 counts 不是 universal density theorem。

## 32. Dominant Failure Gate

**bounded-census diagnostic:** WM divisor incidence (`J|NW` together with `W|P2`) 是最强 early attrition。  
**post-master diagnostic:** G=10 row 说明 mu-Smith 仍可进一步强力切掉 Direct-W/master survivors。

R24 不把二者排序升级成 source-wide dominant theorem。

## 33. Current Frontier Exact Recovery

current packet：

\[
(P_1,P_2,P_3,Q_0)=(640,1420,4727,4977).
\]

canonical carrier：

\[
\boxed{{(a,b,c,h)=(160,355,2426,1213)}}.
\]

且

\[
a^2+b^2=151625,
\quad T_3=2(151625)/1213=250.
\]

lower selectors/exponents：

\[
(A,g_1^*,u_0;m_2,n_3,g,k)=(1,80,1;1,4,0,1).
\]

Y budgets：

\[
B_2=7,\qquad B_5=5,\qquad n_3=4\le5.
\]

recovery：

\[
D=1423,
\quad J_\angle=142280000,
\]

\[
N_W=80\cdot10^4(4977-1420)=2845600000,
\]

\[
W=N_W/J_\angle=20,
\quad M_r=1420/20=71,
\]

\[
C_2=71,
\quad C_3=4727.
\]

support：

\[
g_0=20,\quad\mu=4,
\quad\lambda_z=2,\quad\tau=1,\quad R_1=8,
\]

全部 gcd gates pass。故 current frontier 是从 lower carrier **重新恢复**，没有 hard-code full shape。

## 34. G=10 Diagnostic Recovery

packet：

\[
(200,365,104,429),
\]

canonical carrier：

\[
\boxed{{(a,b,c,h)=(200,365,533,1066)}}.
\]

lower chart：

\[
(A,g_1^*,u_0;m_2,n_3,g,k)=(13,40,1;1,1,1,1).
\]

exact recovery：

\[
D=1571,
\quad T_3=325,
\quad J_\angle=20410000,
\]

\[
N_W=20410000,
\quad W=1,
\quad M_r=365,
\quad(C_2,C_3)=(365,8).
\]

master：

\[
g_0=1,\qquad \mu=40,
\]

但

\[
\gcd(40,365\cdot8)=40.
\]

所以 first failure = `MU_SMITH`。这严格支持“image thinness 来自 support pullback 本身，而非 ratio”的 diagnostic interpretation，但仍不是 global thinness theorem。

## 35. Sphere-Parameter Factorization of T3

\[
\boxed{{T_3=2S/h}},\qquad S=a^2+b^2.
\]

这将 axis gap 变成 sum-of-two-squares content。

## 36. Sphere-Parameter Factorization of P2

\[
\boxed{{P_2=2bc/h}}.
\]

于是 Y-DIV 的两个 sphere factors 变成 `bc` 与 `S`，而不是 generic coordinates。

## 37. Y-DIV Parameter Pullback

综合：

\[
\boxed{{10^{{n_3}}\mid 4bcg_1^*S/h^2}}.
\]

该 law 同时产生 exact 2-budget 和简化的 5-budget `(B2),(B5)`。

## 38. Finite Chamber Decomposition

Y-DIV 的 normalized chamber schema 只需：

1. `v2(h)=0` / `v2(h)=1` 两个 parity cells；
2. `v5(c)<v5(S)`, `=`, `>` 三个 relative 5-adic cells。

合计 **6 个 schema cells**。cell 内 valuations 可以无界增长，但 case structure 不随 exponents 爆炸；因此这是 finite normalized schema，而不是 infinite case split。

## 39. Image Thinness Test

R24 证明了：

- recovery fibre 0/1；
- fixed sphere+g1 的 `n3` fibre finite；
- W/Mr existence 是 moving finite-divisor incidence；
- support gcds 再作 deterministic cuts。

但这些尚不足以证明 global `B_legal` 落在 fixed finite union of proper subvarieties，也不足以排除 infinite image family。

```text
POST_SUPPORT_SOURCE_IMAGE_THINNESS_PROVED=NO
```

## 40. Codimension Collapse

把 `w=W(beta)` 作为 finite divisor selector，WM recovery 等价于

\[
w\mid P_2
\]

以及 exact incidence

\[
\boxed{{
w\,[u_0AXYG(2Kac-R)-2g_1^*S]
=g_1^*AY(GR-2bc)
}}
\tag{{DIV-INC}}
\]

其中 `R=a^2+b^2+c^2`。

这是**relative finite-divisor incidence**：固定 carrier packet 时 `w` 只取 `P2` 的有限 divisors，因此每个 fibre 是有限 union of exact equations。由于 `P2` 随 carrier moving，本轮不把它夸大为 global fixed finite-union codimension theorem。

```text
POST_SUPPORT_SOURCE_IMAGE_CODIMENSION_COLLAPSE=PARTIAL_RELATIVE_FINITE_DIVISOR_INCIDENCE_PLUS_N3_FINITE_FIBRE
```

## 41. Exponent Image

Y-DIV 已严格证明，对固定 `(a,b,c,h,g1*)`：

\[
\boxed{{1\le n_3\le \min(B_2,B_5)}}.
\]

因此 `n3` 不再是无界自由轴 **within a fixed sphere/g1 carrier**。

没有证明 `g=0` 唯一，也没有证明 `k=1` 唯一；G=10 diagnostic 已禁止任何从 bounded full-support evidence 偷渡 `G0_ONLY` theorem。

## 42. Denominator Image Map

对 `beta in B_legal` 定义

\[
\boxed{{
\mathfrak d(\beta)=
(A,W(\beta),m_2,n_3+g)
}}.
\]

于是

\[
\boxed{{
\mathscr I_{{supp}}=
\{{\mathfrak d(\beta):\beta\in\mathcal B_{{legal}}\}
}}.
\]

这是 R24 的 canonical denominator image representation。

## 43. Image × Ratio Chamber Intersection

只有在 graph theorem 完成后才检查 current exact image point：

\[
\mathfrak d(\beta_0)=(1,20,1,4).
\]

其 `d=3`，ratio chamber 要求

\[
100<20<10000,
\]

故 pointwise miss。

但是 `B_legal` 尚未 global classify，所以：

```text
IMAGE_RATIO_CHAMBER_INTERSECTION=UNRESOLVED_GLOBALLY
POST_SUPPORT_SOURCE_IMAGE_AVOIDS_DENOMINATOR_RATIO_CHAMBER=NO_NOT_PROVED
```

## 44. First New Image Point

R24 没有为了堆统计重新扩大 brute-force census。R23 bounded exact search 仍只有一个 unique full-support point；本轮没有找到第二个 structurally independent image point。

```text
SECOND_PRIMITIVE_POST_SUPPORT_IMAGE_POINT=NO
```

## 45. First Ratio-Chamber Image Point

未找到。

```text
FIRST_POST_SUPPORT_SOURCE_IMAGE_POINT_IN_RATIO_CHAMBER=NO
FIRST_POST_MASTER_DENOMINATOR_RATIO_PASS=NO
```

## 46. Integer (z)-Window

未激活。current point 的旧 diagnostic `Z_-=50>Z_+=9` 可保留，但不能冒充 ordered R24 gate。

## 47. Forced Scale

未激活。

## 48. Pre-(q) Shell

未激活。

## 49. Residual Selector

未激活。

## 50. First (z)

无。

## 51. Full Reconstruction

未激活；没有 ratio-chamber image point。

## 52. Exact (U)

未激活；construct-side `u0=1` 不是 downstream plain `U`。

## 53. Downstream Audit

Smith reconstruction / PSDG / DES / source selector / common-U successor / digit synchronization / actual cut / full word / outer completion 均未激活。

## 54. Image Interface Saturation Audit

R24 firewall 条件**没有**满足：

- 0/1 fibre 虽然 uniqueness 本身 elementary，但成功与 canonical sphere pullback结合；
- `T3` 与 `P2` 获得新 factorization；
- `h` 的 2/5-content 得到 closed formula；
- Y-DIV 得到新的 6-cell normalized schema 与 fixed-carrier `n3` finite-fibre theorem；
- Direct-W 在 parameter coordinates 中发生 `h` cancellation：
  \[
  W=
  \frac{{g_1^*AY(GR-2bc)}}
  {{u_0AXYG(2Kac-R)-2g_1^*S}}.
  \tag{{W-PAR}}
  \]

因此：

```text
POST_SUPPORT_SOURCE_IMAGE_INTERFACE_SATURATED=NO
```

但因为尚无 R25 合法 route，不能自动 continuation。

## 55. New First-Failure Gate

数学上剩余对象不是 angular ratio，而是：

\[
\boxed{{
\text{{global classification of }}\mathcal B_{{legal}}
\text{{ under moving divisor incidence (DIV-INC) plus support gcd cuts}}
}}.
\]

这仍是一个 architecture-level classification problem，而不是已经压成 single exact gate。

## 56. R24 Information-Gain Certificate

```text
R24_INFORMATION_GAIN_CERTIFICATE=PASS__CANONICAL_ORIENTED_SPHERE_CHART__T3_AND_P2_FACTORIZATION__H_2_5_CONTENT_LAW__YDIV_SIX_CHAMBER_SCHEMA__FIXED_CARRIER_N3_FINITE_FIBRE__DIRECT_W_H_CANCELLATION__FULL_SUPPORT_ZERO_ONE_GRAPH__RELATIVE_FINITE_DIVISOR_INCIDENCE
```

## 57. R24 Terminal Verdict

```text
R24_TERMINAL_VERDICT=POST_SUPPORT_ZERO_ONE_FIBRE_AND_SOURCE_IMAGE_GRAPH_PROVED__CANONICAL_SPHERE_PARAMETER_PULLBACK_AND_N3_FINITE_FIBRE_PROVED__GLOBAL_B_LEGAL_CLASSIFICATION_OPEN__NO_GLOBAL_RATIO_INTERSECTION_THEOREM
```

本轮不是 failure；它完成了 coordinate reversal 的第一阶段并确实实现 semantic dimension collapse。但它也没有越权把 partial graph theorem 宣布成 global image classification。

## 58. R25 Authorization Decision

用户规定的 Route A–F 中当前无一满足：

- no image avoidance theorem；
- no honest single post-support image gate；
- no first ratio-chamber hit；
- no integer-window/pre-q activation；
- interface itself 又未 saturation。

所以最严格处理为：

```text
R25_AUTHORIZED=NO
R25_ARCHITECTURE=NONE__GLOBAL_ARCHITECTURE_REVIEW_REQUIRED
R25_SINGLE_ATTACK_TARGET=NONE
```

不能机械开 R25 同类 image round。

---

## Machine-readable terminal block

```text
R24_TERMINAL_VERDICT=POST_SUPPORT_ZERO_ONE_FIBRE_AND_SOURCE_IMAGE_GRAPH_PROVED__CANONICAL_SPHERE_PARAMETER_PULLBACK_AND_N3_FINITE_FIBRE_PROVED__GLOBAL_B_LEGAL_CLASSIFICATION_OPEN__NO_GLOBAL_RATIO_INTERSECTION_THEOREM

R1_TO_R23_STATE_FROZEN=YES

R23_MASTER_ANGULAR_SATURATION_ACCEPTED=YES
R24_IMAGE_ARCHITECTURE_REAUTHORIZED=YES__COORDINATE_REVERSAL_ONLY

CURRENT_FIRST_FAILURE_GATE=GLOBAL_LEGAL_LOWER_CARRIER_IMAGE_CLASSIFICATION

FULL_SUPPORT_STACK_DEFINITION=g0|g1*|P1;_gcd(mu,C2C3)=1;_gcd(tau,R1)=1;_gcd(tau,C2C3)=1

LOWER_CARRIER_DEFINITION=(P1,P2,P3,Q0;A,g1*;u0;m2,n3,g,k)__EQUIV_(a,b,c,h;A,g1*;u0;m2,n3,g,k)
MINIMAL_LOWER_CARRIER_PROVED=YES_UP_TO_EQUIVALENT_SPHERE_COORDINATE_CHOICE__n2_RECOVERED_AS_m2+g+k

PRIMITIVE_SPHERE_PARAMETERIZATION=P1=2ac/h;P2=2bc/h;P3=(c^2-a^2-b^2)/h;Q0=(a^2+b^2+c^2)/h
PRIMITIVE_SPHERE_COVERAGE_PROVED=YES__STEREOGRAPHIC_INVERSE_FOR_EVERY_POSITIVE_LABELED_PACKET
PARAMETER_MULTIPLICITY_CONTROLLED=YES__UNIQUE_PER_LABELED_ORIENTATION__AT_MOST_6_OVER_UNORDERED_PACKET

A_DIVISOR_SELECTOR=YES__A|P3
G1_DIVISOR_SELECTOR=YES__g1*|P1

FACE3_RECOVERY_UNIQUE=YES__C3=P3/(A*u0)

J_ANGLE=u0*A*X*Y*G*D-g1*T3
DIRECT_W_RECOVERY=W=g1*A*Y*(GQ0-P2)/J_ANGLE
DIRECT_W_ZERO_ONE_FIBRE_PROVED=YES

MR_RECOVERY=Mr=P2/W
WM_ZERO_ONE_FIBRE_PROVED=YES

C2_RECOVERY=C2=P2/(u0*W)
C3_RECOVERY=C3=P3/(u0*A)

Y_DIVISIBILITY_PULLBACK=10^n3|4*b*c*g1*(a^2+b^2)/h^2__B2_AND_B5_EXACT

SUPPORT_STACK_PULLBACK_THEOREM=YES

POST_SUPPORT_LIFT_FIBRE_SIZE_BOUND=<=1
POST_SUPPORT_ZERO_ONE_LIFT_FIBRE_THEOREM=YES

LEGAL_LOWER_CARRIER_LOCUS=EXPLICIT_BOOLEAN_PULLBACK_DEFINED__GLOBAL_CLASSIFICATION_OPEN

POST_SUPPORT_SOURCE_IMAGE_GRAPH_THEOREM=YES

SEMANTIC_DIMENSION_LEDGER=SPHERE_3PARAM_CANONICAL__ORIENTATION_FINITE__A_AND_G1_DIVISOR_FINITE__N3_FINITE_PER_FIXED_CARRIER__W_MR_C2_C3_MU_TAU_ZERO_ONE_OR_DETERMINISTIC

DECIMAL_VALUATION_CHAMBERS=YES__2_PARITY_X_3_RELATIVE_5ADIC_SCHEMA
FINITE_CHAMBER_DECOMPOSITION=YES_FOR_YDIV_NORMALIZED_SCHEMA__NO_FOR_FULL_B_LEGAL_CLASSIFICATION

POST_SUPPORT_SOURCE_IMAGE_CODIMENSION_COLLAPSE=PARTIAL__RELATIVE_FINITE_DIVISOR_INCIDENCE_PLUS_FIXED_CARRIER_N3_FINITE_FIBRE__NO_GLOBAL_FIXED_FINITE_UNION

FULL_SUPPORT_STACK_IMAGE_POINTS_FOUND=1_REUSED_EXACT_CURRENT_FRONTIER
UNIQUE_IMAGE_POINTS=1_IN_R23_BOUNDED_CENSUS__NOT_GLOBAL_UNIQUENESS_THEOREM
SECOND_PRIMITIVE_POST_SUPPORT_IMAGE_POINT=NO

CURRENT_FRONTIER_RECOVERED_FROM_LOWER_CARRIER=YES__(a,b,c,h)=(160,355,2426,1213)->W20->Mr71->C2=71,C3=4727->FULL_SUPPORT
G10_DIAGNOSTIC_ATTRITION_REGRESSION=YES__(a,b,c,h)=(200,365,533,1066)->W1->Mr365->C2=365,C3=8->mu40->FAIL_MU_SMITH

DOMINANT_LOWER_CARRIER_FAILURE_GATE=BOUNDED_CENSUS_DIAGNOSTIC__WM_DIVISOR_INCIDENCE_EARLY__MU_SMITH_POST_MASTER__NO_GLOBAL_DOMINANCE_THEOREM

EXPONENT_IMAGE=FIXED_SPHERE_AND_G1__1<=n3<=min(B2,B5)__g,k_GLOBAL_OPEN
G0_ONLY_PROVED=NO
MINIMAL_DECIMAL_CHART_ONLY_PROVED=NO

DENOMINATOR_IMAGE_MAP=d(beta)=(A,W(beta),m2,n3+g)

POST_SUPPORT_SOURCE_IMAGE_THINNESS_PROVED=NO

IMAGE_RATIO_CHAMBER_INTERSECTION=UNRESOLVED_GLOBALLY__CURRENT_IMAGE_POINT_MISSES

POST_SUPPORT_SOURCE_IMAGE_AVOIDS_DENOMINATOR_RATIO_CHAMBER=NO_NOT_PROVED

FIRST_POST_SUPPORT_SOURCE_IMAGE_POINT_IN_RATIO_CHAMBER=NO
FIRST_POST_MASTER_DENOMINATOR_RATIO_PASS=NO
RATIO_PASS_SHAPE=NONE

Z_LOWER=NOT_ACTIVATED__CURRENT_DIAGNOSTIC_50
Z_UPPER=NOT_ACTIVATED__CURRENT_DIAGNOSTIC_9
INTEGER_Z_WINDOW_PASS=NO_NOT_ACTIVATED

LAMBDA=NOT_ACTIVATED__CURRENT_DIAGNOSTIC_4
FORCED_SCALE_FIT=NOT_ACTIVATED

FIRST_POST_MASTER_PREQ_SHELL_PASS=NO_NOT_ACTIVATED

RESIDUAL_SUCCESSOR_PASS=NOT_ACTIVATED

Z_SELECTOR_PASS=NO_NOT_ACTIVATED
Z=NONE

FULL_SMITH_RECONSTRUCTION=NOT_ACTIVATED
FULL_POST_PSDG_LIFT=NO_NOT_ACTIVATED

PLAIN_U=NOT_RECOVERED
SOURCE_SELECTOR_PASS=NOT_ACTIVATED
SOURCE_INTEGER_U_FOUND=NO_NOT_ACTIVATED

COMMON_U_INTEGER_SUCCESSOR_GATE=NOT_ACTIVATED

DIGIT_SYNCHRONIZATION=NOT_ACTIVATED
ACTUAL_CUT=NOT_ACTIVATED
FULL_WORD=NOT_ACTIVATED
OUTER_COMPLETION=NOT_ACTIVATED

DENOMINATOR_RATIO_CORRIDOR_OBSTRUCTION_PROVED=NO
POST_MASTER_TRANSVERSE_SHELL_UNLIFTABILITY_PROVED=NO

R24_SINGLE_POST_SUPPORT_IMAGE_GATE=NO__REMAINING_GLOBAL_CLASSIFICATION_NOT_HONESTLY_SINGLE

POST_SUPPORT_SOURCE_IMAGE_INTERFACE_SATURATED=NO__GENUINE_NEW_FACTORIZATION_GRAPH_AND_FINITE_FIBRE_INFORMATION

NEW_FIRST_FAILURE_GATE=GLOBAL_CLASSIFICATION_OF_B_LEGAL_UNDER_MOVING_DIVISOR_INCIDENCE_AND_SUPPORT_GCD_CUTS

R24_INFORMATION_GAIN_CERTIFICATE=PASS__CANONICAL_ORIENTED_SPHERE_CHART__T3_AND_P2_FACTORIZATION__H_2_5_CONTENT_LAW__YDIV_SIX_CHAMBER_SCHEMA__FIXED_CARRIER_N3_FINITE_FIBRE__DIRECT_W_H_CANCELLATION__FULL_SUPPORT_ZERO_ONE_GRAPH__RELATIVE_FINITE_DIVISOR_INCIDENCE

R25_AUTHORIZED=NO
R25_ARCHITECTURE=NONE__GLOBAL_ARCHITECTURE_REVIEW_REQUIRED
R25_SINGLE_ATTACK_TARGET=NONE
```
'''
md=md.replace('{{','{').replace('}}','}')
(ROOT/'105_R24_Post_Support_Source_Carrier_Image.md').write_text(md,encoding='utf-8')

terminal = md.split('## Machine-readable terminal block\n\n```text\n',1)[1].split('\n```',1)[0]
(ROOT/'105_R24_terminal.txt').write_text(terminal+'\n',encoding='utf-8')

# compact theorem JSON useful for machine audits
summary={
 'current': {'beta':asdict(CURRENT),'params':cp,'recovery':{k:fmt_frac(v) if isinstance(v,Fraction) else v for k,v in cur.items()}},
 'g10': {'beta':asdict(G10),'params':gp,'recovery':{k:fmt_frac(v) if isinstance(v,Fraction) else v for k,v in g10.items()}},
 'theorems': {
   'canonical_sphere_chart':True,'direct_w_zero_one':True,'wm_zero_one':True,'post_support_zero_one':True,
   'support_pullback':True,'source_image_graph':True,'ydiv_product_pullback':True,'fixed_carrier_n3_finite':True,
   'global_image_thinness':False,'global_ratio_avoidance':False
 }
}
(ROOT/'105_R24_exact_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')

# manifest
files=[p for p in ROOT.rglob('*') if p.is_file() and p.name!='105_R24_SHA256_Manifest.csv']
man=[]
for p in sorted(files):
    data=p.read_bytes()
    man.append(dict(FILE=str(p.relative_to(ROOT)),BYTES=len(data),SHA256=hashlib.sha256(data).hexdigest()))
write_csv('105_R24_SHA256_Manifest.csv',man,['FILE','BYTES','SHA256'])

# execution log
log='''105-R24 exact source-image execution\nCANONICAL_SPHERE_CHART=PASS\nCURRENT_PARAMS=(160,355,2426,1213)\nG10_PARAMS=(200,365,533,1066)\nH_V2_RULE=PASS\nH_ODD_PRIME_RULE_p5=PASS\nYDIV_PULLBACK_BUDGETS=CURRENT(7,5);G10({},{})\nDIRECT_W_ZERO_ONE_FIBRE=PROVED\nWM_ZERO_ONE_FIBRE=PROVED\nPOST_SUPPORT_ZERO_ONE_FIBRE=PROVED\nSUPPORT_PULLBACK=PROVED\nSOURCE_IMAGE_GRAPH=PROVED\nCURRENT_FRONTIER_RECOVERY=PASS\nG10_MU_SMITH_ATTRITION=PASS\nGLOBAL_IMAGE_THINNESS=NOT_PROVED\nGLOBAL_RATIO_AVOIDANCE=NOT_PROVED\nR25_AUTHORIZED=NO\nALL_ASSERTIONS=PASS\n'''.format(gb2,gb5)
(ROOT/'105_R24_execution.log').write_text(log,encoding='utf-8')

print('105-R24 exact archive: PASS')
print('CURRENT canonical params', (cp['a'],cp['b'],cp['c'],cp['h']), 'Y budgets', (cb2,cb5), 'image', (CURRENT.A,cur['W'],CURRENT.m2,cur['m3']))
print('G10 canonical params', (gp['a'],gp['b'],gp['c'],gp['h']), 'Y budgets', (gb2,gb5), 'first failure', g10['FIRST_FAILURE'])
print('FILES', len([p for p in ROOT.rglob('*') if p.is_file()]))
