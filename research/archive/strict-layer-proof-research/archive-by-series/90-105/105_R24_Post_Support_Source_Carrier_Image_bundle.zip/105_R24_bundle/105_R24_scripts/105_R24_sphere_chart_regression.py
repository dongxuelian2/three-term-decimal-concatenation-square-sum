#!/usr/bin/env python3
"""Standalone exact regression for the R24 canonical sphere chart.
No imports from the archive generator, so running it has no artifact side effects.
"""
from fractions import Fraction
from math import gcd, lcm

def vp(n,p):
    n=abs(n); e=0
    if n==0: raise ValueError('vp(0)')
    while n%p==0: n//=p; e+=1
    return e

def canonical(P1,P2,P3,Q):
    assert P1*P1+P2*P2+P3*P3==Q*Q
    r=Fraction(P1,Q+P3); s=Fraction(P2,Q+P3)
    c=lcm(r.denominator,s.denominator)
    a=r.numerator*(c//r.denominator); b=s.numerator*(c//s.denominator)
    d=gcd(gcd(a,b),c); a//=d; b//=d; c//=d
    raw=(2*a*c,2*b*c,c*c-a*a-b*b,c*c+a*a+b*b)
    h=gcd(gcd(abs(raw[0]),abs(raw[1])),gcd(abs(raw[2]),abs(raw[3])))
    assert tuple(x//h for x in raw)==(P1,P2,P3,Q)
    return a,b,c,h

def predicted_h(a,b,c):
    S=a*a+b*b
    eps=1 if sum(x&1 for x in (a,b,c))==2 else 0
    d=gcd(c,S)
    while d%2==0: d//=2
    return (2**eps)*d

checked=0
for a in range(1,31):
    for b in range(1,31):
        for c in range(1,46):
            if gcd(gcd(a,b),c)!=1 or c*c<=a*a+b*b:
                continue
            raw=(2*a*c,2*b*c,c*c-a*a-b*b,c*c+a*a+b*b)
            h=gcd(gcd(abs(raw[0]),abs(raw[1])),gcd(abs(raw[2]),abs(raw[3])))
            assert h==predicted_h(a,b,c)
            P=tuple(x//h for x in raw)
            assert min(P)>0
            assert canonical(*P)==(a,b,c,h)
            # Explicit valuation checks beyond 2,5 to guard the full oddpart statement.
            for p in (3,5,7,11,13):
                assert vp(h,p)==min(vp(c,p),vp(a*a+b*b,p)) if (c%p==0 and (a*a+b*b)%p==0) else vp(h,p)==0
            checked+=1
print('SPHERE_CHART_ROUNDTRIP_REGRESSION=PASS')
print('COPRIME_POSITIVE_PARAMETER_TRIPLES_CHECKED=',checked)
print('H_EXACT_CONTENT_FORMULA=PASS')
print('ODD_PRIME_VALUATION_RULE=PASS_FOR_p=3,5,7,11,13')
