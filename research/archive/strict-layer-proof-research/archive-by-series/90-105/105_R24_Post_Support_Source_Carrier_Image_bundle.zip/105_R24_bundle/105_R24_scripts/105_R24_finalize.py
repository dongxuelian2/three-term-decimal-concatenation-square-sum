#!/usr/bin/env python3
"""Final semantic/provenance pass for 105-R24.

This script uses exact integer/Fraction arithmetic only.  It supplements the core
R24 generator with:
  * chart-minimal carrier (h,Q0,n2 derived),
  * frozen genuine-positive radial/shape-level predicates,
  * complete regression of the three R23 master-corridor rows,
  * auxiliary finite-divisor exponent-incidence formulas,
  * final SHA256 manifest and terminal consistency.
Run after 105_R24_source_image.py.
"""
from __future__ import annotations
from fractions import Fraction
from math import gcd, lcm
from pathlib import Path
import csv, hashlib, json, re

ROOT=Path('/mnt/data/105_R24_bundle')

def vp(n:int,p:int)->int:
    n=abs(n)
    if n==0: raise ValueError('vp(0)')
    e=0
    while n%p==0:
        n//=p;e+=1
    return e

def ceildiv(a:int,b:int)->int:
    return -((-a)//b)

def canonical(P1,P2,P3,Q):
    assert P1*P1+P2*P2+P3*P3==Q*Q
    r=Fraction(P1,Q+P3); s=Fraction(P2,Q+P3)
    c=lcm(r.denominator,s.denominator)
    a=r.numerator*(c//r.denominator); b=s.numerator*(c//s.denominator)
    q=gcd(gcd(a,b),c); a//=q;b//=q;c//=q
    raw=(2*a*c,2*b*c,c*c-a*a-b*b,c*c+a*a+b*b)
    h=gcd(gcd(abs(raw[0]),abs(raw[1])),gcd(abs(raw[2]),abs(raw[3])))
    assert tuple(x//h for x in raw)==(P1,P2,P3,Q)
    S=a*a+b*b
    eps=1 if sum(x&1 for x in (a,b,c))==2 else 0
    odd_g=gcd(c,S)
    while odd_g%2==0: odd_g//=2
    assert h==(2**eps)*odd_g, (P1,P2,P3,Q,a,b,c,h,eps,odd_g)
    return a,b,c,h,S

def recover(case):
    P1,P2,P3,Q=case['P1'],case['P2'],case['P3'],case['Q0']
    A,g1,u0=case['A'],case['G1_STAR'],case['U0']
    m2,n3,g,k=case['M2'],case['N3'],case['G_EXP'],case['K_EXP']
    a,b,c,h,S=canonical(P1,P2,P3,Q)
    X,Y,G,K=10**m2,10**n3,10**g,10**k
    n2=m2+g+k; m3=n3+g
    D=K*P1-Q; T3=Q-P3; E=G*Q-P2
    YDIV=(P2*g1*T3)%Y==0
    J=u0*A*X*Y*G*D-g1*T3
    Nw=g1*A*Y*E
    w_ok=J>0 and Nw%J==0
    W=Nw//J if w_ok else None
    mr_ok=w_ok and P2%W==0
    Mr=P2//W if mr_ok else None
    c2_ok=mr_ok and Mr%u0==0
    C2=Mr//u0 if c2_ok else None
    a_ok=(P3%A==0)
    Nr=P3//A if a_ok else None
    c3_ok=a_ok and Nr%u0==0
    C3=Nr//u0 if c3_ok else None
    radial_int=c2_ok and c3_ok
    # Frozen R13 positive radial chamber: existence of integer U in both windows.
    if radial_int:
        Ulo=max(ceildiv(u0*10**(n2-1),Mr),ceildiv(u0*10**(n3-1),Nr))
        Uhi=min((u0*10**n2-1)//Mr,(u0*10**n3-1)//Nr)
        bplus=Ulo<=Uhi
    else:
        Ulo=Uhi=None;bplus=False
    shape_ac2=radial_int and gcd(A,C2)==1
    shape_wc3=radial_int and gcd(W,C3)==1
    shape_aw=w_ok and gcd(A,W)==1
    upstream=bplus and shape_ac2 and shape_wc3 and shape_aw
    g0=gcd(u0*A*W,P1) if w_ok else None
    master=w_ok and g1%g0==0 and P1%g1==0
    mu=g1//g0 if master else None
    mu_smith=radial_int and mu is not None and gcd(mu,C2*C3)==1
    lam=Y//gcd(Y,W*T3) if w_ok and mu is not None else None
    tau=lam//gcd(lam,mu) if lam is not None else None
    R1=P1//g1 if P1%g1==0 else None
    tail_g1=tau is not None and R1 is not None and gcd(tau,R1)==1
    tail_smith=tau is not None and radial_int and gcd(tau,C2*C3)==1
    support=master and mu_smith and tail_g1 and tail_smith
    genuine_support=upstream and support
    B2=vp(P2,2)+vp(g1,2)+vp(T3,2)
    B5=vp(P2,5)+vp(g1,5)+vp(T3,5)
    assert B2==2+vp(b,2)+vp(c,2)+vp(g1,2)+vp(S,2)-2*vp(h,2)
    assert B5==vp(g1,5)+vp(b,5)+abs(vp(c,5)-vp(S,5))
    # parameter-native h cancellation
    R=S+c*c
    Jraw=u0*A*X*Y*G*(2*K*a*c-R)-2*g1*S
    Nraw=g1*A*Y*(G*R-2*b*c)
    assert Jraw==h*J and Nraw==h*Nw
    # auxiliary w-incidence formulas, when direct W exists
    if w_ok:
        denY=A*(W*u0*X*G*D-g1*E)
        numY=W*g1*T3
        assert denY>0 and numY%denY==0 and numY//denY==Y
        numX=g1*(A*Y*E+W*T3)
        denX=W*u0*A*Y*G*D
        assert numX%denX==0 and numX//denX==X
    # first failure including semantic upstream before support
    gates=[('A_DIVISOR',a_ok),('G1_DIVISOR',P1%g1==0),('Y_DIV',YDIV),('J_POSITIVE',J>0),('DIRECT_W_INTEGRAL',w_ok),('MR_INTEGRAL',mr_ok),('RADIAL_INTEGRAL',radial_int),('POSITIVE_RADIAL_BOX',bplus),('SHAPE_GCD',shape_ac2 and shape_wc3 and shape_aw),('MASTER_CORRIDOR',master),('MU_SMITH',mu_smith),('TAIL_G1',tail_g1),('TAIL_SMITH',tail_smith)]
    first='FULL_SUPPORT_PASS' if genuine_support else next(name for name,ok in gates if not ok)
    return locals()

CASES=[
 dict(LABEL='CURRENT_FRONTIER',P1=640,P2=1420,P3=4727,Q0=4977,A=1,G1_STAR=80,U0=1,M2=1,N3=4,G_EXP=0,K_EXP=1),
 dict(LABEL='G0_DIAGNOSTIC',P1=480,P2=1040,P3=2499,Q0=2749,A=3,G1_STAR=240,U0=1,M2=2,N3=3,G_EXP=0,K_EXP=1),
 dict(LABEL='G10_DIAGNOSTIC',P1=200,P2=365,P3=104,Q0=429,A=13,G1_STAR=40,U0=1,M2=1,N3=1,G_EXP=1,K_EXP=1),
]
RR={c['LABEL']:recover(c) for c in CASES}
assert (RR['CURRENT_FRONTIER']['a'],RR['CURRENT_FRONTIER']['b'],RR['CURRENT_FRONTIER']['c'],RR['CURRENT_FRONTIER']['h'])==(160,355,2426,1213)
assert (RR['G0_DIAGNOSTIC']['a'],RR['G0_DIAGNOSTIC']['b'],RR['G0_DIAGNOSTIC']['c'],RR['G0_DIAGNOSTIC']['h'])==(30,65,328,41)
assert (RR['G10_DIAGNOSTIC']['a'],RR['G10_DIAGNOSTIC']['b'],RR['G10_DIAGNOSTIC']['c'],RR['G10_DIAGNOSTIC']['h'])==(200,365,533,1066)
assert RR['CURRENT_FRONTIER']['genuine_support']
assert RR['G0_DIAGNOSTIC']['first']=='MU_SMITH' and RR['G0_DIAGNOSTIC']['mu']==40
assert RR['G10_DIAGNOSTIC']['first']=='MU_SMITH' and RR['G10_DIAGNOSTIC']['mu']==40
for lab in RR:
    assert RR[lab]['Ulo']==RR[lab]['Uhi']==1
    assert RR[lab]['upstream']

def write_csv(name,rows,fields=None):
    p=ROOT/name
    if fields is None:
        fields=[]
        for row in rows:
            for k in row:
                if k not in fields: fields.append(k)
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

# Rebuild key companion registries with all three R23 master rows.
sphere=[]; lower=[]; fibres=[]; yrows=[]; ffs=[]; exps=[]
for C in CASES:
    r=RR[C['LABEL']]
    sphere.append(dict(LABEL=C['LABEL'],P1=C['P1'],P2=C['P2'],P3=C['P3'],Q0=C['Q0'],a=r['a'],b=r['b'],c=r['c'],h=r['h'],gcd_abc=1,S_a2_b2=r['S'],T3=r['T3'],P2_RECONSTRUCTED=r['P2'],H_EXACT_FORMULA='2^eps*oddpart(gcd(c,a^2+b^2))',v2_h=vp(r['h'],2),v5_h=vp(r['h'],5),COVERAGE='CANONICAL_ORIENTED_CHART_EXACT'))
    lower.append(dict(LABEL=C['LABEL'],a=r['a'],b=r['b'],c=r['c'],h=r['h'],A=C['A'],G1_STAR=C['G1_STAR'],U0=C['U0'],M2=C['M2'],N3=C['N3'],G_EXP=C['G_EXP'],K_EXP=C['K_EXP'],N2=r['n2'],M3=r['m3'],X=r['X'],Y=r['Y'],G=r['G'],K=r['K'],D=r['D'],T3=r['T3'],Y_DIV_PASS=r['YDIV'],J_ANGLE=r['J'],W_RECOVERABLE=r['w_ok'],W=r['W'],MR_RECOVERABLE=r['mr_ok'],MR=r['Mr'],C2=r['C2'],C3=r['C3'],U_RAD_LO=r['Ulo'],U_RAD_HI=r['Uhi'],POSITIVE_RADIAL_BOX=r['bplus'],SHAPE_GCD_A_C2=r['shape_ac2'],SHAPE_GCD_W_C3=r['shape_wc3'],SHAPE_GCD_A_W=r['shape_aw'],UPSTREAM_GENUINE_POSITIVE=r['upstream'],FULL_SUPPORT=r['genuine_support'],FIRST_FAILURE=r['first']))
    fibres.append(dict(SCOPE=C['LABEL'],FIBRE='FULL_POST_SUPPORT_SOURCE',BOUND='observed 1' if r['genuine_support'] else 'observed 0',RECOVERY=f"W={r['W']};Mr={r['Mr']};C2={r['C2']};C3={r['C3']};mu={r['mu']};tau={r['tau']}",NONEMPTY=r['genuine_support'],STATUS=r['first']))
    yrows += [dict(SCOPE=C['LABEL'],PRIME=2,PULLBACK=f"n3={C['N3']} <= B2={r['B2']}",H_RULE=f"v2(h)={vp(r['h'],2)}",NORMALIZED_CHAMBER='PASS',STATUS='PASS'),dict(SCOPE=C['LABEL'],PRIME=5,PULLBACK=f"n3={C['N3']} <= B5={r['B5']}",H_RULE=f"v5(h)={vp(r['h'],5)}",NORMALIZED_CHAMBER='PASS',STATUS='PASS')]
    ffs.append(dict(LABEL=C['LABEL'],SPHERE_PACKET=f"{C['P1']},{C['P2']},{C['P3']},{C['Q0']}",A=C['A'],G1_STAR=C['G1_STAR'],G=C['G_EXP'],K=C['K_EXP'],M2=C['M2'],N3=C['N3'],Y_DIV_PASS=r['YDIV'],J_POSITIVE=r['J']>0,DIRECT_W_INTEGRAL=r['w_ok'],MR_INTEGRAL=r['mr_ok'],RADIAL_INTEGRAL=r['radial_int'],POSITIVE_RADIAL_BOX=r['bplus'],SHAPE_GCD_PASS=r['shape_ac2'] and r['shape_wc3'] and r['shape_aw'],MASTER_CORRIDOR_PASS=r['master'],MU_SMITH_PASS=r['mu_smith'],TAIL_G1_PASS=r['tail_g1'],TAIL_SMITH_PASS=r['tail_smith'],LOWER_CARRIER_FIRST_FAILURE=r['first']))
    exps.append(dict(SCOPE=C['LABEL'],N3_CONDITION=f"n3={C['N3']} <= min({r['B2']},{r['B5']})",B2=r['B2'],B5=r['B5'],G_CONDITION=f"g={C['G_EXP']}",K_CONDITION=f"k={C['K_EXP']}",STATUS='FULL_SUPPORT' if r['genuine_support'] else 'DIES_MU_SMITH'))
write_csv('105_R24_Primitive_Sphere_Carrier.csv',sphere)
write_csv('105_R24_Lower_Carrier_Registry.csv',lower)
# prepend general fibre facts
fgen=[
 dict(SCOPE='GENERAL',FIBRE='W',BOUND='<=1',RECOVERY='W=Nw/J',NONEMPTY='J>0 and J|Nw',STATUS='PROVED_ALGEBRAICALLY'),
 dict(SCOPE='GENERAL',FIBRE='(W,Mr,C2,C3)',BOUND='<=1',RECOVERY='Mr=P2/W;C2=Mr/u0;C3=P3/(A*u0)',NONEMPTY='all exact integrality gates',STATUS='PROVED_ALGEBRAICALLY'),
 dict(SCOPE='GENERAL',FIBRE='FULL_POST_SUPPORT_SOURCE',BOUND='<=1',RECOVERY='upstream B+ and shape gcd are Boolean; support variables deterministic',NONEMPTY='all lower-native predicates pass',STATUS='PROVED_ALGEBRAICALLY')]
write_csv('105_R24_Zero_One_Fibre_Audit.csv',fgen+fibres)
ygen=[dict(SCOPE='GENERAL',PRIME=2,PULLBACK='n3 <= 2+v2(b)+v2(c)+v2(g1*)+v2(a^2+b^2)-2*v2(h)',H_RULE='v2(h)=1 iff exactly two of a,b,c odd; else 0',NORMALIZED_CHAMBER='PARITY_TWO_ODD / PARITY_OTHER',STATUS='PROVED'),dict(SCOPE='GENERAL',PRIME=5,PULLBACK='n3 <= v5(g1*)+v5(b)+|v5(c)-v5(a^2+b^2)|',H_RULE='v5(h)=min(v5(c),v5(a^2+b^2))',NORMALIZED_CHAMBER='v5(c)<,=,>v5(a^2+b^2)',STATUS='PROVED')]
write_csv('105_R24_Y_Divisibility_Pullback.csv',ygen+yrows)
write_csv('105_R24_Lower_Carrier_First_Failure.csv',ffs)
exgen=[dict(SCOPE='GENERAL_FIXED_ORIENTED_SPHERE_AND_G1',N3_CONDITION='1 <= n3 <= min(B2,B5)',B2='2+v2(b)+v2(c)+v2(g1*)+v2(S)-2*v2(h)',B5='v5(g1*)+v5(b)+|v5(c)-v5(S)|',G_CONDITION='not classified globally',K_CONDITION='not classified globally',STATUS='PROVED_FINITE_N3_FIBRE'),dict(SCOPE='AUXILIARY_W_DIVISOR_INCIDENCE',N3_CONDITION='for each w|P2: Y=w*g1*T3/[A*(w*u0*X*G*D-g1*E)]; at most one power-of-10 Y',B2='',B5='',G_CONDITION='fixed sphere,A,g1,u0,m2,g,k,w',K_CONDITION='w ranges over finite divisors(P2)',STATUS='PROVED_RELATIVE_FINITE_FIBRE')]
write_csv('105_R24_Exponent_Image.csv',exgen+exps)
# Support pullback now explicitly separates frozen upstream genuine-positive predicates.
support=[
 dict(GATE='FROZEN_POSITIVE_RADIAL_BOX',LOWER_NATIVE_FORMULA='recover Mr,Nr; Ulo=max(ceil(u0*10^(n2-1)/Mr),ceil(u0*10^(n3-1)/Nr)); Uhi=min(floor((u0*10^n2-1)/Mr),floor((u0*10^n3-1)/Nr)); require Ulo<=Uhi',STATUS='PROVED_PULLBACK_FROM_FROZEN_R13'),
 dict(GATE='FROZEN_SHAPE_GCD',LOWER_NATIVE_FORMULA='require gcd(A,C2)=gcd(W,C3)=gcd(A,W)=1 after deterministic recovery',STATUS='PROVED_PULLBACK_FROM_FROZEN_R15_R20'),
 dict(GATE='MASTER_CORRIDOR',LOWER_NATIVE_FORMULA='g0=gcd(u0*A*W(beta),P1); require g0|g1*|P1',STATUS='PROVED_PULLBACK'),
 dict(GATE='MU_SMITH',LOWER_NATIVE_FORMULA='mu=g1*/g0; require gcd(mu,C2(beta)*C3(beta))=1',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_SCALE',LOWER_NATIVE_FORMULA='lambda_z=Y/gcd(Y,W(beta)*T3); tau=lambda_z/gcd(lambda_z,mu)',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_G1',LOWER_NATIVE_FORMULA='R1=P1/g1*; require gcd(tau,R1)=1',STATUS='PROVED_PULLBACK'),
 dict(GATE='TAIL_SMITH',LOWER_NATIVE_FORMULA='require gcd(tau,C2(beta)*C3(beta))=1',STATUS='PROVED_PULLBACK')]
for C in CASES:
    r=RR[C['LABEL']]
    support += [dict(GATE=f"{C['LABEL']}:UPSTREAM",LOWER_NATIVE_FORMULA=f"Urad=[{r['Ulo']},{r['Uhi']}]; gcd(A,C2)={gcd(C['A'],r['C2'])};gcd(W,C3)={gcd(r['W'],r['C3'])};gcd(A,W)={gcd(C['A'],r['W'])}",STATUS='PASS' if r['upstream'] else 'FAIL'),dict(GATE=f"{C['LABEL']}:MASTER",LOWER_NATIVE_FORMULA=f"g0={r['g0']};g1*={C['G1_STAR']};P1={C['P1']}",STATUS='PASS' if r['master'] else 'FAIL'),dict(GATE=f"{C['LABEL']}:MU_SMITH",LOWER_NATIVE_FORMULA=f"mu={r['mu']};C2={r['C2']};C3={r['C3']}",STATUS='PASS' if r['mu_smith'] else 'FAIL'),dict(GATE=f"{C['LABEL']}:TAIL",LOWER_NATIVE_FORMULA=f"lambda={r['lam']};tau={r['tau']};R1={r['R1']}",STATUS='PASS' if (r['tail_g1'] and r['tail_smith']) else 'FAIL')]
write_csv('105_R24_Support_Pullback.csv',support)

# Patch markdown semantic precision.
p=ROOT/'105_R24_Post_Support_Source_Carrier_Image.md'
text=p.read_text(encoding='utf-8')
old=r'''R24 的最小 sufficient lower carrier 取

\[
\boxed{
\beta_{min}=
(P_1,P_2,P_3,Q_0;
A,g_1^*;u_0;m_2,n_3,g,k)
}.
\tag{BMIN}
\]

`n2` 不需要独立保留，因为

\[
n_2=m_2+g+k.
\]

等价 parameter-native carrier 为

\[
\boxed{
\beta_{par}=(a,b,c,h;A,g_1^*,u_0;m_2,n_3,g,k)
}.
\]

给定它以后，`X,Y,G,K,D,T3,W,Mr,C2,C3,g0,mu,lambda_z,tau,R1` 全部是 deterministic partial functions。

因此签：

```text
POST_SUPPORT_MINIMAL_LOWER_CARRIER_THEOREM=PROVED_UP_TO_EQUIVALENT_SPHERE_COORDINATE_CHOICE
```'''
new=r'''相对于上一节已经固定的 **canonical labeled stereographic chart**，真正 coordinate-minimal 的 lower carrier 可取

\[
\boxed{
\beta_{\mathrm{par,min}}
=(a,b,c;A,g_1^*;u_0;m_2,n_3,g,k)
}.
\tag{BMIN}
\]

若输入从 unordered sphere packet 开始，再附加有限 orientation label `sigma`；若 `(P1,P2,P3)` roles 已固定，则 `sigma` 省略。

这里 `h,Q0,n2` 都不是独立坐标：

\[
h=2^\varepsilon\operatorname{oddpart}\gcd(c,a^2+b^2),
\qquad
Q_0=\frac{a^2+b^2+c^2}{h},
\qquad
n_2=m_2+g+k.
\]

其中 `epsilon=1` 当且仅当 `(a,b,c)` 恰有两个奇数，否则 `epsilon=0`。所以旧 enriched packet
`(P1,P2,P3,Q0;A,g1*;u0;m2,n3,g,k)` 只是 provenance-preserving coordinate tuple，不是最小 chart。

给定 `beta_par,min` 后，`h,P1,P2,P3,Q0,X,Y,G,K,D,T3,W,Mr,C2,C3,g0,mu,lambda_z,tau,R1` 全部是 deterministic partial functions。这里的“minimal”严格限定为：**相对于 canonical labeled sphere chart，不保留任何可由其余列唯一恢复的坐标**；不宣称对所有可能的抽象重参数化具有绝对最小性。

因此签：

```text
POST_SUPPORT_MINIMAL_LOWER_CARRIER_THEOREM=PROVED__COORDINATE_MINIMAL_RELATIVE_TO_CANONICAL_LABELED_SPHERE_CHART
```'''
if old not in text:
    raise RuntimeError('minimal carrier block not found')
text=text.replace(old,new)
# Strengthen h content in decimal section.
needle='''故 Y-DIV 对 `p=2` 给'''
insert=r'''更精确地，整个公共 content 有闭式：

\[
\boxed{
h=2^\varepsilon\operatorname{oddpart}\gcd(c,S),\qquad S=a^2+b^2,
}
\tag{H-CONTENT}
\]

其中 `epsilon=1` 当且仅当 `(a,b,c)` 恰有两个奇数。对 odd prime `p`，这等价于
`v_p(h)=min(v_p(c),v_p(S))`；它不是仅针对 5 的经验规律。

'''+needle
if needle not in text: raise RuntimeError('decimal needle missing')
text=text.replace(needle,insert,1)
# Replace full support pullback intro to include genuine-positive upstream semantics.
old2='''令 `C1...Cr` 依次表示：sphere/primitivity、A selector、g1 selector、decimal exponents、Y-DIV、J positivity、W integrality、Mr/radial integrality、master corridor、mu-Smith、tail-g1、tail-Smith。

全部已经是 `beta_min` 的 explicit functions/predicates。因此'''
new2=r'''这里需要区分两层：用户定义的 **full support stack** 本身仍是 frozen 四条件；但 `S_post` 的量词域是 **genuine positive source profiles**。因此从 broad primitive-sphere carrier 反拉时，还必须保留 frozen upstream semantic predicate，而不能只检查四个 gcd。

在 `Mr,Nr` 已 deterministic recover 后，R13 的 positive radial chamber 可直接写成

\[
U^-_{\rm rad}=\max\!\left(
\left\lceil\frac{u_0 10^{n_2-1}}{M_r}\right\rceil,
\left\lceil\frac{u_0 10^{n_3-1}}{N_r}\right\rceil
\right),
\]
\[
U^+_{\rm rad}=\min\!\left(
\left\lfloor\frac{u_0 10^{n_2}-1}{M_r}\right\rfloor,
\left\lfloor\frac{u_0 10^{n_3}-1}{N_r}\right\rfloor
\right),
\]

并要求 `U_rad^- <= U_rad^+`。同时保留 frozen shape-level
`gcd(A,C2)=gcd(W,C3)=gcd(A,W)=1`。这些都已经通过 substitution 成为 lower-carrier-native Boolean；没有重新打开 common-U / downstream source-selector theory。

令 `C1...Cr` 依次表示：sphere/primitivity、A selector、g1 selector、decimal exponents、Y-DIV、J positivity、W integrality、Mr/radial integrality、**frozen positive-radial-box、frozen shape-gcd semantics**、master corridor、mu-Smith、tail-g1、tail-Smith。

全部已经是 `beta_par,min` 的 explicit functions/predicates。因此'''
if old2 not in text: raise RuntimeError('support intro not found')
text=text.replace(old2,new2)
# semantic ledger refine
text=text.replace('| oriented primitive sphere | canonical `(a,b,c)` with one quadratic equation already solved by chart |','| oriented primitive sphere | canonical `(a,b,c)`; `h` and the full sphere packet are derived |')
text=text.replace('| exponent chart | `(m2,n3,g,k)`; fixed sphere+g1 gives finite n3 fibre by Y-DIV |','| exponent chart | `(m2,n3,g,k)`; fixed sphere+g1 gives finite n3 fibre by Y-DIV; auxiliary `w|P2` incidence makes `Y` 0/1 for fixed `(sphere,A,g1,u0,m2,g,k,w)` |')
# Insert all-master-row regression after G10 section, before section 35.
marker='\n## 35. Sphere-Parameter Factorization of T3\n'
g0=RR['G0_DIAGNOSTIC']
extra=rf'''
### 34A. Complete R23 Master-Row Lower-Carrier Regression

R23 bounded census actually留下三条 master-corridor rows；R24 现在全部从 lower carrier 重放，而不是只检查 current 与 G=10 两条。

第三条 G=1 diagnostic 为

\[
(P_1,P_2,P_3,Q_0)=(480,1040,2499,2749),
\]
\[
(A,g_1^*,u_0;m_2,n_3,g,k)=(3,240,1;2,3,0,1).
\]

canonical sphere carrier 是

\[
\boxed{{(a,b,c,h)=(30,65,328,41)}}.
\]

exact recovery 给

\[
D={g0['D']},\quad T_3={g0['T3']},\quad
J_\angle={g0['J']},\quad W={g0['W']},\quad M_r={g0['Mr']},
\]
\[
(C_2,C_3)=({g0['C2']},{g0['C3']}),\quad
g_0={g0['g0']},\quad \mu={g0['mu']}.
\]

它的 radial source interval 恰为 `U_rad=[1,1]`，且三条 frozen shape gcd 均 pass；Y-DIV budgets 为 `(B2,B5)=({g0['B2']},{g0['B5']})`。随后

\[
\gcd(\mu,C_2C_3)=40,
\]

所以与 G=10 diagnostic 一样，最早死在 `MU_SMITH`。于是 R23 的三条 master rows 在 R24 graph coordinates 下的完整结构是：**1 条 genuine full-support graph point + 2 条 exact mu-Smith deletions**。
'''
if marker not in text: raise RuntimeError('marker section35 missing')
text=text.replace(marker,extra+marker,1)
# Insert auxiliary exponent incidence in exponent image section.
needle41='''因此 `n3` 不再是无界自由轴 **within a fixed sphere/g1 carrier**。

没有证明 `g=0` 唯一，也没有证明 `k=1` 唯一；G=10 diagnostic 已禁止任何从 bounded full-support evidence 偷渡 `G0_ONLY` theorem。'''
new41=r'''因此 `n3` 不再是无界自由轴 **within a fixed sphere/g1 carrier**。

进一步，在 WM-integrality 阶段把 recovered `W` 暂时记成辅助 finite divisor label `w|P2`（**不把 w 放回 lower carrier**）。由 `w J_angle=N_W` 可线性消去 `Y`：

\[
\boxed{
Y=
\frac{w g_1^*T_3}
{A\left(wu_0XGD-g_1^*(GQ_0-P_2)\right)}.
}
\tag{Y-WINC}
\]

所以固定 `(sphere,A,g1*,u0,m2,g,k,w)` 后，`Y=10^{n3}` 至多一个；它还必须是正整数且恰为 10 的幂。对已固定 `Y,w` 同理

\[
\boxed{
X=
\frac{g_1^*\left(AY(GQ_0-P_2)+wT_3\right)}
{wu_0AYGD}.
}
\tag{X-WINC}
\]

故 fixed divisor-incidence fibre 对 `m2` 也 0/1。这是比 Y-DIV valuation bound 更强的 **relative exponent graph collapse**，但由于 `P2` 随 sphere 移动，不能把它冒充 global finite exponent image。

没有证明 `g=0` 唯一，也没有证明 `k=1` 唯一；G=10 diagnostic 已禁止任何从 bounded full-support evidence 偷渡 `G0_ONLY` theorem。'''
if needle41 not in text: raise RuntimeError('exponent text missing')
text=text.replace(needle41,new41,1)
# Update terminal lower carrier, provenance and info certificate.
text=text.replace('LOWER_CARRIER_DEFINITION=(P1,P2,P3,Q0;A,g1*;u0;m2,n3,g,k)__EQUIV_(a,b,c,h;A,g1*;u0;m2,n3,g,k)','LOWER_CARRIER_DEFINITION=(a,b,c;A,g1*;u0;m2,n3,g,k)__PLUS_sigma_IF_UNORDERED__h_P1_P2_P3_Q0_n2_DERIVED')
text=text.replace('MINIMAL_LOWER_CARRIER_PROVED=YES_UP_TO_EQUIVALENT_SPHERE_COORDINATE_CHOICE__n2_RECOVERED_AS_m2+g+k','MINIMAL_LOWER_CARRIER_PROVED=YES__COORDINATE_MINIMAL_RELATIVE_TO_CANONICAL_LABELED_SPHERE_CHART')
text=text.replace('SUPPORT_STACK_PULLBACK_THEOREM=YES','SUPPORT_STACK_PULLBACK_THEOREM=YES__FROZEN_GENUINE_POSITIVE_BPLUS_AND_SHAPE_GCD_SEMANTICS_ALSO_PULLED_BACK',1)
text=text.replace('SEMANTIC_DIMENSION_LEDGER=SPHERE_3PARAM_CANONICAL__ORIENTATION_FINITE__A_AND_G1_DIVISOR_FINITE__N3_FINITE_PER_FIXED_CARRIER__W_MR_C2_C3_MU_TAU_ZERO_ONE_OR_DETERMINISTIC','SEMANTIC_DIMENSION_LEDGER=SPHERE_3PARAM_CANONICAL__h_AND_PACKET_DERIVED__ORIENTATION_FINITE__A_AND_G1_DIVISOR_FINITE__N3_FINITE_PER_FIXED_CARRIER__AUX_W_DIVISOR_INCIDENCE_GIVES_RELATIVE_X_Y_ZERO_ONE__W_MR_C2_C3_MU_TAU_ZERO_ONE_OR_DETERMINISTIC')
text=text.replace('CURRENT_FRONTIER_RECOVERED_FROM_LOWER_CARRIER=YES__(a,b,c,h)=(160,355,2426,1213)->W20->Mr71->C2=71,C3=4727->FULL_SUPPORT','CURRENT_FRONTIER_RECOVERED_FROM_LOWER_CARRIER=YES__(a,b,c)=(160,355,2426);h=1213_DERIVED->W20->Mr71->C2=71,C3=4727->BPLUS_AND_SHAPE_GCD->FULL_SUPPORT')
text=text.replace('G10_DIAGNOSTIC_ATTRITION_REGRESSION=YES__(a,b,c,h)=(200,365,533,1066)->W1->Mr365->C2=365,C3=8->mu40->FAIL_MU_SMITH','G10_DIAGNOSTIC_ATTRITION_REGRESSION=YES__(a,b,c)=(200,365,533);h=1066_DERIVED->W1->Mr365->C2=365,C3=8->BPLUS_AND_SHAPE_GCD->mu40->FAIL_MU_SMITH__G0_DIAGNOSTIC_ALSO_EXACTLY_REPLAYED_TO_MU_SMITH')
text=text.replace('EXPONENT_IMAGE=FIXED_SPHERE_AND_G1__1<=n3<=min(B2,B5)__g,k_GLOBAL_OPEN','EXPONENT_IMAGE=FIXED_SPHERE_AND_G1__1<=n3<=min(B2,B5)__PLUS_AUX_W_DIVISOR_INCIDENCE_GIVES_RELATIVE_Y_AND_X_ZERO_ONE__g,k_GLOBAL_OPEN')
text=text.replace('R24_INFORMATION_GAIN_CERTIFICATE=PASS__CANONICAL_ORIENTED_SPHERE_CHART__T3_AND_P2_FACTORIZATION__H_2_5_CONTENT_LAW__YDIV_SIX_CHAMBER_SCHEMA__FIXED_CARRIER_N3_FINITE_FIBRE__DIRECT_W_H_CANCELLATION__FULL_SUPPORT_ZERO_ONE_GRAPH__RELATIVE_FINITE_DIVISOR_INCIDENCE','R24_INFORMATION_GAIN_CERTIFICATE=PASS__CANONICAL_ORIENTED_SPHERE_CHART__EXACT_H_CONTENT_FORMULA__T3_AND_P2_FACTORIZATION__YDIV_SIX_CHAMBER_SCHEMA__FIXED_CARRIER_N3_FINITE_FIBRE__AUX_W_DIVISOR_XY_ZERO_ONE_INCIDENCE__DIRECT_W_H_CANCELLATION__FROZEN_GENUINE_POSITIVE_PULLBACK__FULL_SUPPORT_ZERO_ONE_GRAPH__THREE_R23_MASTER_ROWS_EXACTLY_REPLAYED')
p.write_text(text,encoding='utf-8')

# Keep terminal.txt synchronized with the markdown terminal block.
mm=re.search(r'## Machine-readable terminal block\n\n```text\n(.*?)\n```',text,re.S)
if not mm: raise RuntimeError('terminal block not found')
(ROOT/'105_R24_terminal.txt').write_text(mm.group(1).strip()+'\n',encoding='utf-8')
# Update exact summary with final semantic claims.
summary={
 'terminal_verdict':'POST_SUPPORT_ZERO_ONE_FIBRE_AND_SOURCE_IMAGE_GRAPH_PROVED__CANONICAL_SPHERE_PARAMETER_PULLBACK_AND_N3_FINITE_FIBRE_PROVED__GLOBAL_B_LEGAL_CLASSIFICATION_OPEN__NO_GLOBAL_RATIO_INTERSECTION_THEOREM',
 'minimal_lower_carrier':'(a,b,c;A,g1*;u0;m2,n3,g,k) per labeled orientation; sigma finite if unordered',
 'h_formula':'h=2^epsilon*oddpart(gcd(c,a^2+b^2)); epsilon=1 iff exactly two of a,b,c are odd',
 'zero_one_fibre':True,
 'source_image_graph':True,
 'global_thinness_proved':False,
 'global_ratio_intersection':'unresolved',
 'r25_authorized':False,
 'r23_master_rows':{lab:{k:RR[lab][k] for k in ['a','b','c','h','W','Mr','C2','C3','mu','tau','Ulo','Uhi','upstream','genuine_support','first']} for lab in RR},
 'auxiliary_exponent_incidence':{'Y':'w*g1*T3/[A*(w*u0*X*G*D-g1*E)]','X':'g1*(A*Y*E+w*T3)/(w*u0*A*Y*G*D)'},
}
(ROOT/'105_R24_exact_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Execution log append / overwrite concise final exact assertions.
with (ROOT/'105_R24_execution.log').open('w',encoding='utf-8') as f:
    f.write('105-R24 final semantic exact pass: PASS\n')
    for C in CASES:
        r=RR[C['LABEL']]
        f.write(f"{C['LABEL']}: sphere_params={(r['a'],r['b'],r['c'],r['h'])}; W={r['W']}; Mr={r['Mr']}; C2={r['C2']}; C3={r['C3']}; Urad=[{r['Ulo']},{r['Uhi']}]; mu={r['mu']}; first={r['first']}\n")
    f.write('EXACT_H_CONTENT_FORMULA=PASS\n')
    f.write('AUXILIARY_W_DIVISOR_XY_RECOVERY=PASS_ON_ALL_THREE_R23_MASTER_ROWS\n')
    f.write('GLOBAL_IMAGE_THINNESS=NOT_PROVED\nGLOBAL_RATIO_INTERSECTION=UNRESOLVED\nR25_AUTHORIZED=NO\n')
# Scripts README
(ROOT/'105_R24_scripts'/'README.md').write_text('''# 105-R24 exact scripts\n\n1. `105_R24_source_image.py` builds the core graph/pullback archive using exact integer/Fraction arithmetic.\n2. `105_R24_sphere_chart_regression.py` exhaustively regression-checks the canonical sphere chart and `h` content laws on a finite exact parameter box.\n3. `105_R24_finalize.py` is the final semantic/provenance pass: it replays all three R23 master rows, adds frozen genuine-positive pullback predicates, refines the chart-minimal carrier, verifies the auxiliary finite-divisor exponent recovery, synchronizes the terminal block, and regenerates hashes.\n\nNo floating-point arithmetic is used for theorem predicates.\n''',encoding='utf-8')
# Manifest excluding itself and zip.
manifest=[]
for fp in sorted(ROOT.rglob('*')):
    if not fp.is_file() or fp.name=='105_R24_SHA256_Manifest.csv': continue
    rel=str(fp.relative_to(ROOT))
    data=fp.read_bytes()
    manifest.append(dict(FILE=rel,BYTES=len(data),SHA256=hashlib.sha256(data).hexdigest()))
write_csv('105_R24_SHA256_Manifest.csv',manifest,['FILE','BYTES','SHA256'])
print('105-R24 finalizer: PASS')
for lab in RR:
    r=RR[lab]
    print(lab,(r['a'],r['b'],r['c'],r['h']),'W',r['W'],'Mr',r['Mr'],'Urad',(r['Ulo'],r['Uhi']),'first',r['first'])
