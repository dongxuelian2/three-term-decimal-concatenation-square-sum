#!/usr/bin/env python3
"""R21 exact discovery search.
Discovery evidence only: never upgrades finite no-hit to theorem.
Uses integer arithmetic + Fraction. The high-scale campaign archived in R21 used
an equivalent O3 C++ enumerator; this Python version is the transparent reference.
"""
from fractions import Fraction
from functools import lru_cache
from math import gcd,isqrt
import argparse

def digits(n): return len(str(n))
@lru_cache(None)
def divisors(n):
    out=[]
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            out.append(d)
            if d*d!=n: out.append(n//d)
    return tuple(out)

def evaluate(P1,P2,P3,Q0,C2,A=1,g=0,k=1):
    if P2%C2 or P3%A: return None
    W=P2//C2; C3=P3//A
    if C2<10 or gcd(C2,10)!=1: return None
    if gcd(A,C2)!=1 or gcd(W,C3)!=1 or gcd(A,W)!=1: return None
    n2,n3=digits(C2),digits(C3)
    m2=n2-g-k; m3=n3+g
    if m2<1:return None
    G,K=10**g,10**k; X,Y=10**m2,10**n3
    D=K*P1-Q0;T3=Q0-P3
    if D<=0 or T3<=0:return None
    Omega=W*T3-A*Y*(P2-G*Q0)
    NM=A*W*X*Y*G*D
    if Omega<=0 or NM%Omega:return None
    gs=NM//Omega;g0=gcd(A*W,P1)
    if gs%g0 or P1%gs:return None
    mu=gs//g0;R1=P1//gs
    if gcd(mu,C2*C3)!=1:return None
    lam=Y//gcd(Y,W*T3);tau=lam//gcd(lam,mu)
    if gcd(tau,R1)!=1 or gcd(tau,C2*C3)!=1:return None
    d=m3-m2
    theta=Fraction(W,A)*(Fraction(10)**(-d))
    deficit=Fraction(1,10)/theta if theta<=Fraction(1,10) else theta/10 if theta>=10 else Fraction(1)
    return dict(P1=P1,P2=P2,P3=P3,Q0=Q0,C2=C2,C3=C3,A=A,W=W,d=d,theta=theta,deficit=deficit,mu=mu,tau=tau,Lambda=mu*tau)

def run(pmax,mmax,nmax,permutations=False):
    perms=((0,1,2),(0,2,1),(1,0,2),(1,2,0),(2,0,1),(2,1,0)) if permutations else ((0,1,2),)
    unique={}
    for p in range(1,pmax+1):
      for m in range(1,mmax+1):
       for n in range(1,nmax+1):
        raw=[2*m*p,2*n*p,m*m+n*n-p*p];q=m*m+n*n+p*p
        if raw[2]<=0:continue
        h=gcd(gcd(raw[0],raw[1]),gcd(raw[2],q))
        raw=[x//h for x in raw];q//=h
        for i,j,k in perms:
          P1,P2,P3=raw[i],raw[j],raw[k]
          for C2 in divisors(P2):
            r=evaluate(P1,P2,P3,q,C2)
            if r:
              key=(P1,P2,P3,q,C2,r['A'],r['W'])
              unique[key]=r
              if Fraction(1,10)<r['theta']<10:
                print('FIRST_RATIO_PASS',r);return
    print('UNIQUE_SUPPORT_STACK_SHAPES',len(unique))
    for r in unique.values():print(r)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--pmax',type=int,default=25);ap.add_argument('--mmax',type=int,default=64);ap.add_argument('--nmax',type=int,default=142);ap.add_argument('--permutations',action='store_true');a=ap.parse_args();run(a.pmax,a.mmax,a.nmax,a.permutations)
