#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
int digs(i64 x){int d=0;do{d++;x/=10;}while(x);return d;}
i128 p10i(int e){i128 x=1;while(e-->0)x*=10;return x;}
string s128(i128 x){if(!x)return"0";bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
vector<i64> divs(i64 n){vector<i64>d;for(i64 a=1;a*a<=n;a++)if(n%a==0){d.push_back(a);if(a*a!=n)d.push_back(n/a);}return d;}
void emit(const char*tag,int p,int m,int n,int perm,i64 h,i64 P1,i64 P2,i64 P3,i64 Q0,i64 C2,i64 C3,i64 A,i64 W,int n2,int n3,int d,i64 D,i64 T3,i128 Om,i128 NM,i64 gs,i64 g0,i64 mu,i64 R1,i64 lam,i64 tau,i64 L){
 cout<<tag<<" p="<<p<<" m="<<m<<" n="<<n<<" perm="<<perm<<" h="<<h
 <<" P=("<<P1<<","<<P2<<","<<P3<<","<<Q0<<") C2="<<C2<<" C3="<<C3<<" A="<<A<<" W="<<W
 <<" n2="<<n2<<" n3="<<n3<<" d="<<d<<" D="<<D<<" T3="<<T3<<" Omega="<<s128(Om)<<" NM="<<s128(NM)
 <<" gstar="<<gs<<" g0="<<g0<<" mu="<<mu<<" R1="<<R1<<" lambda="<<lam<<" tau="<<tau<<" Lambda="<<L<<"\n";
}
int main(int argc,char**argv){
 int PM=stoi(argv[1]),MM=stoi(argv[2]),NN=stoi(argv[3]);
 int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 long long trip=0,orient=0,pairs=0,ratioCand=0,master=0,corr=0,stack=0,hit=0,near=0;
 set<tuple<i64,i64,i64,i64,i64,i64,i64,i64>> uniq;
 auto st=chrono::steady_clock::now(); bool found=false;
 for(int p=1;p<=PM && !found;p++){
  for(int m=1;m<=MM && !found;m++){
   for(int n=1;n<=NN && !found;n++){
    trip++; if(gcd(gcd(p,m),n)!=1) continue;
    i64 r[3]={2LL*m*p,2LL*n*p,1LL*m*m+1LL*n*n-1LL*p*p};
    i64 q=1LL*m*m+1LL*n*n+1LL*p*p; if(r[2]<=0) continue;
    i64 h=gcd(gcd(r[0],r[1]),gcd(r[2],q)); for(int z=0;z<3;z++)r[z]/=h; q/=h;
    for(int ip=0;ip<6 && !found;ip++){
     i64 P1=r[perms[ip][0]],P2=r[perms[ip][1]],P3=r[perms[ip][2]],Q0=q;
     i64 D=10*P1-Q0; if(D<=0) continue; orient++;
     i64 T3=Q0-P3; auto d2s=divs(P2), d3s=divs(P3);
     for(i64 C2:d2s){
      if(C2<10||gcd(C2,10LL)!=1) continue;
      i64 W=P2/C2; int n2=digs(C2);
      for(i64 A:d3s){
       i64 C3=P3/A; if(gcd(A,C2)!=1||gcd(W,C3)!=1||gcd(A,W)!=1) continue;
       pairs++; int n3=digs(C3), d=n3-n2+1;
       bool pass=false,nr=false;
       if(d>=1){i128 lo=(i128)A*p10i(d-1),hi=(i128)A*p10i(d+1);pass=lo<W&&W<hi;nr=(!pass&&((W<=lo&&lo<(i128)5*W)||(W>=hi&&(i128)W<5*hi)));}
       else {int e=-d; i128 scale=p10i(e+1); bool lower=(i128)W*scale>A; bool upper; if(e>=1)upper=(i128)W*p10i(e-1)<A; else upper=W<10*A; pass=lower&&upper;}
       if(!pass&&!nr) continue; ratioCand++;
       i128 X=p10i(n2-1),Y=p10i(n3),Om=(i128)W*T3+(i128)A*Y*(Q0-P2),NM=(i128)A*W*X*Y*D;
       if(Om<=0||NM%Om) continue; master++;
       i128 gg=NM/Om; if(gg>LLONG_MAX) continue; i64 gs=(i64)gg,g0=gcd(A*W,P1);
       if(gs%g0||P1%gs) continue; corr++;
       i64 mu=gs/g0,R1=P1/gs; if(gcd(mu,C2*C3)!=1) continue;
       i64 yy=(i64)Y,lam=yy/gcd(yy,W*T3),tau=lam/gcd(lam,mu);
       if(gcd(tau,R1)!=1||gcd(tau,C2*C3)!=1) continue; stack++;
       i64 L=mu*tau; auto key=make_tuple(P1,P2,P3,Q0,C2,C3,A,W);
       if(uniq.insert(key).second) emit(pass?"RATIO_HIT":"NEAR_STACK",p,m,n,ip,h,P1,P2,P3,Q0,C2,C3,A,W,n2,n3,d,D,T3,Om,NM,gs,g0,mu,R1,lam,tau,L);
       if(pass){hit++;found=true;break;} else near++;
      }
      if(found)break;
     }
    }
   }
  }
  if(p%10==0||found) cerr<<"p="<<p<<" trip="<<trip<<" orient="<<orient<<" pairs="<<pairs<<" ratioCand="<<ratioCand<<" master="<<master<<" corr="<<corr<<" stack="<<stack<<" hit="<<hit<<" uniq="<<uniq.size()<<" sec="<<chrono::duration<double>(chrono::steady_clock::now()-st).count()<<"\n";
 }
 cerr<<"FINAL trip="<<trip<<" orient="<<orient<<" pairs="<<pairs<<" ratioCand="<<ratioCand<<" master="<<master<<" corr="<<corr<<" stack="<<stack<<" hit="<<hit<<" near="<<near<<" uniq="<<uniq.size()<<" sec="<<chrono::duration<double>(chrono::steady_clock::now()-st).count()<<"\n";
}
