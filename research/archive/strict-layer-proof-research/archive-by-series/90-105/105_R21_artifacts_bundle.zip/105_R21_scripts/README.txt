105-R21 scripts

105_R21_exact_audit.py: exact theorem/witness regression.
105_R21_construct_search.py: transparent exact Python discovery reference.
105_R21_high_scale_standard.cpp: O3 exact integer high-scale standard-orientation census.
105_R21_orientation_search.cpp: six-coordinate-orientation census.
105_R21_AW_ratio_near_search.cpp: all legal A-divisor splits, ratio/near hard-prefilter.

Finite search is discovery evidence only and is never promoted to a universal theorem.
All ratio ranking in the Python audit uses fractions.Fraction; C++ comparisons use cross-multiplied exact integers.
