#include <bits/stdc++.h>
using namespace std; using i64=long long; using i128=__int128_t;
static vector<int> spf;
static int digs(i64 x){int d=0; do{d++;x/=10;}while(x);return d;}
static i128 p10i(int e){i128 x=1;while(e-->0)x*=10;return x;}
static string s128(i128 x){if(x==0)return"0"; bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
static vector<i64> divisors_fast(int n){ vector<pair<int,int>> f; while(n>1){int p=spf[n],e=0;while(n%p==0){n/=p;e++;}f.push_back({p,e});} vector<i64> ds{1};for(auto [p,e]:f){int sz=ds.size();i64 mul=1;for(int k=1;k<=e;k++){mul*=p;for(int i=0;i<sz;i++)ds.push_back(ds[i]*mul);}}return ds;}
struct Cnt{long long triples=0, prim=0, divvis=0, shapes=0, master=0,corr=0,mu=0,stack=0,ratio=0;};
static void printrow(int p,int m,int n,i64 h,i64 P1,i64 P2,i64 P3,i64 Q0,i64 C2,i64 W,int n2,int n3,int d,i64 D,i64 T3,i128 Om,i128 NM,i64 gs,i64 g0,i64 mu,i64 R1,i64 lam,i64 tau,i64 Lambda,const string& tag){
 cout<<tag<<" p="<<p<<" m="<<m<<" n="<<n<<" h="<<h<<" P=("<<P1<<","<<P2<<","<<P3<<","<<Q0<<") C2="<<C2<<" C3="<<P3<<" A=1 W="<<W<<" n2="<<n2<<" n3="<<n3<<" d="<<d<<" D="<<D<<" T3="<<T3<<" Omega="<<s128(Om)<<" NM="<<s128(NM)<<" gstar="<<gs<<" g0="<<g0<<" mu="<<mu<<" R1="<<R1<<" lambda="<<lam<<" tau="<<tau<<" Lambda="<<Lambda<<"\n";
}
int main(int argc,char**argv){if(argc<7){cerr<<"p0 p1 mmax nmax target_d|999 stopratio\n";return 2;}int p0=stoi(argv[1]),pmax=stoi(argv[2]),M=stoi(argv[3]),N=stoi(argv[4]),td=stoi(argv[5]);bool stop=stoi(argv[6]);int lim=2*pmax*N+10;spf.resize(lim+1);iota(spf.begin(),spf.end(),0);for(int i=2;i*(long long)i<=lim;i++)if(spf[i]==i)for(long long j=1LL*i*i;j<=lim;j+=i)if(spf[j]==j)spf[j]=i;
 Cnt c; set<tuple<i64,i64,i64,i64,i64,i64>> uniq; auto st=chrono::steady_clock::now();
 for(int p=p0;p<=pmax;p++){int maxm=min(M,20*p);for(int m=1;m<=maxm;m++){long long T=20LL*m*p-1LL*m*m-1LL*p*p;if(T<=1)continue;int nmax=min<long long>(N, sqrt((long double)(T-1)));while(1LL*(nmax+1)*(nmax+1)<T && nmax<N)nmax++;while(1LL*nmax*nmax>=T)nmax--;for(int n=1;n<=nmax;n++){c.triples++;if(std::gcd(std::gcd(p,m),n)!=1)continue;c.prim++;i64 cnum=1LL*m*m+1LL*n*n-1LL*p*p;if(cnum<=0)continue;i64 a=2LL*m*p,b=2LL*n*p,q=1LL*m*m+1LL*n*n+1LL*p*p; i64 h=std::gcd(std::gcd(a,b),std::gcd(cnum,q));i64 P1=a/h,P2=b/h,P3=cnum/h,Q0=q/h;if(P2>=spf.size()){cerr<<"spf overflow";return 3;}int n3=digs(P3);i64 D=10*P1-Q0;if(D<=0)continue;i64 T3=Q0-P3;
 auto ds=divisors_fast((int)P2);for(i64 C2:ds){c.divvis++;if(C2<10||std::gcd(C2,10LL)!=1)continue;i64 W=P2/C2;if(std::gcd(W,P3)!=1)continue;int n2=digs(C2),d=n3-n2+1;if(td!=999&&d!=td)continue;c.shapes++;i128 X=p10i(n2-1),Y=p10i(n3);i128 Om=(i128)W*T3+Y*(Q0-P2);i128 NM=(i128)W*X*Y*D;if(Om<=0||NM%Om)continue;c.master++;i128 gs128=NM/Om;if(gs128>LLONG_MAX)continue;i64 gs=(i64)gs128,g0=std::gcd(W,P1);if(gs%g0||P1%gs)continue;c.corr++;i64 mu=gs/g0,R1=P1/gs;if(std::gcd(mu,C2*P3)!=1)continue;c.mu++;i64 Y64=(i64)Y; i64 lam=Y64/std::gcd(Y64,W*T3);i64 tau=lam/std::gcd(lam,mu);if(std::gcd(tau,R1)!=1||std::gcd(tau,C2*P3)!=1)continue;c.stack++;i64 Lambda=mu*tau;auto key=make_tuple(P1,P2,P3,Q0,C2,W);bool isnew=uniq.insert(key).second;if(isnew)printrow(p,m,n,h,P1,P2,P3,Q0,C2,W,n2,n3,d,D,T3,Om,NM,gs,g0,mu,R1,lam,tau,Lambda,"STACK");
 bool pass=false,lower=false,upper=false; if(d>=1){i128 lo=p10i(d-1),hi=p10i(d+1);pass=lo<W&&W<hi;lower=W<=lo;upper=W>=hi;}else{ // compare 10^(d-1)<W using multiply by powers
   int e=-d; // lower=10^-e-1, upper=10^-e+1
   // equivalent 10^(e-1) W < 1 < 10^(e+1)W for A=1? original for d=-e: 10^{-e-1}<W<10^{-e+1}; W positive integer => usually upper fail for e>=1. use rational cross
   i128 ww=(i128)W*p10i(e+1); bool l=(ww>1); // W > 10^-e-1
   i128 ww2=(i128)W*p10i(max(e-1,0)); bool u; if(e>=1)u=(ww2<1); else u=(W<10); pass=l&&u; lower=!l;upper=!u;
 }
 if(pass){c.ratio++;printrow(p,m,n,h,P1,P2,P3,Q0,C2,W,n2,n3,d,D,T3,Om,NM,gs,g0,mu,R1,lam,tau,Lambda,"RATIO_HIT"); if(stop){cerr<<"STOP\n";goto done;}}
 else { // near score <5 exact cross for d>=1
   if(d>=1){i128 lo=p10i(d-1),hi=p10i(d+1); if(W<=lo && lo < (i128)5*W) printrow(p,m,n,h,P1,P2,P3,Q0,C2,W,n2,n3,d,D,T3,Om,NM,gs,g0,mu,R1,lam,tau,Lambda,"NEAR_LOWER"); if(W>=hi && W < (i128)5*hi) printrow(p,m,n,h,P1,P2,P3,Q0,C2,W,n2,n3,d,D,T3,Om,NM,gs,g0,mu,R1,lam,tau,Lambda,"NEAR_UPPER");}
 }
 }}}
 if(p%25==0){auto sec=chrono::duration<double>(chrono::steady_clock::now()-st).count();cerr<<"p="<<p<<" triples="<<c.triples<<" div="<<c.divvis<<" shapes="<<c.shapes<<" master="<<c.master<<" corr="<<c.corr<<" stack="<<c.stack<<" uniq="<<uniq.size()<<" sec="<<sec<<"\n";}
 }
done: auto sec=chrono::duration<double>(chrono::steady_clock::now()-st).count();cerr<<"FINAL triples="<<c.triples<<" prim="<<c.prim<<" div="<<c.divvis<<" shapes="<<c.shapes<<" master="<<c.master<<" corr="<<c.corr<<" mu="<<c.mu<<" stack="<<c.stack<<" ratio="<<c.ratio<<" uniq="<<uniq.size()<<" sec="<<sec<<"\n";
}
