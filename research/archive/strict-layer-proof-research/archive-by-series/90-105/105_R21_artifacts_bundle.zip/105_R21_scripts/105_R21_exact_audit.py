#!/usr/bin/env python3
from fractions import Fraction
from math import gcd

C2,C3,A,W=71,4727,1,20
P1,P2,P3,Q0=640,1420,4727,4977
g,k,m2,n2,n3,m3=0,1,1,2,4,4
G,K=10**g,10**k
assert P1*P1+P2*P2+P3*P3==Q0*Q0
D=K*P1-Q0; T3=Q0-P3
X=10**m2;Y=10**n3
Omega=W*T3-A*Y*(P2-G*Q0)
NM=A*W*X*Y*G*D
assert (D,T3,Omega,NM)==(1423,250,35575000,2846000000)
gstar=NM//Omega; g0=gcd(A*W,P1)
assert (gstar,g0)==(80,20) and gstar%g0==0 and P1%gstar==0
mu=gstar//g0;R1=P1//gstar
lambda_z=Y//gcd(Y,W*T3);tau=lambda_z//gcd(lambda_z,mu);Lambda=mu*tau
assert (mu,R1,lambda_z,tau,Lambda)==(4,8,2,1,4)
assert gcd(mu,C2*C3)==1 and gcd(tau,R1)==1 and gcd(tau,C2*C3)==1

d=m3-m2
Theta=Fraction(W,A*10**d)
xi2=Fraction(C2,10**(n2-1));xi3=Fraction(C3,10**(n3-1))
M=xi3/xi2
Sigma=Fraction(P2,G*G*K*P3)
assert d==n3-n2+2*g+k==3
assert xi2==Fraction(71,10) and xi3==Fraction(4727,1000)
assert M==Fraction(4727,7100)
assert Sigma==Fraction(142,4727)
assert Sigma*M==Theta==Fraction(1,50)
assert Fraction(1,100)<Sigma<100
lo=max(Fraction(1,10),Fraction(1,10)/Sigma)
hi=min(Fraction(10),Fraction(10)/Sigma)
assert (lo,hi)==(Fraction(4727,1420),Fraction(10))
assert lo/M==5
assert not (Fraction(1,10)<Theta<10)

def ceildiv(a,b): return (a+b-1)//b
Zlo=max(ceildiv(10**(m2-1),A),ceildiv(10**(m3-1),W))
Zhi=min((10**m2-1)//A,(10**m3-1)//W)
assert (Zlo,Zhi)==(50,9)

# Exhaust exact small rational regression of normalized equivalence.
for d0 in range(-3,4):
    for A0 in range(1,20):
        for W0 in range(1,60):
            theta = Fraction(W0,A0)*(Fraction(10)**(-d0))
            left = Fraction(10)**(d0-1) < Fraction(W0,A0) < Fraction(10)**(d0+1)
            right = Fraction(1,10) < theta < 10
            assert left==right
print('R21_EXACT_AUDIT=PASS')
print('THETA=1/50')
print('SIGMA=142/4727')
print('M=4727/7100')
print('M_TARGET_LO=4727/1420')
print('DEFICIT_FACTOR=5')
print('Z_DIAGNOSTIC=50>9')
