#!/usr/bin/env python3
from math import gcd

def ceil_div(a,b): return (a+b-1)//b

def qwindow(A,W,L,m2,m3):
    zm=max(ceil_div(10**(m2-1),A),ceil_div(10**(m3-1),W))
    zp=min((10**m2-1)//A,(10**m3-1)//W)
    return zm,zp,ceil_div(zm,L),zp//L

def qmaster(Q0,b1,D): return (Q0-1)//(b1*D)

def cutoff_equivalence(Q0,b1,D,Qminus):
    return (qmaster(Q0,b1,D)<Qminus)==(Qminus*b1*D>=Q0)

ROWS=[
('(20,120,123,173)',1,2,5,1,2,1,27,173),
('(48,436,75,445)',3,4,2,1,1,1,35,445),
('(120,900,691,1141)',1,12,2,1,2,1,59,1141),
('(140,1240,491,1341)',1,2,5,1,2,1,59,1341),
('(230,330,1593,1643)',1,2,5,1,2,1,657,1643),
('(288,2584,585,2665)',3,4,2,1,1,1,215,2665),
('(298,2514,1485,2935)',5,1,1,1,1,5,45,2935),
]
for packet,A,W,L,m2,m3,b1,D,Q0 in ROWS:
    zm,zp,qm,qp=qwindow(A,W,L,m2,m3)
    qM=qmaster(Q0,b1,D); qs=min(qp,qM)
    assert cutoff_equivalence(Q0,b1,D,qm)
    assert qm==1 and qs>=1
    assert b1*D<Q0
    print(packet, 'Q=',(qm,qp),'Qmaster=',qM,'Qstar=',qs,'unit_survives_cutoff=YES')
print('CUT_EQUIVALENCE_SYMBOLIC_INTEGER_STEP: floor((Q0-1)/(b1D))<Qminus iff Qminus*b1D>=Q0')
print('UNIT_CHAMBER_LEMMA: Qminus=1 and b1D<Q0 => Qmaster>=1')
