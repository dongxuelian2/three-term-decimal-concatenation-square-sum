#!/usr/bin/env python3
from math import gcd

def terminal_pairs(Uset,Qminus,Qstar,F):
    Q=range(Qminus,Qstar+1) if Qminus<=Qstar else []
    return [(u,q) for u in Uset for q in Q if gcd(q,F*u)==1]

def qF(Qminus,Qstar,F):
    return [q for q in range(Qminus,Qstar+1) if gcd(q,F)==1] if Qminus<=Qstar else []

# This script is a generic exact checker for a supplied finite architecture.
# R35 found no globally certified source-complete architecture with nonempty Q window,
# so no global exhaustive call is asserted here.
assert terminal_pairs([],1,10,1)==[]
assert qF(13,2,671234)==[]
print('GENERIC_TERMINAL_RECTANGLE_CHECKER=PASS')
print('GLOBAL_EXHAUSTIVE_ARCHITECTURE_CLASSIFICATION=NO')
