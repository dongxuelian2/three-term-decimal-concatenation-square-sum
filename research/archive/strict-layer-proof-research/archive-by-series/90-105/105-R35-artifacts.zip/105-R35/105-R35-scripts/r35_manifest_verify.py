#!/usr/bin/env python3
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
manifest=root/'105-R35-SHA256-MANIFEST.txt'
bad=0
for line in manifest.read_text().splitlines():
    if not line or line.startswith('#'): continue
    h,rel=line.split('  ',1)
    p=root/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    ok=(got==h)
    print(('PASS' if ok else 'FAIL'),rel,got)
    bad += (not ok)
raise SystemExit(1 if bad else 0)
