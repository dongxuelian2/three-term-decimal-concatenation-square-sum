# 105-R35 — Terminal Rectangle Analysis

Define
\[
\mathcal Q=[Q_-,Q_*]\cap\mathbf Z_{>0},\qquad
\mathcal Q_F=\{q\in\mathcal Q:(q,F)=1\}.
\]
Then the exact terminal rectangle is \(\mathcal U_0\times\mathcal Q_F\), with a positive pair exactly when some cross pair is coprime.

## Cardinalities
For one architecture,
\[
|\mathcal Q|=\max(0,Q_*-Q_-+1),\qquad |\mathcal Q_F|\le|\mathcal Q|.
\]
R31 gives \(Q_+<10Q_-\). Thus whenever nonempty,
\[
|\mathcal Q|\le 9Q_-.
\]
This is not an architecture-uniform constant because no global bound on \(Q_-\) is known. R35 does **not** prove \(Q_*<2Q_-\), nor \(Q_*<Q_-+C\) with absolute C.

For the source side,
\[
|\mathcal U_0|\le\max(0,U_{hi}-U_{lo}+1),
\]
but no global architecture-uniform constant and no universal zero/one source-fibre theorem is known. R24's zero/one theorem concerns a different fixed-lower-carrier lift fibre and must not be misquoted as \(|\mathcal U_0|\le1\).

## Frozen exact reconnaissance
- R8 exact post-PSDG census A,B,C,E: source fibre empty in all 4; this is not a complete family theorem.
- R33 seven q=1 MASTER hits: all have \(Q_*\ge1\), but all have coarse source integer room empty \(U_{lo}=1>U_{hi}=0\).
- Historical R29 support survivor: raw source room contains U=1, but \(Q_*=2<Q_-=13\), so denominator rectangle is empty.

No frozen point simultaneously certifies `completed-source nonempty` and `master-truncated denominator nonempty`.

## Actual first failure after R35
The current smallest unclassified incidence is not an extra congruence. It is:
\[
\exists\,\mathfrak a\text{ legal post-support architecture}:
\mathcal U_0(\mathfrak a)\ne\varnothing,
\quad Q_-(\mathfrak a)\le Q_*(\mathfrak a).
\]
If such an architecture lies in the unit chamber, it is already a terminal witness. If it is nonunit, only then does the finite coprime-cover question become active.
