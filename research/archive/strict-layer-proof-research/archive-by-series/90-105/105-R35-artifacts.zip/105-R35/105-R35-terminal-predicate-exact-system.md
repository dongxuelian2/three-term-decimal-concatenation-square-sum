# 105-R35 — Terminal Predicate Exact System

## 1. Frozen denominator data
For a fixed legal post-support architecture,
\[
M_0=u_0AW,\quad g_0=(M_0,P_1),\quad \mu=g_1^*/g_0,\quad R_1=P_1/g_1^*,
\]
\[
\lambda_z=\frac{10^{n_3}}{(10^{n_3},W(Q_0-P_3))},\qquad
\Lambda=\operatorname{lcm}(\mu,\lambda_z),
\]
\[
F=\operatorname{rad}(R_1C_2C_3),\qquad V_0=\Lambda u_0AW.
\]
The denominator digit room is
\[
Z_- = \max\left(\left\lceil\frac{10^{m_2-1}}A\right\rceil,\left\lceil\frac{10^{m_3-1}}W\right\rceil\right),
\]
\[
Z_+ = \min\left(\left\lfloor\frac{10^{m_2}-1}A\right\rfloor,\left\lfloor\frac{10^{m_3}-1}W\right\rfloor\right),
\]
\[
Q_-=\left\lceil\frac{Z_-}{\Lambda}\right\rceil,\qquad
Q_+=\left\lfloor\frac{Z_+}{\Lambda}\right\rfloor.
\]

## 2. Completed source set
\[
\mathcal U_0=\{U\in\mathbf Z_{>0}:U_{lo}\le U\le U_{hi},\ U\bmod P_0\in\mathcal R_0,\ (U,V_0)=1,\ \mathsf{SrcComp}(U)\}.
\]
In regular completed strata this is equivalently the canonical periodic source successor inside the decorated R8 interval. Historical q=1 source-chart decorations retain their open-boundary/progression correction; the historical source-chart label must not be confused with the R15 residual denominator q.

## 3. MASTER cutoff
Set
\[
b_1=\frac{\Lambda u_0AW}{g_1^*},\qquad D=10^kP_1-Q_0>0.
\]
R33 proves
\[
q b_1D<Q_0,
\]
therefore
\[
Q_{master}=\left\lfloor\frac{Q_0-1}{b_1D}\right\rfloor,
\qquad Q_*=\min(Q_+,Q_{master}).
\]

## 4. Exact current terminal predicate
The current post-R33 terminal count must be
\[
N_{term}:=\sum_{U\in\mathcal U_0}
\#\{q\in[Q_-,Q_*]\cap\mathbf Z_{>0}:(q,FU)=1\}.
\]
Then, tautologically and exactly,
\[
N_{term}>0\iff
\exists U\in\mathcal U_0\ \exists q\in[Q_-,Q_*]:(q,FU)=1.
\tag{TP}
\]

### Historical-name audit
R30's archived literal \(N_{30}\) counted through \(Q_+\), before the R33 MASTER cutoff was available. Hence the statement `old literal N30 > 0 iff TP` is not definitional. It becomes exact only if the project convention now uses `N30` for the MASTER-refined terminal count above, or if one separately proves that no old positive summand lies above \(Q_{master}\). R35 freezes this distinction rather than silently dropping the new cutoff.

## 5. Coprimality split
\[
(q,FU)=1\iff(q,F)=1\ \&\ (q,U)=1.
\]
Thus with
\[
\mathcal Q_F=\{q\in[Q_-,Q_*]:(q,F)=1\},
\]
TP is exactly
\[
\exists U\in\mathcal U_0\ \exists q\in\mathcal Q_F:(q,U)=1.
\]
