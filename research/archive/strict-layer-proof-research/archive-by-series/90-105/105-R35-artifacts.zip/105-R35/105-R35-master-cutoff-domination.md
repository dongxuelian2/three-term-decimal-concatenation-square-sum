# 105-R35 — MASTER Cutoff Domination

## The exact floor elimination
For positive integers \(Q_0,b_1,D,Q_-\),
\[
Q_{master}<Q_-
\iff
\left\lfloor\frac{Q_0-1}{b_1D}\right\rfloor<Q_-
\iff
\frac{Q_0-1}{b_1D}<Q_-
\iff
Q_0\le Q_-b_1D.
\]
Therefore
\[
\boxed{Q_{master}<Q_-\iff Q_-b_1D\ge Q_0.}
\tag{CUT-EXACT}
\]
This is an exact equivalence, not a sufficient approximation.

Since \(Q_-=\lceil Z_-/\Lambda\rceil\) and \(b_1=\Lambda u_0AW/g_1^*\), a convenient sufficient rational separation is
\[
Z_-\frac{u_0AW}{g_1^*}D\ge Q_0.
\]
Using either active term in \(Z_-\) gives diagnostics
\[
u_0W10^{m_2-1}D\ge g_1^*Q_0
\quad\text{or}\quad
u_0A10^{m_3-1}D\ge g_1^*Q_0,
\]
but R35 does not have a theorem deriving either from \(\mathcal U_0\ne\varnothing\).

## Unit-chamber non-kill lemma
R33 proves \(0<b_1D<Q_0\). If \(Q_-=1\), then
\[
Q_{master}=\left\lfloor\frac{Q_0-1}{b_1D}\right\rfloor\ge1.
\]
If the denominator room also has \(Q_+\ge1\), then \(Q_*\ge1\). Hence MASTER cutoff cannot remove q=1.

Consequently, on the unit denominator chamber,
\[
\mathcal U_0\ne\varnothing\Longrightarrow TP\text{ is positive immediately}.
\]
So the proposed universal theorem
\[
\mathcal U_0\ne\varnothing\Rightarrow Q_{master}<Q_-
\]
would have to imply that every legal unit-chamber source fibre is empty. It is therefore at least as hard as the still-open q=1 source-extinction problem and cannot be obtained from the MASTER defect inequality alone.

## Status of the universal cutoff conjecture
- PROVED? **NO**.
- FALSIFIED by a genuine source-complete counterexample? **NO**.
- Genuine counterexample found? **NO**.
- Independent MASTER-only killer? **NO**, by the unit-chamber lemma.

The strongest global lower bound on \(b_1D\) actually proved from the frozen current interface is positivity/integrality, \(b_1D\ge1\), together with the upper bound \(b_1D<Q_0\). No source-completion theorem currently upgrades this to the scale \(Q_0/Q_-\).

## Historical R29 autopsy
For `(640,1420,4727,4977)`:
\[
b_1D=1423,\quad Q_0=4977,\quad Q_-=13,\quad Q_+=2,\quad Q_{master}=3.
\]
Thus \(Q_--Q_{master}=10\) and \(Q_-b_1D-Q_0=13522\). The early cutoff is not evidence that source completion forces a large \(b_1D\): this row already has an empty denominator chamber \(Q_+<Q_-\), while its raw source room contains \(U=1\) and completed source was not activated. The large margin comes from denominator-scale mismatch, not a proved source→cutoff mechanism.
