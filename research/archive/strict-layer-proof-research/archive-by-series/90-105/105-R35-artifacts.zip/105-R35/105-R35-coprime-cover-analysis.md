# 105-R35 — Coprime Cover Analysis

For an architecture with nonempty sides,
\[
TP\iff\exists U\in\mathcal U_0\ \exists q\in\mathcal Q_F:(U,q)=1.
\]
Extinction is exactly complete bipartite non-coprimality:
\[
\forall U\in\mathcal U_0,\ \forall q\in\mathcal Q_F,\quad (U,q)>1.
\]
Equivalently, for each U,
\[
\mathcal Q_F\subseteq\bigcup_{p\mid U}p\mathbf Z.
\]

R35 does not promote this equivalence into a new Möbius theory. It asks whether a genuine terminal rectangle was reached. In the exact frozen/replayed corpus, none was: the q1 rows have empty source side, and R29 has empty denominator side. Therefore there is no genuine nonempty rectangle on which a global prime-cover certificate can be honestly claimed.

Consequences:
- `TERMINAL_COPRIME_RECTANGLE_EXTINCTION=NOT_PROVED`.
- No genuine coprime terminal pair was found either.
- No pairwise-coprime denominator subset/source-prime-capacity theorem was triggered, because no certified simultaneous nonempty rectangle was reached.

The generic exact checker is preserved in `105-R35-scripts/r35_rectangle_check.py` for any future concrete architecture; it performs the finite decision without heuristics.
