# 105-R23 scripts

- `105_R23_exact_audit.py` — exact integer/Fraction regression for the frozen full-support witness, Y-divisibility budgets, Direct-W/J/H/Theta identities, completed load, z-window diagnostic, and the G+ direct-only diagnostic row.
- `105_R23_decimal_first_construct.cpp` — exact `__int128` decimal-first construct search. Default intended run for this archive: parameter bound `55`, `Q0 <= 6000`, all `A | P3`, `u0=1`, `k=1`, `g in {0,1,2}`, `m2=1..5`. Ordering is Y-DIV first, then J-angle, forced W, digit semantics, g1 corridor, frozen support stack, completed load.

No floating-point value is used for a theorem or pass/fail predicate. The printed decimal `def` is display-only; all gate decisions use exact integer cross multiplication.
