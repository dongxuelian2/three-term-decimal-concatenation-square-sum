#!/usr/bin/env python3
from fractions import Fraction
from math import gcd

def vp(n,p):
    n=abs(n); e=0
    while n and n%p==0:
        n//=p; e+=1
    return e

# Frozen full-support witness
C2,C3,A,W=71,4727,1,20
P1,P2,P3,Q0=640,1420,4727,4977
g,k,m2,n3=0,1,1,4
u0=1; G=10**g; X=10**m2; Y=10**n3
D=10**k*P1-Q0; T3=Q0-P3; g1=80
assert P1*P1+P2*P2+P3*P3==Q0*Q0
assert D==1423 and T3==250
assert (Q0-P2)*(Q0+P2)==P1*P1+P3*P3
assert Q0>P2 and G*Q0-P2>0
J=u0*A*X*Y*G*D-g1*T3
assert J==142_280_000
assert W*J==g1*A*Y*(G*Q0-P2)
assert W==Fraction(g1*A*Y*(G*Q0-P2),J)
Mr=P2//W
assert Mr==71
assert Fraction(P2*J,g1*A*Y*(G*Q0-P2))==Mr
assert (P2*g1*T3)%Y==0
assert (vp(P2,2),vp(g1,2),vp(T3,2),n3)==(2,4,1,4)
assert (vp(P2,5),vp(g1,5),vp(T3,5),n3)==(1,1,3,4)
H=199_080_000
assert Fraction(H,J)==Fraction(G*Q0,G*Q0-P2)
theta=Fraction(g1*X*(G*Q0-P2),G*J)
assert theta==Fraction(1,50)
A0=Fraction(u0*A*Y*D,g1*(Q0-P2))
C0=Fraction(T3,X*(Q0-P2))
assert A0==Fraction(177875,3557)
assert C0==Fraction(25,3557)
assert A0-C0==50
Lrad=Fraction(A*Y*Mr,X*Q0)
LD=Fraction(u0*A*Y*G*D,g1*Q0)
L3=Fraction(P3,X*Q0)
Psi=Lrad+LD+L3
assert Lrad==Fraction(71000,4977)
assert Psi==Fraction(501,10)
assert Psi-Fraction(1,X)==50
assert Psi/Fraction(101,10)==Fraction(501,101)
NJ=Fraction(g1*X*(G*Q0-P2),G)
assert NJ==2_845_600
assert Fraction(J,NJ)==50
# z window diagnostic
Zlo=max((10**(m2-1)+A-1)//A,(10**(n3+g-1)+W-1)//W)
Zhi=min((10**m2-1)//A,(10**(n3+g)-1)//W)
assert (Zlo,Zhi)==(50,9)

# G+ direct-only diagnostic row found by decimal-first search.
p1,p2,p3,q=200,365,104,429
AA,WW,gg,mm2,nn3,gg1=13,1,1,1,1,40
GG,XX,YY=10,10,10
DD=10*p1-q; TT3=q-p3; gap=GG*q-p2
JJ=AA*XX*YY*GG*DD-gg1*TT3
assert JJ==20_410_000
assert WW*JJ==gg1*AA*YY*gap
assert (p2*gg1*TT3)%YY==0
mu=40; CC=365*8
assert gcd(mu,CC)==40 # frozen support-stack failure
At=Fraction(AA*YY*GG*GG*DD,gg1*gap)
Ct=Fraction(GG*TT3,XX*gap)
assert Ct==Fraction(13,157) and Ct<Fraction(1,9)
assert At-Ct==130

print('R23_EXACT_AUDIT=PASS')
print('CURRENT_J_ANGLE=',J)
print('CURRENT_THETA=',theta)
print('CURRENT_PSI=',Psi)
print('CURRENT_COMPLETED_LOAD_DEFICIT=',Psi/Fraction(101,10))
print('CURRENT_YDIV_DELTA2=',vp(P2,2)+vp(g1,2)+vp(T3,2)-n3)
print('CURRENT_YDIV_DELTA5=',vp(P2,5)+vp(g1,5)+vp(T3,5)-n3)
print('GPLUS_DIRECT_DIAGNOSTIC_CORRECTION=',Ct)
print('GPLUS_DIRECT_DIAGNOSTIC_SUPPORT_STACK=FAIL_MU_SMITH')
