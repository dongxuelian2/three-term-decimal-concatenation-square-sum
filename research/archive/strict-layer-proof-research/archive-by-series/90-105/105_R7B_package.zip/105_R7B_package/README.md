# 105-R7B package

Main report: `105_R7B_Oriented_Root_Divisibility.md`

Companions:
- oriented divisibility ledger
- CRT root classes
- quotient-size audit
- shared-gcd ledger
- prime-packet atlas
- split-prime allocation ledger
- integer-lift witness registry
- first-failure ledger
- exact symbolic/regression verifier

Terminal status: reduced to `PRESCRIBED_SOURCE_DIVISOR_MEMBERSHIP`; R8 not authorized.
