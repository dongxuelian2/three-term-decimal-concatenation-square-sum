#!/usr/bin/env python3
from math import gcd, isqrt
from collections import Counter

def divisors(n):
    out=[]
    for d in range(1,isqrt(n)+1):
        if n%d==0:
            out.append(d)
            if d*d!=n: out.append(n//d)
    return sorted(out)

u0,n2,n3=1,2,1
G,K,X,Y=1,10,10,10

def core_ranges(U):
    return (
        range((10+U-1)//U, (100-1)//U+1),
        range((1+U-1)//U, (10-1)//U+1)
    )

core_fail=Counter(); master_class=Counter(); total=0; tail_survivors=0
for U in (1,2,3):
    C2s,C3s=core_ranges(U)
    for C2 in C2s:
        for C3 in C3s:
            total+=1
            hit={x:False for x in ["CF","PRIMITIVE","D","TAIL","MASTER"]}
            for b2 in range(1,10):
                for b3 in range(1,10):
                    for z in divisors(gcd(b2,b3)):
                        A,W=b2//z,b3//z
                        V=z*u0*A*W
                        P2,P3=W*C2,A*C3
                        if gcd(V,P2)!=u0*W or gcd(V,P3)!=u0*A: continue
                        N=P2*P2+P3*P3
                        for y in divisors(N):
                            if y*y>=N: continue
                            x=N//y
                            if (x+y)%2 or (x-y)%2: continue
                            P1,Q0=(x-y)//2,(x+y)//2
                            if P1<=0: continue
                            hit["CF"]=True
                            if gcd(gcd(P1,P2),gcd(P3,Q0))!=1: continue
                            hit["PRIMITIVE"]=True
                            D,T3=K*P1-Q0,Q0-P3
                            if D<=0 or T3<=0: continue
                            hit["D"]=True
                            if (b3*T3)%Y: continue
                            hit["TAIL"]=True; tail_survivors+=1
                            Omega=W*T3-A*Y*(P2-G*Q0)
                            Nmaster=u0*A*W*X*Y*G*D
                            if Omega<=0 or Nmaster%Omega:
                                master_class["G1STAR_NONINTEGRAL"]+=1; continue
                            g1star=Nmaster//Omega
                            if g1star!=gcd(V,P1):
                                master_class["G1_GCD_SHELL_MISMATCH"]+=1; continue
                            b1=V//g1star
                            raw=b1*X*Y*G*D+b2*Y*(P2-G*Q0)-b3*T3
                            H=b2*Q0-b1*X*D
                            if raw==0 and H!=0:
                                hit["MASTER"]=True; master_class["MASTER_PASS"]+=1
            if not hit["CF"]: core_fail["CF"]+=1
            elif not hit["PRIMITIVE"]: core_fail["PRIMITIVE"]+=1
            elif not hit["D"]: core_fail["D_RATIO"]+=1
            elif not hit["TAIL"]: core_fail["TAIL"]+=1
            elif not hit["MASTER"]: core_fail["MASTER"]+=1
            else: core_fail["POST_MASTER"]+=1

print("POSITIVE_CORES_TESTED=", total)
print("CORE_FIRST_FAILURE=", dict(core_fail))
print("TAIL_SURVIVING_ASSIGNMENTS=", tail_survivors)
print("MASTER_CLASS=", dict(master_class))
