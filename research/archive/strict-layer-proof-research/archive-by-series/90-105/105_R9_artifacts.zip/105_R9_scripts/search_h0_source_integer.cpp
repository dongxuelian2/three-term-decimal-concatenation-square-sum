#include <bits/stdc++.h>
using namespace std; using i128=__int128_t; using i64=long long;
static i128 isqrt128(i128 n){ if(n<0) return -1; i128 lo=0, hi=((i128)1<<64); while(lo+1<hi){i128 m=(lo+hi)/2; if(m<=n/m) lo=m; else hi=m;} return lo; }
static string s128(i128 x){if(x==0)return"0"; bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
int main(int argc,char**argv){int B1MAX=argc>1?atoi(argv[1]):1000; int UMAX=argc>2?atoi(argv[2]):9; long long tested=0, discrsq=0, introots=0, gcdpass=0, hits=0;
 for(int U=1;U<=UMAX;U++) for(int b2=1;b2<=9;b2++) for(int b3=1;b3<=9;b3++) for(int b1=1;b1<=B1MAX;b1++){
   i64 V=lcm((i64)b1,lcm((i64)b2,(i64)b3)); if(std::gcd((i64)U,V)!=1) continue;
   i64 g1=V/b1,g2=V/b2,g3=V/b3;
   int c2lo=(10+U-1)/U, c2hi=99/U; int c3lo=(1+U-1)/U, c3hi=9/U;
   for(int C2=c2lo;C2<=c2hi;C2++) if(std::gcd(C2,b2)==1)
   for(int C3=c3lo;C3<=c3hi;C3++) if(std::gcd(C3,b3)==1){
      tested++;
      i128 Bd=100*(i128)b1+10*(i128)b2+b3;
      i128 c=10*(i128)C2+C3;
      i128 D=(i128)b1*b2*b3;
      i128 bb23=(i128)b2*b3, bb13=(i128)b1*b3, bb12=(i128)b1*b2;
      i128 A= Bd*Bd*bb23*bb23 - (i128)1000000*D*D;
      i128 Bq= -(i128)2000*c*D*D;
      i128 Cq= Bd*Bd*((i128)C2*C2*bb13*bb13+(i128)C3*C3*bb12*bb12)-c*c*D*D;
      i128 disc=Bq*Bq-4*A*Cq; if(disc<0)continue; i128 w=isqrt128(disc); if(w*w!=disc)continue; discrsq++;
      for(int sg:{-1,1}){ i128 num=-Bq+sg*w, den=2*A; if(den==0 || num%den)continue; i128 C1=num/den; if(C1<=0 || C1>LLONG_MAX) continue; introots++; i64 c1=(i64)C1; if(std::gcd(c1,b1)!=1) continue; gcdpass++;
        i128 P1=(i128)g1*c1,P2=(i128)g2*C2,P3=(i128)g3*C3;
        i128 Qnum=(i128)V*(1000*C1+10*(i128)C2+C3); i128 Qden=Bd; if(Qnum%Qden)continue; i128 Q0=Qnum/Qden;
        if(P1*P1+P2*P2+P3*P3!=Q0*Q0) {cerr<<"bad"; return 2;}
        // primitive quadruple
        auto gcdll=[](i64 a,i64 b){return std::gcd(a,b);};
        if(P1>LLONG_MAX||P2>LLONG_MAX||P3>LLONG_MAX||Q0>LLONG_MAX)continue;
        i64 gg=gcdll((i64)P1,(i64)P2); gg=gcdll(gg,(i64)P3); gg=gcdll(gg,(i64)Q0); if(gg!=1)continue;
        // A1 D>0 & exact master implicit; DES K3 integrality n3=1
        i128 Dlead=10*P1-Q0; if(Dlead<=0)continue;
        if(((i128)b3*(Q0-P3))%10)continue;
        i128 H=(i128)b2*Q0-10*(i128)b1*Dlead; i128 K3=(i128)b3*(Q0-P3)/10; if((i128)b2*P2!=H+K3)continue;
        hits++;
        cout<<"HIT U="<<U<<" b="<<b1<<","<<b2<<","<<b3<<" V="<<V<<" C="<<c1<<","<<C2<<","<<C3<<" P="<<s128(P1)<<","<<s128(P2)<<","<<s128(P3)<<","<<s128(Q0)<<" D="<<s128(Dlead)<<" H="<<s128(H)<<" K3="<<s128(K3)<<"\n";
        if(hits>=20){cerr<<"tested="<<tested<<" sq="<<discrsq<<" roots="<<introots<<" gcd="<<gcdpass<<" hits="<<hits<<"\n"; return 0;}
      }
   }
 }
 cerr<<"tested="<<tested<<" sq="<<discrsq<<" roots="<<introots<<" gcd="<<gcdpass<<" hits="<<hits<<"\n";
}
