#include <bits/stdc++.h>
using namespace std; using i128=__int128_t; using i64=long long;
static i128 isqrt128(i128 n){ if(n<0) return -1; i128 lo=0,hi=((i128)1<<64);while(lo+1<hi){i128 m=(lo+hi)/2;if(m<=n/m)lo=m;else hi=m;}return lo;}
static string s128(i128 x){if(x==0)return"0";bool neg=x<0;if(neg)x=-x;string s;while(x){s.push_back('0'+x%10);x/=10;}if(neg)s.push_back('-');reverse(s.begin(),s.end());return s;}
int main(int argc,char**argv){int B1MAX=argc>1?atoi(argv[1]):20,C2MAX=argc>2?atoi(argv[2]):300,C3MAX=argc>3?atoi(argv[3]):100,MAXH=argc>4?atoi(argv[4]):100;
 long long tested=0,sq=0,roots=0,hits=0,fa=0,fb=0,cont=0; set<tuple<long long,long long,long long,long long,long long,long long,long long,long long>> uniq;
 for(int b2=1;b2<=9;b2++)for(int b3=1;b3<=9;b3++)for(int b1=1;b1<=B1MAX;b1++){
  i64 V=lcm((i64)b1,lcm((i64)b2,(i64)b3)),g1=V/b1,g2=V/b2,g3=V/b3;
  for(int C2=1;C2<=C2MAX;C2++)if(gcd(C2,b2)==1)for(int C3=1;C3<=C3MAX;C3++)if(gcd(C3,b3)==1){tested++;
   i128 Bd=100*(i128)b1+10*(i128)b2+b3,c=10*(i128)C2+C3,D=(i128)b1*b2*b3;
   i128 bb23=(i128)b2*b3,bb13=(i128)b1*b3,bb12=(i128)b1*b2;
   i128 A=Bd*Bd*bb23*bb23-(i128)1000000*D*D;
   i128 Bq=-(i128)2000*c*D*D;
   i128 Cq=Bd*Bd*((i128)C2*C2*bb13*bb13+(i128)C3*C3*bb12*bb12)-c*c*D*D;
   i128 disc=Bq*Bq-4*A*Cq;if(disc<0)continue;i128 w=isqrt128(disc);if(w*w!=disc)continue;sq++;
   for(int sg:{-1,1}){i128 num=-Bq+sg*w,den=2*A;if(den==0||num%den)continue;i128 C1=num/den;if(C1<=0||C1>LLONG_MAX)continue;roots++;i64 c1=(i64)C1;if(gcd(c1,b1)!=1)continue;
    i128 P1=(i128)g1*c1,P2=(i128)g2*C2,P3=(i128)g3*C3,Qnum=(i128)V*(1000*C1+10*(i128)C2+C3);if(Qnum%Bd)continue;i128 Q0=Qnum/Bd;
    if(P1*P1+P2*P2+P3*P3!=Q0*Q0||P1<=0||P1>=Q0)continue;
    if(P1>LLONG_MAX||P2>LLONG_MAX||P3>LLONG_MAX||Q0>LLONG_MAX)continue;
    i64 gg=gcd((i64)P1,(i64)P2);gg=gcd(gg,(i64)P3);gg=gcd(gg,(i64)Q0);if(gg!=1)continue;
    i128 Dlead=10*P1-Q0;if(Dlead<=0)continue;if(((i128)b3*(Q0-P3))%10)continue;
    i128 H=(i128)b2*Q0-10*(i128)b1*Dlead,K3=(i128)b3*(Q0-P3)/10;if((i128)b2*P2!=H+K3)continue;
    auto key=make_tuple((i64)P1,(i64)P2,(i64)P3,(i64)Q0,(i64)V,(i64)C2,(i64)C3,(i64)b1); if(!uniq.insert(key).second)continue;
    hits++; bool Aface=(10LL*C3>=C2); // L2>=L3: 10/C2 >=1/C3 -> 10*C3>=C2
    bool real=Aface?((i128)C2*10-(i128)C3*10>0):((i128)C3*100-(i128)C2>0); // GA/GB
    if(Aface)fa++; else fb++; if(real)cont++;
    cout<<"HIT face="<<(Aface?'A':'B')<<" real="<<real<<" b="<<b1<<","<<b2<<","<<b3<<" V="<<V<<" C="<<c1<<","<<C2<<","<<C3<<" P="<<s128(P1)<<","<<s128(P2)<<","<<s128(P3)<<","<<s128(Q0)<<"\n";
    if(hits>=MAXH){cerr<<"tested="<<tested<<" sq="<<sq<<" roots="<<roots<<" hits="<<hits<<" A="<<fa<<" B="<<fb<<" real="<<cont<<"\n";return 0;}
   }
  }
 }
 cerr<<"tested="<<tested<<" sq="<<sq<<" roots="<<roots<<" hits="<<hits<<" A="<<fa<<" B="<<fb<<" real="<<cont<<"\n";
}
