#!/usr/bin/env python3
"""105-R9 exact endpoint quotient / DES transport verifier.

Scope firewall:
- R1--R8 are treated as frozen.
- No PSDG/discriminant/packet search is reopened.
- The four R7D/R8 reduced profiles A,B,C,E are frozen exact post-PSDG inputs.
- All arithmetic is exact integer/Fraction arithmetic.
"""
from fractions import Fraction
from math import gcd, ceil

PROFILES = [
    ("A",(1,6,8),(24,52,159,169),24,2,1,1,1,1,0),
    ("B",(1,6,8),(48,436,75,445),24,2,1,1,1,1,0),
    ("C",(1,6,8),(456,292,2907,2957),24,2,1,1,1,1,0),
    ("E",(5,5,1),(298,2514,1485,2935),5,2,1,1,1,1,0),
]

def bezout(a,b):
    if b == 0:
        return (1,0,a)
    x,y,g = bezout(b,a%b)
    return (y, x-(a//b)*y, g)

def check(item):
    name,b,P,V,n2,n3,m2,m3,k,g = item
    b1,b2,b3=b; P1,P2,P3,Q0=P
    G,K,X,Y=10**g,10**k,10**m2,10**n3
    assert P1*P1+P2*P2+P3*P3==Q0*Q0
    assert gcd(gcd(P1,P2),gcd(P3,Q0))==1
    gs=(gcd(V,P1),gcd(V,P2),gcd(V,P3))
    C1,C2,C3=(P1//gs[0],P2//gs[1],P3//gs[2])
    assert tuple(V//x for x in gs)==b
    assert gcd(b1,C1)==gcd(b2,C2)==gcd(b3,C3)==1

    D=K*P1-Q0
    H=b2*Q0-b1*X*D
    assert (b3*(Q0-P3))%Y==0
    K3=b3*(Q0-P3)//Y
    assert b2*P2==G*H+K3

    x2=10**(n2-1); x3=10**(n3-1)
    q2,r2=divmod(x2,C2); q3,r3=divmod(x3,C3)
    delta2=0 if r2==0 else C2-r2
    delta3=0 if r3==0 else C3-r3
    uz2=ceil(Fraction(x2,C2)); uz3=ceil(Fraction(x3,C3))
    assert delta2==C2*uz2-x2
    assert delta3==C3*uz3-x3

    LA=Fraction(x2,C2); L3=Fraction(x3,C3)
    face='A' if LA>=L3 else 'B'
    GA=C2*10**n3-C3*x2
    GB=C3*10**n2-C2*x3
    SA=GA-C3*delta2
    SB=GB-C2*delta3
    assert SA==C2*(10**n3-C3*uz2)
    assert SB==C3*(10**n2-C2*uz3)

    # DES -> endpoint transport on Face-A endpoint x2.
    h=gcd(P1,Q0)
    s,t,h2=bezout(D,P1); assert h2==h
    E2=(s*K*(G*b2*Q0+K3)
        +t*(G*(b1*X+b2)*Q0+K3))
    d2star=gcd(C2,10*b1*h); M2=C2//d2star
    assert E2%d2star==0
    if M2>1:
        rho2=((E2//d2star)*pow((10*b1*h)//d2star,-1,M2))%M2
        assert r2%M2==rho2
    else:
        rho2=0

    # DES -> endpoint transport on Face-B endpoint x3.
    d3star=gcd(C3,10*K3); M3=C3//d3star
    assert (b3*Q0)%d3star==0
    if M3>1:
        rho3=((b3*Q0//d3star)*pow((10*K3)//d3star,-1,M3))%M3
        assert r3%M3==rho3
    else:
        rho3=0

    L=max(Fraction(x2,C2),Fraction(x3,C3))
    R=min(Fraction(10*x2,C2),Fraction(10*x3,C3))
    return dict(name=name,C=(C1,C2,C3),face=face,L=L,R=R,
                real=L<R,q2=q2,r2=r2,delta2=delta2,GA=GA,SA=SA,
                q3=q3,r3=r3,delta3=delta3,GB=GB,SB=SB,
                h=h,d2star=d2star,M2=M2,rho2=rho2,
                d3star=d3star,M3=M3,rho3=rho3,D=D,H=H,K3=K3)

if __name__ == '__main__':
    for p in PROFILES:
        print(check(p))
