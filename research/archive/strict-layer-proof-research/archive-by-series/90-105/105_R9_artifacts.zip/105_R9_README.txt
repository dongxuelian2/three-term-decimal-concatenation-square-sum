105-R9 artifact bundle

Main report:
- 105_R9_Endpoint_Quotient_Source_Successor.md

Companion registries:
- 105_R9_Endpoint_Quotient_Registry.csv
- 105_R9_Remainder_Atlas.csv
- 105_R9_Gap_Surplus_Registry.csv
- 105_R9_DES_Endpoint_Transport.csv
- 105_R9_Post_PSDG_Phase_Audit.csv
- 105_R9_Plain_Integer_Hits.csv
- 105_R9_Source_Integer_Hits.csv
- 105_R9_First_Failure_Registry.csv

Scripts:
- 105_R9_scripts/verify_r9_endpoint.py
- 105_R9_scripts/search_h0_source_integer.cpp
- 105_R9_scripts/search_h0_postpsdg.cpp
- exact output/summary files

Theorem/computation firewall: see main report sections 21 and Provenance ledger.
