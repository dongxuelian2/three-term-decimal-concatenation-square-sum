# 105-R36 — Source Periodic Residue Analysis

The completed source selector is finite-periodic profile-by-profile, not source-wide with a single universal period. The exact data are \((P_0,\mathcal R_0,V_0)\), with
\[
M_U=\operatorname{lcm}(P_0,V_0),\qquad
\mathcal R_{\rm adm}=\{r\bmod M_U:r\bmod P_0\in\mathcal R_0,(r,V_0)=1\}.
\]
An equivalent radical period uses \(\operatorname{rad}(V_0)\).

### Generic completed strata
The source progression itself has step 1. If the native selector is trivial (\(P_0=1\)), the admissible classes are precisely the units modulo \(V_0\) (or modulo \(\operatorname{rad}(V_0)\) in the reduced period). The residue count is then \(\varphi(\operatorname{rad}(V_0))\) in the radical period. This does not imply a hit: the first unit can still lie above \(R_{\rm src}\).

### Decorated q_src=1 strata
The affine congruence contributes a nontrivial finite-index progression before the unit condition is merged by CRT. This is separate from residual denominator q.

### Short-kill audit
1. \(\mathcal R_{\rm adm}=\varnothing\): valid immediate kill, but no universal unit theorem forces it.
2. \(M_U\) larger than room: insufficient alone when an admissible class is aligned with the integer lower edge.
3. Endpoint alignment \(d_{\min}=0\): not automatically contradictory; it means \(U_{\rm lo}\) itself is admissible and must be checked against the strict upper endpoint and all frozen source-completion predicates.
4. Exact circular interval nonintersection is equivalent to computing the canonical successor; R36 found no source-wide residue exclusion theorem.

Hence opening the periodic selector removes a black box but does not introduce a new independent obstruction.
