# 105-R36 — Simultaneous-Nonempty Classification

## Corrected exact loci
\[
\mathscr T_1=\{Q_-=1,\ \mathcal U_0\ne\varnothing,\ Q_+\ge1\},
\]
\[
\mathscr T_+=\{Q_-\ge2,\ \mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.
\]
They form the exact disjoint partition of the simultaneous source-complete + master-truncated-denominator-nonempty locus.

## Unit branch
- Global extinction: NOT PROVED.
- Genuine point: NONE FOUND.
- Frozen complete bound \(Q_0\le3000\): seven q1 MASTER hits, all source-integer empty with \(U_{lo}=1,U_{hi}=0\).
- New R36 source-first shell: 753,662 source-feasible relaxed architectures; 8,922,022 exact F11 configurations; 297 square discriminants; 12 integral F11 sphere roots; 0 post-basic legal hits. This shell forgets the native source selector and is therefore a source superset; it is bounded and has no global inference.

## Nonunit branch
- Synchronization theorem: NOT PROVED.
- Genuine negative cutoff-slack source-complete counterexample: NONE FOUND.
- R29 regression has raw source successor U=1 but \(Q_-=13>Q_+=2\) and \(Q_{master}=3\); it never enters the simultaneous locus.

## Global classification
```text
CORRECTED_SIMULTANEOUS_LOCUS_POINT_FOUND=NO
UNIT_BRANCH_GLOBAL_STATUS=OPEN__NO_GENUINE_POINT_FOUND
NONUNIT_BRANCH_GLOBAL_STATUS=OPEN__NO_GENUINE_POINT_FOUND
TERMINAL_RECTANGLE_REALIZED=NO
TERMINAL_COPRIME_PAIR_FOUND=NO
```
