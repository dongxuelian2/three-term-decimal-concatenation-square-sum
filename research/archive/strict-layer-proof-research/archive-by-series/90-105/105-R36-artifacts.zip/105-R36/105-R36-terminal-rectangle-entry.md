# 105-R36 — Terminal Rectangle Entry

For any future \(\mathfrak a\in\mathscr T\), define
\[
\mathcal Q=[Q_-,Q_*]\cap\mathbf Z_{>0},\qquad
\mathcal Q_F=\{q\in\mathcal Q:(q,F)=1\}.
\]
Then enumerate the completed source fibre \(\mathcal U_0\) exactly and test
\[
\exists (U,q)\in\mathcal U_0\times\mathcal Q_F:\ (q,U)=1.
\]
This is equivalent to the master-refined TP.

In R36 no genuine architecture reached \(\mathscr T\), so no actual rectangle existed to enumerate. Consequently no prime-cover certificate and no coprime pair certificate is claimed. In the corrected unit locus \(\mathscr T_1\), rectangle entry would be immediate because \(q=1\) itself is a coprime terminal pair.

```text
TERMINAL_RECTANGLE_ENTERED=NO
QF_NONEMPTY_GENUINE_ARCHITECTURE=NOT_TRIGGERED
MASTER_REFINED_TERMINAL_POSITIVE=NO
```
