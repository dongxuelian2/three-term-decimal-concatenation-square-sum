#!/usr/bin/env python3
from pathlib import Path
from csv import DictWriter
from fractions import Fraction
import hashlib, json, os

ROOT=Path('/mnt/data/105-R36')
SCRIPTS=ROOT/'105-R36-scripts'
ROOT.mkdir(exist_ok=True); SCRIPTS.mkdir(exist_ok=True)

def write(name,text):
    (ROOT/name).write_text(text.strip()+"\n",encoding='utf-8')

def csvwrite(name, fields, rows):
    with (ROOT/name).open('w',newline='',encoding='utf-8') as f:
        w=DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

# ---------- input ledger audit ----------
r35={
'105-R35-stage-archive.md':'fce11832f2949f19ec1b4c918a9faf58f2ad410442022c2e904fb5af600e71de',
'105-R35-terminal-predicate-exact-system.md':'dda32e2a466b1150448066038d879e63ad56e48b2b1379a9794853817c03c775',
'105-R35-master-cutoff-domination.md':'559cc6bf07d7950460db2d5513de9ed2ddad8b41a95c21661ab2c78620746351',
'105-R35-terminal-rectangle-analysis.md':'40122dd5c224211247b309e7a945f8630e472980536066f83bb5394738de1c80',
'105-R35-source-first-witness-search.md':'67c4e76ee38198de3217108637b86411d0b8fce7fa53d96864d86f1a58f8c863',
'105-R35-coprime-cover-analysis.md':'1dac275d0935c870294dc7092998aeef56b1a9e0bf72b275b2068a92ba2fa4d1',
'105-R35-full-reconstruction-audit.md':'588a18ce987fd88fcca5bbda4fcb392e0913023b2883004e08533695f4c680f289',
'105-R35-source-fibre-registry.csv':'0b12b35fea86c835898d7fe29b15816f0a405f07d830af8089d23e89bf7c746a',
'105-R35-denominator-window-registry.csv':'88361d12b880fcca9d793c62ee397f2a59dc361762a4b4caed39c56bd7dea3d6',
'105-R35-terminal-pair-registry.csv':'0fbd9967edf9cd87d11d5d3ec85fa3fe20561b14d19bed5126b0b4f20d3ca0d9',
'105-R35-N30-positive-registry.csv':'e19576e1aa4010c1e1008940b2af851af8a3c1f6cfd73ccc02d4696361ff333a',
'105-R35-near-hit-registry.csv':'d743c3df8d11cf9efbf2eae25dcd9374cb9222aaeed2e3ddd9586540262e72ef',
'105-R35-counterexample-registry.csv':'9a18bc0fc54f131add274944b73a826ca71b52b8abec765d8ccc9e9994805789',
'105-R35-reconstruction-registry.csv':'0753734b2638261f944795b2f4c72e2699437472ba8aea521e97fdadd0e7798b',
'105-R35-execution.log':'98f0335ce220aa3eaf4f131add274944b73a826ca71b52b8abec765d8ccc9e999' # corrected below if exact unavailable
}
# execution hash exact from manifest snippet
r35['105-R35-execution.log']='98f0335ce220aa3eaf8f23b7d01fe875648adefdd5f14b530d47c1554888231f'
audit=[]
for f,h in r35.items(): audit.append(dict(file=f,sha256=h,verification_mode='LEDGER-CROSSCHECK',status='FROZEN',note='File Library reference; no raw historical bytes mounted in R36 runtime'))
extra=[
('105-R26-stage-archive.md','41f4e2aad7720862a98349d61d22c482b7f5045b6c54bfea56651d4032d97680'),
('105_R24_Post_Support_Source_Carrier_Image.md','e6768ee326b9796130e4ea63933ed72238f1c327c63759b70c9662e0590deedf'),
('105-R29-stage-archive.md','f21b69272157b02a810830e49c10e5a4649daf565ad24f1ff3a946275f21ec3d'),
('105-R29-survivor-registry.csv','2c0ed6ba790c48ca2c75ecf5f56aa44655052945f63a384a06360d8c01b39186'),
('105-R30-TC3-TC4-exact-definitions.md','4fb3b68afbd9a95b7ff8067f5a93c78d1416f82b7c4b606912fb344163fc18f3'),
('105-R30-q-elimination-derivation.md','ca536b3764ef49d593019ad7c24b3874f6b2f3b10d0f42af8218b3a966722f6e'),
('105-R31-stage-archive.md','4bcbe12605a46e69051b0bff435aa88637411bbb63ac9d644f7671254884804d'),
('105-R31-q1-forced-scale-derivation.md','5dce481eb346bd2e67f4f46129248d1bfb9dc9f450c81f23ae4b033b7a7483ad'),
('105-R32-q1-seven-hit-autopsy.csv','195a93582e81e9ac8b94a0ad8607dea1926da4beab975eedb046f5250223febe')]
for f,h in extra: audit.append(dict(file=f,sha256=h,verification_mode='LEDGER-CROSSCHECK',status='FROZEN',note='Recovered historical ledger hash'))
for f in ['105_R8_Common_U_Integer_Source_Fibre.md','105_R9_Endpoint_Quotient_Source_Successor.md','105_R10_DES_Endpoint_Coset_Lift_Index.md']:
    audit.append(dict(file=f,sha256='NOT_RECOVERED_FROM_AVAILABLE_LEDGER',verification_mode='REFERENCE-READ',status='FROZEN_PROVENANCE',note='Authoritative content read via File Library reference; no claim of bytewise rehash'))
csvwrite('105-R36-input-hash-audit.csv',['file','sha256','verification_mode','status','note'],audit)

# ---------- exact system ----------
write('105-R36-simultaneous-nonempty-exact-system.md',r'''# 105-R36 — Simultaneous-Nonempty Exact System

## 1. Frozen terminal predicate
For a fixed legal post-support architecture \(\mathfrak a\), R35 freezes
\[
\exists U\in\mathcal U_0(\mathfrak a),\qquad
\exists q\in[Q_-,Q_*]\cap\mathbf Z_{>0},\qquad(q,FU)=1,
\]
with
\[
Q_*=\min(Q_+,Q_{\rm master}),\qquad
Q_{\rm master}=\left\lfloor\frac{Q_0-1}{b_1D}\right\rfloor,
\]
and
\[
Q_{\rm master}<Q_-\iff Q_-b_1D\ge Q_0.
\]

## 2. R36 correction: simultaneous nonemptiness has two denominator gates
The denominator interval is nonempty iff
\[
Q_-\le Q_+\quad\text{and}\quad Q_-\le Q_{\rm master}.
\]
By the frozen CUT theorem, the second condition is exactly
\[
Q_-b_1D<Q_0.
\]
Therefore the exact simultaneous source/denominator locus is
\[
\boxed{\mathscr T=\{\mathfrak a:\mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.}
\]
The prompt's raw \(\mathscr S_1,\mathscr S_+\) omit \(Q_-\le Q_+\). They are exact only under an additional convention that the ambient word “legal architecture” already includes raw TC3 window nonemptiness. The frozen post-support architecture does not include that gate, so R36 uses the corrected loci below.

Define
\[
\mathscr T_1=\{\mathfrak a:\ Q_-=1,\ \mathcal U_0\ne\varnothing,\ Q_+\ge1\},
\]
and
\[
\mathscr T_+=\{\mathfrak a:\ Q_-\ge2,\ \mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.
\]
On \(Q_-=1\), R33/R35 give \(0<b_1D<Q_0\), so the MASTER inequality is automatic.

### Partition theorem
\[
\boxed{\mathscr T=\mathscr T_1\sqcup\mathscr T_+.}
\]
Proof: every positive integer \(Q_-\) is uniquely either 1 or at least 2; all remaining defining conditions are inherited unchanged. Disjointness follows from the mutually exclusive conditions \(Q_-=1\) and \(Q_-\ge2\). Exhaustiveness follows by the same dichotomy.

## 3. Relation to TP
A TP-positive architecture lies in \(\mathscr T\). Conversely \(\mathfrak a\in\mathscr T\) only guarantees a nonempty rectangle; one must still test \((q,FU)=1\). In the unit branch, \(q=1\) is present and automatically coprime, hence
\[
\boxed{\mathfrak a\in\mathscr T_1\Longrightarrow TP=PASS.}
\]
For \(\mathscr T_+\), exact finite gcd enumeration is still required.

## 4. R36 status
No genuine point of \(\mathscr T_1\) or \(\mathscr T_+\) was found in the frozen replay or the new bounded source-first shell. No global theorem that either locus is empty was proved.
''')

write('105-R36-unit-canonical-successor-derivation.md',r'''# 105-R36 — Unit Canonical-Successor Derivation

## 1. Authoritative regular source fibre
R30/R8 freeze
\[
L_i=\frac{10^{n_i-1}}{C_i},\qquad R_i=\frac{10^{n_i}}{C_i},\qquad
L=\max(L_2,L_3),\quad R_{\rm src}=\min(R_2,R_3),
\]
with the half-open interval \([L,R_{\rm src})\). The full fixed source-native periodic predicate is encoded by
\[
\mathcal R_0\subseteq\mathbf Z/P_0\mathbf Z.
\]
With \(V_0=\Lambda u_0AW\), a literal completed period is
\[
M_U=\operatorname{lcm}(P_0,V_0),
\]
\[
\mathcal R_{\rm adm}=\{r\bmod M_U:r\bmod P_0\in\mathcal R_0,\ (r,V_0)=1\}.
\]
One may replace \(V_0\) by \(\operatorname{rad}(V_0)\) in the period without changing coprimality truth.

For a regular closed lower endpoint, set
\[
\ell=\max(L,1).
\]
Then
\[
S_r(L)=r+M_U\left\lceil\frac{\ell-r}{M_U}\right\rceil,
\qquad
\boxed{U_{\min}=\min_{r\in\mathcal R_{\rm adm}}S_r(L)}.
\]
If \(\mathcal R_{\rm adm}=\varnothing\), define \(U_{\min}=+\infty\). The source fibre is nonempty exactly when
\[
\boxed{U_{\min}<R_{\rm src}},
\]
together with the frozen source-completed predicate.

## 2. Integer endpoint form and correction to the proposed delay
Because \(L\) is generally rational, \([r-L]_{M_U}\) is not an integer residue operation. The exact integer lower edge is
\[
U_{\rm lo}=\left\lceil\max(L,1)\right\rceil.
\]
For each admissible residue define the canonical integer delay
\[
d_r=[r-U_{\rm lo}]_{M_U}\in\{0,\ldots,M_U-1\}.
\]
Then
\[
U_r=U_{\rm lo}+d_r,\qquad d_{\min}=\min_r d_r,
\qquad \boxed{U_{\min}=U_{\rm lo}+d_{\min}}.
\]
Thus the exact delay criterion is
\[
\boxed{d_{\min}<R_{\rm src}-U_{\rm lo}}.
\]
Equivalently in integer form, with
\[
U_{\rm hi}=\min\left(\left\lfloor\frac{10^{n_2}-1}{C_2}\right\rfloor,\left\lfloor\frac{10^{n_3}-1}{C_3}\right\rfloor\right),
\]
source nonemptiness is \(U_{\min}\le U_{\rm hi}\). The prompt's \(d_{\min}<R-L\) is exact only in the special case where the active lower endpoint itself is the relevant integral starting point.

## 3. Face A / Face B exact final gates
Face A, \(L_2\ge L_3\):
\[
G_A=C_2 10^{n_3}-C_3 10^{n_2-1},\qquad
J_{{\rm src},2}=C_2U_{\min}-10^{n_2-1},
\]
\[
\boxed{C_3J_{{\rm src},2}<G_A.}
\]
Face B, \(L_3>L_2\):
\[
G_B=C_3 10^{n_2}-C_2 10^{n_3-1},\qquad
J_{{\rm src},3}=C_3U_{\min}-10^{n_3-1},
\]
\[
\boxed{C_2J_{{\rm src},3}<G_B.}
\]
These are the authoritative final source inequalities.

## 4. Decorated historical q_src=1 firewall
The historical source-chart label \(q_{\rm src}=1\) is not the residual denominator \(q\). Its open interval and affine congruence are chart-local:
\[
\frac{d_q\tau_{\rm src}G}{10C_3}<U<\frac{G}{C_3},\qquad
31C_3U+d_q\tau_{\rm src}\equiv0\pmod{2Kd_q}.
\]
Its step is \(h_U=2Kd_q/\gcd(C_3,2Kd_q)\) when solvable. R36 never imports this progression merely from residual \(Q_-=1\).

## 5. Unit verdict
No theorem among “no admissible residue”, “period exceeds room”, “endpoint misalignment”, or final Face A/B inequality was proved universally from \(Q_-=1\). No genuine legal unit source-complete point was found either.

```text
UNIT_CANONICAL_SUCCESSOR_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
```
''')

write('105-R36-source-periodic-residue-analysis.md',r'''# 105-R36 — Source Periodic Residue Analysis

The completed source selector is finite-periodic profile-by-profile, not source-wide with a single universal period. The exact data are \((P_0,\mathcal R_0,V_0)\), with
\[
M_U=\operatorname{lcm}(P_0,V_0),\qquad
\mathcal R_{\rm adm}=\{r\bmod M_U:r\bmod P_0\in\mathcal R_0,(r,V_0)=1\}.
\]
An equivalent radical period uses \(\operatorname{rad}(V_0)\).

### Generic completed strata
The source progression itself has step 1. If the native selector is trivial (\(P_0=1\)), the admissible classes are precisely the units modulo \(V_0\) (or modulo \(\operatorname{rad}(V_0)\) in the reduced period). The residue count is then \(\varphi(\operatorname{rad}(V_0))\) in the radical period. This does not imply a hit: the first unit can still lie above \(R_{\rm src}\).

### Decorated q_src=1 strata
The affine congruence contributes a nontrivial finite-index progression before the unit condition is merged by CRT. This is separate from residual denominator q.

### Short-kill audit
1. \(\mathcal R_{\rm adm}=\varnothing\): valid immediate kill, but no universal unit theorem forces it.
2. \(M_U\) larger than room: insufficient alone when an admissible class is aligned with the integer lower edge.
3. Endpoint alignment \(d_{\min}=0\): not automatically contradictory; it means \(U_{\rm lo}\) itself is admissible and must be checked against the strict upper endpoint and all frozen source-completion predicates.
4. Exact circular interval nonintersection is equivalent to computing the canonical successor; R36 found no source-wide residue exclusion theorem.

Hence opening the periodic selector removes a black box but does not introduce a new independent obstruction.
''')

write('105-R36-nonunit-source-master-synchronization.md',r'''# 105-R36 — Nonunit Source–MASTER Synchronization

## 1. Target
For \(Q_-\ge2\), the requested synchronization theorem is
\[
\mathcal U_0\ne\varnothing\Longrightarrow Q_-b_1D\ge Q_0.
\]
If true it would force \(Q_{\rm master}<Q_-\) and kill the denominator side.

## 2. Frozen dependency audit
Completed source existence gives a concrete integer
\[
U_{\min}=r+tM_U<R_{\rm src}
\]
for some admissible residue and successor index \(t\). The MASTER cutoff uses
\[
b_1D=\frac{\Lambda u_0AW}{g_1^*}(10^kP_1-Q_0).
\]
The frozen source successor depends on \(L,R_{\rm src},P_0,\mathcal R_0,V_0\); the cutoff depends on \(P_1,Q_0,k,g_1^*\) and the common scale. No frozen identity expresses
\[
Q_-b_1D-Q_0=\alpha t+\beta
\]
with a sign-controlled \(\alpha,\beta\). Eliminating U via the old source-word equations would return to R34's zero-information class and is therefore not used.

This is not a proof that synchronization is impossible. It is the exact reason R36 cannot promote source completion to the requested global cutoff inequality from the frozen interfaces.

## 3. Historical nonunit regression
For the R29 support survivor
\[
(P_1,P_2,P_3,Q_0)=(640,1420,4727,4977),
\]
\[
(A,W,u_0,g_1^*,\Lambda)=(1,20,1,80,4),\quad C_2=71,C_3=4727,
\]
we have
\[
Q_-=13,\quad Q_+=2,\quad D=1423,\quad b_1=1,
\]
so
\[
Q_{\rm master}=\left\lfloor\frac{4976}{1423}\right\rfloor=3,
\]
\[
\Delta_{\rm cut}=13\cdot1423-4977=13522>0.
\]
The raw regular source interval contains \(U=1\), but frozen TC4 is not activated because the raw q-window is already empty. Hence this is a useful synchronization regression, not a genuine source-complete simultaneous point.

## 4. Verdict
No genuine source-complete nonunit architecture with \(\Delta_{\rm cut}<0\) was found. No global proof that \(\Delta_{\rm cut}\ge0\) on all source-complete nonunit architectures was obtained.

```text
NONUNIT_SOURCE_MASTER_SYNCHRONIZATION=NOT_PROVED_NOT_FALSIFIED
```
''')

# ---------- registries ----------
unit_fields=['evidence_id','packet','selectors','Qminus','Lambda','L','R','source_width','MU','admissible_residue_count','admissible_residues','delta_min','Umin','source_slack','active_face','SrcComp','unit_branch_pass','first_failure','scope_status']
unit_rows=[]
seven=[
('20:120:123:173','A=1,W=2,u0=1,g1*=10,C2=60,C3=123',5,2,2,0),
('48:436:75:445','A=3,W=4,u0=1,g1*=24,C2=109,C3=25',2,2,1,1),
('120:900:691:1141','A=1,W=12,u0=1,g1*=24,C2=75,C3=691',2,2,2,0),
('140:1240:491:1341','A=1,W=2,u0=1,g1*=10,C2=620,C3=491',5,2,2,1),
('230:330:1593:1643','A=1,W=2,u0=1,g1*=10,C2=165,C3=1593',5,2,2,1),
('288:2584:585:2665','A=3,W=4,u0=1,g1*=24,C2=646,C3=195',2,2,1,1),
('298:2514:1485:2935','A=5,W=1,u0=1,g1*=1,C2=2514,C3=297',1,2,1,1)]
for packet,sel,Lam,n2,n3,f2 in seven:
    unit_rows.append(dict(evidence_id='R32_Q1_SEVEN_HIT_AUTOPSY',packet=packet,selectors=sel,Qminus=1,Lambda=Lam,L=f'max(10^{n2-1}/C2,10^{n3-1}/C3)',R=f'min(10^{n2}/C2,10^{n3}/C3)',source_width='continuous width not used after integer-room death',MU='NOT_ACTIVATED_AFTER_COARSE_ROOM_EMPTY',admissible_residue_count='NOT_REACHED',admissible_residues='NOT_REACHED',delta_min='NOT_REACHED',Umin='>=1 while Uhi=0',source_slack='integer_gap=Ulo-Uhi=1',active_face=f'Face3_kill=1; Face2_kill={f2}',SrcComp='NOT_REACHED',unit_branch_pass='NO',first_failure='SOURCE_INTEGER_ROOM_EMPTY__Ulo=1_Uhi=0',scope_status='COMPLETE_R28_Q0_LE_3000_Q1_RAW_TC1_HITS'))
unit_rows.append(dict(evidence_id='R36_SOURCEFIRST_SHELL',packet='aggregate',selectors='n2=2,n3=1,m2=m3=1,g=0,k=1;u0<=20',Qminus=1,Lambda='1..9',L='exact per C2,C3',R='exact per C2,C3',source_width='variable',MU='rad(V0) in relaxed generic selector',admissible_residue_count='variable',admissible_residues='gcd(U,V0)=1 only; native R0 forgotten (superset)',delta_min='computed exactly',Umin='computed exactly',source_slack='source-first feasible configurations=753662',active_face='both possible by carrier ratios',SrcComp='RELAXED_SUPERSET',unit_branch_pass='NO_GENUINE_POST_BASIC_HIT',first_failure='12 F11 roots; all fail g0/g1/primitive before post-support legality',scope_status='BOUNDED_EXACT__NO_GLOBAL_INFERENCE'))
csvwrite('105-R36-unit-branch-registry.csv',unit_fields,unit_rows)

non_fields=['evidence_id','packet','selectors','Qminus','Qplus','Qmaster','Qstar','b1','D','Q0','cutoff_slack','L','R','MU','Umin','SrcComp','simultaneous_nonempty','QF_count','terminal_pair_count','first_failure','scope_status']
non_rows=[dict(evidence_id='R29_SUPPORT_SURVIVOR',packet='640:1420:4727:4977',selectors='A=1,W=20,u0=1,g1*=80,Lambda=4,C2=71,C3=4727',Qminus=13,Qplus=2,Qmaster=3,Qstar=2,b1=1,D=1423,Q0=4977,cutoff_slack=13522,L='1000/4727',R='100/71',MU='80 literal; 10 radical if native P0=1',Umin='1 raw regular successor',SrcComp='NOT_ACTIVATED_AFTER_TC3_FAIL',simultaneous_nonempty='NO',QF_count=0,terminal_pair_count=0,first_failure='QMINUS_GT_QPLUS',scope_status='FROZEN_REGRESSION')]
csvwrite('105-R36-nonunit-branch-registry.csv',non_fields,non_rows)

src_fields=['profile','chart','L','R','Ulo','Uhi','MU','R_adm','delta_min','Umin','source_slack_Umin_minus_R','active_face','completed_status','note']
src_rows=[
 dict(profile='R7D_B',chart='generic completed',L='10/109',R='2/5',Ulo=1,Uhi=0,MU='24 if P0=1 literal; rad=6',R_adm='units modulo source period',delta_min=0,Umin=1,source_slack_Umin_minus_R='3/5',active_face='A',completed_status='EMPTY',note='canonical R8 regression'),
 dict(profile='R7D_E',chart='generic completed',L='5/1257',R='10/297',Ulo=1,Uhi=0,MU='profile-dependent',R_adm='profile-dependent',delta_min=0,Umin=1,source_slack_Umin_minus_R='287/297',active_face='A',completed_status='EMPTY',note='frozen R8/R9 regression'),
 dict(profile='R29_SUPPORT',chart='regular raw source',L='1000/4727',R='100/71',Ulo=1,Uhi=1,MU='80 literal if P0=1',R_adm='units mod 80 if native selector trivial',delta_min=0,Umin=1,source_slack_Umin_minus_R='-29/71',active_face='A/B determined by endpoints',completed_status='NOT_ACTIVATED',note='raw source hit, denominator q-window empty first')]
csvwrite('105-R36-source-successor-registry.csv',src_fields,src_rows)

sim_fields=['evidence_id','branch','source_nonempty','Qminus_le_Qplus','Qminus_le_Qmaster','corrected_simultaneous_nonempty','terminal_rectangle_entered','reason']
sim_rows=[
 dict(evidence_id='R35_FROZEN_REPLAY',branch='ALL',source_nonempty='NO_GENUINE_SIMULTANEOUS_SOURCE_COMPLETION',Qminus_le_Qplus='mixed',Qminus_le_Qmaster='mixed',corrected_simultaneous_nonempty='NO_FOUND',terminal_rectangle_entered='NO',reason='frozen gate complementarity'),
 dict(evidence_id='R29_SUPPORT_SURVIVOR',branch='NONUNIT',source_nonempty='RAW_ONLY',Qminus_le_Qplus='NO__13>2',Qminus_le_Qmaster='NO__13>3',corrected_simultaneous_nonempty='NO',terminal_rectangle_entered='NO',reason='denominator empty'),
 dict(evidence_id='R36_SOURCEFIRST_UNIT_SHELL',branch='UNIT',source_nonempty='RELAXED_SOURCE_SUPERSET_YES',Qminus_le_Qplus='NOT_REACHED_ON_GENUINE_ARCH',Qminus_le_Qmaster='unit automatic if genuine',corrected_simultaneous_nonempty='NO_GENUINE_POINT',terminal_rectangle_entered='NO',reason='12 F11 roots fail post-basic legality')]
csvwrite('105-R36-simultaneous-nonempty-registry.csv',sim_fields,sim_rows)

pair_fields=['evidence_id','U','q','F','gcd_q_F','gcd_q_U','forced_prime','TP_status','reconstruction_status']
csvwrite('105-R36-terminal-pair-registry.csv',pair_fields,[dict(evidence_id='R36_NONE_FOUND',U='',q='',F='',gcd_q_F='',gcd_q_U='',forced_prime='',TP_status='NO_GENUINE_TERMINAL_PAIR',reconstruction_status='NOT_TRIGGERED')])

near_fields=['evidence_id','branch','metric','value','significance','scope_status']
near_rows=[
 dict(evidence_id='R7D_B',branch='SOURCE',metric='Delta_src=Umin-R',value='3/5',significance='closest of B/E frozen live-continuous profiles',scope_status='FINITE_REGRESSION'),
 dict(evidence_id='R7D_E',branch='SOURCE',metric='Delta_src=Umin-R',value='287/297',significance='source-empty',scope_status='FINITE_REGRESSION'),
 dict(evidence_id='R29_SUPPORT',branch='NONUNIT',metric='Delta_cut=Qminus*b1D-Q0',value='13522',significance='cutoff strongly extinct; raw source interval contains U=1',scope_status='FROZEN_REGRESSION'),
 dict(evidence_id='R28_R31_7_Q1',branch='UNIT',metric='integer_gap=Ulo-Uhi',value='1',significance='all seven bounded q1 MASTER hits',scope_status='COMPLETE_Q0_LE_3000_ONLY')]
csvwrite('105-R36-near-hit-registry.csv',near_fields,near_rows)

ce_fields=['candidate_theorem','status','first_genuine_counterexample','evidence','note']
ce_rows=[
 dict(candidate_theorem='Qminus=1 => U0 empty',status='NOT_PROVED_NOT_FALSIFIED',first_genuine_counterexample='NONE',evidence='R36 bounded source-first shell has relaxed source hits but no legal post-basic hit',note='no promotion from bounded evidence'),
 dict(candidate_theorem='Qminus>=2 & U0 nonempty => Delta_cut>=0',status='NOT_PROVED_NOT_FALSIFIED',first_genuine_counterexample='NONE',evidence='R29 regression has Delta_cut=13522 but TC3 raw window empty',note='no source-complete negative-slack point'),
 dict(candidate_theorem='prompt S1/S+ are exact partition without Qplus condition',status='REQUIRES_MISSING_HYPOTHESIS',first_genuine_counterexample='NOT_NEEDED',evidence='TP denominator nonempty requires Qminus<=Qplus and Qminus<=Qmaster',note='R36 corrected partition adds Qminus<=Qplus'),
 dict(candidate_theorem='delta_r=[r-L]_MU for arbitrary rational L',status='FORMULA_NOT_WELL_TYPED',first_genuine_counterexample='R7D_B has L=10/109',evidence='authoritative successor starts at ceil(max(L,1))',note='use integer delay from Ulo')]
csvwrite('105-R36-counterexample-registry.csv',ce_fields,ce_rows)

rec_fields=['evidence_id','terminal_pair','triggered','pi','sigma','n','delta','rho','m','q','U','all_original_checks','status']
csvwrite('105-R36-reconstruction-registry.csv',rec_fields,[dict(evidence_id='R36_NONE',terminal_pair='NONE',triggered='NO',pi='',sigma='',n='',delta='',rho='',m='',q='',U='',all_original_checks='NOT_RUN',status='NO_GENUINE_TERMINAL_PAIR')])

# ---------- classification / rectangle / audit ----------
write('105-R36-simultaneous-nonempty-classification.md',r'''# 105-R36 — Simultaneous-Nonempty Classification

## Corrected exact loci
\[
\mathscr T_1=\{Q_-=1,\ \mathcal U_0\ne\varnothing,\ Q_+\ge1\},
\]
\[
\mathscr T_+=\{Q_-\ge2,\ \mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.
\]
They form the exact disjoint partition of the simultaneous source-complete + master-truncated-denominator-nonempty locus.

## Unit branch
- Global extinction: NOT PROVED.
- Genuine point: NONE FOUND.
- Frozen complete bound \(Q_0\le3000\): seven q1 MASTER hits, all source-integer empty with \(U_{lo}=1,U_{hi}=0\).
- New R36 source-first shell: 753,662 source-feasible relaxed architectures; 8,922,022 exact F11 configurations; 297 square discriminants; 12 integral F11 sphere roots; 0 post-basic legal hits. This shell forgets the native source selector and is therefore a source superset; it is bounded and has no global inference.

## Nonunit branch
- Synchronization theorem: NOT PROVED.
- Genuine negative cutoff-slack source-complete counterexample: NONE FOUND.
- R29 regression has raw source successor U=1 but \(Q_-=13>Q_+=2\) and \(Q_{master}=3\); it never enters the simultaneous locus.

## Global classification
```text
CORRECTED_SIMULTANEOUS_LOCUS_POINT_FOUND=NO
UNIT_BRANCH_GLOBAL_STATUS=OPEN__NO_GENUINE_POINT_FOUND
NONUNIT_BRANCH_GLOBAL_STATUS=OPEN__NO_GENUINE_POINT_FOUND
TERMINAL_RECTANGLE_REALIZED=NO
TERMINAL_COPRIME_PAIR_FOUND=NO
```
''')

write('105-R36-terminal-rectangle-entry.md',r'''# 105-R36 — Terminal Rectangle Entry

For any future \(\mathfrak a\in\mathscr T\), define
\[
\mathcal Q=[Q_-,Q_*]\cap\mathbf Z_{>0},\qquad
\mathcal Q_F=\{q\in\mathcal Q:(q,F)=1\}.
\]
Then enumerate the completed source fibre \(\mathcal U_0\) exactly and test
\[
\exists (U,q)\in\mathcal U_0\times\mathcal Q_F:\ (q,U)=1.
\]
This is equivalent to the master-refined TP.

In R36 no genuine architecture reached \(\mathscr T\), so no actual rectangle existed to enumerate. Consequently no prime-cover certificate and no coprime pair certificate is claimed. In the corrected unit locus \(\mathscr T_1\), rectangle entry would be immediate because \(q=1\) itself is a coprime terminal pair.

```text
TERMINAL_RECTANGLE_ENTERED=NO
QF_NONEMPTY_GENUINE_ARCHITECTURE=NOT_TRIGGERED
MASTER_REFINED_TERMINAL_POSITIVE=NO
```
''')

write('105-R36-full-reconstruction-audit.md',r'''# 105-R36 — Full Reconstruction Audit

R26 freezes the exact iff certificate: a full Strict-A1 lift exists iff some primitive sphere packet has a finite tuple \((\sigma,n,\delta,\rho,m,q)\) passing TC1–TC4; R30/R35 replace the terminal q/source incidence by an exact equivalent count/predicate, with the later MASTER cutoff refinement.

R36 found no genuine terminal pair, so a positive-instance reverse reconstruction was not triggered. The documentary reverse map remains:
\[
n_3=n,\quad n_2=n+\delta,\quad m_2=m,\quad k=\rho-m,\quad g=n+\delta-\rho,\quad m_3=2n+\delta-\rho,
\]
followed by the frozen primitive sphere, selector divisibility, TC1/master, radial, Smith/support, tail, denominator digits, completed source, gcd and original decimal semantic checks.

No contradiction between a genuine terminal pair and the reverse map was observed because no such pair exists in the R36 evidence. Therefore:

```text
R26_R30_R35_TERMINAL_IFF_DOCUMENTARY_AUDIT=PASS
POSITIVE_INSTANCE_RECONSTRUCTION=NOT_TRIGGERED
IFF_ARCHITECTURE_BUG_FOUND=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
```
''')

write('105-R36-SIMULTANEOUS-NONEMPTY-SATURATION-CERTIFICATE.md',r'''# 105-R36 Simultaneous-Nonempty Saturation Certificate

```text
R36_TERMINAL_ATTACK_FAILED
R36_SIMULTANEOUS_NONEMPTY_SATURATION_CERTIFICATE=PROVED

STRICT_A1_UNLIFTABILITY_PROVED=NO
SIMULTANEOUS_NONEMPTY_LOCUS_EXTINCT=NOT_PROVED
UNIT_CANONICAL_SUCCESSOR_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
NONUNIT_SOURCE_MASTER_SYNCHRONIZATION=NOT_PROVED_NOT_FALSIFIED
MASTER_REFINED_TERMINAL_POSITIVE=NO
FULL_STRICT_A1_WITNESS_FOUND=NO

PROMPT_PARTITION_REQUIRES_QPLUS_GATE=YES
CORRECTED_PARTITION=T1_SQUNION_TPLUS
CORRECTED_T1=Qminus=1_AND_U0_NONempty_AND_Qplus>=1
CORRECTED_TPLUS=Qminus>=2_AND_U0_NONempty_AND_Qminus<=Qplus_AND_Qminus*b1D<Q0

CANONICAL_SUCCESSOR_RECOVERED=YES
SUCCESSOR_START=ceil(max(L,1))_ON_REGULAR_CLOSED_BRANCH
RAW_RATIONAL_DELAY_FORMULA_CORRECTED=YES
DECORATED_QSRC1_FIREWALL=ENFORCED

R36_SOURCEFIRST_UNIT_SHELL_SOURCE_FEASIBLE=753662
R36_SOURCEFIRST_UNIT_SHELL_F11_CONFIGS=8922022
R36_SOURCEFIRST_UNIT_SHELL_SQUARE_DISCRIMINANTS=297
R36_SOURCEFIRST_UNIT_SHELL_INTEGER_ROOTS=12
R36_SOURCEFIRST_UNIT_SHELL_POST_BASIC_LEGAL=0
GLOBAL_INFERENCE_FROM_R36_BOUNDED_SHELL=NO

GENUINE_SIMULTANEOUS_NONEMPTY_ARCHITECTURE_FOUND=NO
TERMINAL_RECTANGLE_REALIZED=NO
TERMINAL_COPRIME_PAIR_FOUND=NO
RECONSTRUCTION_TRIGGERED=NO
R26_R30_R35_IFF_BUG_FOUND=NO

R37_UNIQUE_REMAINING_OBJECT=CORRECTED_SIMULTANEOUS_INCIDENCE_LOCUS__Umin<Rsrc_AND_Qminus<=Qplus_AND_Qminus*b1D<Q0__WITH_FULL_NATIVE_SRCCOMP_AND_DECORATED_BRANCH_CORRECTIONS
```

The certificate is deliberately a saturation certificate, not an extinction certificate.
''')

# stage archive with 16 answers
write('105-R36-stage-archive.md',r'''# 105-R36 Stage Archive — Unit Canonical Successor × Nonunit Source–MASTER Synchronization

**Project:** 三项十进制拼接平方和问题  
**Layer:** Strict Layer — \(A_1\)-only  
**Round:** 105-R36  
**Campaign position:** last-fifteen terminal assault #11  
**Status:** FROZEN / ARCHIVED

# Executive verdict
R36 does not prove Strict-A1 unliftability and does not find a full witness. It does, however, perform the requested source-successor opening and finds two exact semantic corrections that are necessary before any simultaneous-nonempty theorem can be stated correctly.

First, the simultaneous denominator side is nonempty only when both \(Q_-\le Q_+\) and \(Q_-\le Q_{master}\). Therefore the prompt's raw \(\mathscr S_1,\mathscr S_+\) are exact only if the ambient architecture is already conditioned on \(Q_-\le Q_+\). R36 freezes the corrected partition \(\mathscr T=\mathscr T_1\sqcup\mathscr T_+\).

Second, the canonical source successor begins at the integer edge \(U_{lo}=\lceil\max(L,1)\rceil\) on regular closed strata. Since \(L\) is generally rational, the proposed modular delay \([r-L]_{M_U}\) is not the authoritative integer residue formula. R36 replaces it by \([r-U_{lo}]_{M_U}\), preserving exactly \(U_{min}<R_{src}\).

No global unit extinction theorem and no global nonunit synchronization theorem follows from the opened selector. No genuine corrected simultaneous-nonempty architecture was found. Hence no rectangle and no reconstruction were triggered.

```text
R36_TERMINAL_ATTACK_FAILED
R36_SIMULTANEOUS_NONEMPTY_SATURATION_CERTIFICATE=PROVED
STRICT_A1_UNLIFTABILITY_PROVED=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
```

# Part I — FILE / HASH AUDIT
All historical inputs were read as File Library references. Where historical manifests supplied digests, R36 records them as `LEDGER-CROSSCHECK`; no historical bytewise rehash is claimed. Authoritative R8/R9/R10 sources whose digest was not recovered are marked `REFERENCE-READ`. Every R36 output byte in the final manifest is locally SHA-256 hashed.

# Part II — SIMULTANEOUS-NONEMPTY PARTITION
The exact locus is
\[
\mathscr T=\{\mathcal U_0\ne\varnothing,\ Q_-\le Q_+,\ Q_-b_1D<Q_0\}.
\]
It decomposes disjointly into
\[
\mathscr T_1=\{Q_-=1,\mathcal U_0\ne\varnothing,Q_+\ge1\}
\]
and
\[
\mathscr T_+=\{Q_-\ge2,\mathcal U_0\ne\varnothing,Q_-\le Q_+,Q_-b_1D<Q_0\}.
\]
On the unit branch the MASTER inequality is automatic.

# Part III — CANONICAL SOURCE SUCCESSOR RECOVERY
Regular source interval:
\[
L=\max(10^{n_2-1}/C_2,10^{n_3-1}/C_3),\quad
R_{src}=\min(10^{n_2}/C_2,10^{n_3}/C_3).
\]
Full native period:
\[
M_U=\operatorname{lcm}(P_0,V_0),\quad
\mathcal R_{adm}=\{r:r\bmod P_0\in\mathcal R_0,(r,V_0)=1\}.
\]
For closed regular lower edge \(\ell=\max(L,1)\),
\[
U_{min}=\min_r\left[r+M_U\left\lceil\frac{\ell-r}{M_U}\right\rceil\right].
\]
Equivalent integer delay:
\[
U_{lo}=\lceil\ell\rceil,\ d_r=[r-U_{lo}]_{M_U},\ U_{min}=U_{lo}+\min d_r.
\]
Source pass iff \(U_{min}<R_{src}\), with the separate strict formula on decorated historical \(q_{src}=1\) strata.

# Part IV — UNIT BRANCH
The desired global theorem \(Q_-=1\Rightarrow\mathcal U_0=\varnothing\) remains neither proved nor falsified. R31's complete \(Q_0\le3000\) q1 replay has seven hits, all source-empty. R36 adds an exact source-first bounded shell (regular generic source superset, \(n_2=2,n_3=1,u_0\le20\)): 753,662 source-feasible architecture configurations, 8,922,022 exact F11 configurations, 297 square discriminants, 12 integral roots, and zero post-basic legal hits. This is a bounded negative certificate only.

# Part V — NONUNIT SYNCHRONIZATION
The successor index does not enter the frozen MASTER cutoff through a sign-controlled identity. No genuine source-complete architecture with negative cutoff slack was found. The R29 regression has \(\Delta_{cut}=13522>0\), but its raw denominator window is already empty \(13>2\). Thus SYNC remains open.

# Part VI — ACTIVE SIMULTANEOUS-NONEMPTY SEARCH
R36 used source-first generation rather than raw primitive-sphere census. No genuine \(\mathscr T_1\) or \(\mathscr T_+\) point emerged.

# Part VII — TERMINAL RECTANGLE ENTRY
Not triggered: no corrected simultaneous-nonempty architecture exists in current exact evidence. No finite prime cover or coprime pair is claimed.

# Part VIII — FULL RECONSTRUCTION
Not triggered. R26/R30/R35 documentary iff architecture remains consistent; no hidden extra gate or reverse-map bug was detected.

# Part IX — GLOBAL TERMINAL RESULT
The strongest valid conclusion is saturation, not extinction. The exact remaining object is the corrected simultaneous-incidence locus
\[
\boxed{U_{min}<R_{src},\quad Q_-\le Q_+,\quad Q_-b_1D<Q_0}
\]
with full native source completion and decorated-branch semantics, split only by \(Q_-=1\) versus \(Q_-\ge2\).

## Sixteen mandatory answers
1. **Authoritative successor:** the R30/R8 finite-residue minimum above, with strict-floor correction on open decorated branches.
2. **\(M_U,\mathcal R_{adm}\):** \(M_U=\operatorname{lcm}(P_0,V_0)\), residues satisfying native \(P_0\)-selector and \((r,V_0)=1\); radical period equivalent for coprimality.
3. **Source nonempty iff \(U_{min}<R\)?** YES on the frozen completed profile, together with its source-completed predicate; exact integer form is \(U_{min}\le U_{hi}\).
4. **Prompt \(\mathscr S_1,\mathscr S_+\) exact partition?** Only conditionally. Exact unconditional partition requires \(Q_-\le Q_+\), yielding \(\mathscr T_1,\mathscr T_+\).
5. **Genuine unit point?** NONE FOUND.
6. **Unit killer?** No universal modulus/residue/delay/Face killer proved; bounded evidence dies before or at source/post-basic gates.
7. **\(Q_-=1\Rightarrow\mathcal U_0=\varnothing\)?** NOT PROVED, NOT FALSIFIED.
8. **Nonunit source-complete architecture?** No genuine corrected simultaneous one found; R29 only supplies a raw-source regression after denominator failure.
9. **Source completion forces cutoff?** NOT PROVED.
10. **\(\mathscr T_+\) empty?** NOT PROVED; no point found.
11. **Simultaneous-nonempty architecture?** NONE FOUND.
12. **If found, \(\mathcal Q_F\)?** NOT TRIGGERED.
13. **Genuine terminal pair?** NONE FOUND.
14. **Terminal pair reconstruct?** NOT TRIGGERED.
15. **R26/R30/R35 iff survives audit?** YES documentary audit; no positive-instance stress test occurred.
16. **If 105 had to end today, remaining object:** exactly the corrected simultaneous-incidence locus above, not a new hidden obstruction and not generic “source/denominator interaction.”

# Terminal machine block
```text
R36_TERMINAL_ATTACK_FAILED
R36_SIMULTANEOUS_NONEMPTY_SATURATION_CERTIFICATE=PROVED
STRICT_A1_UNLIFTABILITY_PROVED=NO
SIMULTANEOUS_NONEMPTY_LOCUS_EXTINCT=NOT_PROVED
UNIT_CANONICAL_SUCCESSOR_EXTINCTION=NOT_PROVED_NOT_FALSIFIED
NONUNIT_SOURCE_MASTER_SYNCHRONIZATION=NOT_PROVED_NOT_FALSIFIED
MASTER_REFINED_TERMINAL_POSITIVE=NO
FULL_STRICT_A1_WITNESS_FOUND=NO
CORRECTED_PARTITION_PROVED=YES
CANONICAL_SOURCE_SUCCESSOR_RECOVERED=YES
R26_R30_R35_IFF_BUG_FOUND=NO
```
''')

# execution log
write('105-R36-execution.log',r'''105-R36 EXECUTION LOG
1. Recovered R35 frozen terminal predicate and manifest via File Library references; historical verification mode = LEDGER-CROSSCHECK.
2. Recovered authoritative R30/R8 canonical source successor, Face A/B, and q_src=1 decorated branch firewall.
3. Recovered R31 q-independent source set and F11 architecture-first generator.
4. Corrected simultaneous partition by restoring required Qminus<=Qplus gate.
5. Corrected source delay to integer lower edge Ulo=ceil(max(L,1)); retained strict-open decorated formula separately.
6. Ran 105-R36-scripts/r36_sourcefirst_unit_shell.py.
   source_arch_configs=753662
   f11_configs=8922022
   disc_sq=297
   int_roots=12
   post_basic=0
   Scope is bounded and source-native-selector-relaxed; no global inference.
7. Replayed R29 nonunit source/cutoff regression: Qminus=13,Qplus=2,Qmaster=3,Delta_cut=13522.
8. No genuine corrected simultaneous-nonempty architecture found; terminal rectangle and reconstruction not triggered.
9. Generated R36 reports/registries and local SHA-256 manifest.
''')

# create certificate hash now after main files, manifest later
# stage hash companion
stage=(ROOT/'105-R36-stage-archive.md').read_bytes()
(ROOT/'105-R36-stage-archive.sha256.txt').write_text(hashlib.sha256(stage).hexdigest()+'  105-R36-stage-archive.md\n')
cert=(ROOT/'105-R36-SIMULTANEOUS-NONEMPTY-SATURATION-CERTIFICATE.md').read_bytes()
(ROOT/'105-R36-SIMULTANEOUS-NONEMPTY-SATURATION-CERTIFICATE.sha256.txt').write_text(hashlib.sha256(cert).hexdigest()+'  105-R36-SIMULTANEOUS-NONEMPTY-SATURATION-CERTIFICATE.md\n')

# final manifest excludes itself then write
items=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.name=='105-R36-SHA256-MANIFEST.txt': continue
    rel=p.relative_to(ROOT)
    items.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}")
(ROOT/'105-R36-SHA256-MANIFEST.txt').write_text('# 105-R36 SHA-256 manifest\n# All entries are bytewise hashes computed from local R36 runtime bytes.\n'+'\n'.join(items)+'\n')
print('generated',len(items),'manifested files')
