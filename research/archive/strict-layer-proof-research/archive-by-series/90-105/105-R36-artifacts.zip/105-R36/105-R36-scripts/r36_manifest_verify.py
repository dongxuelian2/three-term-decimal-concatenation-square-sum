#!/usr/bin/env python3
from pathlib import Path
import hashlib,sys
root=Path('/mnt/data/105-R36')
manifest=root/'105-R36-SHA256-MANIFEST.txt'
ok=True;n=0
for line in manifest.read_text().splitlines():
    if not line or line.startswith('#'): continue
    h,rel=line.split('  ',1); p=root/rel; n+=1
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
    if got!=h:
        ok=False; print('FAIL',rel,h,got)
print('VERIFIED',n,'FILES' if ok else 'FILES_WITH_FAILURES')
sys.exit(0 if ok else 1)
