#!/usr/bin/env python3
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1<<20),b""): h.update(chunk)
    return h.hexdigest()
out=[]
for p in sorted(ROOT.rglob("*")):
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix()
    if rel in ("105-R32-SHA256-MANIFEST.txt","105-R32-SHA256-MANIFEST.sha256.txt"): continue
    out.append(f"{sha(p)}  {rel}")
(ROOT/"105-R32-SHA256-MANIFEST.txt").write_text("\n".join(out)+"\n",encoding="utf-8")
mh=sha(ROOT/"105-R32-SHA256-MANIFEST.txt")
(ROOT/"105-R32-SHA256-MANIFEST.sha256.txt").write_text(f"{mh}  105-R32-SHA256-MANIFEST.txt\n",encoding="utf-8")
print("R32 manifest: PASS", len(out), "files")
