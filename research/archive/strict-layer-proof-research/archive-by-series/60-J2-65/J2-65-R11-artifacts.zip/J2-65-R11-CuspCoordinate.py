#!/usr/bin/env python3
import sympy as sp
xi,n=sp.symbols('xi n')
# Reduction step matrix Q=T_n W=[[-n,1],[1,0]]
Q=sp.Matrix([[-n,1],[1,0]])
assert Q.det()==-1
Qinv=Q.inv()
X,Y=sp.symbols('X Y')
v=sp.Matrix([X,Y])
vp=sp.simplify(Qinv*v)
print("Q_INV=",Qinv.tolist())
print("ISOTROPIC_COORDINATE_UPDATE: xi=X/Y -> xi'=Y/(X+nY)=1/(xi+n)")
print("CUSP_COORDINATE=(1+i-z)/a before primitive scaling")
print("STANDARD_NEAREST_GAUSSIAN_CF_MATCH=PARTIAL")
print("REASON=digit n is nearest to z/a=(1+i)/a-xi, not to xi alone")
print("CORRECT_OBJECT=determinant-2 Hermitian continued-fraction word with exact Mobius update")
