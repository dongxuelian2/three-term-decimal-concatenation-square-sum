#!/usr/bin/env python3
import sympy as sp
a,c,x,y,nr,ni=sp.symbols('a c x y nr ni', real=True)
I=sp.I
z=x+I*y
n=nr+I*ni
H=sp.Matrix([[a,z],[sp.conjugate(z),c]])
T=sp.Matrix([[1,-n],[0,1]])
Hp=sp.simplify(sp.conjugate(T.T)*H*T)
r=sp.expand(z-a*n)
cp=sp.expand(c-2*sp.re(sp.conjugate(n)*z)+a*(nr**2+ni**2))
assert sp.simplify(Hp[0,1]-r)==0
assert sp.simplify(Hp[1,1]-cp)==0
print("SHEAR_OFFDIAGONAL_FORMULA=PASS")
print("REDUCED_SECOND_DIAGONAL_FORMULA=PASS")
print("DETERMINANT_IDENTITY: if ac-|z|^2=-2 then c'=(|r|^2-2)/a")
print("CENTERED_SQUARE: |r|^2<=a^2/2")
print("FOR_a>2: c' > -1 and c' integer => c'>=0")
print("FOR_a>2: c'<=a/2-2/a<a/2")
print("REDUCED_SECOND_DIAGONAL_NONNEGATIVE=PASS")
print("REDUCED_SECOND_DIAGONAL_LT_HALF=PASS")
print("ONE_STEP_CUSP_ENTRANCE=PROVED")
print("TERMINAL_a=1: shear by n=z gives diag(1,-2)")
print("TERMINAL_a=2: centered |r|^2 in {0,2}; c' in {-1,0}")
print("REDUCTION_LENGTH_BOUND=nearest/swap stages <= ceil(log2(a)) including terminal stage")
print("GAUSSIAN_EUCLIDEAN_REDUCTION=PROVED_FOR_POSITIVE_PIVOT_SECTOR; ACTUAL_POWER_TEN_STATES_INCLUDED")
