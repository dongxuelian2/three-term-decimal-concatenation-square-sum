#!/usr/bin/env python3
import sympy as sp
I=sp.I
H0=sp.Matrix([[1,1],[1,-1]])
V=sp.Matrix([[I,-I],[1,1]])
HV=sp.simplify(sp.conjugate(V.T)*H0*V)
print("UNIVERSAL_BASIS_V=",V.tolist())
print("GRAM=",HV.tolist())
assert HV[0,0]==0 and HV[1,1]==0
assert sp.simplify(V.det()-2*I)==0
print("DET_V=2i")
print("For every odd u, 2i is a unit mod u.")
print("LEVEL_u_ISOTROPIC_BASIS_CONDITION=PROVED")
print("LEVEL_u_ISOTROPIC_BASIS_OBSTRUCTION=FALSE")
print("HECKE_INTERPRETATION=NOT_APPLICABLE")
