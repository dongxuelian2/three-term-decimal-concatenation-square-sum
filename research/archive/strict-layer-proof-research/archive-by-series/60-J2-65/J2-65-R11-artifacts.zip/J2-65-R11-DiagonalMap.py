#!/usr/bin/env python3
import sympy as sp
I=sp.I
p,q,r,s=sp.symbols('p q r s')
Hcan=sp.Matrix([[0,1+I],[1-I,1]])
X=sp.Matrix([[p,q],[r,s]])
HX=sp.simplify(sp.conjugate(X.T)*Hcan*X)
print("DIAGONAL_1=",sp.expand_complex(HX[0,0]))
print("DIAGONAL_2=",sp.expand_complex(HX[1,1]))
print("EXACT_FORMULA:")
print("Phi(x,y)=|y|^2+2 Re((1+i) conjugate(x) y)")
print("If X=(reduction_word * terminal_normalizer)^(-1),")
print("Dplus=Phi(X11,X21), Dminus=Phi(X12,X22).")
print("The entries of X are Gaussian continuants by the two-term recurrence.")
print("DIAGONAL_MAP_IN_CONTINUANT_COORDINATES=PROVED")
