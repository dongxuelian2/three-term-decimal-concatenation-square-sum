#!/usr/bin/env python3
import sympy as sp
from itertools import product
I=sp.I
D=sp.diag(1,-2)
Hcan=sp.Matrix([[0,1+I],[1-I,1]])
R=sp.Matrix([[1-I,1],[-I,0]])
C=sp.Matrix([[1+I,-1+I],[1,-I]])
J=sp.Matrix([[0,1],[-1,0]])

assert sp.simplify(sp.conjugate(R.T)*D*R-Hcan)==sp.zeros(2)
assert sp.simplify(sp.conjugate(C.T)*D*C-4*I*J)==sp.zeros(2)

# SU(D) <-> a level-4 subgroup of SL2(Z)
p,q,r,s=sp.symbols('p q r s', integer=True, real=True)
g=sp.Matrix([[p,q],[r,s]])
Phi=sp.simplify(C*g*C.inv())
print("PHI_GENERAL=",Phi)

# Reduction mod 4 subgroup.
def mul(A,B,m=4):
    return tuple(sum(A[2*i+k]*B[2*k+j] for k in range(2))%m
                 for i in range(2) for j in range(2))
SL4=[]
H8=[]
for a,b,c,d in product(range(4), repeat=4):
    if (a*d-b*c)%4==1:
        SL4.append((a,b,c,d))
        if ((a-d)%2==0 and (b-c)%2==0 and
            (a-d-(b+c))%4==0):
            H8.append((a,b,c,d))
assert len(SL4)==48 and len(H8)==8
print("SL2_ZMOD4_SIZE=48")
print("LEVEL4_IMAGE_SIZE=8")
print("INDEX_IN_SL2Z=6")

S=sp.Matrix([[0,-1],[1,0]])
T=sp.Matrix([[1,1],[0,1]])
E=sp.simplify(T**2*S*T**-2)
P=sp.simplify(T**4)
print("GAMMA_STAR_GENERATORS_S=",S.tolist())
print("GAMMA_STAR_GENERATORS_E=",E.tolist())
print("GAMMA_STAR_GENERATORS_P=",P.tolist())

# Full projective extension and exact Hcan generators.
K=sp.Matrix([[1,1],[-1,1]])
L=sp.Matrix([[1,-5],[1,-3]])
assert sp.simplify(K**2 + 2*S)==sp.zeros(2)
assert sp.simplify(L**2 + 2*E)==sp.zeros(2)
assert sp.simplify(K*L-2*T**-4)==sp.zeros(2)

Kc=sp.Matrix([[I,0],[-2*I,1]])
Lc=sp.Matrix([[1,-1+I],[2*I,-2-I]])
for A in (Kc,Lc):
    assert sp.simplify(sp.conjugate(A.T)*Hcan*A-Hcan)==sp.zeros(2)
    assert sp.simplify(A**4-sp.eye(2))==sp.zeros(2)
assert sp.simplify(Kc*Lc - I*sp.Matrix([[1,-1+I],[0,1]]))==sp.zeros(2)

print("FULL_AUT_HCAN_GENERATOR_K=",Kc.tolist())
print("FULL_AUT_HCAN_GENERATOR_L=",Lc.tolist())
print("CENTRAL_GENERATOR=iI")
print("PROJECTIVE_PRESENTATION=<K,L | K^4=L^4=1> = C4 * C4")
print("FULL_PRESENTATION=C4_central x (C4 * C4)")
print("NUMBER_OF_CUSPS=1")
print("CUSP_PARABOLIC=K*L=i*P_-1")
print("AUTOMORPHISM_PRESENTATION=PROVED")
