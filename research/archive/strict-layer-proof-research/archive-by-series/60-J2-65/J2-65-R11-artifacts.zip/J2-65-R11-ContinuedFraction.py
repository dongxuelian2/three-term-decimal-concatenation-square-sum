#!/usr/bin/env python3
import sympy as sp
n0,n1,n2=sp.symbols('n0 n1 n2')
def R(n): return sp.Matrix([[-n,1],[1,0]])
M=sp.simplify(R(n0)*R(n1)*R(n2))
print("R(n)=[[-n,1],[1,0]]")
print("PRODUCT_3=",M.tolist())
print("CONTINUANT_RECURRENCE:")
print("P_-1=0,P_0=1; R_-1=1,R_0=0")
print("P_{j+1}=-n_j P_j+P_{j-1}")
print("R_{j+1}=-n_j R_j+R_{j-1}")
print("M_j=[[P_j,P_{j-1}],[R_j,R_{j-1}]]")
print("GAUSSIAN_CF_MATCHES_REDUCTION=PROVED_AS_HERMITIAN_CF; STANDARD_NEAREST_CF=PARTIAL")
