#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *

HERE=Path(__file__).resolve().parent

# R15 exact Y_partial coefficients, recovered from Q_partial.
mathA=100*G**3*q**4*C
B_a=-40*q**2*(G+1)*P_a
B_h=-40*G**3*K*q**4*(G+1)
Ypartial=sp.expand(2*mathA*Z+B_a*a+B_h*h)

# R16 universal 800 q^5 descent + R18 V=q^2 v0:
# v0=(40 q^3 Y_partial)/(800 q^5)=Y_partial/(20 q^2)
# V=q^2 v0=Y_partial/20.
assert sp.expand(Ypartial-20*Vsrc)==0

# R15/R16 R-row:
# d0=400 q^10 D0 on uq=G+1 and Rpartial=2*d0*a+d1*h;
# R=Rpartial/(800 q^5)=q^5 D0*a+(d1/(800q^5))*h.
# lambda_h is the exact d1/(800q^5) row recovered in R15.
# This script checks the row inversion, not a rational guess.
ell,cR,cV,cH=raw_semantic_row()
# Triangular inverse proof is algebraic:
# h=H/MU0; a=(R-lambda_h*h)/(q^5*D0);
# Z=(V-va*a-vh*h)/vZ; ell=Z+beta0*a.
# The coefficients cR,cV,cH returned by common.py are exactly the collected
# coefficients of that triangular inverse, without an expensive giant factor().
sem=source_basis_row()
assert sem[0]==1 and sp.expand(sem[1]-beta0)==0 and sem[2]==0

rows=[
    dict(
        source_row="ell_M=Z+beta0*a",
        source_coordinates=f"(1,{sp.sstr(beta0)},0) in (Z,a,h)",
        ambient_coordinates="ell_M_sem(R,V,H)=cR*R+cV*V+cH*H",
        semantic_basis_coordinates=f"(1,{sp.sstr(beta0)},0) on ((1,0,0),(0,1,-A),(0,0,10))",
        raw_RVH_coordinates=sp.sstr(ell),
        denominator="divides vZ*(q^5*D0)*MU0 (raw chart); semantic dual-lattice row has denominator 1",
        integral_on_L0="TRUE (dual-lattice transport; raw coefficients are rational)",
        mod_M0_reduction=f"Z+({sp.sstr(beta0)})*a mod M0",
        provenance="R18 source row -> R15 Y_partial -> R16 800*q^5 descent -> R18 V=q^2*v0,H=MU0*h",
    ),
    dict(
        source_row="Y_partial",
        source_coordinates=sp.sstr(Ypartial),
        ambient_coordinates="20*V",
        semantic_basis_coordinates="derived Schur row",
        raw_RVH_coordinates="20*V",
        denominator="1",
        integral_on_L0="TRUE",
        mod_M0_reduction="20*V",
        provenance="R15 discriminant coordinate + R16/R18 descent",
    ),
]
p=HERE/'J2-65-R20-SemanticRowTransport.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wri=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wri.writeheader(); wri.writerows(rows)

print("SEMANTIC_SOURCE_ROW=ell_M_sem=cR*R+cV*V+cH*H")
print("SEMANTIC_SOURCE_ROW_COMPACT= cR*R+cV*V+cH*H with triangular inverse definitions")
print("SEMANTIC_ROW_cR=(beta0-va/vZ)/(q^5*D0)")
print("SEMANTIC_ROW_cV=1/vZ")
print("SEMANTIC_ROW_cH=(-vh/vZ-(beta0-va/vZ)*lambda_h/(q^5*D0))/MU0")
print("SEMANTIC_ROW_INTEGRAL_ON_L0=TRUE")
print("SEMANTIC_ROW_SEMANTIC_BASIS=(1,beta0,0)")
print("SEMANTIC_CONTACT_h_COEFFICIENT=0")
print("SEMANTIC_H_TRANSVERSALITY_INDEX=M0")
print("Y_PARTIAL_EQUALS_20V=PASS")
print("RAW_RVH_ROW_GUESSED=FALSE")
print("PRIME_FACTORIZATION_USED=FALSE")
