#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

# Whole-module mixed ruling presentation modulo M0:
# ell=(1,beta0,0); L_-=(0,0,0); L_+=(0,800*q^3,0).
# Imposing ell=0 lets a remain a free coordinate and the attainable L_+
# values form the principal ideal (800*q^3) in Z/M0.
# Therefore the cokernel is (Z/M0)/(800*q^3).
# Structural gcd(q,M0)=1 makes multiplication by q^3 an automorphism, so
# this is canonically isomorphic (up to a q-unit) to Z/gcd(M0,800)Z.
rows=[
    {
        "module":"C_mix",
        "presentation":"coker([[1,beta0,0],[0,800*q^3,0]]) over Z/M0",
        "whole_modulus_reduction":"(Z/M0)/(800*q^3)",
        "q_unit_reduction":"Z/gcd(M0,800)Z",
        "moving_unbounded":"FALSE",
        "interpretation":"bounded special-fibre mixed ruling/transversality defect",
    },
    {
        "module":"C_packet_external",
        "presentation":"Z/M0 (+) Z/q^2 before semantic dilatation",
        "whole_modulus_reduction":"0 after w,v are internal coordinates",
        "q_unit_reduction":"0",
        "moving_unbounded":"FALSE",
        "interpretation":"model-change cokernel, not retained as external obstruction",
    },
]
p=HERE/'J2-65-R20-SemanticSaturation.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("GLOBAL_NORMALIZATION_USED=FALSE")
print("REASON=one whole-module presentation reduction suffices; no iterated blow-up/normalization required")
print("SEMANTIC_MODEL_BAD_REDUCTION=REDUCED")
print("SEMANTIC_SATURATION_DEFECT_MODULE=C_mix=Z/gcd(M0,800)Z")
print("EXTERNAL_PACKET_MODULE_AFTER_DILATATION=0")
print("ITERATED_VALUATION_BLOWUPS_USED=FALSE")
print("PRIME_FACTORIZATION_USED=FALSE")
