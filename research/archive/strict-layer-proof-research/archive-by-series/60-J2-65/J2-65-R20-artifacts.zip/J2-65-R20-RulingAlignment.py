#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

# Check the ruling rows coefficientwise on uq=G+1.  This avoids any giant
# global factorization and proves exactly the same whole-G divisibility.
uq=(G+1)/q
rA_rel=sp.cancel((q**5*D0).subs(u,uq))
rH_rel=lambda_h
vZ_rel=vZ
va_rel=va
vh_rel=vh
lm_coeffs=[
    sp.cancel(-20*uq*vZ_rel),
    sp.cancel(rA_rel-20*uq*va_rel),
    sp.cancel(rH_rel-20*uq*vh_rel),
]
lp_coeffs=[
    sp.cancel(20*uq*vZ_rel),
    sp.cancel(rA_rel+20*uq*va_rel),
    sp.cancel(rH_rel+20*uq*vh_rel),
]
assert all(sp.simplify(c.subs(G,0))==0 for c in lm_coeffs)
assert sp.simplify(lp_coeffs[0].subs(G,0))==0
assert sp.simplify(lp_coeffs[1].subs(G,0)-800*q**3)==0
assert sp.simplify(lp_coeffs[2].subs(G,0))==0

# Semantic source row in canonical fixed-decimal/contact basis.
ell_basis=source_basis_row()
assert ell_basis[0]==1 and ell_basis[2]==0

# Since M0|G, restrictions modulo M0 are:
#   L_- = 0,
#   L_+ = 800*q^3*a,
# whereas ell=(1,beta0,0), so neither ruling row can be a unit multiple of ell.
# q is a unit modulo M0 (R18/R19 structural coprimality), hence the mixed
# transversality cokernel is q-unit equivalent to quotient by 800.
rows=[
    {
        "object":"ell_M_sem",
        "mod_M0_row":f"(1,{sp.sstr(beta0)},0)",
        "Z_coefficient":"1",
        "a_coefficient":sp.sstr(beta0),
        "contact_coefficient":"0",
        "verdict":"primitive source hyperplane",
    },
    {
        "object":"L_MINUS",
        "mod_M0_row":"(0,0,0)",
        "Z_coefficient":"0",
        "a_coefficient":"0",
        "contact_coefficient":"0",
        "verdict":"vanishes on fixed-contact semantic lattice mod M0",
    },
    {
        "object":"L_PLUS",
        "mod_M0_row":"(0,800*q^3,0)",
        "Z_coefficient":"0",
        "a_coefficient":"800*q^3",
        "contact_coefficient":"0",
        "verdict":"one surviving ruling coordinate",
    },
    {
        "object":"C_mix",
        "mod_M0_row":"coker([ell;L_plus])",
        "Z_coefficient":"-",
        "a_coefficient":"-",
        "contact_coefficient":"-",
        "verdict":"(Z/M0)/(800*q^3) ~= Z/gcd(M0,800)Z",
    },
]
p=HERE/'J2-65-R20-RulingAlignment.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("L_MINUS_PULLBACK_DIVISIBLE_BY_G=TRUE")
print("L_PLUS_PULLBACK_MOD_G=800*q^3*a")
print("SEMANTIC_ROW_MOD_M0=(1,beta0,0)")
print("SEMANTIC_RULING_ALIGNMENT=MIXED_THICKENING")
print("ALIGNMENT_MOD_M0_PROOF=ell has Z-coefficient 1; both ruling rows have Z-coefficient 0")
print("SEMANTIC_H_TRANSVERSALITY_INDEX=M0")
print("SOURCE_SELECTS_CANONICAL_RULING=FALSE")
print("RULING_IDEAL_PAIR_FREE_INVARIANT=FALSE")
print("SEMANTIC_RULING_DEFECT_MODULE=Z/gcd(M0,800)Z")
print("RULING_CONDUCTOR_COUPLING=INDEPENDENT")
print("PRIME_FACTORIZATION_USED=FALSE")
