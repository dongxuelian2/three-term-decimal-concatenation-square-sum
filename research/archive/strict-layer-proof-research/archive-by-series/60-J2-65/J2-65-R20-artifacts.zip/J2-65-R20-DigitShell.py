#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

h_sem=sp.factor(H/MU0)
a_sem=sp.factor((R-lambda_h*h_sem)/(q**5*D0))

rows=[
    {
        "quantity":"h",
        "semantic_formula":sp.sstr(h_sem),
        "gate":"h>0",
        "role":"contact height",
    },
    {
        "quantity":"a",
        "semantic_formula":sp.sstr(a_sem),
        "gate":"1<=a<G",
        "role":"digit height",
    },
    {
        "quantity":"eta",
        "semantic_formula":"(H/MU0)/a_sem",
        "gate":"eta in I_eta",
        "role":"R15 inherited projective W-sector",
    },
    {
        "quantity":"thin shell",
        "semantic_formula":"G <= j(10*u)*a*(A*a+1)",
        "gate":"inherited only; not re-proved",
        "role":"R15/R16 source-height shell",
    },
]
p=HERE/'J2-65-R20-DigitShell.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("OMEGA_SEM_DEFINED=TRUE")
print("SEMANTIC_h=H/MU0")
print("SEMANTIC_a=(R-lambda_h*H/MU0)/(q^5*D0)")
print("SEMANTIC_REAL_DIGIT_LOCUS=ONE_NONEMPTY_OPEN_SUBSET_OF_P1R_CONDITIONAL_ON_R19_R15_SHELL_HYPOTHESIS")
print("NEW_HEIGHT_CAMPAIGN_OPENED=FALSE")
