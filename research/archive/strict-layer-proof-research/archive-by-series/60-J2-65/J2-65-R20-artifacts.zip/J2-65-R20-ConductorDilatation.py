#!/usr/bin/env python3
from pathlib import Path
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

Lm,Lp,theta,psi,Q0=ruling_objects()
Qdil=sp.expand(Q0.subs(V,q**2*v))
assert sp.expand(Qdil-(R**2-q**4*D0*v**2-F0*N0*H**2))==0
assert sp.expand(Qdil.subs(v,V/q**2)-Q0)==0

text=f"""J2-65-R20 CONDUCTOR DILATATION
=================================
CONDUCTOR_COORDINATE=V=q^2*v
Q_DIL={sp.sstr(Qdil)}
INTEGRAL_POINT_BIJECTION:
  (R,v,H) in X_q^dil(Z) -> (R,q^2*v,H) in X0(Z), q^2|V.
  inverse is v=V/q^2 whenever q^2|V.
GENERIC_FIBRE_ISOMORPHISM=TRUE over Q because q != 0.
PRIME_FACTORIZATION_USED=FALSE
VALUATION_LADDER_USED=FALSE
"""
(HERE/'J2-65-R20-ConductorDilatation.txt').write_text(text,encoding='utf-8')
print("CONDUCTOR_COORDINATE=V=q^2*v")
print("CONDUCTOR_INTEGRAL_POINT_BIJECTION=PROVED")
print("CONDUCTOR_GENERIC_FIBRE_ISOMORPHISM=TRUE")
print("q_ADIC_DEPTH_USED=FALSE")
