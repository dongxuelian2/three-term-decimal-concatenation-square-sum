#!/usr/bin/env python3
from pathlib import Path
import csv
HERE=Path(__file__).resolve().parent

# Semantic lattice scaling theorem (purely global, no prime localization):
#
# Let Gamma be a full-rank finite-index sublattice of L0 and Q a homogeneous
# quadratic form.  If [x] is a rational isotropic projective point, choose a
# nonzero integer D clearing its rational denominators in an L0-basis, then
# multiply by the finite index [L0:Gamma].  The resulting vector lies in Gamma
# and remains isotropic by homogeneity.  Express it in a Gamma-basis and divide
# by the gcd of the three coordinates; this produces the primitive generator
# of the same rational ray in Gamma.
#
# If the split conic has a nonempty real open digit arc, P^1(Q) is dense in
# P^1(R), so choose a rational ray in that arc before applying the same scaling.
# R19's Congruence-Archimedean Independence may therefore be reused directly;
# no finite residue orbit theorem is needed.

rows=[
    {
        "stage":"finite semantic admissibility",
        "statement":"rational isotropic ray -> primitive integral Gamma_src ray by one global denominator/index clearing",
        "status":"PROVED",
        "dependency":"Gamma_src full rank finite index in L0; Q homogeneous",
    },
    {
        "stage":"real arc compatibility",
        "statement":"choose rational projective point inside any nonempty split real open arc",
        "status":"PROVED",
        "dependency":"split conic ~= P1; density of P1(Q) in P1(R)",
    },
    {
        "stage":"global lifting",
        "statement":"scale chosen rational arc point into Gamma_src; primitive-normalize in a Gamma basis",
        "status":"PROVED",
        "dependency":"does not change projective digit direction",
    },
    {
        "stage":"R19 CAI",
        "statement":"finite semantic admissibility + real digit arc => simultaneous realization",
        "status":"REUSED",
        "dependency":"R19 frozen theorem",
    },
]
p=HERE/'J2-65-R20-Lifting.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("SEMANTIC_FINITE_ADMISSIBILITY=PROVED")
print("SEMANTIC_CONDUCTOR_RULING_LIFTING=PROVED")
print("PROOF_OBJECT=full-rank semantic source lattice + homogeneous scaling + primitive Gamma-basis normalization")
print("CONGRUENCE_ARCHIMEDEAN_INDEPENDENCE_REUSED=TRUE")
print("FINITE_SOURCE_PACKET_RETIRED=TRUE")
print("R15_R20_LAYER_RETIRED=TRUE")
print("PRIME_LOCALIZATION_USED=FALSE")
print("RESIDUE_ENUMERATION_USED=FALSE")
