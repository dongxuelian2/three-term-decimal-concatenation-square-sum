#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

FR,FV,FH,Qp=veronese()
QF=sp.expand(FR**2-D0*FV**2-F0*N0*FH**2)
assert sp.factor(QF-(s**2-D0*t**2)**2*Qp)==0

ell,cR,cV,cH=raw_semantic_row()
ellF=sp.factor(cR*FR+cV*FV+cH*FH)
v_sem=sp.cancel(FV/q**2)
w_sem=sp.cancel(ellF/sp.Symbol('M0', nonzero=True))
M0=sp.Symbol('M0', nonzero=True)
assert sp.factor(FV-q**2*v_sem)==0
assert sp.factor(ellF-M0*(ellF/M0))==0

# Source-adapted integral degree-2 parameterization principle:
# For an integral quadratic form Q on the semantic source lattice Gamma and an
# integral isotropic basepoint p, write the integral polar form
# B(x,y)=Q(x+y)-Q(x)-Q(y).  For a linear parameter vector y(s,t),
#   F_sem = Q(y)*p - B(p,y)*y
# is integral, homogeneous degree 2, and Q(F_sem)=0 because Q(p)=0.
# Thus the semantic lattice itself admits an integral degree-2 chart once one
# primitive integral p is supplied (proved in Lifting.py).

rows=[
    {
        "object":"R19_Verone­se_R",
        "formula":sp.sstr(FR),
        "degree":"2",
        "integrality":"after basepoint denominator clearing",
        "packet_status":"ambient formula",
    },
    {
        "object":"semantic_v",
        "formula":"F_V/q^2",
        "degree":"2",
        "integrality":"rational graph coordinate; integral on semantic source chart",
        "packet_status":"V-q^2*v == 0 identically",
    },
    {
        "object":"semantic_w",
        "formula":"ell_M_sem(F_R,F_V,F_H)/M0",
        "degree":"2",
        "integrality":"rational graph coordinate; integral on semantic source chart",
        "packet_status":"ell-M0*w == 0 identically",
    },
    {
        "object":"source_integral_Verone­se",
        "formula":"Q(y)*p-B(p,y)*y in a Gamma-basis",
        "degree":"2",
        "integrality":"integral coefficients if p and Gamma-basis integral",
        "packet_status":"built into Gamma; no external pullback",
    },
]
p=HERE/'J2-65-R20-SemanticVeronese.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("SEMANTIC_RATIONAL_PARAMETERIZATION=PROVED")
print("SEMANTIC_PARAMETER_DEGREE=2")
print("SEMANTIC_INTEGRAL_PARAMETERIZATION=PROVED_CONDITIONAL_ON_ONE_SEMANTIC_INTEGRAL_BASEPOINT")
print("SEMANTIC_PRIMITIVE_CONTENT=CONTENT_ONLY:gcd(source-basis degree-2 components)")
print("SEMANTIC_VERONESE_PACKET_PULLBACK=IDENTICALLY_ZERO")
print("R19_AMBIENT_PACKET_POLYNOMIAL_REPLACED_BY_GRAPH_IDENTITIES=TRUE")
