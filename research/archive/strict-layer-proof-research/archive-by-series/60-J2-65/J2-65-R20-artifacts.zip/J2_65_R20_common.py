#!/usr/bin/env python3
"""Common exact symbolic objects for J2-65-R20.
No prime factorization, residue enumeration, valuation ladder, Pell/unit, or fixed-fibre search.
"""
import sympy as sp

G,q,K,u=sp.symbols('G q K u', nonzero=True)
Z,a,h=sp.symbols('Z a h')
R,V,H=sp.symbols('R V H')
w,v=sp.symbols('w v')
s,t=sp.symbols('s t')
pR,pV,pH=sp.symbols('pR pV pH')

A=2*u+1
beta0=u*(1+2*u)**3

F0=sp.expand(G*A*(G*A+2))
W0=sp.expand(G**4*A**2+400*u**2)
T0=sp.expand(2*K*G*u)
N0=sp.expand(T0**2-(G*A+1)**2+2)
S0=sp.expand(G**2*A*T0+20*u)
D0=sp.expand(S0**2-F0*W0)

MU0=20*G**2*q**4*(G+1)

# R15/R16/R18 source->q-free Schur coordinate rows.
C=2*G**2+G*q+2*G+2*q
P_a=(
    2*G**4*K*q+40*G**4+G**3*K*q**2+2*G**3*K*q
    +40*G**3*q+80*G**3+10*G**2*q**2+60*G**2*q+40*G**2
    +10*G*q**2+20*G*q-10*q**2
)
vZ=10*G**3*q**4*C
va=-2*q**2*(G+1)*P_a
vh=-2*G**3*K*q**4*(G+1)

P_lam=(
    -8*G**6*K**2+8*G**6-4*G**5*K**2*q-24*G**5*K**2
    +12*G**5*q+24*G**5-8*G**4*K**2*q-24*G**4*K**2
    +6*G**4*q**2+32*G**4*q+24*G**4-4*G**3*K**2*q
    -8*G**3*K**2+G**3*q**3+14*G**3*q**2+28*G**3*q+8*G**3
    -40*G**2*K*q+2*G**2*q**3+8*G**2*q**2+8*G**2*q
    -80*G*K*q-40*K*q
)
lambda_h=-G**3*q**2*P_lam

# Actual source pullback.  The identity u*q=G+1 is imposed when comparing
# with the R15 q-chart.  R=q^5*D0*a+lambda_h*h, V=Y_partial/20.
Rsrc=sp.expand(q**5*D0*a+lambda_h*h)
Vsrc=sp.expand(vZ*Z+va*a+vh*h)
Hsrc=sp.expand(MU0*h)

def impose_cyclotomic(expr):
    """Eliminate u using uq=G+1 for exact comparison to the R15 q-chart."""
    return sp.factor(sp.cancel(expr.subs(u,(G+1)/q)))

def raw_semantic_row():
    """Exact raw (R,V,H) rational expansion of ell=Z+beta0*a.

    Keep the formula in triangular inverse form.  This is intentionally not
    fully factor-expanded: the semantic row is an integer-valued dual-lattice
    functional, whereas its raw-coordinate coefficients are large rationals.
    """
    cV=1/vZ
    delta=beta0-va/vZ
    cR=delta/(q**5*D0)
    cH=(-vh/vZ-delta*lambda_h/(q**5*D0))/MU0
    ell=cR*R+cV*V+cH*H
    return ell,cR,cV,cH

def ruling_objects():
    Lm=R-20*u*V
    Lp=R+20*u*V
    theta=sp.factor((D0-400*u**2)/G)
    psi=sp.expand(theta*V**2+A*(G*A+2)*N0*H**2)
    Q0=sp.expand(R**2-D0*V**2-F0*N0*H**2)
    assert sp.factor(Q0-(Lm*Lp-G*psi))==0
    return Lm,Lp,theta,psi,Q0

def source_ruling_pullbacks():
    """Pull L_+/- back to the fixed-decimal/contact lattice before M0.

    Return coefficient triples after imposing uq=G+1.  Avoid a giant global
    factorization; divisibility is checked coefficientwise.
    """
    uq=(G+1)/q
    Rq=sp.expand((q**5*D0*a+lambda_h*h).subs(u,uq))
    Vq=sp.expand(Vsrc.subs(u,uq))
    lm=sp.expand(Rq-20*uq*Vq)
    lp=sp.expand(Rq+20*uq*Vq)
    return lm,lp

def veronese():
    """R19 witness-dependent degree-2 isotropic Veronese."""
    FR=-D0*pR*t**2+2*D0*pV*s*t-pR*s**2
    FV=D0*pV*t**2-2*pR*s*t+pV*s**2
    FH=pH*(s**2-D0*t**2)
    Qp=sp.expand(pR**2-D0*pV**2-F0*N0*pH**2)
    QF=sp.expand(FR**2-D0*FV**2-F0*N0*FH**2)
    assert sp.factor(QF-(s**2-D0*t**2)**2*Qp)==0
    return sp.factor(FR),sp.factor(FV),sp.factor(FH),sp.factor(Qp)

def source_basis_row():
    """Canonical fixed-decimal/contact basis:
      e_Z=(1,0,0), e_a=(0,1,-A), e_10=(0,0,10).
    ell=Z+beta0*a has coordinates (1,beta0,0).
    """
    return (sp.Integer(1),sp.expand(beta0),sp.Integer(0))
