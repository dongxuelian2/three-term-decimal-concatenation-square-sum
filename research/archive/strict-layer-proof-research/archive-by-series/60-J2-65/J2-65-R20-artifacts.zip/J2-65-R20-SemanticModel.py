#!/usr/bin/env python3
from pathlib import Path
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

ell,cR,cV,cH=raw_semantic_row()
Lm,Lp,theta,psi,Q0=ruling_objects()
Qsem=sp.expand(Q0.subs(V,q**2*v))

model=f"""J2-65-R20 SEMANTIC MODEL — EXACT GRAPH/DILATATION PRESENTATION

Ambient q-free conic:
  Q0(R,V,H)=R^2-D0*V^2-F0*N0*H^2=0.

Semantic coordinates:
  V=q^2*v,
  ell_M_sem(R,V,H)=M0*w.

Coordinate-ring presentation (M0 is the whole source modulus from R18):
  O_sem =
    Z[L0; v,w] /
    ( Q0(R,V,H), V-q^2*v, ell_M_sem(R,V,H)-M0*w ).

After eliminating V:
  Q0(R,q^2*v,H)=0,
  ell_M_sem(R,q^2*v,H)=M0*w.

Raw dual-lattice row:
  ell_M_sem={sp.sstr(ell)}

Semantic fixed-contact basis row:
  ell_M_sem=(1,beta0,0), beta0={sp.sstr(beta0)}.

INTEGRAL POINT EQUIVALENCE
  O_sem(Z) projects bijectively to
  {{x in X0(L0): q^2|V(x), M0|ell_M_sem(x)}} = X0 cap ker(pi_src).
The inverse is uniquely v=V/q^2 and w=ell_M_sem/M0.

GENERIC FIBRE
  Over Q, q^2 and M0 are nonzero scalars, hence v and w are unique graph
  coordinates.  Therefore X_sem,Q ~= X0,Q; no rational geometry is added.

SOURCE MODEL COMPARISON
  The R15 fixed-contact source lattice maps by the exact R15->R16->R18
  Schur chain to precisely the two divisibility conditions above.
  Hence R15 source model <-> R20 semantic model is an integral isomorphism
  on actual source states (with the fixed decimal/contact chart retained).
"""
(HERE/'J2-65-R20-SemanticModel.txt').write_text(model,encoding='utf-8')

print("M0_COORDINATE=ell_M_sem=M0*w")
print("CONDUCTOR_COORDINATE=V=q^2*v")
print("SEMANTIC_MODEL_GENERIC_FIBRE=ISOMORPHIC_TO_Q0")
print("SEMANTIC_INTEGRAL_POINTS=EXACTLY_SOURCE_PACKET_KERNEL")
print("FINITE_PACKET_EXTERNAL_CONGRUENCE_RETAINED=FALSE")
print("R15_SOURCE_MODEL_TO_R20_SEMANTIC_MODEL=INTEGRAL_ISOMORPHISM")
