#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

Lm,Lp,theta,psi,Q0=ruling_objects()
theta_expected=(2*u+1)*(
    8*G**5*K**2*u**3+4*G**5*K**2*u**2-8*G**5*u**3-12*G**5*u**2
    -6*G**5*u-G**5-8*G**4*u**2-8*G**4*u-2*G**4
    +80*G**2*K*u**2-800*G*u**3-400*G*u**2-800*u**2
)
assert sp.expand(theta-theta_expected)==0
assert sp.factor(D0-400*u**2-G*theta)==0
assert sp.factor(Q0-(Lm*Lp-G*psi))==0

rows=[{
    "object":"THETA_D",
    "formula":sp.sstr(theta),
    "integral":"TRUE",
    "identity":"D0-400*u^2=G*THETA_D",
},{
    "object":"PSI_G",
    "formula":sp.sstr(psi),
    "integral":"TRUE",
    "identity":"Q0=L_MINUS*L_PLUS-G*PSI_G",
},{
    "object":"L_MINUS",
    "formula":"R-20*u*V",
    "integral":"TRUE",
    "identity":"ruling 1",
},{
    "object":"L_PLUS",
    "formula":"R+20*u*V",
    "integral":"TRUE",
    "identity":"ruling 2",
}]
p=HERE/'J2-65-R20-RulingFactorization.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("L_MINUS=R-20*u*V")
print("L_PLUS=R+20*u*V")
print("THETA_D=(D0-400*u^2)/G")
print("THETA_D_POLYNOMIAL_INTEGRAL=TRUE")
print("THETA_D=",sp.sstr(theta))
print("PSI_G=THETA_D*V^2+A*(G*A+2)*N0*H^2")
print("EXACT_RULING_FACTOR=Q0=L_MINUS*L_PLUS-G*PSI_G")
print("G=M0*G_src")
print("PRIME_FACTORIZATION_USED=FALSE")
