#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R20_common import *
HERE=Path(__file__).resolve().parent

Lm,Lp,theta,psi,Q0=ruling_objects()
assert sp.factor(Q0-(Lm*Lp-G*psi))==0

# R20 alignment is MIXED_THICKENING, so the ruling-aligned formula L_-=M0*w_-
# is not legal.  The correct single Rees/dilatation chart is the graph model:
# V=q^2*v, ell=M0*w, Q0=0.
normal_form=(
    "Q0(R,q^2*v,H)=0; ell_M_sem(R,q^2*v,H)=M0*w; "
    "on Q0: L_MINUS*L_PLUS=M0*G_src*PSI_G"
)
rows=[{
    "alignment":"MIXED_THICKENING",
    "semantic_ruling_normal_form":normal_form,
    "ruling_minus_mod_M0":"0 on fixed-contact semantic lattice",
    "ruling_plus_mod_M0":"800*q^3*a",
    "normalized_defect":"C_mix=Z/gcd(M0,800)Z",
    "status":"REDUCED",
}]
p=HERE/'J2-65-R20-RulingResolution.tsv'
with p.open('w',newline='',encoding='utf-8') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t')
    wr.writeheader();wr.writerows(rows)

print("SEMANTIC_MODEL_BAD_REDUCTION=REDUCED")
print("SEMANTIC_RULING_NORMAL_FORM=",normal_form)
print("RULING_ALIGNED_BLOWUP_APPLICABLE=FALSE")
print("WHY=source row is neither ruling and has zero contact-h coefficient")
print("RULING_IDEAL_PAIR_FREE_INVARIANT=FALSE")
print("SEMANTIC_RULING_DEFECT_MODULE=Z/gcd(M0,800)Z")
print("ITERATED_VALUATION_BLOWUPS_USED=FALSE")
