#!/usr/bin/env python3
from pathlib import Path
import subprocess, hashlib, sys

HERE=Path(__file__).resolve().parent
scripts=[
    'J2-65-R20-SemanticRowTransport.py',
    'J2-65-R20-RulingFactorization.py',
    'J2-65-R20-RulingAlignment.py',
    'J2-65-R20-ConductorDilatation.py',
    'J2-65-R20-SemanticModel.py',
    'J2-65-R20-SemanticSaturation.py',
    'J2-65-R20-RulingResolution.py',
    'J2-65-R20-SemanticVeronese.py',
    'J2-65-R20-Lifting.py',
    'J2-65-R20-DigitShell.py',
]
required=[
    'J2-65-R20-Semantic-Conductor-Ruling-Report.md',
    *scripts,
    'J2-65-R20-Regression.py',
    'J2-65-R20-SemanticRowTransport.tsv',
    'J2-65-R20-RulingFactorization.tsv',
    'J2-65-R20-RulingAlignment.tsv',
    'J2-65-R20-SemanticModel.txt',
    'J2-65-R20-SemanticSaturation.tsv',
    'J2-65-R20-RulingResolution.tsv',
    'J2-65-R20-SemanticVeronese.tsv',
    'J2-65-R20-Lifting.tsv',
    'J2-65-R20-DigitShell.tsv',
    'J2-65-R20-certificate.txt',
]
print('J2-65 R20 REGRESSION')
print('====================')
for s in scripts:
    p=subprocess.run([sys.executable,str(HERE/s)],capture_output=True,text=True,timeout=45)
    assert p.returncode==0,(s,p.stderr)
    print(f'SCRIPT_PASS={s}')
for f in required:
    p=HERE/f
    assert p.exists() and p.stat().st_size>0,f
print('REQUIRED_ARTIFACT_AUDIT=PASS')

text='\n'.join((HERE/s).read_text(encoding='utf-8') for s in scripts)
for bad in ['factorint(', 'primerange(', 'pollard_', 'pell_solution', 'hensel_lift']:
    assert bad not in text,bad
print('PRIME_FACTORIZATION_USED=FALSE')
print('RESIDUE_ENUMERATION_USED=FALSE')
print('HENSEL_LADDER_USED=FALSE')
print('PELL_UNIT_REOPENED=FALSE')
print('FIXED_g_k_q_SCAN_USED=FALSE')
print('ITERATED_BLOWUP_TREE_USED=FALSE')

cert=(HERE/'J2-65-R20-certificate.txt').read_text(encoding='utf-8')
assert 'SEMANTIC_RULING_ALIGNMENT=MIXED_THICKENING' in cert
assert 'SEMANTIC_CONDUCTOR_RULING_LIFTING=PROVED' in cert
assert 'SEMANTIC_RULING_DEFECT_MODULE=Z/gcd(M0,800)Z' in cert
assert 'FINITE_SOURCE_PACKET_RETIRED=TRUE' in cert
assert 'J2_STATUS=OPEN' in cert
print('CERTIFICATE_REGRESSION=PASS')

print('SHA256_BEGIN')
for f in required:
    b=(HERE/f).read_bytes()
    print(hashlib.sha256(b).hexdigest(),f)
print('SHA256_END')
print('J2_STATUS=OPEN')
