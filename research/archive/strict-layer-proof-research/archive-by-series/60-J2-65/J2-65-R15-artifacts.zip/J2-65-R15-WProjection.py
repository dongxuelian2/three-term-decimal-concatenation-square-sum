#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
print("NORMALIZED_CONTACT=eta=hLOW/a3_0")
print("PROJECTIVE_x_OVER_a3=(A+eta)/10")
print("z_s=",sp.factor(z_s))
print("z_ct=",sp.factor(z_ct))
print("z_UP_eta=",sp.factor(z_up))
print("I_eta={eta>0:D_eta>=0 and z_plus>max(z_s,z_ct,z_UP(eta))}")
print("W_SECTOR_PROJECTED_TO_eta=PROVED_FIXED_COMPLEXITY")
print("ETA_REGION_COMPONENT_COUNT<=9")
print("ETA_ZERO_IN_ADMISSIBLE_CLOSURE=TRUE")
print("UNIFORM_PROJECTIVE_CLEARANCE=FALSE")
