#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
assert sp.Poly(Qpartial,Z,a,h).total_degree()==2
assert sp.gcd_list(sp.Poly(Qpartial,Z,a,h).coeffs())==1
print("BOUNDARY_TERNARY_FORM_PRIMITIVE=TRUE")
print("SOURCE_INTEGRAL_EQUIVALENCE=PROVED_ON_Lambda_partial")
for n,v in [("coef_Z2",coef_Z2),("coef_Za",coef_Za),("coef_Zh",coef_Zh),("coef_aa",coef_aa),("coef_ah",coef_ah),("coef_hh",coef_hh)]:
    print(n,"=",v)
