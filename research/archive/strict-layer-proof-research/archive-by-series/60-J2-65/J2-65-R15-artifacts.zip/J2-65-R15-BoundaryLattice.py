#!/usr/bin/env python3
print("Tpartial=[[1,0,0],[0,1,0],[0,-A,10]]")
print("BOUNDARY_LINEAR_MAP_DETERMINANT=10")
print("BOUNDARY_LATTICE_BASIS=(M,0,0),(rho,1,-A),(0,0,10)")
print("BOUNDARY_LATTICE_INDEX=10*M")
print("BOUNDARY_LATTICE_SNF=(1,gcd(M,10),10*M/gcd(M,10))")
print("FIXED_MOD10_CONDITION=A*a3+hLOW == 0 (mod 10)")
print("MOVING_DENOMINATOR_CASE_SPLIT_USED=FALSE")
