#!/usr/bin/env python3
print("kappa=min(9/10,h/(A*a+h))")
print("For h>=1: h/(A*a+h)>=1/(A*a+1), and 9/10>=1/(A*a+1).")
print("CLEARANCE_QUANTIZATION=PROVED")
print("QUANTIZED_HEIGHT_NECESSITY=G<=j(10*u)*a*(A*a+1)")
