#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
chi=sp.factor((A*a+h)/(10*A*a))
assert sp.factor(chi-sp.Rational(1,10)-h/(10*A*a))==0
print("LOW_DEFECT_COORDINATE=hLOW=10*x0-A*a3_0")
print("LOW_DEFECT_POSITIVE=PROVED")
print("CLEARANCE_IN_hLOW=min(9/10,hLOW/(A*a3_0+hLOW))")
print("CLEARANCE_QUANTIZATION=kappa>=1/(A*a3_0+1)")
print("QUANTIZED_HEIGHT_NECESSITY=G<=j(10*u)*a3_0*(A*a3_0+1)")
print("CHI_RETAINED_AS_TERMINAL_VARIABLE=FALSE")
