#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
assert sp.factor(Ypartial**2-Dpartial-4*mathA*Qpartial)==0
assert sp.factor(d0+400*q**6*DLB)==0
content=sp.factor(sp.gcd(sp.gcd(2*mathA,coef_Za),coef_Zh))
assert content==40*q**2
print("QUADRATIC_IN_Z=PASS")
print("BINARY_DISCRIMINANT_FORM=d0*a^2+d1*a*h+d2*h^2")
print("d0=",d0)
print("d1=",d1)
print("d2=",d2)
print("EXACT_DISCRIMINANT_SQUARE_IDENTITY=PASS")
print("Y_FIXED_POLYNOMIAL_CONTENT=40*q^2")
print("BOUNDARY_DISCRIMINANT_CONVERSE=SQUARE_PLUS_FIXED_LATTICE_CONGRUENCE")
print("R14_DLB_RECOVERED=PASS_EXACT")
