#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
assert sp.factor(Delta_partial+64*mathA*detGram)==0
assert sp.factor(detGram-40000*G**2*q**10*(G+1)**2*(2*G+q+2)*Delta_fib)==0
assert sp.factor(Rpartial**2-4*d0*Dpartial-Delta_partial*h**2)==0
print("SCHUR_COMPLEMENT_IDENTITY=PROVED")
print("Delta_partial=-64*mathA*detGram(Qpartial)")
print("R7_FIBRE_DISCRIMINANT_RELATION=PROVED")
print("SOURCE_PRESERVING_NORM_COMPLETION=PASS")
