#!/usr/bin/env python3
"""Exact symbolic core for J2-65-R15. No ray enumeration and no factorization of u."""
import sympy as sp
G,q,K,u,d,Z,a,h,eta,z=sp.symbols("G q K u d Z a h eta z", integer=True)
A=(2*G+q+2)/q
c=q**3+10*q**2+12*q+8
Btail=(q+2)*(q**2-4*q-4)
Rz=2*G**2+G*q+2*G+2*q
pZZ=G**3*q**4*Rz
Pza0=4*G**4+4*G**3*q+8*G**3+G**2*q**2+6*G**2*q+4*G**2+G*q**2+2*G*q-q**2
pZa=-4*q**2*(G+1)*Pza0
pZx=-4*G**3*K*q**4*(G+1)
paa=4*(G+1)**2*(2*G+q+2)**3
pax=8*K*q**2*(G+1)**2*(2*G**2+G*q+2*G-q)
pxx=G**2*q**4*(2*G+q+2)
xsub=(A*a+h)/10
Fsrc=sp.expand(pZZ*Z**2+pZa*Z*a+pZx*Z*xsub+paa*a**2+pax*a*xsub+pxx*xsub**2)
Qpartial=sp.expand(sp.cancel(100*Fsrc))
P=sp.Poly(Qpartial,Z,a,h)
coef_Z2=sp.factor(P.coeff_monomial(Z**2))
coef_Za=sp.factor(P.coeff_monomial(Z*a))
coef_Zh=sp.factor(P.coeff_monomial(Z*h))
coef_aa=sp.factor(P.coeff_monomial(a**2))
coef_ah=sp.factor(P.coeff_monomial(a*h))
coef_hh=sp.factor(P.coeff_monomial(h**2))
mathA=coef_Z2
mathB=sp.expand(coef_Za*a+coef_Zh*h)
mathC=sp.expand(coef_aa*a**2+coef_ah*a*h+coef_hh*h**2)
Dpartial=sp.factor(mathB**2-4*mathA*mathC)
DP=sp.Poly(sp.expand(Dpartial),a,h)
d0=sp.factor(DP.coeff_monomial(a**2))
d1=sp.factor(DP.coeff_monomial(a*h))
d2=sp.factor(DP.coeff_monomial(h**2))
Delta_partial=sp.factor(d1**2-4*d0*d2)
DLB=sp.factor(-d0/(400*q**6))
Delta_fib=sp.factor(-4*G**4*K**2+4*G**4-8*G**3*K**2+4*G**3*q+8*G**3-4*G**2*K**2+G**2*q**2+8*G**2*q+4*G**2+2*G*q**2+4*G*q-q**2)
Ypartial=sp.expand(2*mathA*Z+mathB)
Rpartial=sp.expand(2*d0*a+d1*h)
Gram=sp.hessian(Qpartial,(Z,a,h))/2
detGram=sp.factor(Gram.det())
hZ=q**2*(c*(G-1)-Btail)
ha=4*Btail-2*q*c*A
uc=(G+1)/q
sbar=sp.factor((hZ*z+ha)/G)
tbar=q**2*z-4
ctminus=sp.factor(c*tbar-sbar)
Nbar=q*(G-1)*z-2*A
Xbar=sp.factor((z+uc*Nbar)/2)
D2bar=sp.factor(uc+G*Xbar)
L=G**2/K
UPmargin=sp.factor(8*uc*D2bar-A*L*(A+eta)/10)
def threshold(expr):
    p=sp.Poly(sp.together(expr),z)
    c1=sp.factor(p.coeff_monomial(z)); c0=sp.factor(p.coeff_monomial(1))
    return c1,c0,sp.factor(-c0/c1)
_,_,z_s=threshold(hZ*z+ha)
_,_,z_ct=threshold(G*ctminus)
_,_,z_up=threshold(UPmargin)
B_eta=sp.expand(coef_Za+coef_Zh*eta)
C_eta=sp.expand(coef_aa+coef_ah*eta+coef_hh*eta**2)
D_eta=sp.factor(d0+d1*eta+d2*eta**2)
Qnorm=sp.factor(coef_Z2*z**2+B_eta*z+C_eta)
