#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
PK=sp.Poly(DLB,K)
K2=sp.factor(PK.coeff_monomial(K**2)); K1=sp.factor(PK.coeff_monomial(K))
assert K2==-4*G**6*(G+1)**2*(2*G+q+2)**2
assert K1==-80*G**3*q*(G+1)**2*(2*G+q+2)
print("DLB_DEGREE_IN_K=2")
print("DLB_STRICTLY_DECREASING_FOR_K>0=TRUE")
print("POWER_TEN_BASE=G>=10,K>=10,q<=G+1<=11G/10")
print("DLB_K10_POSITIVE_MONOMIAL_BOUND=9588271/625000*G^10")
print("DLB_K10_UPPER_BOUND=-980411729/625000*G^10")
print("DLB_SIGN_ON_POWER_TEN_W_SECTOR=NEGATIVE")
print("DLB_SQUARECLASS_STATUS=MOVING")
print("REAL_LOW_BOUNDARY_INTERSECTION=TWO_DISTINCT_POINTS")
