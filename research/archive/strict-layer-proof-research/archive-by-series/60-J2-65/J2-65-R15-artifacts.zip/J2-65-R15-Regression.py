#!/usr/bin/env python3
import sympy as sp
from J2_65_R15_common import *
assert sp.Poly(Qpartial,Z,a,h).total_degree()==2
assert sp.gcd_list(sp.Poly(Qpartial,Z,a,h).coeffs())==1
assert sp.factor(Ypartial**2-Dpartial-4*mathA*Qpartial)==0
assert sp.factor(d0+400*q**6*DLB)==0
assert sp.factor(Delta_partial+64*mathA*detGram)==0
assert sp.factor(detGram-40000*G**2*q**10*(G+1)**2*(2*G+q+2)*Delta_fib)==0
assert sp.factor(Rpartial**2-4*d0*Dpartial-Delta_partial*h**2)==0
assert sp.factor(sp.gcd(sp.gcd(2*mathA,coef_Za),coef_Zh)-40*q**2)==0
print("R15_REGRESSION=PASS")
print("R14_DLB_RECOVERED=PASS")
print("R7_DELTA_FIB_RECOVERED=PASS")
print("SOURCE_PRESERVING_NORM_COMPLETION=PASS")
print("RAY_ENUMERATION_USED=FALSE")
print("FACTOR_u_USED=FALSE")
