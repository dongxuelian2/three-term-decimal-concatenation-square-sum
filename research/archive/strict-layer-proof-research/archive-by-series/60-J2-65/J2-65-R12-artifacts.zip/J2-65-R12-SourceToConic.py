#!/usr/bin/env python3
import sympy as sp

q,G,u,r = sp.symbols("q G u r", nonzero=True)
A = 2*u+1
c = q**3 + 10*q**2 + 12*q + 8
Bt = (q+2)*(q**2-4*q-4)

Nhat = sp.factor((Bt*r + G)/(q*c))
Zhat = sp.factor((A*r - 2*Nhat)/(q*(q+4)))
a3hat = sp.factor(((G-1)*r - q*Nhat)/(2*(q+4)))
Xhat = sp.factor((Zhat + u*Nhat)/2)
Dhat = sp.factor(u*a3hat + G*Xhat)

print("J2-65 R12 SOURCE-TO-CONIC RADIAL CERTIFICATE")
print("RADIAL_SCALE=s=alpha/d")
print("t=s*r")
print("x=s*y")
print("Ntail=s*Nhat(r), Nhat=", Nhat)
print("Z=s*Zhat(r), Zhat=", Zhat)
print("a3=s*a3hat(r), a3hat=", a3hat)
print("Xrad=s*Xhat(r), Xhat=", Xhat)
print("D2=s*Dhat(r), Dhat=", Dhat)
print("DHAT_DEGREE_IN_r=", sp.degree(sp.together(Dhat).as_numer_denom()[0], r))
print("SHARED_D_PROJECTIVE_CONTENT=NONE")
