#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
scripts=[
"J2-65-R12-BrauerWitness.py",
"J2-65-R12-SourceToConic.py",
"J2-65-R12-SourceToHermitian.py",
"J2-65-R12-PrimitivePullback.py",
"J2-65-R12-DigitConePullback.py",
"J2-65-R12-IncidenceElimination.py",
"J2-65-R12-ContinuantProjection.py",
"J2-65-R12-PowerTenIncidence.py",
]
ok=True
for s in scripts:
    p=subprocess.run([sys.executable,str(HERE/s)],capture_output=True,text=True)
    print(f"===== {s} =====")
    print(p.stdout,end="")
    if p.stderr:
        print(p.stderr,end="")
    if p.returncode!=0:
        ok=False
print("R12_REGRESSION=PASS" if ok else "R12_REGRESSION=FAIL")
sys.exit(0 if ok else 1)
