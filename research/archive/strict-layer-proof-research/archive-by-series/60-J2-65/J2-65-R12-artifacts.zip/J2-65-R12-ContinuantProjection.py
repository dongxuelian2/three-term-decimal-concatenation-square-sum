#!/usr/bin/env python3
print("J2-65 R12 CONTINUANT PROJECTION VERDICT")
print("R11_DIAGONAL_MAP_FROZEN=TRUE")
print("DPLUS=Phi(p_c,r_c)=u(2KG+B)")
print("DMINUS=Phi(q_c,s_c)=u(2KG-B)")
print("PURE_CONTINUANT_LAYER_ADDS_NEW_INDEPENDENT_GATE=FALSE")
print("CONTINUANT_SOURCE_IMAGE=FAIL_AS_SOURCE_ATTACHED")
print("REASON=norm-one integralization torsor intervenes before canonical R11 word")
print("SECOND_GAUSSIAN_DIGIT_ANALYZED=FALSE")
