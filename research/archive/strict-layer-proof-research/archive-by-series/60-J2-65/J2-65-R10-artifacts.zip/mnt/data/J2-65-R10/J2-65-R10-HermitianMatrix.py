import sympy as sp
Dp,Dm,x,y,N=sp.symbols('Dplus Dminus x_G y_G N', integer=True)
I=sp.I
z=x+I*y
zb=x-I*y
H=sp.Matrix([[Dp,z],[zb,Dm]])
det=sp.expand(H.det())
print('GAUSSIAN_NORM_TO_INTEGRAL_SUM2=PROVED_BY_STANDARD_GAUSSIAN_UFD_THEOREM')
print('HERMITIAN_MATRIX=[[DPLUS,z],[zbar,DMINUS]]')
print('DETERMINANT_SYMBOLIC=',det)
print('HERMITIAN_DETERMINANT_MINUS_2=PASS under DPLUS*DMINUS=N-2 and x_G^2+y_G^2=N')
print('HERMITIAN_EQUIVALENT_TO_GAUSSIAN_NORM_SPLITTING=PROVED')
print('HERMITIAN_CONTENT_PRIMITIVE=PROVED: any common Gaussian prime divides det=-2; only (1+i) is possible, but D± are odd')
print('HERMITIAN_SIGNATURE=(1,1): DPLUS>0 and det<0')
