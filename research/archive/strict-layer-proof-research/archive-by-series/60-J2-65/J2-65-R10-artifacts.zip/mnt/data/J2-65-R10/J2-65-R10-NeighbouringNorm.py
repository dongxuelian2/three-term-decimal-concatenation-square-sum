import sympy as sp
G,K,q,u=sp.symbols('G K q u', integer=True, positive=True)
A=2*u+1
B=2*G+q
M=G*A+1
S=2*K*u*G
rho=M**2-2
N=sp.expand(S**2-rho)
Cplus=2*K*G+B
Cminus=2*K*G-B
rel=G+1-u*q

def zero_mod_rel(expr):
    expr=sp.expand(expr)
    # relation is linear in q; substitute q=(G+1)/u and clear denominator
    return sp.factor(sp.together(expr.subs(q,(G+1)/u)))==0

checks={}
checks['M_EQUALS_GA_PLUS_1']=sp.expand(M-(G*A+1))==0
checks['M_EQUALS_uB']=zero_mod_rel(M-u*B)
checks['N_EQUALS_S2_MINUS_M2_PLUS_2']=sp.expand(N-(S**2-M**2+2))==0
checks['N_EQUALS_2_PLUS_u2_TIMES_FACTOR']=zero_mod_rel(N-(2+u**2*(4*K**2*G**2-B**2)))
checks['CPLUS_CMINUS_FACTOR']=sp.expand(Cplus*Cminus-(4*K**2*G**2-B**2))==0
checks['N_CONGRUENT_2_MOD_u2']=zero_mod_rel(N-2-u**2*Cplus*Cminus)
checks['N_MOD_G2_TANGENT']=sp.factor(N-(1-2*A*G)) % G**2 == 0 if False else sp.factor((N-(1-2*A*G))/G**2).is_polynomial(G,K,u)
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
print('N_EXACT=',sp.factor(N))
print('N_MINUS_2_FACTOR=',sp.factor(sp.together((N-2).subs(q,(G+1)/u))))
print('G2_QUOTIENT=',sp.factor((N-(1-2*A*G))/G**2))
