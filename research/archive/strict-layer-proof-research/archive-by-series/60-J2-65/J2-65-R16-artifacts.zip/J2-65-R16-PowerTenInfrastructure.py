#!/usr/bin/env python3
from J2_65_R16_common import *
print("K_MOTION_S_D=affine in K")
print("K_MOTION_R_D=independent of K")
print("K_MOTION_DEFECT_IDEAL_PHASE=S_D mod R_D")
print("POWER_OF_TEN_INFRASTRUCTURE_STABILITY=NOT_PROVED")
print("POWER_OF_TEN_INFRASTRUCTURE_PHASE_COMPRESSION=PROVED")
