#!/usr/bin/env python3
"""Whole-object source norm lattice; symbolic HNF/SNF is encoded by determinantal divisors."""
from J2_65_R16_common import *
M,rho,A=sp.symbols("M rho A", positive=True, integer=True)
B=sp.Matrix([
 [0, r_a-A*r_h, 10*r_h],
 [v_z*M, v_z*rho+v_a-A*v_h, 10*v_h],
 [0, -A, 10],
])
mins2=[]
for rs in ((0,1),(0,2),(1,2)):
 for cs in ((0,1),(0,2),(1,2)):
  mins2.append(sp.factor(B.extract(rs,cs).det()))
D1=sp.Function("gcd_all_entries")(*list(B))
D2=sp.Function("gcd_all_2x2_minors")(*mins2)
det=sp.factor(B.det())
print("SOURCE_NORM_LATTICE_RANK=3")
print("BASIS_MATRIX=",B)
print("SNF_DETERMINANTAL_DIVISORS=(D1,D2,abs(det))")
print("SNF=(D1,D2/D1,abs(det)/D2)")
print("HNF=HermiteNormalForm(B) AS_ONE_COMPOSITE_WHOLE_OBJECT")
print("NO_GCD_BRANCH_TREE_USED=TRUE")
