#!/usr/bin/env python3
"""J2-65-R16 exact symbolic common data. No numerical factorization or Pell enumeration."""
import sympy as sp
G,q,K=sp.symbols("G q K", positive=True, integer=True)
RF = 4*G**4 + 4*G**3*q + 8*G**3 + G**2*q**2 + 8*G**2*q + 4*G**2 + 2*G*q**2 + 4*G*q - q**2
Delta_fib = sp.expand(RF-4*K**2*G**2*(G+1)**2)
T = 2*K*G*(G+1)
C = 2*G+q+2
P = 2*G**2+G*q+2*G+2*q
PD = 2*G**3*(G+1)*C
QD = 20*q*(G+1)
SD = sp.expand(PD*K+QD)
RD = sp.factor(G*C*P*(G**4*C**2+400*(G+1)**2))
D = sp.expand(SD**2-RD)
DLB = -D
d0 = sp.expand(400*q**6*D)
d1 = -800*G**3*q**7*(-8*G**6*K**2 + 8*G**6 - 4*G**5*K**2*q - 24*G**5*K**2 + 12*G**5*q + 24*G**5 - 8*G**4*K**2*q - 24*G**4*K**2 + 6*G**4*q**2 + 32*G**4*q + 24*G**4 - 4*G**3*K**2*q - 8*G**3*K**2 + G**3*q**3 + 14*G**3*q**2 + 28*G**3*q + 8*G**3 - 40*G**2*K*q + 2*G**2*q**3 + 8*G**2*q**2 + 8*G**2*q - 80*G*K*q - 40*K*q)
d2 = -400*G**5*q**8*(-4*G**3*K**2 + 4*G**3 - 8*G**2*K**2 + 4*G**2*q + 8*G**2 - 4*G*K**2 + G*q**2 + 8*G*q + 4*G + 2*q**2 + 4*q)
Delta_partial = sp.factor(d1**2-4*d0*d2)
Sdelta = 16000*G**2*q**7*(G+1)
Ecore = sp.factor(-G*C*P*Delta_fib)
C0 = 800*q**5
S0 = sp.factor(Sdelta/C0)
EN0 = sp.factor(S0**2*Ecore)
coef_Z2 = 100*G**3*q**4*(2*G**2 + G*q + 2*G + 2*q)
coef_Za = -40*q**2*(G + 1)*(2*G**4*K*q + 40*G**4 + G**3*K*q**2 + 2*G**3*K*q + 40*G**3*q + 80*G**3 + 10*G**2*q**2 + 60*G**2*q + 40*G**2 + 10*G*q**2 + 20*G*q - 10*q**2)
coef_Zh = -40*G**3*K*q**4*(G + 1)
Y_Z = 2*coef_Z2
Y_a = coef_Za
Y_h = coef_Zh
V_Z = sp.factor(40*q**3*Y_Z)
V_a = sp.factor(40*q**3*Y_a)
V_h = sp.factor(40*q**3*Y_h)
R_a = sp.factor(2*d0)
R_h = d1
r_a = sp.factor(R_a/C0)
r_h = sp.factor(R_h/C0)
v_z = sp.factor(V_Z/C0)
v_a = sp.factor(V_a/C0)
v_h = sp.factor(V_h/C0)
