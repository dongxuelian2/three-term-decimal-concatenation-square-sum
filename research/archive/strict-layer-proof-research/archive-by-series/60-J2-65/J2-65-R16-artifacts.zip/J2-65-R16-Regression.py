#!/usr/bin/env python3
from J2_65_R16_common import *
assert sp.factor(-Delta_fib-(T**2-RF))==0
assert sp.factor(D-(SD**2-RD))==0
assert not RD.has(K)
assert sp.factor(d0-(20*q**3)**2*D)==0
assert sp.factor(Delta_partial-Sdelta**2*Ecore)==0
assert sp.factor(Sdelta/C0-20*G**2*q**2*(G+1))==0
assert sp.gcd(sp.Poly(RD,G,q),sp.Poly(RF,G,q)).as_expr()==1
assert sp.resultant(RD,RF,q)!=0
assert sp.resultant(RD,RF,G)!=0
# Sign proof interface: q<=G+1 gives RF < 3G(G+1)^2(3G+2).
RFupper=3*G*(G+1)**2*(3*G+2)
assert sp.factor(400*G**2*(G+1)**2-RFupper)==G*(G+1)**2*(391*G-6)
print("R16_REGRESSION=PASS")
print("DOUBLE_NEAR_SQUARE=PASS")
print("MAXIMAL_UNIVERSAL_COORDINATE_CONTENT=800*q^5")
print("DEFECT_GCD=1; BOTH_RESULTANTS_NONZERO")
print("DELTA_FIB_NEGATIVE_ON_ACTUAL_BASE=PASS via K>=10,q<=G+1,G>=10")
print("PELL_ENUMERATION_USED=FALSE")
print("NUMERICAL_FACTORING_USED=FALSE")
print("q1_REOPENED=FALSE")
