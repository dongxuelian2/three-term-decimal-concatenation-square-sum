#!/usr/bin/env python3
"""Quadratic étale/order audit. D may specialize to a square, so fieldhood is not assumed."""
from J2_65_R16_common import *
print("BOUNDARY_NORM_ETALE_ALGEBRA=Q[t]/(t^2-D)")
print("NONSPLIT_SPECIALIZATION=real quadratic field Q(sqrt(D_sf))")
print("SPLIT_SPECIALIZATION=D square -> Q x Q")
print("AMBIENT_COORDINATE_ORDER=Z[sqrt(D)] ; discriminant=4*D")
print("SOURCE_ORDER=MultiplierRing(L_src) subset of maximal etale order")
print("ORDER_CONDUCTOR=whole composite conductor; no numerical factorization")
print("NUMERICAL_FACTORING_OF_D_USED=FALSE")
