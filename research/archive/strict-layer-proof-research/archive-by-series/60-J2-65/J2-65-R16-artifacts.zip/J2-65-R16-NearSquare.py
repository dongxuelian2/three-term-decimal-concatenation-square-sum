#!/usr/bin/env python3
from J2_65_R16_common import *
assert sp.expand(-Delta_fib-(T**2-RF))==0
assert sp.expand(D-(SD**2-RD))==0
assert not RD.has(K)
assert sp.expand(SD-(G**2*(2*G+q+2)*T+20*q*(G+1)))==0
g=sp.gcd(sp.Poly(RD,G,q),sp.Poly(RF,G,q))
assert g.as_expr()==1
rq=sp.factor(sp.resultant(RD,RF,q))
rG=sp.factor(sp.resultant(RD,RF,G))
assert rq!=0 and rG!=0
print("FIBRE_NEAR_SQUARE=-Delta_fib=T^2-R_F")
print("BOUNDARY_NEAR_SQUARE=D=S_D^2-R_D")
print("R_D=",sp.factor(RD))
print("BOUNDARY_DEFECT_K_INDEPENDENT=TRUE")
print("NEAR_SQUARE_DEFECT_GCD=1")
print("NEAR_SQUARE_DEFECT_RELATION=NONE_COMMON_FACTOR")
