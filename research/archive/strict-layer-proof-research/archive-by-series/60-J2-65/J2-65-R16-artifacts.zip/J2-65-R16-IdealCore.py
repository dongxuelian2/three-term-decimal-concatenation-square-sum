#!/usr/bin/env python3
print("IDEAL_PACKET_FINITE_FOR_FIXED_BASE_AND_h=TRUE")
print("PROOF_INTERFACE=nO subset (xi) subset O; ideals correspond to finite-submodule data of O/nO")
print("h_CLASS_GROUP_DEPENDENCE=NONE")
print("REASON=(h)^2 is a principal square; it vanishes in ordinary/narrow class obstruction")
print("ELEMENT_AND_SOURCE_LATTICE_h_DEPENDENCE=RETAINED")
print("BOUNDARY_NORM_IDEAL_CLASS_OBSTRUCTION=GENUINELY_MOVING")
print("PRIME_IDEAL_ALLOCATION_USED=FALSE")
