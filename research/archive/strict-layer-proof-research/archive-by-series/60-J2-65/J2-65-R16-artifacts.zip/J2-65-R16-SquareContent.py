#!/usr/bin/env python3
from J2_65_R16_common import *
assert sp.factor(d0-(20*q**3)**2*D)==0
assert sp.factor(4*d0-(40*q**3)**2*D)==0
assert sp.factor(Delta_partial-Sdelta**2*Ecore)==0
# Maximal universal polynomial gcd of the two norm-coordinate coefficient rows.
def pgcd(xs):
    p=sp.Poly(sp.expand(xs[0]),G,K,q,domain="ZZ")
    for x in xs[1:]: p=sp.gcd(p,sp.Poly(sp.expand(x),G,K,q,domain="ZZ"))
    return sp.factor(p.as_expr())
assert pgcd([R_a,R_h])==800*q**6
assert pgcd([V_Z,V_a,V_h])==1600*q**5
assert pgcd([R_a,R_h,V_Z,V_a,V_h])==C0
assert sp.rem(Sdelta,C0,G)==0 or sp.factor(Sdelta/C0).is_polynomial()
print("D_BOUNDARY=-D_LB")
print("d0=(20*q^3)^2*D_BOUNDARY")
print("V_NORM=40*q^3*Ypartial")
print("DELTA_PARTIAL_STRUCTURAL_SQUARE=S_delta^2")
print("S_delta=16000*G^2*q^7*(G+1)")
print("UNIVERSAL_COORDINATE_CONTENT=800*q^5")
print("RESIDUAL_SQUARE_SCALE=20*G^2*q^2*(G+1)")
print("ILLEGAL_SQUARE_DIVISION_USED=FALSE")
