#!/usr/bin/env python3
from J2_65_R16_common import *
assert sp.expand((SD+sp.Symbol("w"))*(SD-sp.Symbol("w"))-RD).subs(sp.Symbol("w")**2,D)==0
print("S_D_MINUS_SQRT_D=R_D/(S_D+sqrt(D))")
print("FIRST_CF_FLOOR=S_D-ceil(R_D/(S_D+sqrt(D))) on nonsquare specializations")
print("CANONICAL_DEFECT_IDEAL=(R_D, S_D+sqrt(D))")
print("DEFECT_IDEAL_K_DEPENDENCE=only through S_D mod R_D")
print("K_DEPENDENCE_AFTER_FIRST_NEARSQUARE_REDUCTION=REDUCED")
print("STRICT_GAUSS_REDUCEDNESS_UNIFORMLY_PROVED=FALSE")
print("FULL_CF_DIGIT_ENUMERATION_USED=FALSE")
