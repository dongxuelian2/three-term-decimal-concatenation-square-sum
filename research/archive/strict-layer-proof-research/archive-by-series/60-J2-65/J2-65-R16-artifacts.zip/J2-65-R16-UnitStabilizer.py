#!/usr/bin/env python3
print("NONSPLIT_TOTALLY_POSITIVE_NORM_ONE_UNIT_GROUP=Z (rank 1)")
print("SPLIT_ETALE_SPECIALIZATION=finite integral norm-one units; no Pell dynamics")
print("SOURCE_STABILIZER=kernel of action on finite source-lattice quotient/coset datum")
print("SOURCE_STABILIZER_INDEX=order of generator image in one finite automorphism quotient")
print("UNIVERSAL_ORDER_UNIT_BOUND=epsilon >= (sqrt(D_sf)+sqrt(D_sf+4))/2 > sqrt(D_sf)")
print("STRONGER_ZsqrtD_BOUND=epsilon>2*sqrt(D_sf) only when integral coefficient condition is proved")
print("NEAR_SQUARE_REGULATOR_BOUND=NOT_OBTAINED")
