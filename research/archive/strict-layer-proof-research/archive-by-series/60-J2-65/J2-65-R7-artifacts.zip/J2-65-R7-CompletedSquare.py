#!/usr/bin/env python3
from J2_65_R7_common import *
Ar=sp.expand(A+B*r+C*r**2); Lr=sp.expand(E+F*r); Bn=sp.expand(lam**2*Lr**2-4*D*Ar); Db=sp.factor(sp.discriminant(Bn,r)); assert sp.simplify(Db+64*D*sp.factor((MP+lam*MS).det()))==0
print('COMPLETED_SQUARE_NORM_FORM=PROVED')
