#!/usr/bin/env python3
from J2_65_R7_common import *
Lx=X*e*alpha+f*T; assert sp.factor(S/(4*q**2*Y*(q+4)*c)+(X+1)*Lx)==0
print('R6_TWO_ROW_PULLBACK=PASS'); print('R6_COEFFICIENT_MAP_PULLBACK=PASS'); print('R5_TUBES_REOPENED=FALSE'); print('R4_BRACKETS_REOPENED=FALSE')
