#!/usr/bin/env python3
# Reconstructs the exact R2 source, extracts R6 two rows, and exposes MP/MS.
import sympy as sp
G,K,q,d,alpha,t,x,X,U,V,lam,T,Y,r=sp.symbols('G K q d alpha t x X U V lam T Y r')
c=q**3+10*q**2+12*q+8; Btail=(q+2)*(q**2-4*q-4); u=(G+1)/q; Aroot=2*u+1
N=(Btail*t+alpha*G/d)/(q*c); Z=(Aroot*t-2*N)/(q*(q+4)); a3=((G-1)*t-q*N)/(2*(q+4)); Xrad=(Z+u*N)/2; D2=u*a3+G*Xrad; Froot=Aroot*Xrad**2+Z*D2
Qclr=sp.together(Aroot*G**2*x**2-8*K*u*D2*x+4*Froot); Qsat,Dstr=sp.fraction(Qclr); Qsat=sp.expand(Qsat)
pk=sp.Poly(Qsat,K); Psrc=sp.expand(pk.coeff_monomial(1)/G); Ssrc=sp.expand(pk.coeff_monomial(K)); P=sp.expand(Psrc.subs(G,X).subs({t:T/d,x:Y/d})); S=sp.expand(Ssrc.subs(G,X).subs({t:T/d,x:Y/d}))
pP=sp.Poly(P,alpha,T,Y); pS=sp.Poly(S,alpha,T,Y); A=sp.factor(pP.coeff_monomial(alpha**2)); B=sp.factor(pP.coeff_monomial(alpha*T)); C=sp.factor(pP.coeff_monomial(T**2)); D=sp.factor(pP.coeff_monomial(Y**2)); E=sp.factor(pS.coeff_monomial(alpha*Y)); F=sp.factor(pS.coeff_monomial(T*Y))
MP=sp.Matrix([[A,B/2,0],[B/2,C,0],[0,0,D]]); MS=sp.Matrix([[0,0,E/2],[0,0,F/2],[E/2,F/2,0]])
e=sp.factor(E/(-4*X*q**2*(X+1)*(q+4)*c)); f=sp.factor(F/(-4*q**2*(X+1)*(q+4)*c)); R=sp.factor((4*A*C-B**2)/(4*q**2*(X+1)**2*(q+4)**2*c**2))
