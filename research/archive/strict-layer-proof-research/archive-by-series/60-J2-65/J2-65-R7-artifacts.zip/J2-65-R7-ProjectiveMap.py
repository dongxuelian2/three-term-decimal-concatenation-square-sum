#!/usr/bin/env python3
from J2_65_R7_common import *
h=sp.symbols('h'); assert sp.expand(P.subs({alpha:h*alpha,T:h*T,Y:h*Y})-h**2*P)==0; assert sp.expand(S.subs({alpha:h*alpha,T:h*T,Y:h*Y})-h**2*S)==0
print('PROJECTIVE_POWER_TEN_TARGET=PROVED'); print('RAW_GCD_H_PROJECTIVE_FRONTIER=REMOVED')
