#!/usr/bin/env python3
from J2_65_R7_common import *
v=sp.Matrix([alpha,T,Y]); assert sp.expand(P-(v.T*MP*v)[0])==0; assert sp.expand(S-(v.T*MS*v)[0])==0
print('VERONESE_BLOCK_SEPARATION=PROVED'); print('S_ROW_GENERIC_RANK=2')
