#!/usr/bin/env python3
from J2_65_R7_common import *
DET=sp.factor((U*MP+V*MS).det()); expected=sp.factor(U*X*q**6*(X+1)**2*(q+4)**4*(2*X+q+2)*c**4*(U**2*R-4*V**2*X**4*(X+1)**2)); assert sp.simplify(DET-expected)==0
print('PENCIL_DISCRIMINANT_DEGREE_IN_LAMBDA=2'); print('ACTUAL_SINGULAR_FIBRES=CLOSED_BY_GLOBAL_SIZE_THEOREM')
