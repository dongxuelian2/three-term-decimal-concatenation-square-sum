#!/usr/bin/env python3
from J2_65_R7_common import *
assert sp.factor(R.subs(q,0))==4*X**2*(X+1)**2
print('UNIVERSAL_RATIONAL_SECTION=FALSE'); print('ARGUMENT=PROPER_SPECIALIZATION_TO_POSITIVE_DEFINITE_LAMBDA_ZERO_FIBRE')
