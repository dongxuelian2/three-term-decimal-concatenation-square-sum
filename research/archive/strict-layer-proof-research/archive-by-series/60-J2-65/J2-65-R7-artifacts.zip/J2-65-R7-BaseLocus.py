#!/usr/bin/env python3
from J2_65_R7_common import *
r0=sp.factor(-E/F); ysq=sp.factor(-(A+B*r0+C*r0**2)/D); target=sp.factor(-X**4*(X+1)**2/(q**2*f**2)); assert sp.simplify(ysq-target)==0
print('CASE_Z_Q_GT_1=CLOSED'); print('CASE_Z_SQUARE_CLASS=',ysq)
