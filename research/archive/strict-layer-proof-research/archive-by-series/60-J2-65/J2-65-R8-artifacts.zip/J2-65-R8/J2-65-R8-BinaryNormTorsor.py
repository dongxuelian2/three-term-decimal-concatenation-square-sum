from J2_65_R8_common import *
print('MOVING_NORM_FORM=w^2-4*a*z^2=Delta_B')
print('DELTA_SQUARECLASS=-Xi')
print('FIXED_NORM_FIELD=F(sqrt(-R))')
print('FIXED_NORM_TARGET_SQUARECLASS=-A1*h*Xi')
