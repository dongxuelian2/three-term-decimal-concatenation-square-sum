from J2_65_R8_common import *
rho=sp.factor(R.subs(X,u*q-1)/q**2)
sigma=sp.factor(A1.subs(X,u*q-1)/q)
Phi=sp.factor(rho-4*K**2*u**2*(u*q-1)**2)
print('CYCL_PULLED_BRAUER=(-rho,-sigma*(2u+1)*Phi)')
print('rho=',rho)
print('sigma=',sigma)
print('Phi=',Phi)
