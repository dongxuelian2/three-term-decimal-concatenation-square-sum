import sympy as sp
q,X,lam,u,K=sp.symbols('q X lam u K')
c=q**3+10*q**2+12*q+8
A1=(2*q**2+16*q+32)*X**3+(q**3+10*q**2+40*q+64)*X**2+(2*q**3+18*q**2+40*q+40)*X+c
A=X*A1
R=4*X**4+4*X**3*q+8*X**3+X**2*q**2+8*X**2*q+4*X**2+2*X*q**2+4*X*q-q**2
h=2*X+q+2
Xi=sp.factor(R-4*lam**2*X**4*(X+1)**2)
