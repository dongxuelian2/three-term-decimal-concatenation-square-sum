#!/usr/bin/env python3
import sympy as sp
from J2_65_R13_common import *

# Exact inverse identities.  They show that Z,a3 plus alpha and x generate all
# source-integrality constraints.
assert sp.expand(N_ZA - (q*(G-1)*Z0-2*A*a30))==0
assert sp.expand(t_ZA - (q**2*Z0-4*a30))==0

# Parity is automatic on the actual J2 structural locus:
# G is even; q,u,A are odd.  Hence N == Z (mod 2), and X,h,m are integral.
print("SOURCE_INTEGRALITY_MINIMAL_GENERATORS=alpha,x,Z,a3")
print("DERIVED_INTEGER=t,N,X,D2,h,m,r_rem,F")
print("TAIL_SCALE_CONGRUENCE=G | d*(q*c*N-B*t)")
print("NO_DENOMINATOR_CASE_SPLIT=TRUE")
