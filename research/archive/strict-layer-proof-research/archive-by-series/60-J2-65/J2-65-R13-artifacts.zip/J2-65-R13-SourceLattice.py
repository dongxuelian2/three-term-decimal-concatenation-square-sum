#!/usr/bin/env python3
from math import gcd
import argparse
import sympy as sp

def build(G,q,u,d):
    assert u*q==G+1
    A=2*u+1
    c=q**3+10*q*q+12*q+8
    B=(q+2)*(q*q-4*q-4)
    hZ=q*q*(c*(G-1)-B)
    ha=4*B-2*q*c*A
    # whole-modulus saturation invariant
    delta=gcd(G, gcd(abs(d*hZ),abs(d*ha)))
    M=G//delta
    ap=(d*hZ)//delta
    bp=(d*ha)//delta
    assert gcd(ap,M)==1
    rr=0 if M==1 else (-bp*pow(ap,-1,M))%M
    alpha1=ap
    assert (d*(hZ*rr+ha))%G==0
    alpha2=d*(hZ*rr+ha)//G
    # Columns are primitive source-lattice basis vectors in (s,t,x).
    # s=(alpha1*w1+alpha2*w2)/d
    # t=q^2*M*w1+(q^2*rr-4)*w2
    basis=[
        (sp.Rational(alpha1,d), sp.Rational(alpha2,d), 0),
        (q*q*M, q*q*rr-4, 0),
        (0,0,1),
    ]
    det=sp.Rational(2*q*q*(q+4)*c,delta)
    return dict(A=A,c=c,B=B,hZ=hZ,ha=ha,delta=delta,M=M,rho=rr,
                alpha1=alpha1,alpha2=alpha2,basis=basis,det=det)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--G",type=int)
    ap.add_argument("--q",type=int)
    ap.add_argument("--u",type=int)
    ap.add_argument("--d",type=int,default=1)
    a=ap.parse_args()
    if None in (a.G,a.q,a.u):
        print("SOURCE_INTEGER_QUANTITY_COUNT=12")
        print("SOURCE_LINEAR_FORM_COUNT=4  # minimal saturated generators alpha,x,Z,a3")
        print("SOURCE_LATTICE_RANK=3")
        print("SOURCE_LATTICE_BASIS=TEMPLATE: Z=M*w1+rho*w2; a3=w2; x=w3; s=(alpha1*w1+alpha2*w2)/d; t=q^2*Z-4*a3")
        print("SOURCE_LATTICE_SNF=(1,1,M), M=G/delta")
        print("delta=gcd(G,d*hZ,d*ha); hZ=q^2*(c*(G-1)-B); ha=4B-2*q*c*A")
        print("POWER_TEN_COLLAPSE (live q): delta=gcd(G,2*d*(q+4))")
        print("DENOMINATOR_CASE_SPLIT_USED=FALSE")
    else:
        z=build(a.G,a.q,a.u,a.d)
        print("SOURCE_INTEGER_QUANTITY_COUNT=12")
        print("SOURCE_LINEAR_FORM_COUNT=4")
        print("SOURCE_LATTICE_RANK=3")
        print("SOURCE_LATTICE_BASIS=",z["basis"])
        print("SOURCE_LATTICE_SNF=",(1,1,z["M"]))
        print("SOURCE_LATTICE_DETERMINANT=",z["det"])
        print("SATURATION_DELTA=",z["delta"])
        print("CONGRUENCE_RESIDUE_rho=",z["rho"])
        print("DENOMINATOR_CASE_SPLIT_USED=FALSE")
