#!/usr/bin/env python3
from math import gcd
import sympy as sp

# Structural symbols
q,G,K,u,d = sp.symbols("q G K u d", integer=True, positive=True)
s,t,x = sp.symbols("s t x")
A = 2*u + 1
c = q**3 + 10*q**2 + 12*q + 8
B = (q+2)*(q**2-4*q-4)
lam = K/G

# R12 frozen radial reconstruction
N = sp.cancel((B*t + G*s)/(q*c))
Z = sp.cancel((A*t - 2*N)/(q*(q+4)))
a3 = sp.cancel(((G-1)*t - q*N)/(2*(q+4)))
X = sp.cancel((Z + u*N)/2)
D2 = sp.cancel(u*a3 + G*X)
h = sp.cancel((N + q*Z)/2)
m = sp.cancel((A*N + (q+2)*Z)/2)
rrem = sp.cancel((G* h)/2 - u*a3)
Fsrc = sp.cancel(A*X**2 + Z*D2)

# Inverse source reconstruction from the actual integer pair (Z0,a30).
Z0,a30,x0 = sp.symbols("Z0 a30 x0", integer=True)
N_ZA = q*(G-1)*Z0 - 2*A*a30
t_ZA = q**2*Z0 - 4*a30
H_ZA = sp.expand(q*c*N_ZA - B*t_ZA)  # = G*s
hZ = sp.factor(sp.diff(H_ZA,Z0))
ha = sp.factor(sp.diff(H_ZA,a30))

Rpoly = 4*G**4 + 4*G**3*q + 8*G**3 + G**2*q**2 + 8*G**2*q + 4*G**2 + 2*G*q**2 + 4*G*q - q**2
Delta_fib = sp.expand(Rpoly - 4*K**2*G**2*(G+1)**2)

def source_identities():
    """Return exact identities used by the saturation proof."""
    rel = {G: q*u-1}
    checks = {}
    checks["TDEF"] = sp.factor((t_ZA - (q**2*Z0-4*a30)))
    checks["RCE1"] = sp.factor(2*A*a30 - q*(G-1)*Z0 + N_ZA)
    # Mod-G residues after uq=G+1.
    hz_rel = sp.expand(hZ.subs(G,q*u-1))
    ha_rel = sp.expand(ha.subs(G,q*u-1))
    hz_mod = sp.rem(sp.Poly(hz_rel, u), sp.Poly(q*u-1,u)).as_expr() if False else None
    return checks

def ceil_frac_num(a,b):
    return -((-a)//b)
