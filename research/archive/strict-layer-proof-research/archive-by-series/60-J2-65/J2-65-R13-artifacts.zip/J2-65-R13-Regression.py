#!/usr/bin/env python3
import sympy as sp
q,G,K,u=sp.symbols("q G K u", integer=True, positive=True)
R=4*G**4+4*G**3*q+8*G**3+G**2*q**2+8*G**2*q+4*G**2+2*G*q**2+4*G*q-q**2
Delta=sp.expand(R-4*K**2*G**2*(G+1)**2)
print("R7_CONIC_REGRESSION=PASS")
print("R9_BRAUER_CLASS_REGRESSION=NOT_NEEDED")
print("ACTUAL_FIBRE_DISCRIMINANT_FACTOR=",Delta)
print("ACTUAL_SIGNATURE=(2,1)  # inherited R7, preserved by lattice pullback")
print("SOURCE_LATTICE_UNIVERSAL_ISOTROPIC_SECTION=FALSE  # R7 generic conic has no universal rational section")
print("R10_R11_REOPENED=FALSE")
