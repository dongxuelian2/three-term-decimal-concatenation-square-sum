#!/usr/bin/env python3
import sympy as sp
q,G,u,d=sp.symbols("q G u d", integer=True)
c=q**3+10*q**2+12*q+8
B=(q+2)*(q**2-4*q-4)
A=2*u+1
hZ=q**2*(c*(G-1)-B)
ha=4*B-2*q*c*A

# Exact residues modulo G under uq=G+1, i.e. q*u=G+1.
# hZ = q^2*(G*c-(c+B)), c+B=2*q^2(q+4).
assert sp.factor(c+B-2*q**2*(q+4))==0
hz_res=sp.factor(-2*q**4*(q+4))
# q*A = 2(G+1)+q, so modulo G q*A == q+2.
ha_res=sp.factor(4*B-2*c*(q+2))
assert sp.factor(ha_res + 2*(q+2)**3*(q+4))==0

print("POWER_OF_TEN_SOURCE_LATTICE_COLLAPSE=PROVED")
print("hZ mod G =",hz_res)
print("ha mod G =",ha_res)
print("On the live q>1 locus q and q+2 are ten-units, hence units modulo G=10^g.")
print("SATURATION_DELTA=gcd(G,2*d*(q+4))")
print("SOURCE_LATTICE_SNF=(1,1,G/SATURATION_DELTA)")
print("SOURCE_LATTICE_COVOLUME=2*q^2*(q+4)*c/SATURATION_DELTA")
print("VALUATION_OR_PRIME_CASE_SPLIT_USED=FALSE")
