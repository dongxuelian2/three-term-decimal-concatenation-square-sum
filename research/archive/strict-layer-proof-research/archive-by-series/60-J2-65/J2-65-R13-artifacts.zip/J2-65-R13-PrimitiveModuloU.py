#!/usr/bin/env python3
print("LAMBDA_u=Lambda_src/u*Lambda_src ~= (Z/uZ)^3 after choosing B_Lambda")
print("IN_CANONICAL_SOURCE_COORDINATES: Z0=M*w1+rho*w2 ; a3_0=w2 ; x0=w3")
print("U_SQ_RAY=x0^2 == Z0^2 (mod u)")
print("RAY_Z0_UNIT_MOD_u_REQUIRED=TRUE")
print("RAY_x0_UNIT_MOD_u_AUTOMATIC_FROM_U_SQ_AND_Z0_UNIT=TRUE")
print("PRIMITIVE_MODULO_u_COMPOSITE_OBSTRUCTION=NOT_PROVED")
print("PRIMITIVE_MODULO_u_AUTOMATICITY=PARTIAL: x-unit automatic; Z-unit not automatic")
print("PRIME_DECOMPOSITION_USED=FALSE")
