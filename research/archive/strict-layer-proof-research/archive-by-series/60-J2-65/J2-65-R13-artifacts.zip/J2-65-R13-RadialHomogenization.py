#!/usr/bin/env python3
import sympy as sp

G,K,q,d,alpha,T,Y = sp.symbols("G K q d alpha T Y", nonzero=True)
u=(G+1)/q
A=2*u+1
c=q**3+10*q**2+12*q+8
B=(q+2)*(q**2-4*q-4)
tt=T/d
xx=Y/d
N=(B*tt+alpha*G/d)/(q*c)
Z=(A*tt-2*N)/(q*(q+4))
a3=((G-1)*tt-q*N)/(2*(q+4))
X=(Z+u*N)/2
D2=u*a3+G*X
F=A*X**2+Z*D2

Qclr=sp.cancel(A*G**2*xx**2-8*K*u*D2*xx+4*F)
Dstr=d**2*q**5*(q+4)**2*c**2
Qsat=sp.expand(sp.cancel(Dstr*Qclr))
assert sp.denom(Qsat)==1
PK=sp.Poly(Qsat,K)
assert PK.degree()==1
P=sp.expand(PK.coeff_monomial(1)/G)
S=sp.expand(PK.coeff_monomial(K))
p=sp.Poly(P,alpha,T,Y)
spoly=sp.Poly(S,alpha,T,Y)
Ac=sp.factor(p.coeff_monomial(alpha**2))
Bc=sp.factor(p.coeff_monomial(alpha*T))
Cc=sp.factor(p.coeff_monomial(T**2))
Dc=sp.factor(p.coeff_monomial(Y**2))
Ec=sp.factor(spoly.coeff_monomial(alpha*Y))
Fc=sp.factor(spoly.coeff_monomial(T*Y))
assert sp.expand(P-(Ac*alpha**2+Bc*alpha*T+Cc*T**2+Dc*Y**2))==0
assert sp.expand(S-(Ec*alpha*Y+Fc*T*Y))==0

s,t,x=sp.symbols("s t x")
lam=K/G
Qrad=sp.expand(Ac*s**2+Bc*s*t+Cc*t**2+Dc*x**2+lam*x*(Ec*s+Fc*t))
assert all(sum(m) == 2 for m,_ in sp.Poly(Qrad,s,t,x).terms())
r,y=sp.symbols("r y")
aff=sp.expand(Qrad.subs({t:s*r,x:s*y})/s**2)
expected=sp.expand(Ac+Bc*r+Cc*r**2+Dc*y**2+lam*y*(Ec+Fc*r))
assert sp.simplify(aff-expected)==0

# R7 factor regressions.
e=G**2*(q+4)+2*G-q
assert sp.factor(Ec + 4*G*q**2*(G+1)*(q+4)*c*e)==0
assert sp.factor(Dc - G*q**4*(q+4)**2*(2*G+q+2)*c**2)==0

print("R7_PROJECTIVE_CONIC_RELOADED=PASS")
print("RADIAL_SUBSTITUTION=r=t/s ; y=x/s")
print("RADIAL_HOMOGENEOUS_FORM=Ac*s^2+Bc*s*t+Cc*t^2+Dc*x^2+(K/G)*x*(Ec*s+Fc*t)")
print("Ac=",Ac)
print("Bc=",Bc)
print("Cc=",Cc)
print("Dc=",Dc)
print("Ec=",Ec)
print("Fc=",Fc)
print("FORM_DEGREE=2")
print("FORM_HOMOGENEOUS=TRUE")
print("PROJECTIVE_TO_RADIAL_EQUIVALENCE=PASS")
