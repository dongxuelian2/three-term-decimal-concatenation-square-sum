#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib
import sympy as sp
from J2_65_R4_common import *
OUT=Path(__file__).resolve().parent

def write_tsv(name, rows, fields):
    with (OUT/name).open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=fields,delimiter='\t'); w.writeheader(); w.writerows(rows)

def factor_desc(expr):
    try:
        c0,fs=sp.factor_list(sp.expand(expr))
        return str((c0,[(str(f),e) for f,e in fs]))
    except Exception:
        return str(sp.factor(expr))

m=master(); QNUM=m['QNUM']; source_hash=hashlib.sha256(str(QNUM).encode()).hexdigest()
assert source_hash=='8892befa7c4d420b20cd73dfc06cb6ebd52a1a093ea90ca421a52166b29fc2dc'
assert sp.factor(m['QDEN']-d**2*q**5*(q+4)**2*c**2)==0
assert sorted([z for z,co in m['P'].terms() if co!=0],key=lambda z:(z[1],z[0]))==SUPPORT
content,structural,add=coefficient_decomposition()

bracket_for={(1,0):'B10',(2,0):'H20',(3,0):'H30',(4,0):'B40',(1,1):'B11',(2,1):'B21',(3,1):'B31'}
rows=[]
for a,b in SUPPORT:
    C=coeff(a,b)
    rows.append(dict(
        a=a,b=b,coefficient=str(sp.expand(C)),content=str(content[(a,b)]),
        structural_monomial_factor=str(sp.factor(structural[(a,b)])),
        additive_factor=str(sp.factor(add[(a,b)])),
        irreducible_factors=factor_desc(C),row='K_ROW' if b else 'G_ROW',source_hash=source_hash))
write_tsv('J2-65-R4-CoefficientFactorization.tsv',rows,
          ['a','b','coefficient','content','structural_monomial_factor','additive_factor','irreducible_factors','row','source_hash'])

cat=[]
for bid in BRACKET_IDS:
    if bid in LINEAR_IDS:
        expr=linear_expr(bid); prim=linear_expr(bid,primitive=True); typ='L'
        uq,vq=str(sp.factor(U[bid])),str(sp.factor(V[bid])); vars_='alpha,T'; zl=f'{bid}=0 => [A0:T0]=[-V_{bid}:U_{bid}]'
    else:
        expr=higher_exprs()[bid]; prim=expr; typ='H'; uq=vq=''; vars_='alpha,T,Y'; zl=f'{bid}(q,alpha,T,Y)=0 homogeneous quadratic conic'
    occ=OCCURRENCES[bid]
    cat.append(dict(bracket_id=bid,expression=str(sp.factor(expr)),primitive_expression=str(sp.factor(prim)),type=typ,
                    U_q=uq,V_q=vq,variables=vars_,occurrence_count=len(occ),occurrences=';'.join(f'C_{a}_{b}' for a,b in occ),
                    p2_relevant='TRUE',p5_relevant='TRUE',arch_relevant='TRUE',zero_locus=zl))
write_tsv('J2-65-R4-BracketCatalog.tsv',cat,
          ['bracket_id','expression','primitive_expression','type','U_q','V_q','variables','occurrence_count','occurrences','p2_relevant','p5_relevant','arch_relevant','zero_locus'])

inc=[]
for bid,occs in OCCURRENCES.items():
    for a,b in occs:
        inc.append(dict(coefficient_id=f'C_{a}_{b}',bracket_id=bid,multiplicity=1,row='K_ROW' if b else 'G_ROW',G_exp=a,K_exp=b))
write_tsv('J2-65-R4-BracketIncidence.tsv',inc,['coefficient_id','bracket_id','multiplicity','row','G_exp','K_exp'])

dep=[]
for a,b in SUPPORT:
    dep.append(dict(source=f'C_{a}_{b}',target='Q_sat',relation='FULL_ROOT_COEFFICIENT',detail='exact grouped coefficient of Level-1 master root'))
    dep.append(dict(source=f'C_{a}_{b}',target=str(sp.factor(structural[(a,b)])),relation='STRUCTURAL_FACTOR',detail='factor separated before additive analysis'))
for bid,occs in OCCURRENCES.items():
    for a,b in occs:
        dep.append(dict(source=f'C_{a}_{b}',target=bid,relation='SHARES_PRIMITIVE_BRACKET',detail='exact factor incidence'))
for i in range(len(LINEAR_IDS)):
    for j in range(i+1,len(LINEAR_IDS)):
        bi,bj=LINEAR_IDS[i],LINEAR_IDS[j]
        dep.append(dict(source=bi,target=bj,relation='PAIRWISE_DETERMINANT',detail=str(determinant(bi,bj))))
for bid in K_LINEAR:
    dep.append(dict(source='R3_K_ROW_INTERNAL',target=bid,relation='LIVE_CELL_REQUIRES',detail='possible linear generator whenever a K-row individual coefficient controls a live internal-min refinement'))
for bid in G_LINEAR+G_HIGHER:
    dep.append(dict(source='R3_G_ROW_INTERNAL',target=bid,relation='LIVE_CELL_REQUIRES',detail='possible generator whenever a G-row individual coefficient controls a live internal-min refinement'))
# No distinct generic generators are proportional.
for i in range(len(LINEAR_IDS)):
    for j in range(i+1,len(LINEAR_IDS)):
        assert determinant(LINEAR_IDS[i],LINEAR_IDS[j])!=0
write_tsv('J2-65-R4-BracketDependency.tsv',dep,['source','target','relation','detail'])

print('R4 BRACKET EXTRACTION CERTIFICATE')
print('MASTER_HASH='+source_hash)
print('GROUPED_COEFFICIENT_COUNT=10')
print('ADDITIVE_COEFFICIENT_COUNT=7')
print('PRIMITIVE_BRACKET_GENERATOR_COUNT=7')
print('LINEAR_PROJECTIVE_BRACKET_COUNT=5')
print('HIGHER_BRACKET_COUNT=2')
print('LINEAR_PAIR_PROPORTIONALITY=NONE')
print('EXTRACTION_STATUS=PASS')
