#!/usr/bin/env python3
from __future__ import annotations
import sympy as sp
from functools import lru_cache

G,K,q,d,alpha,t,x = sp.symbols('G K q d alpha t x', integer=True)
T,Y,A0,T0,h = sp.symbols('T Y A0 T0 h', integer=True)

c = q**3+10*q**2+12*q+8
Btail = (q+2)*(q**2-4*q-4)
Rpoly = q**3+5*q**2-4*q-4

@lru_cache(None)
def master():
    u=(G+1)/q
    A=2*u+1
    N=sp.cancel((Btail*t+alpha*G/d)/(q*c))
    Z=sp.cancel((A*t-2*N)/(q*(q+4)))
    a3=sp.cancel(((G-1)*t-q*N)/(2*(q+4)))
    X=sp.cancel((Z+u*N)/2)
    D2=sp.cancel(u*a3+G*X)
    F=sp.cancel(A*X**2+Z*D2)
    Qclr=sp.cancel(A*G**2*x**2-8*K*u*D2*x+4*F)
    qnum,qden=map(sp.factor,sp.fraction(Qclr))
    qnum=sp.expand(qnum)
    P=sp.Poly(qnum,G,K)
    return dict(u=u,A=A,N=N,Z=Z,a3=a3,X=X,D2=D2,F=F,Qclr=Qclr,QNUM=qnum,QDEN=qden,P=P)

SUPPORT=[(1,0),(2,0),(3,0),(4,0),(5,0),(0,1),(1,1),(2,1),(3,1),(4,1)]

def coeff(a,b):
    P=master()['P']
    return sp.factor(P.coeff_monomial(G**a*K**b))

# Primitive additive generators. T is shorthand for d*t; Y for d*x.
U = {
'B10': c,
'B40': q**2+6*q+16,
'B11': sp.Integer(1),
'B21': 2-q,
'B31': q+6,
}
V = {
'B10': 3*q**6+36*q**5+156*q**4+352*q**3+240*q**2-64*q-64,
'B40': 8*(q+2)*Rpoly,
'B11': q**3-6*q**2-28*q-8,
'B21': (q+2)*(3*q-2)*(q**2+8*q+4),
'B31': 2*(q+2)*Rpoly,
}
LINEAR_IDS=['B10','B40','B11','B21','B31']

def linear_expr(bid, primitive=False):
    aa=A0 if primitive else alpha
    tt=T0 if primitive else T
    return sp.expand(U[bid]*aa+V[bid]*tt)

def to_TY(expr):
    return sp.factor(sp.cancel(expr.subs({t:T/d,x:Y/d})))

@lru_cache(None)
def higher_exprs():
    H20=to_TY(coeff(2,0))
    H30=sp.factor(to_TY(coeff(3,0))/2)
    return {'H20':H20,'H30':H30}

BRACKET_IDS=['B10','H20','H30','B40','B11','B21','B31']

OCCURRENCES={
'B10':[(1,0)], 'H20':[(2,0)], 'H30':[(3,0)], 'B40':[(4,0)],
'B11':[(1,1)], 'B21':[(2,1)], 'B31':[(3,1)]
}

# Structural coefficient decomposition: coefficient = content * structural * additive, where additive=1 for monomial coefficients.
def coefficient_decomposition():
    add={
      (1,0):linear_expr('B10').subs({T:d*t}),
      (2,0):higher_exprs()['H20'].subs({T:d*t,Y:d*x}),
      (3,0):higher_exprs()['H30'].subs({T:d*t,Y:d*x}),
      (4,0):linear_expr('B40').subs({T:d*t}),
      (5,0):sp.Integer(1),
      (0,1):sp.Integer(1),
      (1,1):linear_expr('B11').subs({T:d*t}),
      (2,1):linear_expr('B21').subs({T:d*t}),
      (3,1):linear_expr('B31').subs({T:d*t}),
      (4,1):sp.Integer(1),
    }
    content={(1,0):2,(2,0):1,(3,0):2,(4,0):1,(5,0):2,(0,1):8,(1,1):4,(2,1):-4,(3,1):-4,(4,1):-4}
    structural={
      (1,0):d*q**2*t*(q+4),
      (2,0):1,
      (3,0):1,
      (4,0):alpha*(q+4),
      (5,0):alpha**2*(q+4)**2,
      (0,1):d**2*q**5*t*x*(q+4)**2*c,
      (1,1):d*q**3*x*(q+4)*c,
      (2,1):d*q**2*x*(q+4)*c,
      (3,1):d*q**2*x*(q+4)*c,
      (4,1):alpha*d*q**2*x*(q+4)**2*c,
    }
    for m in SUPPORT:
        assert sp.factor(coeff(*m)-content[m]*structural[m]*add[m])==0, (m,sp.factor(coeff(*m)-content[m]*structural[m]*add[m]))
    return content,structural,add

# Pairwise determinant convention Delta_ij = U_i V_j - U_j V_i.
def determinant(i,j):
    return sp.factor(U[i]*V[j]-U[j]*V[i])

# Named irreducible factors occurring in determinant family.
DFACTORS={
'D1':3*q**7+34*q**6+148*q**5+568*q**4+1456*q**3+1184*q**2+64*q-128,
'D2':q**4+12*q**3+68*q**2+80*q+32,
'D3a':3*q+2,
'D3b':q**2+4*q-4,
'D3c':q**2+6*q+4,
'D4':q**6+16*q**5+132*q**4+480*q**3+432*q**2-64,
'D5':q**4-12*q**3-56*q**2-96*q-16,
'D6':3*q**3+30*q**2-4*q-8,
'D7':q**3+5*q**2-4*q-4,
'D8':q**2+q+2,
'D9':q**3+10*q**2+36*q+8,
'D10':5*q**3+26*q**2-4*q-8,
}

# R3 row meta-types / Arch faces.
ARCH=['A_SIGMA0','A_SIGMA1','A_TAILSAT']
ROW_TYPES=['K_LT_G','K_EQ_G','G_LT_K']

# Additive generators carried by each coefficient row.
K_LINEAR=['B11','B21','B31']
G_LINEAR=['B10','B40']
G_HIGHER=['H20','H30']

# R3 exact targets, represented symbolically as strings in downstream ledgers.
T2='2*v2(d)+k+3+v2(x)'
T5='2*v5(d)+2*b5+2*c5+k+v5(x)'

# Linear coefficient term-base valuations after B_i=h L_i, on q ten-unit.
# These are valuations of term excluding v_p(L_i). p2 uses v2(t)=0 and c,q+4 2-units.
P2_BASE={
'B10':'g+1+v2(d)+v2(h)',
'B40':'4*g+v2(alpha)+v2(h)',
'B11':'g+k+2+v2(d)+v2(x)+v2(h)',
'B21':'g+k+2+v2(d)+v2(x)+v2(h)',
'B31':'g+k+2+v2(d)+v2(x)+v2(h)',
}
P5_BASE={
'B10':'g+v5(d)+v5(t)+b5+v5(h)',
'B40':'4*g+v5(alpha)+b5+v5(h)',
'B11':'g+k+v5(d)+v5(x)+b5+c5+v5(h)',
'B21':'g+k+v5(d)+v5(x)+b5+c5+v5(h)',
'B31':'g+k+v5(d)+v5(x)+b5+c5+v5(h)',
}
P2_REQ={
'B10':'max(0, v2(d)+k+2+v2(x)-g-v2(h))',
'B40':'max(0, 2*v2(d)+k+3+v2(x)-4*g-v2(alpha)-v2(h))',
'B11':'max(0, v2(d)+1-g-v2(h))',
'B21':'max(0, v2(d)+1-g-v2(h))',
'B31':'max(0, v2(d)+1-g-v2(h))',
}
P5_REQ={
'B10':'max(0, v5(d)+b5+2*c5+k+v5(x)-g-v5(t)-v5(h))',
'B40':'max(0, 2*v5(d)+b5+2*c5+k+v5(x)-4*g-v5(alpha)-v5(h))',
'B11':'max(0, v5(d)+b5+c5-g-v5(h))',
'B21':'max(0, v5(d)+b5+c5-g-v5(h))',
'B31':'max(0, v5(d)+b5+c5-g-v5(h))',
}
