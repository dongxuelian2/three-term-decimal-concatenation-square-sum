#!/usr/bin/env python3
from pathlib import Path
import csv,itertools
from J2_65_R4_common import *
OUT=Path(__file__).resolve().parent

def write_tsv(name,rows,fields):
    with (OUT/name).open('w',newline='',encoding='utf-8') as fh:
        w=csv.DictWriter(fh,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(rows)

def coeffs(rt):
    if rt=='K_LT_G': return ['C_0_1','C_1_1','C_2_1','C_3_1','C_4_1']
    if rt=='G_LT_K': return ['C_1_0','C_2_0','C_3_0','C_4_0','C_5_0']
    return ['C_0_1','C_1_1','C_2_1','C_3_1','C_4_1','C_1_0','C_2_0','C_3_0','C_4_0','C_5_0']

def brackets(rt):
    if rt=='K_LT_G': return K_LINEAR
    if rt=='G_LT_K': return G_LINEAR+G_HIGHER
    return []

def linear_brackets(rt):
    if rt=='K_LT_G': return K_LINEAR
    if rt=='G_LT_K': return G_LINEAR
    return []

def mechanism(rt):
    if rt=='K_EQ_G': return 'C1_CROSS_ROW_TIE; no additive lift forced'
    return 'C2_INTERNAL_NATURAL_TIE OR C3_ADDITIVE_BRACKET_LIFT; R3 meta-cell does not force which disjunct'

def dets_for_sets(s1,s2):
    ss=[]
    allids=sorted(set(s1+s2),key=lambda z:LINEAR_IDS.index(z))
    for a,b in itertools.combinations(allids,2):
        ss.append(f'DELTA({a},{b})')
    return ';'.join(ss)

cells=[]; depth=[]; classmap={}
idx=0
for arch in ARCH:
  for p2 in ROW_TYPES:
    for p5 in ROW_TYPES:
      idx+=1; cid=f'R4C{idx:02d}'
      b2=brackets(p2); b5=brackets(p5); l2=linear_brackets(p2); l5=linear_brackets(p5)
      reqd=dets_for_sets(l2,l5)
      if p2=='K_EQ_G' and p5=='K_EQ_G': status='OPEN_C1_CROSS_ROW_NO_BRACKET_FORCED'
      else: status='OPEN_FINITE_LINE_CONIC_CANCELLATION_COMPLEX'
      cells.append(dict(cell_id=cid,arch_face=arch,p2_row_type=p2,p5_row_type=p5,
                        possible_p2_min_coefficients=';'.join(coeffs(p2)),possible_p5_min_coefficients=';'.join(coeffs(p5)),
                        required_p2_brackets=';'.join(b2) if b2 else 'NONE_FORCED',required_p5_brackets=';'.join(b5) if b5 else 'NONE_FORCED',
                        required_pairwise_determinants=reqd if reqd else 'NONE_FORCED',status=status,
                        p2_mechanism=mechanism(p2),p5_mechanism=mechanism(p5)))
      key=(p2,p5)
      classmap.setdefault(key,[]).append(cid)
      # Conditional depth-to-target metadata, not a claim that the bracket is mandatory.
      for place,rt,bs,reqmap in [('p2',p2,b2,P2_REQ),('p5',p5,b5,P5_REQ)]:
          for bid in bs:
              if bid in reqmap:
                  partners=[z for z in set(l2+l5) if z!=bid]
                  depth.append(dict(cell_id=cid,place=place,bracket_id=bid,required_depth=reqmap[bid],depth_expression=reqmap[bid],
                                    partner_bracket=';'.join(sorted(partners)) if partners else 'NONE',
                                    reason='CONDITIONAL: if this bracket-bearing coefficient is the unique sub-target minimum and must be lifted to row target; R3 meta-cell alone does not force this disjunct'))
              else:
                  depth.append(dict(cell_id=cid,place=place,bracket_id=bid,required_depth='N/A_CONIC',depth_expression='valuation of homogeneous quadratic Type-H generator',
                                    partner_bracket='H20/H30 or line-conic resultant kernel',
                                    reason='Type H is live only in G-row internal refinements; tracked by finite resultant complex rather than scalar projective-line depth'))

assert len(cells)==27 and len(classmap)==9
write_tsv('J2-65-R4-LiftedThreePlaceCells.tsv',cells,
          ['cell_id','arch_face','p2_row_type','p5_row_type','possible_p2_min_coefficients','possible_p5_min_coefficients','required_p2_brackets','required_p5_brackets','required_pairwise_determinants','status','p2_mechanism','p5_mechanism'])
write_tsv('J2-65-R4-BracketDepthRequirements.tsv',depth,
          ['cell_id','place','bracket_id','required_depth','depth_expression','partner_bracket','reason'])

qrows=[]
pattern_ids={key:f'BPF{n:02d}' for n,key in enumerate(classmap.keys(),1)}
strict_n=0
for r in cells:
    strict_n+=1
    key=(r['p2_row_type'],r['p5_row_type'])
    p2,p5=key
    b2=brackets(p2);b5=brackets(p5);l2=linear_brackets(p2);l5=linear_brackets(p5)
    same=sorted(set(b2).intersection(b5))
    qrows.append(dict(strict_class_id=f'BEQ{strict_n:02d}',bracket_pattern_fibre=pattern_ids[key],arch_face=r['arch_face'],
                      p2_row_type=p2,p5_row_type=p5,origin_cells=r['cell_id'],multiplicity=1,
                      p2_bracket_set=';'.join(b2) if b2 else 'NONE',p5_bracket_set=';'.join(b5) if b5 else 'NONE',
                      determinant_support=dets_for_sets(l2,l5) or 'NONE',ten_primary_same_brackets=';'.join(same) if same else 'NONE',
                      arch_escape_condition=r['arch_face'],status='STRICT_EQUIVALENCE_SINGLETON; shares bracket fibre across Arch base'))
write_tsv('J2-65-R4-BracketCellQuotient.tsv',qrows,
          ['strict_class_id','bracket_pattern_fibre','arch_face','p2_row_type','p5_row_type','origin_cells','multiplicity','p2_bracket_set','p5_bracket_set','determinant_support','ten_primary_same_brackets','arch_escape_condition','status'])

bothcross=sum(1 for r in cells if r['p2_row_type']=='K_EQ_G' and r['p5_row_type']=='K_EQ_G')
atleastcross=sum(1 for r in cells if r['p2_row_type']=='K_EQ_G' or r['p5_row_type']=='K_EQ_G')
internal=sum(1 for r in cells if r['p2_row_type']!='K_EQ_G' or r['p5_row_type']!='K_EQ_G')
print('R4 CELL LIFT CERTIFICATE')
print('R3_META_CELL_REGRESSION=PASS')
print('R3_META_CELL_COUNT=27')
print('R4_BRACKET_EQUIVALENCE_CLASSES=27_STRICT')
print('R4_BRACKET_PATTERN_FIBRES=9')
print('BOTH_PLACES_CROSS_ROW_CELL_COUNT='+str(bothcross))
print('CELLS_WITH_AT_LEAST_ONE_CROSS_ROW='+str(atleastcross))
print('CELLS_WITH_INTERNAL_PLACE='+str(internal))
print('CROSS_ROW_CELL_COUNT=3  # both places C1')
print('INTERNAL_MONOMIAL_CELL_COUNT=0_FORCED (C2 remains a disjunct inside internal cells)')
print('GENUINE_BRACKET_LIFT_CELL_COUNT=0_FORCED;24_POTENTIAL')
print('CELLS_CLOSED_BY_DETERMINANT_GCD=0_RAW_META_CELLS')
print('WHY_ZERO_RAW_CLOSURES=R3 row-order cells do not force a specific bracket pair or positive depth; determinant theorem kills refined C3 subcells, not an entire row-order meta-cell without further inequalities')
