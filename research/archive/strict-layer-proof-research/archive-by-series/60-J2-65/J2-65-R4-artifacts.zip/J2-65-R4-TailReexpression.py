#!/usr/bin/env python3
from pathlib import Path
import csv
import sympy as sp
from J2_65_R4_common import *
OUT=Path(__file__).resolve().parent
Nsym,Zsym,a3sym=sp.symbols('N Z a3', integer=True)
rows=[]
# Exact tail substitution alpha=d(qcN-Bt)/G.
alpha_tail=d*(q*c*Nsym-Btail*t)/G
for bid in LINEAR_IDS:
    B=linear_expr(bid).subs(T,d*t)
    sub=sp.factor(sp.cancel(B.subs(alpha,alpha_tail)))
    expected=sp.factor(d/G*(U[bid]*q*c*Nsym+(V[bid]*G-U[bid]*Btail)*t))
    assert sp.cancel(sub-expected)==0
    # Check projective proportionality to the exact DTF mismatch direction (-alpha+cT).
    mismatch_det=sp.factor(U[bid]*c+V[bid])
    assert mismatch_det!=0
    rows.append(dict(bracket_id=bid,original_expression=str(sp.factor(B)),tail_substituted_expression=str(sub),
                     known_old_linear_form='NONE_EXACT; exact tail substitution shown; DTF mismatch direction determinant='+str(mismatch_det),
                     dependency_status='NEW_LINEAR_COMBINATION_NOT_OLD_ZERO_FORM',retire='FALSE'))
for bid,H in higher_exprs().items():
    sub=sp.factor(sp.cancel(H.subs({alpha:alpha_tail,T:d*t,Y:d*x})*G**2/d**2))
    rows.append(dict(bracket_id=bid,original_expression=str(H),tail_substituted_expression='(G^2/d^2)*H_after_tail = '+str(sub),
                     known_old_linear_form='NOT_LINEAR; homogeneous quadratic after tail substitution',dependency_status='NEW_HIGHER_DEGREE_GENERATOR',retire='FALSE'))
with (OUT/'J2-65-R4-TailReexpression.tsv').open('w',newline='',encoding='utf-8') as fh:
    w=csv.DictWriter(fh,fieldnames=['bracket_id','original_expression','tail_substituted_expression','known_old_linear_form','dependency_status','retire'],delimiter='\t');w.writeheader();w.writerows(rows)
print('R4 TAIL REEXPRESSION CERTIFICATE')
print('TAIL_REEXPRESSION_AUDIT=PASS')
print('BRACKETS_RETIRED_AS_OLD_SHADOWS=0')
print('LINEAR_BRACKETS_NEW_EXACT_COMBINATIONS=5')
print('HIGHER_BRACKETS_NEW=2')
print('TAIL_CONGRUENCE_USED_AS_DEPENDENCY_EQUALITY=FALSE')
