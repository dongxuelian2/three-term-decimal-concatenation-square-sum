#!/usr/bin/env python3
import sympy as sp
from J2_65_R4_common import *

for bid in LINEAR_IDS:
    B=linear_expr(bid)
    L=linear_expr(bid,primitive=True)
    ck=sp.expand(B.subs({alpha:h*A0,T:h*T0})-h*L)
    assert ck==0, (bid,ck)

for i in range(len(LINEAR_IDS)):
    for j in range(i+1,len(LINEAR_IDS)):
        bi,bj=LINEAR_IDS[i],LINEAR_IDS[j]
        Li,Lj=linear_expr(bi,True),linear_expr(bj,True)
        Delta=determinant(bi,bj)
        assert sp.expand(V[bj]*Li-V[bi]*Lj-Delta*A0)==0
        assert sp.expand(U[bi]*Lj-U[bj]*Li-Delta*T0)==0
        assert Delta!=0

# Source-level nonzero gate is inherited, not rediscovered here:
# t is odd (hence nonzero), d is a localized structural factor, and q>1 alpha=0 is retired.
print('R4 PROJECTIVIZATION CERTIFICATE')
print('T_ZERO_STATUS=NONZERO (source: t odd; d structural nonzero)')
print('ALPHA_ZERO_QGT1=RETIRED_INHERITED_R3')
print('PRIMITIVE_PROJECTIVIZATION=PASS')
print('GCD_ALPHA_DT_THEOREM=NO_GLOBAL_h=1_THEOREM_RECOVERED')
print('P2_h_CONTENT=v2(h)=min(v2(alpha),v2(d)) because v2(t)=0')
print('P5_h_CONTENT=v5(h)=min(v5(alpha),v5(d)+v5(t))')
print('PAIRWISE_DETERMINANT_IDENTITIES=PASS')
print('PAIRWISE_GCD_DIVIDES_DETERMINANT=PROVED_BY_PRIMITIVITY')
