#!/usr/bin/env python3
"""R19 exact source quotient-map certificate.

The canonical ambient is R18's semantic ambient: fixed decimal chart and
contact-height line are built into L0.  The moving packet is therefore the
transported M0 source row plus the post-Schur conductor coordinate V mod q^2.
"""
from math import gcd

def crt_idempotents(M0,q):
    assert gcd(M0,q)==1
    q2=q*q; m=M0*q2
    eM=(q2*pow(q2,-1,M0))%m
    eq=(M0*pow(M0,-1,q2))%m
    assert eM%M0==1 and eM%q2==0
    assert eq%M0==0 and eq%q2==1
    return eM,eq

THEOREM="""
beta0=u(1+2u)^3.
Let ell_M^sem be the transport to the R18 semantic ambient L0 of the exact
pre-Schur row ell_M(Z,a,h)=Z+beta0*a.  Let ell_q(R,V,H)=V.
Then
  pi_tilde(v)=(ell_M^sem(v) mod M0, V(v) mod q^2)
lands in Z/M0 direct_sum Z/q^2, and the actual source lattice is its kernel.
Under the canonical CRT isomorphism, with e_M and e_q the two idempotents,
  pi_src(v)=e_M*ell_M^sem(v)+e_q*V(v) mod M0*q^2.
The source class is 0.  No affine translation occurs.
"""
print('SOURCE_PACKET_MODULUS=m_src=M0*q^2')
print('SOURCE_QUOTIENT_MAP=CRT(e_M*ell_M_sem + e_q*V)')
print('SOURCE_CLASS=0')
print('SOURCE_LATTICE_IS_KERNEL_OR_COSET=KERNEL')
print('SOURCE_QUOTIENT_CYCLIC=TRUE')
print('RAW_RVH_EXPANSION_OF_ell_M=NOT_PRINTED_BY_R18; SEMANTIC_TRANSPORT_IS_EXACT')
print('PRIME_FACTORIZATION_USED=FALSE')
