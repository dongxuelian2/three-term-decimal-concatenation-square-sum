#!/usr/bin/env python3
"""Witness-dependent degree-2 parametrization of a split ternary conic."""
import sympy as sp
s,t,D,C,pR,pV,pH=sp.symbols('s t D C pR pV pH')
qx=s**2-D*t**2
b=pR*s-D*pV*t
FR=sp.expand(qx*pR-2*b*s)
FV=sp.expand(qx*pV-2*b*t)
FH=sp.expand(qx*pH)
QF=sp.factor(FR**2-D*FV**2-C*FH**2)
Qp=pR**2-D*pV**2-C*pH**2
assert sp.factor(QF-qx**2*Qp)==0
print('RATIONAL_ISOTROPIC_BASEPOINT=WITNESS_DEPENDENT')
print('BASEPOINT_CONDITION=pR^2-D0*pV^2-F0*N0*pH^2=0')
print('ISOTROPIC_VERONESE_MAP:')
print('R=',sp.factor(FR))
print('V=',sp.factor(FV))
print('H=',sp.factor(FH))
print('VERONESE_DEGREE=2')
print('IDENTITY=Q0(F(s,t))=(s^2-D0*t^2)^2*Q0(p)')
print('PROJECTIVE_PARAMETERIZATION=PROVED_ON_TRANSVERSE_CHART')
print('INTEGRAL_PARAMETERIZATION=PROVED_AFTER_CLEARING_ONE_BASEPOINT_DENOMINATOR; PRIMITIVE_NORMALIZATION_REQUIRES_CONTENT')
print('PRIMITIVE_CONTENT_FUNCTION=gcd(F_R(s,t),F_V(s,t),F_H(s,t))')
