#!/usr/bin/env python3
"""Congruence--Archimedean independence on the split conic."""
THEOREM="""
On a rationally split conic C~=P1, let U_infty be a nonempty real open arc and
let U_m be a nonempty finite congruence neighborhood in P1(Q) representing an
admissible parameter class modulo the whole integer m.  Weak approximation on
P1 gives a rational parameter lying in U_infty and U_m simultaneously.  After
clearing denominators by an integer which is a unit at the finite modulus and
then primitive normalization, the finite projective class is unchanged.
Therefore the real digit arc creates no additional obstruction after finite
admissibility has been proved.
"""
print('REAL_DIGIT_ARC_NONEMPTY=CONDITIONAL_ON_R18/R15_REAL_SHELL_HYPOTHESIS')
print('FINITE_CLASS_ADMISSIBLE=UNRESOLVED')
print('CONGRUENCE_ARCHIMEDEAN_INDEPENDENCE=PROVED_CONDITIONAL_ON_FINITE_ADMISSIBILITY')
print('EXPLICIT_P1_APPROXIMATION_USED=TRUE')
print('PRIMITIVE_NORMALIZATION=PROJECTIVELY_LEGAL_WHEN_FINITE_CLASS_IS_UNIMODULAR')
print('SHELL_IS_NOT_THE_CURRENT_INDEPENDENT_OBSTRUCTION=TRUE')
