#!/usr/bin/env python3
"""Pull the exact moving packet back through the degree-2 isotropic map."""
THEOREM="""
Let nu_p=[F_R:F_V:F_H] be the R19 degree-2 Veronese chart.
The q^2 conductor equation is F_V(s,t)=0 mod q^2.
The M0 equation is (ell_M^sem o nu_p)(s,t)=0 mod M0, where ell_M^sem is
R18's exact transported source row.  Because ell_M^sem is linear and nu_p is
quadratic, this is a homogeneous binary quadratic congruence.  CRT recombines
both equations into one degree-2 condition Phi_m(s,t)=0 in Z/(M0*q^2), with
no prime decomposition.
"""
print('PACKET_PULLBACK_TO_P1=Phi_m(s,t)=0 modulo m_src')
print('PACKET_PULLBACK_DEGREE=2')
print('q2_COMPONENT=F_V(s,t)==0 mod q^2')
print('M0_COMPONENT=(ell_M_sem o nu_p)(s,t)==0 mod M0')
print('SOURCE_PARAMETER_SUBSET_MOD_m=closed degree-2 projective subscheme')
print('SOURCE_PARAMETER_SUBSET=PROPER_COMPLEX_UNLESS_A_SEPARATE_IDENTITY_IS_PROVED')
print('WITNESS_CHOICE=GAUGE; DIFFERENT_BASEPOINTS_ARE_RELATED_OVER_Q_BY_SPIN')
print('PRIME_DECOMPOSITION_USED=FALSE')
