#!/usr/bin/env python3
"""Correct integral/semantic group definition."""
print('AMBIENT_LATTICE=L0=R18 canonical semantic lattice (fixed decimal chart + contact-height line)')
print('GAMMA_SPIN={g in Spin(Q0)(Q): g(L0)=L0}')
print('SEMANTIC_STABILIZER=GAMMA_SPIN')
print('FIXED_DECIMAL_CONTACT_ALREADY_BUILT_INTO_L0=TRUE')
print('DIGIT_HEIGHT_FUNCTIONAL_GROUP_INVARIANT=FALSE')
print('FULL_RAW_SPIN_TRANSITIVITY_IS_NOT_A_LEGAL_SUBSTITUTE=TRUE')
print('SEMANTIC_INDEX_IN_RAW_SPIN=NOT_USED')
print('BAD_REDUCTION_M0_PERSISTS_IN_SEMANTIC_MODULE=TRUE')
