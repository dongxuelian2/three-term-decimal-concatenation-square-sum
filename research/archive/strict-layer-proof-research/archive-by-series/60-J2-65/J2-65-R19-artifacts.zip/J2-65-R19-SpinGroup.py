#!/usr/bin/env python3
"""R19 Clifford/Spin structural certificate for the q-free ternary form."""
import sympy as sp
R,V,H,D,C=sp.symbols('R V H D C', nonzero=True)
Q=R**2-D*V**2-C*H**2
# determinant of the diagonal Gram matrix
Gram=sp.diag(1,-D,-C)
assert sp.factor(Gram.det()-D*C)==0
print('Q0_DIMENSION=3')
print('Q0_SIGNATURE=(2,1)  # inherited on actual smooth fibres')
print('EVEN_CLIFFORD_ALGEBRA=quaternion algebra C0(Q0)')
print('SPIN_Q0_TYPE=A1')
print('SPIN_Q0_RATIONAL_SPLIT=CONDITIONAL_ON_ISOTROPY')
print('IF_Q0(Q)_NONEMPTY_THEN_C0_Q0=M2(Q)_AND_SPIN_Q0=SL2=TRUE')
print('RATIONAL_CONJUGATING_MATRIX=WITNESS_DEPENDENT_FROM_ONE_ISOTROPIC_POINT')
print('INTEGRAL_SPIN_LATTICE=norm-one units of the even-Clifford order stabilizing L0')
print('INTEGRAL_GROUP_NOT_IDENTIFIED_WITH_SL2Z=TRUE')
