#!/usr/bin/env python3
"""Whole-composite finite-orbit audit, deliberately without factoring M0 or q."""
import sympy as sp
G,u,K=sp.symbols('G u K', integer=True)
A=2*u+1
F0=G*A*(G*A+2)
T0=2*K*G*u
W0=G**4*A**2+400*u**2
S0=G**2*A*T0+20*u
D0=sp.expand(S0**2-F0*W0)
# M0 divides G.  These polynomial divisibilities certify the whole-module reduction.
assert sp.rem(F0,G,G)==0
assert sp.rem(D0-S0**2,G,G)==0
assert sp.rem(S0-20*u,G,G)==0
assert sp.factor(D0-400*u**2).subs(G,0)==0
print('COMPOSITE_MODULUS=m_src=M0*q^2')
print('PRIME_FACTORIZATION_USED=FALSE')
print('PRIMITIVE_ISOTROPIC_MOD_m_DEFINED=TRUE')
print('M0_DIVIDES_G=TRUE')
print('Q0_MOD_M0=(R-20*u*V)*(R+20*u*V)')
print('M0_REDUCTION_RANK_LEQ_2=TRUE')
print('M0_REDUCTION_SMOOTH_TERNARY=FALSE')
print('SMOOTH_SPLIT_SPIN_TRANSITIVITY_THEOREM_APPLICABLE=FALSE')
print('RULING_IDEAL_INVARIANT=((R-20uV),(R+20uV)) in ideals of Z/M0Z')
print('SPIN_ORBIT_COUNT=UNCLASSIFIED_BAD_REDUCTION')
print('SPIN_ACTION_TRANSITIVE=PARTIAL; SMOOTHNESS_HYPOTHESIS_FAILS')
print('ORBIT_COUNT_UNIFORM_O1=NOT_PROVED')
