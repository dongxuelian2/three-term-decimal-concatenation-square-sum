#!/usr/bin/env python3
"""Strong/weak approximation applicability audit."""
print('RATIONAL_SPLIT_GROUP=Spin(Q0)~=SL2 over Q, conditional on Q0(Q)!=empty')
print('ABSTRACT_GROUP_STRONG_APPROXIMATION=APPLICABLE_TO_SPLIT_SIMPLY_CONNECTED_GROUP')
print('STRONG_APPROXIMATION_APPLICABLE=PARTIAL')
print('WHY_PARTIAL=integral semantic lattice has bad reduction on M0 and conductor section is not known to be in the same finite orbit')
print('STRONG_APPROXIMATION_CANNOT_CREATE_AN_EMPTY_OR_DIFFERENT_FINITE_ORBIT=TRUE')
print('EXPLICIT_P1_APPROXIMATION_USED=TRUE_CONDITIONALLY')
print('FINITE_CLASS_ADMISSIBLE=UNRESOLVED')
print('MISSING_THEOREM=SEMANTIC_CONDUCTOR_RULING_LIFTING')
