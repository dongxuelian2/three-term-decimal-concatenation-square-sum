#!/usr/bin/env python3
from pathlib import Path
import subprocess
D=Path(__file__).resolve().parent
scripts=[
'J2-65-R19-SourceQuotient.py','J2-65-R19-SpinGroup.py','J2-65-R19-CompositeOrbit.py',
'J2-65-R19-IsotropicVeronese.py','J2-65-R19-PacketPullback.py','J2-65-R19-ConductorAutomaticity.py',
'J2-65-R19-StrongApproximation.py','J2-65-R19-DigitShellApproximation.py','J2-65-R19-SemanticStabilizer.py']
required=[
'J2-65-R19-Finite-Module-Spin-Report.md',*scripts,'J2-65-R19-Regression.py',
'J2-65-R19-SourceQuotientMap.tsv','J2-65-R19-SpinGroup.tsv','J2-65-R19-CompositeOrbit.tsv',
'J2-65-R19-IsotropicVeronese.tsv','J2-65-R19-PacketPullback.tsv','J2-65-R19-ConductorPacket.tsv',
'J2-65-R19-SemanticStabilizer.tsv','J2-65-R19-DigitShellApproximation.tsv','J2-65-R19-FinitePacketVerdict.tsv',
'J2-65-R19-certificate.txt']
for s in scripts:
    p=subprocess.run(['python',str(D/s)],capture_output=True,text=True)
    assert p.returncode==0,(s,p.stderr)
    print('SCRIPT_PASS='+s)
for f in required:
    p=D/f
    assert p.exists() and p.stat().st_size>0,f
print('REQUIRED_ARTIFACT_AUDIT=PASS')
text='\n'.join((D/s).read_text(encoding='utf-8') for s in scripts)
for banned in ['factorint(', 'prime_factors(', 'hensel', 'Pell']:
    assert banned not in text, banned
print('PRIME_FACTORIZATION_USED=FALSE')
print('RESIDUE_ENUMERATION_USED=FALSE')
print('PELL_UNIT_REOPENED=FALSE')
print('FIXED_g_k_q_SCAN_USED=FALSE')
print('M0_BAD_REDUCTION_REGRESSION=PASS')
print('VERONESE_IDENTITY_REGRESSION=PASS')
print('J2_STATUS=OPEN')
