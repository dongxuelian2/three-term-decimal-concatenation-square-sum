#!/usr/bin/env python3
"""Common exact symbolic source for J2-65-R6.

Reconstructs the R2 Level-1 master from the source definitions, then extracts
the two (G,K)-rows.  No R4/R5 refined stratum is used to define the master.
"""
from __future__ import annotations
import sympy as sp
import hashlib

G,K,q,d,alpha,t,x,X = sp.symbols('G K q d alpha t x X')
c = q**3+10*q**2+12*q+8
Btail = (q+2)*(q**2-4*q-4)
u=(G+1)/q
A=2*u+1
N=sp.cancel((Btail*t+alpha*G/d)/(q*c))
Z=sp.cancel((A*t-2*N)/(q*(q+4)))
a3=sp.cancel(((G-1)*t-q*N)/(2*(q+4)))
Xrad=sp.cancel((Z+u*N)/2)
D2=sp.cancel(u*a3+G*Xrad)
F=sp.cancel(A*Xrad**2+Z*D2)
QCLR=sp.cancel(A*G**2*x**2-8*K*u*D2*x+4*F)
QNUM,QDEN=sp.fraction(QCLR)
QNUM=sp.expand(QNUM)
QDEN=sp.factor(QDEN)
QDEN_EXPECTED=d**2*q**5*(q+4)**2*c**2
assert sp.factor(QDEN-QDEN_EXPECTED)==0

PGK=sp.Poly(QNUM,G,K)
P=sp.expand(sum(PGK.coeff_monomial(G**(i+1))*X**i for i in range(5)))
S=sp.expand(sum(PGK.coeff_monomial(G**i*K)*X**i for i in range(5)))
assert sp.expand(QNUM-(G*P.subs(X,G)+K*S.subs(X,G)))==0
assert sp.Poly(P,X).degree()==4
assert sp.Poly(S,X).degree()==4

C_P=sp.Integer(1)
C_S=4*d*q**2*x*(q+4)*c
Pstar=P
Sstar=sp.cancel(S/C_S)
assert sp.expand(S-C_S*Sstar)==0
T3=sp.factor(-Sstar/(X+1))
assert sp.expand(Sstar+(X+1)*T3)==0
assert sp.Poly(T3,X).degree()==3

Pminus=sp.factor(sp.Poly(P,X).eval(-1))

def sha(expr):
    return hashlib.sha256(str(sp.expand(expr)).encode()).hexdigest()

def primitive_poly_content(expr):
    poly=sp.Poly(expr,X)
    vals=poly.all_coeffs()
    g=vals[0]
    for z in vals[1:]:
        g=sp.gcd(g,z)
    return sp.factor(g)
