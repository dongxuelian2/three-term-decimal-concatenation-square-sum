#!/usr/bin/env python3
import hashlib
import sympy as sp
from J2_65_R6_common import *

Rpos=sp.resultant(Pstar,T3,X)
Rwhole=sp.resultant(Pstar,Sstar,X)
assert Rpos!=0 and Rwhole!=0
assert sp.factor(Rwhole-Pminus*Rpos)==0
fac_whole=sp.factor_list(Rwhole)
fac_pos=sp.factor_list(Rpos)
large=max((f for f,m in fac_pos[1]), key=lambda z: len(str(z)))
small_new=[f for f,m in fac_pos[1] if 50 < len(str(f)) < 500]
print("J2-65 R6 ROW RESULTANT CERTIFICATE")
print("ROW_RESULTANT_STATUS=NONZERO")
print("FULL_PRIMITIVE_RESULTANT_FACTOR_COUNT="+str(len(fac_whole[1])))
print("POSITIVE_ROOT_RESULTANT_FACTOR_COUNT="+str(len(fac_pos[1])))
print("RESULTANT_IDENTITY_RWHOLE_EQUALS_PMINUS1_TIMES_RPOS=PASS")
print("P_MINUS_ONE_FACTOR_COUNT="+str(len(sp.factor_list(Pminus)[1])))
print("L_ROW="+str(small_new[0] if small_new else 'NOT_FOUND'))
print("W_ROW_SHA256="+hashlib.sha256(str(sp.expand(large)).encode()).hexdigest())
