#!/usr/bin/env python3
import sympy as sp
from J2_65_R6_common import *

def content_X(expr):
    vals=sp.Poly(expr,X).all_coeffs(); g=vals[0]
    for z in vals[1:]: g=sp.gcd(g,z)
    return sp.factor(g)
subs=sp.subresultants(Pstar,Sstar,X)
degs=[sp.Poly(z,X).degree() for z in subs]
assert degs==[4,4,3,2,1,0],degs
print("J2-65 R6 ROW SUBRESULTANT CERTIFICATE")
print("ROW_SUBRESULTANT_LEVELS="+",".join(map(str,degs)))
for i,z in enumerate(subs):
    deg=sp.Poly(z,X).degree()
    ct=content_X(z)
    ctext=str(ct) if deg>0 else "FULL_RESULTANT_SEE_RowResultantFactors.tsv"
    print(f"SRES_{i}_DEG={deg} CONTENT={ctext} SHA256={sha(z)}")
print("GENERIC_GCD_DEGREE=0")
print("GENERIC_SYLVESTER_RANK=8")
