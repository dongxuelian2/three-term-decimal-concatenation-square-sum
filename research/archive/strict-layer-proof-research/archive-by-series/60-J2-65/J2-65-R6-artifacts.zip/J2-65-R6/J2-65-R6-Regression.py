#!/usr/bin/env python3
import sympy as sp
from J2_65_R6_common import *
assert sp.expand(QNUM-(G*P.subs(X,G)+K*S.subs(X,G)))==0
assert sp.factor(QDEN-d**2*q**5*(q+4)**2*c**2)==0
assert sp.factor(Sstar+(X+1)*T3)==0
assert sp.factor(QDEN.subs(q,1)-25*d**2*31**2)==0
print("J2-65 R6 REGRESSION CERTIFICATE")
print("R2_EXACT_MASTER=PASS")
print("R3_FINE_CELLS_REOPENED=FALSE")
print("R4_BRACKETS_REOPENED=FALSE")
print("R5_FINE_STRATA_REOPENED=FALSE")
print("Q1_TWO_ROW_DECOMPOSITION=PASS")
