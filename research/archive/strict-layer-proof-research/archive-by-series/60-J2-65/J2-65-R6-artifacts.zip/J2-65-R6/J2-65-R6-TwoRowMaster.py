#!/usr/bin/env python3
from __future__ import annotations
import csv
import sympy as sp
from J2_65_R6_common import *

assert sp.expand(QNUM-(G*P.subs(X,G)+K*S.subs(X,G)))==0
assert sp.Poly(P,X).degree()==4 and sp.Poly(S,X).degree()==4
assert primitive_poly_content(P)==1
assert sp.factor(primitive_poly_content(S)-C_S)==0

print("J2-65 R6 TWO-ROW MASTER CERTIFICATE")
print("TWO_ROW_MASTER_REGRESSION=PASS")
print("ROW_P_DEGREE=4")
print("ROW_S_DEGREE=4")
print("ROW_P_CONTENT=1")
print("ROW_S_CONTENT="+str(sp.factor(C_S)))
print("S_PRIMITIVE_FACTOR_X_PLUS_1=PROVED")
print("S_PRIMITIVE_REDUCED_DEGREE=3")
