#!/usr/bin/env python3
import itertools
import sympy as sp
from J2_65_R6_common import *

AA,TT,YY=sp.symbols("AA TT YY")
rawP=[sp.expand(sp.Poly(P,X).coeff_monomial(X**i).subs({d:1,t:TT,x:YY,alpha:AA})) for i in range(5)]
rawS=[sp.expand(sp.Poly(S,X).coeff_monomial(X**i).subs({d:1,t:TT,x:YY,alpha:AA})) for i in range(5)]
mons=[AA**2,AA*TT,TT**2,YY**2,AA*YY,TT*YY]
L=sp.Matrix([[sp.Poly(e,AA,TT,YY).coeff_monomial(m) for m in mons] for e in rawP+rawS])
assert L.rank()==6
assert L[:5,:4].rank()==4
assert L[5:,4:].rank()==2
assert len(L.T.nullspace())==4

# Generic projective dimension: chart AA=1, r=TT/AA, s=YY/AA.
r,s=sp.symbols("r s")
vals=[sp.factor(e.subs({AA:1,TT:r,YY:s})) for e in rawP+rawS]
den=vals[4] # C50=2(q+4)^2
outs=[sp.cancel(vals[i]/den) for i in (0,5,6)]
J=sp.Matrix([[sp.diff(f,v) for v in (q,r,s)] for f in outs])
det=sp.factor(J.det())
assert det!=0
assert det.subs({q:1,r:1,s:1})!=0

# K-block minor identities expose coefficient-minor geometry.
KB=L[5:,4:]
mins={}
for i,j in itertools.combinations(range(5),2):
    mins[(i,j)]=sp.factor(KB[[i,j],:].det())

print("J2-65 R6 COEFFICIENT IMAGE CERTIFICATE")
print("COEFFICIENT_LINEAR_MAP_RANK=6")
print("FIXED_Q_IMAGE_DIMENSION=2")
print("GLOBAL_IMAGE_DIMENSION=3")
print("GLOBAL_IMAGE_CODIMENSION_IN_P9=6")
print("LINEAR_SYZYGY_DIMENSION_OVER_Q(q)=4")
print("LATENT_VERONESE_QUADRICS=6")
print("COEFFICIENT_MATRIX_2x5_GENERIC_RANK=2")
print("JACOBIAN_SAMPLE_DET="+str(sp.factor(det.subs({q:1,r:1,s:1}))))
