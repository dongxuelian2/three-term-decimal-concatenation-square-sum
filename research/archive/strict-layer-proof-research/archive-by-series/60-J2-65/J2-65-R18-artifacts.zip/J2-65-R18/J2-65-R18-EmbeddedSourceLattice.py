#!/usr/bin/env python3
# Exact structural source embedding. r_a,r_h,v_Z,v_a,v_h are the exact
# integer row coefficients of R16's B_N0, not new parameters.
print("BOUNDARY_QFREE_BASIS_COLUMNS:")
print("(M0,0,0),(rho0,1,-A),(0,0,10)")
print("M0=G/gcd(G,2*d*(1+4u))")
print("rho0 == -u*(1+2u)^3 (mod M0)")
print("R16_PRE_EXTRA_ROWS: r0=r_a*a+r_h*h; v0=v_Z*Z+v_a*a+v_h*h")
print("QFREE_EMBEDDING_MATRIX_ROWS:")
print("[0, r_a-A*r_h, 10*r_h]")
print("[q^2*v_Z*M0, q^2*(v_Z*rho0+v_a-A*v_h), 10*q^2*v_h]")
print("[0, -A*MU0, 10*MU0]")
print("CONTACT_HEIGHT_LINE=MU0*Z inside the chosen ambient lattice")
print("UNIVERSAL_ORDER_PACKET=Z/q^2Z")
print("DECIMAL_AMBIENT_SOURCE_PACKET=Z/M0Z direct_sum Z/q^2Z")
print("gcd(M0,q)=1 => DECIMAL_AMBIENT_SOURCE_PACKET ~= Z/(M0*q^2)Z")
