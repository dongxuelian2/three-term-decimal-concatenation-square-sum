#!/usr/bin/env python3
import sympy as sp
R,V,H,D0,J0,W0,N0,F0=sp.symbols("R V H D0 J0 W0 N0 F0")
# Assumptions encoded as polynomial relations:
# R^2-D0 V^2-F0 N0 H^2=0 and D0+J0^2-W0 N0=0.
lhs=R**2+(J0*V)**2-N0*(W0*V**2+F0*H**2)
reduced=sp.expand(lhs.subs(D0,W0*N0-J0**2))
# Replace R^2 using ambient equation:
reduced=sp.expand(reduced.subs(R**2,(W0*N0-J0**2)*V**2+F0*N0*H**2))
assert reduced==0
print("CAS_IDENTITY=PASS")
print("R^2+(J0*V)^2=N0*(W0*V^2+F0*H^2)")
print("Q_AUX=W0*V^2+F0*H^2")
print("Q_AUX_CONTENT=gcd(W0,F0)")
print("Q_AUX_DISCRIMINANT=-4*W0*F0")
print("Q_AUX_POSITIVE=TRUE")
print("COMPOSITION_ADAPTED_SOURCE_COORDINATES=NOT_FOUND")
