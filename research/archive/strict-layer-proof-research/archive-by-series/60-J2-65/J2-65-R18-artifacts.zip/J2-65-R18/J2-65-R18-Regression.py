#!/usr/bin/env python3
import sympy as sp
G,u,q,K=sp.symbols("G u q K", integer=True)
A=2*u+1
F0=G*A*(G*A+2)
U0=G**2*A; V0=20*u; W0=U0**2+V0**2
T0=2*K*G*u; S0=U0*T0+V0; J0=U0-V0*T0
N0=T0**2-(G*A+1)**2+2
D0=sp.expand(S0**2-F0*W0)
assert sp.expand(D0+J0**2-W0*N0)==0
e1=sp.factor(u**5*q**4*(q+4)-(1+4*u))
e2=sp.factor(u**5*(q+2)**3*(q+4)-u*(1+2*u)**3*(1+4*u))
assert sp.factor(e1/(u*q-1)).is_polynomial(G,u,q,K)
assert sp.factor(e2/(u*q-1)).is_polynomial(G,u,q,K)
print("R18_REGRESSION=PASS")
print("SOURCE_ROW_CYCLOTOMIC_REDUCTION=PASS")
print("MASTER_COMPOSITION_REGRESSION=PASS")
print("QFREE_AMBIENT_ALGEBRA=PASS")
print("PRIME_FACTORIZATION_USED=FALSE")
print("PELL_UNIT_PHASE_REOPENED=FALSE")
print("q1_REOPENED=FALSE")
print("GENERAL_J_REOPENED=FALSE")
