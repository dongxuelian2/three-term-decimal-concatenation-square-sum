#!/usr/bin/env python3
import sympy as sp
G,u,K,q=sp.symbols("G u K q", integer=True)
A=2*u+1
F0=G*A*(G*A+2)
U0=G**2*A
V0=20*u
W0=U0**2+V0**2
T0=2*K*G*u
S0=U0*T0+V0
J0=U0-V0*T0
N0=T0**2-(G*A+1)**2+2
D0=sp.expand(S0**2-F0*W0)
assert sp.expand(D0+J0**2-W0*N0)==0
mu0=20*G**2*q**4*(G+1)
print("MU0=",mu0)
print("MU0_INTEGRAL=TRUE")
print("AMBIENT_COORDINATES=R=r0; V=q^2*v0; H=MU0*h")
print("Q_FREE_AMBIENT_FORM=R^2-D0*V^2-F0*N0*H^2")
print("Q_FREE_AMBIENT_COEFFICIENTS_DEPEND_ONLY_ON_G_u_K=TRUE")
print("NOTE=C_extra is avoided by using the pre-extra R16 coordinates (r0,v0)")
