#!/usr/bin/env python3
# Structural certificate. No prime factorization is used.
print("CYCLOTOMIC_SOURCE_SATURATION=PROVED")
print("DEFINITION=legal row-equivalence/saturation inside the fixed boundary coordinate lattice")
print("OLD_CONGRUENCE=G | d*(hZ*Z+ha*a)")
print("NEW_EQUIVALENT_CONGRUENCE=G | 2*d*(1+4u)*(Z+u*(1+2u)^3*a)")
print("WHY_EQUIVALENT=multiply the congruence row by u^5, a unit modulo G")
print("delta_old=gcd(G,2*d*(q+4))")
print("delta0=gcd(G,2*d*(1+4u))")
print("delta_old=delta0 because gcd(u,G)=1 and u*(q+4)=G+1+4u")
print("SATURATION_QUOTIENT=0")
print("SATURATION_QUOTIENT_ORDER=1")
print("PRIME_FACTORIZATION_USED=FALSE")
