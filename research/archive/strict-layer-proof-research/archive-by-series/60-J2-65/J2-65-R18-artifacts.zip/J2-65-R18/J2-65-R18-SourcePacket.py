#!/usr/bin/env python3
import sympy as sp
G,u,q,d=sp.symbols("G u q d", integer=True)
# R13 actual power-of-ten residue rows:
# hZ == -2*q^4*(q+4), ha == -2*(q+2)^3*(q+4) (mod G).
# Exact resonance uq=G+1, hence uq-1=G.
e1=sp.factor(u**5*q**4*(q+4)-(1+4*u))
e2=sp.factor(u**5*(q+2)**3*(q+4)-u*(1+2*u)**3*(1+4*u))
assert sp.rem(e1, u*q-1, q)==0
assert sp.rem(e2, u*q-1, q)==0
print("SOURCE_PACKET_CYCLOTOMIC_ROW_REDUCTION=PASS")
print("u^5*q^4*(q+4) == 1+4u (mod G)")
print("u^5*(q+2)^3*(q+4) == u*(1+2u)^3*(1+4u) (mod G)")
print("PRE_SCHUR_Q_FREE_CONGRUENCE:")
print("G | 2*d*(1+4*u)*(Z+u*(1+2*u)^3*a)")
print("delta0=gcd(G,2*d*(1+4*u)); M0=G/delta0")
print("q_INDEPENDENT_BASE_COORDINATE_RETIRED=TRUE")
