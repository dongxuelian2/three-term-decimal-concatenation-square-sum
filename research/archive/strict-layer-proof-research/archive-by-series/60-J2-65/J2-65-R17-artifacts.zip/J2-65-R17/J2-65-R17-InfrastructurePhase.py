#!/usr/bin/env python3
# Whole-modulus proof, g>=2.
#
# P0=2uG^3A, R0=GA(GA+2)(G^4A^2+400u^2), A=2u+1.
# gcd(u,G)=gcd(u,A)=1 and G == -1 (mod u), hence
# gcd(u,GA+2)=gcd(u,W0)=1.
# Thus gcd(P0,R0)=GA*gcd(2G^2,(GA+2)W0).
#
# For G=10^g, g>=2:
# v2(GA+2)=1, v5(GA+2)=0;
# v2(W0)=4 and v5(W0)=2 because
# W0=G^4 A^2+400u^2, u a ten-unit, and the summands have
# distinct 2/5-valuations (>=8 vs 4, >=8 vs 2).
# No prime outside {2,5} divides 2G^2.
# Hence gcd(2G^2,(GA+2)W0)=2^5*5^2=800.

print("S0=P0*K+Q0")
print("P0=2*u*G^3*A")
print("Q0=20*u")
print("R0=F0*W0")
print("g_GE_2_PHASE_GCD=gcd(P0,R0)=800*G*A")
print("PHASE_MODULUS=m_ph=((G*A+2)/2)*(u^2+(G^2*A/20)^2)")
print("PHASE_STEP=c_ph=u*G^2/400")
print("GCD_mph_10=1")
print("GCD_mph_u=1")
print("GCD_cph_mph=1")
print("NORMALIZED_PHASE_ORBIT=psi_k=c_ph*10^k mod m_ph")
print("NUMERICAL_FACTORING_USED=FALSE")
