#!/usr/bin/env python3
import sympy as sp
G,u,K=sp.symbols("G u K", positive=True)
A=2*u+1
L0=G*A+1
F0=L0**2-1
T0=2*K*G*u
N0=T0**2-L0**2+2
U0=G**2*A
V0=20*u
W0=U0**2+V0**2
S0=U0*T0+V0
J0=U0-V0*T0
D0=S0**2-F0*W0
I=sp.I

assert sp.expand((U0-I*V0)*(T0+I)-(S0+I*J0))==0
assert sp.expand(S0**2+J0**2-W0*(T0**2+1))==0
assert sp.expand(T0**2+1-F0-N0)==0
assert sp.expand(D0+J0**2-W0*N0)==0

M=sp.Matrix([[U0,V0],[-V0,U0]])
assert sp.simplify(M.T*M-W0*sp.eye(2))==sp.zeros(2)
assert sp.simplify(M*sp.Matrix([T0,1])-sp.Matrix([S0,J0]))==sp.zeros(2,1)

print("S0=U0*T0+V0")
print("J0=U0-V0*T0")
print("GAUSSIAN_PRODUCT=(U0-i*V0)*(T0+i)=S0+i*J0")
print("LAGRANGE_IDENTITY=S0^2+J0^2=W0*(T0^2+1)")
print("MASTER_COMPOSITION=D0+J0^2=W0*N0")
print("ORTHOGONAL_SIMILITUDE_MATRIX=[[U0,V0],[-V0,U0]]")
print("M0T_M0_EQUALS_W0_I=PASS")
print("CYCLOTOMIC_ORTHOGONAL_COMPOSITION_THEOREM=PROVED")
