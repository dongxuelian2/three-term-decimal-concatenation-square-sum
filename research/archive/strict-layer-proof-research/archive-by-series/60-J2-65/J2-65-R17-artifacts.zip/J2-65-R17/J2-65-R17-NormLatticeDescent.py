#!/usr/bin/env python3
# Exact descent audit using R16 PN0:
# r0^2-D*v0^2=(20 G^2 q^2 (G+1))^2 E_partial h^2,
# D=q^4 D0, E_partial=q^4 F0 N0.
#
# Multiplication v_circ=q^2 v0 is always integral, so:
# r0^2-D0*v_circ^2=(20 G^2 q^4 (G+1))^2 F0 N0 h^2.
#
# At the final R16 source-normalized level:
# rN^2-D0*(q^2 vN)^2 =
#   (20 G^2 q^4 (G+1)/C_extra)^2 F0 N0 h^2.
#
# No theorem in R16 proves that the q^4 scalar divides the real coordinate
# after the already maximal universal 800 q^5 descent; C_extra is a moving
# source-lattice gcd. Therefore further division would be illegal.

print("q_ELIMINATION_FIELD_LEVEL=TRUE")
print("q_ELIMINATION_ORDER_LEVEL=PARTIAL")
print("q_ELIMINATION_SOURCE_LATTICE_LEVEL=PARTIAL")
print("q_ELIMINATION_DIGIT_SHELL_LEVEL=PARTIAL")
print("Q_FREE_SOURCE_NORM_CORE=PARTIAL")
print("RESIDUAL_q_DEPENDENCE_REASON=SOURCE_LATTICE_INDEX/COSET_AND_ORDER_CONDUCTOR")
print("LEGAL_NORMALIZED_EQUATION=rN^2-D0*(q^2*vN)^2=(20*G^2*q^4*(G+1)/C_extra)^2*F0*N0*h^2")
print("ILLEGAL_RATIONAL_DIVISION_USED=FALSE")
print("q_SURVIVES_AS_INTEGRAL_SCALE_NOT_INDEPENDENT_BASE_COORDINATE=TRUE")
