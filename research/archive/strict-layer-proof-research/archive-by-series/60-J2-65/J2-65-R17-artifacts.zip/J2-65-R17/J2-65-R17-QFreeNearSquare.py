#!/usr/bin/env python3
import sympy as sp
G,q,u,K=sp.symbols("G q u K", nonzero=True)
A=2*u+1
C=2*G+q+2
H=2*G**2+G*q+2*G+2*q
L0=G*A+1
F0=L0**2-1
T0=2*K*G*u
U0=G**2*A
V0=20*u
W0=U0**2+V0**2
S0=U0*T0+V0
R0=F0*W0
D0=S0**2-R0

RF=(4*G**4+4*G**3*q+8*G**3+G**2*q**2+8*G**2*q+4*G**2
    +2*G*q**2+4*G*q-q**2)
Delta_fib=RF-4*K**2*G**2*(G+1)**2
RD=G*C*H*(G**4*C**2+400*(G+1)**2)
SD=2*K*G**3*(G+1)*C+20*q*(G+1)
D=SD**2-RD
Epartial=-G*C*H*Delta_fib
N0=T0**2-L0**2+2

qsub=(G+1)/u
def z(expr):
    return sp.factor(sp.together(expr.subs(q,qsub)))

assert sp.factor(F0-G*A*(G*A+2))==0
assert z(G**4*C**2+400*(G+1)**2-q**2*W0)==0
assert z(RD-q**4*F0*W0)==0
assert z(SD-q**2*S0)==0
assert z(D-q**4*D0)==0
assert z(Epartial-q**4*F0*N0)==0

print("U0=G^2*A")
print("V0=20*u")
print("W0=U0^2+V0^2")
print("F0=(GA+1)^2-1=GA*(GA+2)")
print("R_D_EQUALS_q4*F0*W0=PASS")
print("S_D_EQUALS_q2*S0=PASS")
print("D_BOUNDARY_EQUALS_q4*D0=PASS")
print("E_PARTIAL_EQUALS_q4*F0*N0=PASS")
print("q_ELIMINATED_FROM_NORMALIZED_NEARSQUARE_CORE=TRUE")
