#!/usr/bin/env python3
import sympy as sp
G,u,K,Y=sp.symbols("G u K Y", positive=True)
A=2*u+1
L0=G*A+1
F0=L0**2-1
T0=2*K*G*u
N0=T0**2-L0**2+2
U0=G**2*A
V0=20*u
W0=U0**2+V0**2
S0=U0*T0+V0
J0=U0-V0*T0
R0=F0*W0
D0=sp.expand(S0**2-R0)
P0=2*u*G**3*A
Q0=20*u

assert sp.expand(S0-(P0*K+Q0))==0
assert sp.expand(D0-((P0*K+Q0)**2-R0))==0
discK=sp.factor(sp.discriminant(sp.Poly(D0,K),K))
assert sp.factor(discK-4*P0**2*R0)==0
assert sp.expand(D0+J0**2-W0*N0)==0

print("D_SQUARE_IFF_D0_SQUARE=PROVED because D=q^4*D0")
print("SPLIT_ETALE_LOCUS_q_FREE=TRUE")
print("SPLIT_COMPOSITION_EQUATION=Y^2+J0^2=W0*N0")
print("D0_QUADRATIC_IN_K=TRUE")
print("D0_K_DISCRIMINANT=4*P0^2*R0")
print("SPLIT_CURVE_OVER_Q(G,u)=GENUS_0_CONIC")
print("TORIC_FACTOR_FORM=(S0-Y)*(S0+Y)=R0")
print("SPLIT_LOCUS_RELATION_TO_R9_NORM=FIXED_COORDINATE_GAUSSIAN_INCIDENCE_NOT_AUTOMATIC")
