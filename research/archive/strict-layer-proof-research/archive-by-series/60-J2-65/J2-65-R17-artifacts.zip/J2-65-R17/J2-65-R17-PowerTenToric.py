#!/usr/bin/env python3
import sympy as sp
G,u,K=sp.symbols("G u K", positive=True)
A=2*u+1
L0=G*A+1
T0=2*u*G*K
N0=sp.expand(T0**2-L0**2+2)
U0=G**2*A
V0=20*u
S0=sp.expand(U0*T0+V0)
J0=sp.expand(U0-V0*T0)
F0=sp.expand(L0**2-1)
W0=sp.expand(U0**2+V0**2)
D0=sp.expand(S0**2-F0*W0)

def support(expr):
    P=sp.Poly(expr,G,K,u)
    return sorted(P.monoms())

print("TORIC_BASE=T10={(G,K)=(10^g,10^k):0<k<2g}, with u|(G+1)")
print("q_RECOVERY=(G+1)/u")
print("N0=", N0)
print("S0=", S0)
print("J0=", J0)
print("N0_SUPPORT_SIZE=", len(support(N0)))
print("S0_SUPPORT_SIZE=", len(support(S0)))
print("J0_SUPPORT_SIZE=", len(support(J0)))
print("D0_DEGREE_IN_K=", sp.Poly(D0,K).degree())
print("EXACT_ZERO_LOCUS_FOR_S_UNIT_STAGE=NOT_FORCED")
print("S_UNIT_STAGE_TRIGGERED=FALSE")
