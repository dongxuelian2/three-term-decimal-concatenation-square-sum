#!/usr/bin/env python3
import sympy as sp
G,u,K=sp.symbols("G u K", positive=True)
A=2*u+1
L0=G*A+1
F0=L0**2-1
T0=2*K*G*u
N0=T0**2-L0**2+2
U0=G**2*A
V0=20*u
W0=U0**2+V0**2
S0=U0*T0+V0
J0=U0-V0*T0
D0=S0**2-F0*W0
M=sp.Matrix([[U0,V0],[-V0,U0]])
assert M.T*M==W0*sp.eye(2)
assert M*sp.Matrix([T0,1])==sp.Matrix([S0,J0])
assert sp.expand(D0+J0**2-W0*N0)==0

print("R9_GAUSSIAN_TARGET=N0")
print("BOUNDARY_RADICAND=D0")
print("CANONICAL_GAUSSIAN_FACTOR=U0-i*V0")
print("EUCLIDEAN_PARAMETER_SIMILITUDE=PROVED")
print("SCHUR_COMPLEMENT_FUNCTORIAL_IDENTITY=PROVED")
print("R9_TO_R16_SOURCE_NORM_BRIDGE=FORMAL_IDENTITY_ONLY")
print("REASON=M0 acts on parameter vector (T0,1), not on the R16 source norm lattice coordinates (rN,vN,h); no integral converse/coset/order map is proved")
print("BOUNDARY_NORM_ARITHMETIC_INDEPENDENT_OF_R9=UNRESOLVED_AT_SOURCE_LATTICE_LEVEL")
