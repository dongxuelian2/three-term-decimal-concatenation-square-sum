#!/usr/bin/env python3
import subprocess, sys
scripts=[
"J2-65-R17-CyclotomicElimination.py",
"J2-65-R17-QFreeNearSquare.py",
"J2-65-R17-OrthogonalComposition.py",
"J2-65-R17-SplitEtaleLocus.py",
"J2-65-R17-SourceNormBridge.py",
"J2-65-R17-PowerTenToric.py",
]
for s in scripts:
    p=subprocess.run([sys.executable,s],capture_output=True,text=True)
    assert p.returncode==0,(s,p.stderr)
print("R17_REGRESSION=PASS")
print("R16_UNIT_ORBIT_REOPENED=FALSE")
print("PELL_ENUMERATION_USED=FALSE")
print("CONTINUED_FRACTIONS_USED=FALSE")
print("FACTOR_u_USED=FALSE")
print("FACTOR_R0_USED=FALSE")
print("MULTIPLICATIVE_ORDER_COMPUTATION_USED=FALSE")
print("GAUSSIAN_HERMITIAN_REOPENED=FALSE")
print("OLD_C2_C3_TUBES_REOPENED=FALSE")
print("q1_REOPENED=FALSE")
print("GENERAL_J_REOPENED=FALSE")
