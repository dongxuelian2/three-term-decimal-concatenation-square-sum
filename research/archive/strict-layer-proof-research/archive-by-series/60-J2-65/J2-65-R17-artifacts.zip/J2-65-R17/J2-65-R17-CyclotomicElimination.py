#!/usr/bin/env python3
import sympy as sp
G,q,u,K=sp.symbols("G q u K", nonzero=True)
A=2*u+1
B=2*G+q
L0=G*A+1
T0=2*K*G*u

RF=(4*G**4+4*G**3*q+8*G**3+G**2*q**2+8*G**2*q+4*G**2
    +2*G*q**2+4*G*q-q**2)
Delta_fib=RF-4*K**2*G**2*(G+1)**2
qsub=(G+1)/u

def z(expr):
    return sp.factor(sp.together(expr.subs(q,qsub)))

assert z(2*G+q+2-q*A)==0
assert z(2*G**2+G*q+2*G+2*q-q*(G*A+2))==0
assert z(RF-q**2*(L0**2-2))==0
assert z(2*K*G*(G+1)-q*T0)==0

N0=T0**2-L0**2+2
assert z(-Delta_fib-q**2*N0)==0

N_R9=2+u**2*(4*K**2*G**2-B**2)
assert z(N_R9-N0)==0

print("C_EQUALS_qA=PASS")
print("GA_PLUS_1_EQUALS_uB=PASS")
print("R_F_EQUALS_q2_TIMES_L0SQ_MINUS_2=PASS")
print("T_EQUALS_q*T0=PASS")
print("-DELTA_FIB_EQUALS_q2*N0=PASS")
print("N0_EQUALS_R9_GAUSSIAN_N=PASS")
print("R7_R9_DISCRIMINANT_BRIDGE=PROVED")
