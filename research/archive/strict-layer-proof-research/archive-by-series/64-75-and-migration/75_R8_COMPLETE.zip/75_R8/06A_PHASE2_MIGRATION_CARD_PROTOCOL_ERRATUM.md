# 75-R8 Phase-II Protocol Erratum — Migration Cards

## Nature of erratum

The frozen `06_promoted_weapon_registry.md` states that no new Migration Card is required because no theorem was promoted. That is too narrow relative to the explicit R8 rule:

> once theorem hypotheses are actually validated / source-mapped, create a Migration Card, even if the theorem is later rejected.

During Phase II, Laurent and ESS were not merely bibliographically screened: their theorem input hypotheses were explicitly checked against the frozen N0 source map. Therefore two cards are required.

No mathematical verdict changes.

## Corrected protocol state

```text
NEW_MIGRATION_CARDS=MC-003_Laurent_N0_R8;MC-004_ESS_N0_R8
MC-003_STATUS=REJECTED
MC-004_STATUS=REJECTED
WEAPONS_PROMOTED=0
FORMAL_ACTIVE_MIGRATIONS=0
LAURENT_CONCEPTUAL_RESERVE=RETAINED
ESS_CONCEPTUAL_RESERVE=RETAINED
```

The word `REJECTED` here means rejected as an R8 formal migration at the current proved interface. It does not erase their pre-existing A-reserve architectural value if a future internal bridge changes the theorem input.

---

STAGE_INPUTS=06_promoted_weapon_registry.md;WC-R8-004;WC-R8-005;R8 Migration Card rule
STANDARD_OBJECTS_ESTABLISHED=unchanged
NEW_PROVED_RESULTS=none mathematical
NEW_REDUCTIONS=protocol correction only
NEGATIVE_RESULTS=none new
EXTERNAL_SOURCES_USED=Laurent 1984;Evertse-Schlickewei-Schmidt 2002
WEAPON_CANDIDATES_CREATED=0 additional
MIGRATION_CARDS_CREATED_OR_UPDATED=MC-003 created STATUS=REJECTED;MC-004 created STATUS=REJECTED
REJECTED_ROUTES=current Laurent migration;current ESS migration
OUTPUT_DEPENDENCIES=Phase III must import MC-003 and MC-004 as rejected pre-migration tests
UNRESOLVED_ITEMS=unchanged
PHASE_STATUS=FROZEN_ADDENDUM
