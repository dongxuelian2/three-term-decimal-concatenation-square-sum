# 75-R8 Phase I-B — N0 Square-Class / Norm Dictionary

## 1. Primary standard object
The current rational-split gate is best standardized as
\[
\boxed{N_0\in N_{\mathbf Q(i)/\mathbf Q}(\mathbf Q(i)^\times)}.
\]
Equivalently,
\[
\boxed{(-1,N_0)=0}.
\]
Because N0 is a positive integer on the actual family, this is also equivalent to integral representation by the fixed principal binary quadratic form
\[
\boxed{N_0=x^2+y^2,\qquad x,y\in\mathbf Z}.
\]
The rational/integral distinction is conceptually important, but for this specific positive integral N0 the two existence criteria coincide.

## 2. Exact rational norm criterion
For a positive rational number n, membership in the norm group of Q(i)/Q is equivalent to
\[
\boxed{v_p(n)\equiv0\pmod2\quad\text{for every prime }p\equiv3\pmod4}.
\]
For the integer N0 this is precisely the classical two-squares criterion.

Hence the actual split obstruction is not a varying quadratic field: the field is fixed Q(i). It is a varying **value-factorization parity problem** inside one fixed norm group.

## 3. Square-class support
The exact congruences from Phase I-A give
\[
\gcd(N_0,10Gu)=1.
\]
Therefore:

- v2(N0)=0;
- v5(N0)=0;
- every prime dividing u has valuation 0 in N0;
- every prime dividing G has valuation 0 in N0;
- only new primes outside the source support 10Gu can affect [N0] in Q*/Q*2.

Since N0>0, the real square-class sign is positive.

## 4. What actually decides split/nonsplit
Write
\[
N_0=\prod_p p^{e_p}.
\]
Then
\[
\boxed{\text{rational split}\iff e_p\text{ even for every }p\equiv3\pmod4.}
\]
Primes p=2 and p≡1 mod4 do not obstruct Gaussian norm membership.

Equivalently define the 3-mod-4 squarefree obstruction kernel
\[
\kappa_-(N_0)=\prod_{\substack{p\equiv3\ (4)\\ e_p\text{ odd}}}p.
\]
Then
\[
\boxed{\text{rational split}\iff\kappa_-(N_0)=1.}
\]
This depends only on the squarefree kernel of N0, but **the support of that kernel is not known to lie in any fixed finite prime set across the family**.

## 5. Answers to SQ1–SQ5

### SQ1 — class variation in Q*/Q*2
\[
[N_0]\in\mathbf Q^\times/\mathbf Q^{\times2}
\]
varies through the squarefree prime support of N0. The fixed power-ten/source primes 2,5 and primes dividing u or G are absent. No finite global list of remaining primes is currently proved.

### SQ2 — automatically even valuations
Automatically even (indeed zero):
\[
v_2(N_0)=v_5(N_0)=0,
\]
and for every p|uG,
\[
v_p(N_0)=0.
\]
No theorem imported so far makes v_p(N0) automatically even for all other p≡3 mod4.

### SQ3 — true support of the obstruction
Only primes
\[
\boxed{p\equiv3\pmod4,\qquad p\nmid10Gu,\qquad p\mid N_0}
\]
with odd valuation can obstruct rational split.

### SQ4 — finite characteristic of sf(N0)?
For each fixed N0, yes: only the 3-mod-4 part of sf(N0) matters. Uniformly over the family, NO fixed finite support is known. Thus the criterion is finite per value, but not finitized at family level.

### SQ5 — representation criterion
Yes. Because N0 is a positive integer,
\[
\boxed{(-1,N_0)=0}
\iff
\boxed{N_0=x^2+y^2\text{ for some }x,y\in\mathbf Z}.
\]
This is a fixed binary quadratic form of discriminant -4, not a varying genus/class-group problem.

## 6. Gaussian composition dictionary
If D0=Y^2, then
\[
Y^2+J_0^2=W_0N_0,
\qquad
W_0=U_0^2+V_0^2,
\]
so
\[
N_0=N_{\mathbf Q(i)/\mathbf Q}\left(\frac{Y+iJ_0}{U_0+iV_0}\right).
\]
Thus the R17/R18 identity supplies a standard **norm quotient with prescribed numerator coordinate**.

Conversely, if N0=a^2+b^2, multiplication gives
\[
(U_0+iV_0)(a+ib)
\]
as some representation of W0N0, but there is no reason its imaginary or real coordinate equals the source-prescribed J0. Therefore Gaussian composition alone does not classify the current split family.

## 7. Binary quadratic / genus status
The natural binary form is
\[
x^2+y^2,
\]
with fixed discriminant -4 and class number 1. Hence generic genus theory, principal-genus theory, or a varying class-group stack adds no information to the basic representation criterion unless a new source condition produces a different form.

## 8. Hilbert-symbol status
The norm obstruction is genuinely local-global but elementary for the fixed extension Q(i)/Q:

- real place: automatic since N0>0;
- p=2: automatic in the present family because N0≡1 mod8;
- p≡1 mod4: no obstruction;
- p≡3 mod4: valuation parity is the only obstruction.

Thus a Hasse norm theorem can certify equivalence of local and global norm conditions, but by itself cannot control the varying prime factorization of the N0 value family.

## 9. Classification of standard identities

```text
N0_PRIMARY_STANDARD_OBJECT=VALUE_OF_A_SPARSE_POWER_DIVISOR_FAMILY_TESTED_FOR_MEMBERSHIP_IN_FIXED_GAUSSIAN_NORM_GROUP
N0_SECONDARY_STANDARD_OBJECT_1=PRINCIPAL_BINARY_QUADRATIC_FORM_x2+y2_DISCRIMINANT_-4
N0_SECONDARY_STANDARD_OBJECT_2=SQUARE_CLASS_PARAMETER_FOR_-Delta_fib
N0_SECONDARY_STANDARD_OBJECT_3=FIXED_COORDINATE_GAUSSIAN_NORM_QUOTIENT_VIA_D0+J0^2=W0N0
N0_NOT_NATURALLY=VARYING_QUADRATIC_FIELD;GENERIC_PELL_FAMILY;NONTRIVIAL_FIXED_CLASS_GROUP_PROBLEM
```

---
STAGE_INPUTS=00_N0_imported_state.md;01_N0_standard_forms.md
STANDARD_OBJECTS_ESTABLISHED=fixed_Gaussian_norm_group;two_squares_form_discriminant_minus4;3mod4_squarefree_obstruction_kernel
NEW_PROVED_RESULTS=rational_norm_equals_integral_two_square_existence_for_actual_positive_integer_N0;only_3mod4_odd_valuations_obstruct;fixed_source_prime_support_absent
NEW_REDUCTIONS=genus_lane_demoted_for_current_G1_gate;Hasse_norm_reduced_to_value_factorization_parity
NEGATIVE_RESULTS=no_uniform_finite_prime_support;composition_not_sufficient_for_converse;class_group_not_nontrivial
EXTERNAL_SOURCES_USED=NONE
WEAPON_CANDIDATES_CREATED=NONE
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
REJECTED_ROUTES=varying_field_norm_treatment_for_G1;generic_genus_theory_as_primary_weapon
OUTPUT_DEPENDENCIES=03_N0_parameter_dimension_audit.md;PhaseII specialized search
UNRESOLVED_ITEMS=uniform control of p=3mod4 valuation parity in N0 values;prescribed-coordinate incidence if D0-square becomes relevant
PHASE_STATUS=FROZEN
