# 75-R8 Phase I Addendum — Exact q>1 Rational-Split Witness

## Protocol status
Phase I files 01–03 were already frozen. This addendum does NOT modify them. It records a new exact stress-test result discovered afterward and is a required dependency of Phase II onward.

## Exact R17-legal base tuple
R17 explicitly identifies the g=1, q>1 exact-resonance case as
\[
G=10,\qquad q=11,\qquad u=1,\qquad k=1,\qquad K=10,
\]
with A=3.

Then
\[
T_0=2KGu=200,
\qquad
L_0=GA+1=31,
\]
so
\[
\boxed{N_0=200^2-31^2+2=39041}.
\]
And exactly
\[
\boxed{39041=25^2+196^2}.
\]
Therefore
\[
\boxed{(-1,N_0)=0}
\]
and the actual q>1 rational-split base is NONEMPTY.

## Strong separation from the D0-square locus
For the same tuple,
\[
U_0=300,\quad V_0=20,\quad W_0=90400,
\]
\[
J_0=U_0-V_0T_0=-3700,
\]
and
\[
D_0=W_0N_0-J_0^2=3515616400.
\]
Direct square bracketing gives
\[
59292^2=3515541264
<3515616400
<3515659849=59293^2.
\]
Hence
\[
\boxed{D_0\text{ is not a square}}.
\]
Thus this single exact tuple proves
\[
\boxed{N_0\text{ Gaussian norm }\centernot\Rightarrow D_0\text{ square}}.
\]
The implication imported from R17 remains strictly one-way:
\[
D_0\text{ square}\Rightarrow N_0\text{ Gaussian norm}.
\]

## Strategic consequence for Phase II/III
The payoff
```text
PROVE_ALL_q>1_ACTUAL_FIBRES_NONSPLIT
```
is impossible at the N0 base level.
External weapons must instead be evaluated for:

- classification of the split family;
- reduction to explicit exceptional subfamilies;
- effective finiteness only after respecting this witness;
- stronger source gates beyond rational split.

Any theorem candidate predicting an empty rational-split q>1 family is rejected by this exact witness.

---
STAGE_INPUTS=Frozen Phase I;R17 explicit g=1 q>1 base statement
STANDARD_OBJECTS_ESTABLISHED=exact rational-split witness;strict separation between N0 norm and D0-square
NEW_PROVED_RESULTS=N0(10,10,1,11)=39041=25^2+196^2;D0=3515616400 nonsquare
NEW_REDUCTIONS=Payoff_A_all_nonsplit_falsified_at_N0_base_level
NEGATIVE_RESULTS=N0_norm_does_not_imply_D0_square;all_qgt1_nonsplit_strategy_false
EXTERNAL_SOURCES_USED=NONE
WEAPON_CANDIDATES_CREATED=NONE
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
REJECTED_ROUTES=ANY_EXTERNAL_CLAIM_ALL_qgt1_N0_NONSPLIT
OUTPUT_DEPENDENCIES=04_specialized_weapon_search_map.md;all Phase II/III candidate sheets
UNRESOLVED_ITEMS=structure/size/classification of the nonempty split family
PHASE_STATUS=FROZEN_ADDENDUM
