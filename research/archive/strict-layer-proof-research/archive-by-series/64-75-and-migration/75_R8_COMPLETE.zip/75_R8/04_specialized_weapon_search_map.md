# 75-R8 Phase II — Specialized External-Weapon Search Map

## 0. Frozen input

This phase uses only the frozen Phase-I object and its frozen addendum.

Primary arithmetic gate:
\[
(-1,N_0)=0
\iff
N_0\in N_{\mathbf Q(i)/\mathbf Q}(\mathbf Q(i)^\times)
\iff
N_0=x^2+y^2\quad(x,y\in\mathbf Z),
\]
for the actual positive integer family
\[
N_0=4u^2G^2K^2-(G(2u+1)+1)^2+2,
\quad G=10^g,\ K=10^k,\ uq=G+1,\ q>1,\ 0<k<2g.
\]

The exact Phase-I addendum already gives an actual split witness
\[
(G,K,u,q)=(10,10,1,11),\qquad N_0=39041=25^2+196^2,
\]
so a theorem claiming the whole q>1 family is nonsplit is impossible.

## 1. Search discipline

The search was restricted to theorem families whose hypotheses match one of the frozen standard objects. Generic strong approximation, generic quadrics, the retired R5 chart, the retired N4-A elimination, and Gaussian unit-orbit classification were not reopened.

## 2. Lane audit

| Lane | Frozen standard object | Primary theorem/source audited | Exact hypothesis gate | Family-level fit | Verdict |
|---|---|---|---|---|---|
| A Gaussian norm / sums of two squares | fixed norm group of Q(i)/Q; fixed form x^2+y^2 | Hasse norm theorem; Fermat–Euler two-squares criterion | fixed cyclic extension / local norm data | exact criterion, but no control of p≡3 mod4 valuations in the moving N0-value family | RELATED_BUT_NONWEAPON |
| B Binary quadratic forms / genus | principal form x^2+y^2, discriminant -4 | classical composition/genus theory | fixed discriminant/class group | class group is already trivial; no remaining class-group compression exists | REJECT |
| C Norm-form Diophantine equations | N_{Q(i)/Q}(z)=N0(G,K,u) | fixed-field norm equations / Hasse norm theorem | fixed field, arbitrary RHS | field is fixed, but theorem only restates local norm criterion; no uniform RHS classification | RELATED_BUT_NONWEAPON |
| D Square values / curves | only the stronger D0=Y^2 locus | curve/integral-point / polynomial representation literature | low-dimensional fixed polynomial or fixed curve | D0-square is not equivalent to G1; exact witness has N0 split but D0 nonsquare | REJECT_FOR_G1 |
| E Laurent / ESS | possible torus/exponential-polynomial incidence | Laurent 1984; Evertse–Schlickewei–Schmidt 2002 | fixed algebraic subvariety intersect fixed finite-rank multiplicative group; or linear equation with variables in fixed finite-rank group | x,y remain unrestricted additive variables and u/q remains moving divisor data; no fixed finite-rank source system | KEEP_AS_RESERVE |
| F Pell / Lucas / recurrence | no fixed Pell coefficient and no certified recurrence sequence for N0 | Bilu–Hanrot–Voutier primitive divisor theorem | nth Lucas/Lehmer term | N0 is not a Lucas/Lehmer divisibility sequence; no theorem map | REJECT |
| G Restricted prime support / cyclotomic | obstruction kernel κ_-(N0) | cyclotomic sum-of-two-squares results such as a^n+1; Thue–Mahler/S-unit theory | fixed cyclotomic sequence or fixed finite S | N0 lacks certified cyclotomic factorization and its 3 mod 4 obstruction support is not confined to a fixed finite S | REJECT_CURRENTLY |
| H Polynomial values represented by quadratic forms | x^2+y^2=N0 | Grechuk–Agbanwa 2026; Iyer 2025 family | fixed univariate polynomial P(n), fixed form | N0 is a rank-two power base plus moving divisor fibre, not one fixed univariate polynomial; available results are largely infinitude/existence, not classification/finiteness of this family | RELATED_BUT_NONWEAPON |

## 3. Primary sources audited

### S1 — Hasse norm theorem
H. Hasse, *Beweis eines Satzes und Wiederlegung einer Vermutung über das allgemeine Normenrestsymbol*, Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen, Mathematisch-Physikalische Klasse (1931), 64–69.

Relevant theorem family: local-global norm theorem for cyclic extensions. For the fixed cyclic extension Q(i)/Q this standardizes the split gate, but does not reduce the moving N0 family.

### S2 — Laurent
M. Laurent, *Equations diophantiennes exponentielles*, Inventiones Mathematicae 78 (1984), 299–327, DOI 10.1007/BF01388597.

Relevant theorem family: exponential-Diophantine / torus intersection finiteness. Current failure is pre-theorem: the source has not been mapped to a fixed torus/subvariety system.

### S3 — Evertse–Schlickewei–Schmidt
J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt, *Linear equations in variables which Lie in a multiplicative group*, Annals of Mathematics 155 (2002), 807–836, DOI 10.2307/3062133.

Exact theorem entry: for a fixed subgroup Γ⊂(K*)^n of finite rank r, the number of nondegenerate solutions to a fixed linear equation a1x1+...+anxn=1 with x∈Γ admits a bound depending only on n and r. Current N0=x^2+y^2 does not put x,y into such a Γ.

### S4 — Bilu–Hanrot–Voutier
Y. Bilu, G. Hanrot, P. M. Voutier, *Existence of primitive divisors of Lucas and Lehmer numbers*, Journal für die reine und angewandte Mathematik 539 (2001), 75–122.

Exact relevant theorem: every n-th Lucas or Lehmer number with n>30 has a primitive divisor. No Lucas/Lehmer sequence identity for N0 has been established.

### S5 — Dresden et al.
G. Dresden et al., *When is a^n+1 the sum of two squares?*, Involve 12 (2019), 585–605; arXiv:1609.04391.

This shows how powerful cyclotomic factorization can be for an actual fixed exponential sequence. The defining factorization is absent for N0.

### S6 — Grechuk–Agbanwa
B. Grechuk, J. Agbanwa, *On the polynomial values represented by quadratic forms*, arXiv:2607.06627 (submitted 7 July 2026).

The paper treats representation of values of a fixed univariate polynomial P(x) by a fixed quadratic form, including x^2+y^2 in special cubic/quartic/composite cases. The current N0 family is not of that input type.

### S7 — Iyer
S. Iyer, *Cubic polynomials and sums of two squares*, arXiv:2510.25492 (2025).

Again the object is a fixed univariate cubic; the result is quantitative existence/infinitude, not a uniform classification of the rank-two/divisor family occurring here.

## 4. Search-level negative theorems

### N-WEAPON-1 — Genus collapse
The binary form in G1 is already the principal class of discriminant -4. Therefore moving-discriminant genus/class-group technology cannot compress G1: there is no moving class group at this interface.

### N-WEAPON-2 — Fixed-field norm theorem saturation
The field Q(i) is fixed, so fixed-field local-global norm theory is fully available. Its conclusion is exactly the already-frozen parity criterion on p≡3 (mod 4). It does not constrain how those valuations arise in N0(G,K,u).

### N-WEAPON-3 — Laurent/ESS activation still fails
Writing
\[
x^2+y^2=1-2(2u+1)G+\bigl(4u^2K^2-(2u+1)^2\bigr)G^2
\]
does not create a fixed finite-rank multiplicative-group equation: x,y are free additive variables, while u=(G+1)/q ranges over divisors of G+1. Hence the R6/R7 activation blocker remains, now proved directly at the N0 interface rather than inherited from N4-A.

### N-WEAPON-4 — Recurrence primitive-divisor mismatch
BHV-type primitive-divisor theorems require a Lucas/Lehmer recurrence term. N0 is not certified as such a term, and a primitive divisor of an auxiliary sequence would not by itself imply an odd valuation at a prime 3 mod 4 in N0.

### N-WEAPON-5 — Fixed-polynomial representation mismatch
Current representation-by-quadratic-form theorems for fixed P(n) do not cover a family with two independent decimal exponents plus a moving divisor fibre. Freezing q/u/k would yield fixed-fibre problems, which is below the required whole-family scope.

## 5. Promote decision

No candidate passes the formal promotion threshold.

```text
WEAPON_FAMILIES_AUDITED=8
WEAPONS_PROMOTED=0
PROMOTE_LIMIT=3
PROMOTE_LIMIT_RESPECTED=TRUE
BEST_CURRENT_EXTERNAL_RESULT=EXACT_GAUSSIAN_NORM_DICTIONARY_ONLY
BEST_HIGH_VALUE_RESERVES=LAURENT;ESS
NEW_FORMAL_MIGRATION_CARDS_REQUIRED=NO
```

The reason is not lack of relevance. It is that every mature theorem family either:

1. already terminates at the known local parity criterion;
2. requires a fixed univariate/fixed recurrence input absent here;
3. requires a fixed finite-rank multiplicative source image absent here; or
4. targets the stronger D0-square locus, which is not equivalent to G1.

---

STAGE_INPUTS=00_N0_imported_state.md;01_N0_standard_forms.md;02_N0_squareclass_norm_dictionary.md;03_N0_parameter_dimension_audit.md;03A_PHASE1_ADDENDUM_SPLIT_WITNESS.md;R6/R7 frozen external-weapon state
STANDARD_OBJECTS_ESTABLISHED=Fixed Gaussian norm group Q(i)/Q; principal binary quadratic form x^2+y^2 of discriminant -4; rank-two power/divisor value family; fixed-coordinate Gaussian composition as strictly stronger separate locus
NEW_PROVED_RESULTS=Genus/class-group lane has zero compression at discriminant -4; fixed-field norm theorem stops exactly at existing parity criterion; Laurent/ESS still lack fixed finite-rank source image after N0 standardization; D0-square theory cannot classify G1 because exact split/nonsquare-D0 witness exists
NEW_REDUCTIONS=External search reduced from broad arithmetic geometry to eight specialized theorem families; no formal migration required
NEGATIVE_RESULTS=No theorem family produces whole-family finiteness/classification/effective exceptional set for actual N0; no all-nonsplit theorem can be true
EXTERNAL_SOURCES_USED=Hasse 1931;Laurent 1984;Evertse-Schlickewei-Schmidt 2002;Bilu-Hanrot-Voutier 2001;Dresden et al. 2019;Grechuk-Agbanwa 2026;Iyer 2025
WEAPON_CANDIDATES_CREATED=WC-R8-001 through WC-R8-008
MIGRATION_CARDS_CREATED_OR_UPDATED=MC-001 status reaffirmed SUPERSEDED;MC-002 status reaffirmed MIGRATED/FALLBACK;no new formal card
REJECTED_ROUTES=genus/class-group as new gate;fixed-field norm theorem as family classifier;D0-square as equivalent split criterion;BHV without recurrence;fixed-univariate polynomial representation;Thue-Mahler without fixed S/form;current Laurent/ESS activation
OUTPUT_DEPENDENCIES=05_weapon_candidate_sheets/*;06_promoted_weapon_registry.md;Phase III zero-promotion audit
UNRESOLVED_ITEMS=Uniform classification of p≡3 mod4 odd valuations in N0;explicit structural classification of actual split subfamily
PHASE_STATUS=FROZEN
