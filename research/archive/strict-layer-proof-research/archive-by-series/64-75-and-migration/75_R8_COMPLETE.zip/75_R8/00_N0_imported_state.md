# 75-R8 Phase 0 — N0 Imported-State Freeze

## Scope
Strict Layer — A1-only — Exact Resonance R=0 — J=2 — q>1.
This file imports only already-certified state from 65-R17/R18/R20 and 75-R4–R7. No literature search and no new theorem migration is used here.

## Exact imported scalar core

Let
\[
A=2u+1,\qquad uq=G+1,\qquad G=10^g,\qquad K=10^k,\qquad 0<k<2g.
\]
Define
\[
T_0=2KGu,\qquad L_0=GA+1=u(2G+q),
\]
\[
N_0=T_0^2-L_0^2+2
=4u^2G^2K^2-(GA+1)^2+2.
\]
The original source quotient is recovered by
\[
q=(G+1)/u,
\]
so q is not an independent coordinate of the normalized scalar core.

## Fibre discriminant relation

65-R17 proves
\[
\boxed{-\Delta_{\rm fib}=q^2N_0}.
\]
Hence the fibre square-class is exactly the square-class of N0.

## q-free boundary/composition packet

Define
\[
U_0=G^2A,\qquad V_0=20u,\qquad W_0=U_0^2+V_0^2,
\]
\[
S_0=U_0T_0+V_0=2uG^3AK+20u,
\]
\[
J_0=U_0-V_0T_0=G^2A-40u^2GK,
\]
\[
F_0=GA(GA+2),\qquad D_0=S_0^2-F_0W_0.
\]
Then 65-R17 proves the exact Cyclotomic Orthogonal-Composition identity
\[
\boxed{D_0+J_0^2=W_0N_0},
\qquad
\boxed{W_0=U_0^2+V_0^2}.
\]
It also proves D=q^4D0 for the old boundary radicand.

65-R18 upgrades this to the source-attached identity
\[
\boxed{R^2+(J_0V)^2=N_0\bigl(W_0V^2+F_0H^2\bigr)}
\]
on actual source variables, while explicitly NOT producing an integral similitude of the full source lattice.

## Distinct split notions — frozen anti-conflation rule

1. Current q>1 rational-split gate (65 terminal recompression / 75-R6):
\[
\boxed{(-1,N_0)=0}
\]
in the rational norm/quaternion sense.

2. R17 boundary quadratic-etale split locus:
\[
\boxed{D_0=Y^2}.
\]
On this locus the composition identity becomes
\[
Y^2+J_0^2=W_0N_0.
\]
Since W0 is a Gaussian norm, D0 square implies N0 is a rational Gaussian norm. The converse was NOT proved and is not imported.

3. R7 allowed-ruling lift has binary discriminant kernel N0:
\[
\operatorname{disc}_{Z,\lambda}\mathscr D_\sigma
=4A^4G^2u^2N_0,
\]
plus an independent source congruence. Thus the same N0 reappears, but square of the lifted discriminant alone is not sufficient for source admissibility.

## Known integral/source state around N0

65-R18 canonical q-free ambient form:
\[
Q_0(R,V,H)=R^2-D_0V^2-F_0N_0H^2=0.
\]
65-R20 proves the finite source packet is a model-change/dilatation phenomenon rather than an independent nonemptiness obstruction, conditional on rational split. Therefore the live first gate is again the rational split classification through N0.

## Retired interfaces carried from R7

- R5 transverse Veronese/USSPAL interface: RETIRED on the frozen chart because
\[
a_p\mathcal H_{\perp,\tau}\ge G/4.
\]
- Current N4-A / 65 elimination activation bridge: RETIRED because reverse semantics reinstates the original source gates.
- Laurent / ESS: A-grade reserve only; not activated by the retired N4-A interface.

## Previous migration state

- MC-001 (Huang-type counting): SUPERSEDED / retained.
- MC-002 (Cassels small zero): MIGRATED as fallback only; not an active dependency.
- R6 created no new active theorem migration. Laurent and ESS were reserves, not migration cards.

## Required machine-readable state

```text
EXACT_N0_FORMULA=N0=4u^2G^2K^2-(G(2u+1)+1)^2+2=T0^2-L0^2+2
PARAMETER_RELATIONS=A=2u+1;uq=G+1;G=10^g;K=10^k;0<k<2g;q>1
FIBRE_DISCRIMINANT_RELATION=-Delta_fib=q^2*N0
NORM_IDENTITIES=D0+J0^2=W0*N0;W0=U0^2+V0^2;R^2+(J0V)^2=N0(W0V^2+F0H^2)
SPLIT_CRITERION=RATIONAL_SOURCE_SPLIT_IS_(-1,N0)=0;D0_SQUARE_IS_DISTINCT_STRONGER_FIXED_COORDINATE_INCIDENT
KNOWN_SQUARE_CLASS_DATA=q^2_is_square_so_fibre_squareclass_equals_[N0]
KNOWN_VALUATION_DATA=PHASE0_IMPORT_ONLY_NO_NEW_VALUATION_CLAIMS
KNOWN_COMPOSITION_DATA=CYCLOTOMIC_ORTHOGONAL_COMPOSITION_EXACT;SOURCE_ATTACHED_CAS_EXACT;FULL_SOURCE_LATTICE_SIMILITUDE_NOT_FOUND
RETIRED_INTERFACES=R5_TRANSVERSE_USSPAL;CURRENT_N4A_65_ELIMINATION
ACTIVE_EXTERNAL_WEAPONS=NONE;LAURENT_ESS_RESERVE_ONLY;MC002_FALLBACK_ONLY
PHASE_STATUS=FROZEN
```

---
STAGE_INPUTS=J2-65-R17-Cyclotomic-Composition-Report.md;J2-65-R18-Integral-Descent-Commutation-Report.md;J2-65-R20-Semantic-Conductor-Ruling-Report.md;75-R5 certificate;75-R6 terminal/certificate;75-R7 terminal/interface decision
STANDARD_OBJECTS_ESTABLISHED=N0 common discriminant/norm kernel;distinct rational-split and D0-square loci;Gaussian composition packet
NEW_PROVED_RESULTS=NONE_PHASE0_IMPORT_ONLY
NEW_REDUCTIONS=PRIMARY_INTERFACE_NONE_TO_N0_DISCRIMINANT_FIRST_STATE
NEGATIVE_RESULTS=R5_TRANSVERSE_RETIRED;CURRENT_N4A_RETIRED;NO_ACTIVE_EXTERNAL_THEOREM
EXTERNAL_SOURCES_USED=NONE
WEAPON_CANDIDATES_CREATED=NONE
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
REJECTED_ROUTES=USSPAL_CHART_REOPTIMIZATION;CURRENT_N4A_RETRY;GAUSSIAN_UNIT_ORBIT_REOPENING
OUTPUT_DEPENDENCIES=01_N0_standard_forms.md;02_N0_squareclass_norm_dictionary.md;03_N0_parameter_dimension_audit.md
UNRESOLVED_ITEMS=N0 rational-norm classification on actual power-ten/divisor family;external theorem applicability
PHASE_STATUS=FROZEN
