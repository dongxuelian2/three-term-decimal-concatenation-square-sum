# 75-R8 Phase I-A — N0 Standard Forms

## 1. Frozen definitions
\[
A=2u+1,\quad uq=G+1,\quad G=10^g,\quad K=10^k,\quad 0<k<2g,
\]
\[
T_0=2KGu,\qquad L_0=GA+1=u(2G+q),
\]
\[
\boxed{N_0=T_0^2-L_0^2+2}.
\]

## 2. Form A — q-free (G,u,K)
\[
\boxed{N_0=4u^2G^2K^2-(G(2u+1)+1)^2+2}.
\]
Expanded sparsely in G:
\[
\boxed{N_0=1-2AG+\bigl(4u^2K^2-A^2\bigr)G^2}.
\]
This makes the exact 10-adic near-1 structure visible.

## 3. Form B — R9/Gaussian-target form
Since L0=u(2G+q),
\[
\boxed{N_0=2+u^2\left(4G^2K^2-(2G+q)^2\right)}.
\]
Equivalently,
\[
\boxed{N_0=2+u^2\bigl(2G(K-1)-q\bigr)\bigl(2G(K+1)+q\bigr)}.
\]
The two odd factors in parentheses are coprime:
\[
\gcd\bigl(2G(K-1)-q,\ 2G(K+1)+q\bigr)=1.
\]
Reason: their common divisor is odd and divides both 2KG and 2G+q; but gcd(2KG,2G+q)=1 because gcd(G,q)=1 and 2G+q is coprime to 2 and 5.

## 4. Form C — eliminate u in favour of q
Using u=(G+1)/q,
\[
\boxed{
q^2N_0=(G+1)^2\left(4G^2K^2-(2G+q)^2\right)+2q^2.
}
\]
Equivalently,
\[
\boxed{
q^2N_0=\bigl(2GK(G+1)\bigr)^2-\bigl((G+1)(2G+q)\bigr)^2+2q^2.
}
\]
Because q^2 is a rational square, this has the same square-class as N0 and is exactly -Delta_fib.

## 5. Form D — power-ten section
\[
\boxed{
N_0=4u^2\,10^{2g+2k}-\bigl((2u+1)10^g+1\bigr)^2+2,
\qquad u\mid10^g+1.
}
\]
Or as a sparse exponential polynomial:
\[
\boxed{
N_0=1-2(2u+1)10^g+
\left(4u^2 10^{2k}-(2u+1)^2\right)10^{2g}.
}
\]
This is NOT a fixed-coefficient exponential polynomial because u is a divisor parameter moving with g.

## 6. Exact near-square / difference-of-squares structure
\[
\boxed{N_0=(T_0-L_0)(T_0+L_0)+2}.
\]
With uq=G+1,
\[
T_0-L_0=u\bigl(2G(K-1)-q\bigr),
\]
\[
T_0+L_0=u\bigl(2G(K+1)+q\bigr).
\]
Thus N0 is naturally a shifted difference of two squares, not a Pell equation with fixed nonsquare coefficient.

## 7. Positivity on the actual q>1 family
Because u>=1 and q=(G+1)/u<=G+1, while K>=10,
\[
\frac{T_0}{u}=2KG\ge20G>3G+1\ge2G+q=\frac{L_0}{u}.
\]
Hence
\[
\boxed{T_0>L_0>0},\qquad\boxed{N_0>2>0}.
\]
There is therefore no real-place sign obstruction in the rational Gaussian norm test.

## 8. Exact congruence/coprimality package
From the sparse G-form,
\[
\boxed{N_0\equiv1\pmod G}.
\]
Since G=10^g,
\[
\boxed{\gcd(N_0,10)=1}.
\]
Since both T0 and L0 are divisible by u,
\[
\boxed{N_0\equiv2\pmod{u^2}},
\qquad
\boxed{\gcd(N_0,u)=1}
\]
(the actual u is odd because u|10^g+1).
Also T0 is divisible by 8 and L0 is odd, so
\[
\boxed{N_0\equiv1\pmod8}.
\]
Combining,
\[
\boxed{\gcd(N_0,10Gu)=1}.
\]
A useful q-residue is
\[
\boxed{N_0\equiv4u^2(K^2-1)+2\pmod q},
\]
from G=-1 mod q.

## 9. Composition reinterpretation
The exact identity
\[
D_0+J_0^2=W_0N_0,\qquad W_0=U_0^2+V_0^2
\]
means:

- W0 is a fixed explicit Gaussian norm at each source parameter tuple;
- if D0=Y^2, then
  \[
  W_0N_0=Y^2+J_0^2=N_{\mathbf Q(i)/\mathbf Q}(Y+iJ_0),
  \]
  so
  \[
  N_0=N_{\mathbf Q(i)/\mathbf Q}\!\left(\frac{Y+iJ_0}{U_0+iV_0}\right).
  \]
- therefore D0-square implies rational Gaussian norm of N0;
- the converse requires a Gaussian norm representation of W0N0 with the prescribed coordinate J0 and is NOT automatic.

Thus the arithmetic leverage of the composition identity is a **fixed-coordinate norm quotient incidence**, not an equivalence between D0-square and the rational N0 norm gate.

## 10. Standardization table

| Internal Form | Standard Arithmetic Object | Exact Equivalence | Extra Conditions | External-Theory Vocabulary |
|---|---|---|---|---|
| N0=T0^2-L0^2+2 | shifted difference of squares | exact | T0,L0 share factor u; T0>L0 | near-square; norm-form value after shift |
| N0=2+u^2(4G^2K^2-(2G+q)^2) | Gaussian-target / sparse quadratic value | exact | uq=G+1 | value set; divisor-parametrized exponential polynomial |
| q^2N0=-Delta_fib | fibre discriminant square-class | exact square-class equality | q rational/integer nonzero | discriminant; Hilbert symbol; norm residue |
| (-1,N0)=0 | fixed quadratic norm-group membership | exact current rational-split criterion | N0>0 automatic | Q(i)/Q norm; quaternion split; Hilbert norm residue |
| N0=x^2+y^2 over Q | rational Gaussian norm representation | equivalent to (-1,N0)=0 | N0>0 | norm equation; principal binary quadratic form |
| N0=x^2+y^2 over Z | integral sum of two squares | equivalent here to rational norm because N0 is a positive integer | none beyond N0 integer positive | Fermat two-square theorem; discriminant -4 principal form |
| D0+J0^2=W0N0 | fixed-coordinate Gaussian norm quotient | exact | D0 square needed to turn first summand into square coordinate | prescribed-coordinate sum of two squares; Gaussian divisibility |
| sparse G/K form | rank-two power family with divisor decoration | exact | u|(10^g+1), 0<k<2g | exponential-polynomial values; torus base plus divisor fibre |

---
STAGE_INPUTS=00_N0_imported_state.md
STANDARD_OBJECTS_ESTABLISHED=shifted_difference_of_squares;fixed_Qi_norm_value;principal_form_x2_plus_y2;fixed_coordinate_norm_quotient;sparse_rank_two_power_divisor_family
NEW_PROVED_RESULTS=N0>0;N0=1_mod_G;N0=2_mod_u2;N0=1_mod_8;gcd(N0,10Gu)=1;coprime_shift_factor_pair_after_dividing_u
NEW_REDUCTIONS=N0 rational split becomes fixed-field Gaussian norm membership;D0-square isolated as stronger prescribed-coordinate norm incidence
NEGATIVE_RESULTS=not_fixed_Pell;not_fixed_coefficient_exponential_polynomial_before_divisor_control;composition_not_converse_split_criterion
EXTERNAL_SOURCES_USED=NONE
WEAPON_CANDIDATES_CREATED=NONE
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
REJECTED_ROUTES=automatic_Pell_activation;automatic_Gaussian_composition_converse
OUTPUT_DEPENDENCIES=02_N0_squareclass_norm_dictionary.md;03_N0_parameter_dimension_audit.md
UNRESOLVED_ITEMS=uniform classification of 3mod4 prime parity in N0 values;whether divisor parameter can be eliminated or finitized
PHASE_STATUS=FROZEN
