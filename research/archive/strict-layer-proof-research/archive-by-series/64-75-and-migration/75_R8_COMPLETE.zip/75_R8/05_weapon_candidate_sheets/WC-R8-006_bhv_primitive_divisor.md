# WC-R8-006 — Primitive Divisors / Lucas–Lehmer

```text
WEAPON_ID=WC-R8-006
THEORY_FAMILY=primitive divisors of Lucas/Lehmer sequences
STANDARD_N0_OBJECT=possible restricted-prime-support collision
PRIMARY_SOURCE=Y. Bilu, G. Hanrot, P.M. Voutier, Existence of primitive divisors of Lucas and Lehmer numbers, J. Reine Angew. Math. 539 (2001), 75-122
EXACT_THEOREM=Every nth Lucas or Lehmer number for n>30 has a primitive divisor
N0_HYPOTHESIS_MAP=FAIL; N0 is not an nth term of a certified Lucas/Lehmer sequence
TARGET_SPLIT_GATE=would need a new 3 mod 4 odd-valuation prime in N0
TARGET_OTHER_GATES=none
POWER_TEN_PRESERVATION=not enough
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=wrong sequence class
EFFECTIVITY=strong within its own class
MIGRATION_COST=bridge as hard as discovering a new recurrence identity
EXPECTED_PAYOFF=none currently
FINAL_PROOF_PERSISTENCE=LOW
PRELIMINARY_VERDICT=REJECT
```

Even a primitive divisor theorem for an auxiliary sequence would still need a congruence and odd-valuation theorem forcing that divisor into N0 with residue 3 mod 4.
