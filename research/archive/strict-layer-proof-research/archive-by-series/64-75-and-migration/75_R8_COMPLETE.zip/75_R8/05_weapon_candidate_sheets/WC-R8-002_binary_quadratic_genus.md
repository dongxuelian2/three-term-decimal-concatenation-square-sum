# WC-R8-002 — Binary Quadratic Forms / Genus Theory

```text
WEAPON_ID=WC-R8-002
THEORY_FAMILY=binary quadratic forms; genus theory; class-group composition
STANDARD_N0_OBJECT=representation by x^2+y^2, discriminant -4
PRIMARY_SOURCE=classical Gauss composition/genus theory
EXACT_THEOREM=representation by the principal form is governed by local prime-exponent criterion; the class group at discriminant -4 is trivial
N0_HYPOTHESIS_MAP=FIXED_DISCRIMINANT_-4
TARGET_SPLIT_GATE=G1
TARGET_OTHER_GATES=none
POWER_TEN_PRESERVATION=irrelevant
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=fixed form
EFFECTIVITY=exact pointwise criterion
MIGRATION_COST=LOW
EXPECTED_PAYOFF=ZERO beyond WC-R8-001
FINAL_PROOF_PERSISTENCE=LOW as a separate citation
PRELIMINARY_VERDICT=REJECT
```

There is no moving class group to finite-ize. Genus theory would add machinery without reducing the remaining N0-value problem.
