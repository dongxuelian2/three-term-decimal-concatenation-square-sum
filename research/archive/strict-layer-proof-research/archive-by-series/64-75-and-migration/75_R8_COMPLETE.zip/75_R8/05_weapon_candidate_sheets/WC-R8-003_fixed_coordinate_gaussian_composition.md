# WC-R8-003 — Fixed-Coordinate Gaussian Composition

```text
WEAPON_ID=WC-R8-003
THEORY_FAMILY=Gaussian factorization / prescribed-coordinate norm representation
STANDARD_N0_OBJECT=D0+J0^2=W0*N0 with W0=U0^2+V0^2
PRIMARY_SOURCE=internal R17/R18 composition plus classical Gaussian factorization
EXACT_THEOREM=If D0=Y^2 then W0*N0=Y^2+J0^2 and hence N0 is a rational Gaussian norm; converse requires a representation of W0*N0 with prescribed coordinate J0
N0_HYPOTHESIS_MAP=exact internal identity
TARGET_SPLIT_GATE=only a sufficient sublocus for G1
TARGET_OTHER_GATES=R17/R18 composition explanation
POWER_TEN_PRESERVATION=YES
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=no verified theorem found classifying representations with this moving prescribed coordinate across the family
EFFECTIVITY=not applicable
MIGRATION_COST=HIGH relative to payoff
EXPECTED_PAYOFF=structural interpretation only
FINAL_PROOF_PERSISTENCE=MEDIUM as internal identity, LOW as external theorem stack
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```

Exact counterexample to converse: (G,K,u,q)=(10,10,1,11) has N0=39041=25^2+196^2 but D0=3515616400 is not a square.
