# WC-R8-001 — Fixed Gaussian Norm / Hasse Norm Theorem

```text
WEAPON_ID=WC-R8-001
THEORY_FAMILY=Hasse norm theorem + Gaussian norm criterion
STANDARD_N0_OBJECT=positive integer N0 in N_{Q(i)/Q}(Q(i)^*)
PRIMARY_SOURCE=H. Hasse, Beweis eines Satzes und Wiederlegung einer Vermutung über das allgemeine Normenrestsymbol, Nachrichten Göttingen (1931), 64-69
EXACT_THEOREM=For a cyclic extension L/K, an element of K* that is a local norm at every place is a global norm; specialized to Q(i)/Q and positive integer N0 this matches the classical p≡3 mod4 even-valuation criterion
N0_HYPOTHESIS_MAP=FIELD_FIXED_TRUE;RHS=N0(G,K,u);POSITIVITY_TRUE;INTEGRALITY_TRUE
TARGET_SPLIT_GATE=G1 rational split
TARGET_OTHER_GATES=none automatically
POWER_TEN_PRESERVATION=YES but unused by theorem
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES;the theorem only decides ambient rational norm
UNIFORMITY_SCOPE=uniform in the fixed field but conclusion is pointwise local-norm membership, not family classification
EFFECTIVITY=criterion effective given factorization/local valuations;no family height bound
MIGRATION_COST=LOW
EXPECTED_PAYOFF=exact standard dictionary only
FINAL_PROOF_PERSISTENCE=HIGH as a clean statement of the split criterion, LOW as an external weapon
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```

Reason: this theorem is already exactly saturated by the Phase-I square-class dictionary. It does not constrain which 3 mod 4 primes divide N0 to odd order.
