# WC-R8-008 — Polynomial Values Represented by Quadratic Forms

```text
WEAPON_ID=WC-R8-008
THEORY_FAMILY=representation of polynomial values by fixed binary quadratic forms
STANDARD_N0_OBJECT=x^2+y^2=N0(G,K,u)
PRIMARY_SOURCE=B. Grechuk, J. Agbanwa, On the polynomial values represented by quadratic forms, arXiv:2607.06627 (2026); compare S. Iyer, Cubic polynomials and sums of two squares, arXiv:2510.25492 (2025)
EXACT_THEOREM=methods/results for a fixed univariate polynomial P(n) represented by a fixed form, including certain cubic/quartic/composite P and sum-of-two-squares examples
N0_HYPOTHESIS_MAP=FAIL; actual N0 is D2 rank-two power base plus moving divisor fibre, not a fixed univariate P(n)
TARGET_SPLIT_GATE=G1
TARGET_OTHER_GATES=none
POWER_TEN_PRESERVATION=no direct theorem map
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=fixed polynomial, not the moving coefficient family here
EFFECTIVITY=not a family-classification theorem for this input; key results include infinitude/existence
MIGRATION_COST=requires freezing parameters, yielding only fixed-fibre statements
EXPECTED_PAYOFF=none at family level
FINAL_PROOF_PERSISTENCE=LOW
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```
