# WC-R8-007 — Cyclotomic Sum-of-Two-Squares Classification

```text
WEAPON_ID=WC-R8-007
THEORY_FAMILY=cyclotomic factorization + Fermat two-squares criterion
STANDARD_N0_OBJECT=sparse power-ten/divisor value
PRIMARY_SOURCE=G. Dresden et al., When is a^n+1 the sum of two squares?, Involve 12 (2019), 585-605; arXiv:1609.04391
EXACT_THEOREM=classification consequences for the special sequence a^n+1 using cyclotomic/Aurifeuilian factorization
N0_HYPOTHESIS_MAP=FAIL; N0 is not a fixed a^n+1 sequence and contains both K and a moving divisor u of G+1
TARGET_SPLIT_GATE=G1
TARGET_OTHER_GATES=potential prime-support understanding
POWER_TEN_PRESERVATION=YES in spirit, not in theorem input
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=wrong family
EFFECTIVITY=structured for the specific sequence
MIGRATION_COST=requires a new exact factorization of N0
EXPECTED_PAYOFF=none currently
FINAL_PROOF_PERSISTENCE=LOW
PRELIMINARY_VERDICT=REJECT
```
