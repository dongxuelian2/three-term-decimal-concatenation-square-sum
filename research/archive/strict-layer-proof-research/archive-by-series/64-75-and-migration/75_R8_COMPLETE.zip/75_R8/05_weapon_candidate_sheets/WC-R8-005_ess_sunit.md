# WC-R8-005 — Evertse–Schlickewei–Schmidt / S-Unit

```text
WEAPON_ID=WC-R8-005
THEORY_FAMILY=Subspace theorem / linear equations in finite-rank multiplicative groups
STANDARD_N0_OBJECT=x^2+y^2=1-2AG+(4u^2K^2-A^2)G^2
PRIMARY_SOURCE=J.-H. Evertse, H.P. Schlickewei, W.M. Schmidt, Linear equations in variables which Lie in a multiplicative group, Ann. of Math. 155 (2002), 807-836, DOI 10.2307/3062133
EXACT_THEOREM=For fixed finite-rank Gamma subset (K*)^n, nondegenerate solutions in Gamma to a fixed linear equation have an explicit bound depending on n and rank
N0_HYPOTHESIS_MAP=FAIL; x,y are not in a fixed finite-rank multiplicative group and u/q is not eliminated to fixed Gamma-coordinates
TARGET_SPLIT_GATE=potentially family finiteness after stronger reduction
TARGET_OTHER_GATES=power-ten incidence
POWER_TEN_PRESERVATION=YES for G,K but not enough
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=YES
UNIFORMITY_SCOPE=not reached
EFFECTIVITY=quantitative solution-count theorem, but irrelevant before hypothesis map
MIGRATION_COST=HIGH
EXPECTED_PAYOFF=HIGH after a new bridge, ZERO currently
FINAL_PROOF_PERSISTENCE=VERY_HIGH if activated
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```
