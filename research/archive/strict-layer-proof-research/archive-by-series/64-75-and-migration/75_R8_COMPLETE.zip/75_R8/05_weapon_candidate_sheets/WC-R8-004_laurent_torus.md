# WC-R8-004 — Laurent Exponential-Diophantine / Torus Intersection

```text
WEAPON_ID=WC-R8-004
THEORY_FAMILY=Laurent-type exponential Diophantine / Mordell-Lang for tori
STANDARD_N0_OBJECT=potential algebraic incidence over (G,K) in Gamma_10
PRIMARY_SOURCE=M. Laurent, Equations diophantiennes exponentielles, Invent. Math. 78 (1984), 299-327, DOI 10.1007/BF01388597
EXACT_THEOREM=torus/finitely-generated multiplicative-group intersection finiteness framework
N0_HYPOTHESIS_MAP=FAILS_FIXED_SOURCE_IMAGE; x,y free; u/q moving divisor fibre
TARGET_SPLIT_GATE=potentially G1 if exact fixed source image existed
TARGET_OTHER_GATES=power-ten incidence; potentially q=1/general-J architecture
POWER_TEN_PRESERVATION=EXCELLENT
SOURCE_SEMANTICS_REQUIRED_AFTER_APPLICATION=UNRESOLVED
UNIFORMITY_SCOPE=not reached
EFFECTIVITY=not the primary issue; applicability fails first
MIGRATION_COST=currently prohibitive because a new exact source-image bridge is required
EXPECTED_PAYOFF=very high only after a genuinely new internal algebraicization
FINAL_PROOF_PERSISTENCE=VERY_HIGH if ever activated
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

R8 re-test result: N0 standardization does not remove the R6/R7 activation blocker.
