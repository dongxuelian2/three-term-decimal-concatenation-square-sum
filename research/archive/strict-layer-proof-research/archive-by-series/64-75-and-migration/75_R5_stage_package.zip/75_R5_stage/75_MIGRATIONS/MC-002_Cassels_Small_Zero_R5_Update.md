# MC-002 — R5 Update

```text
MIGRATION_CARD_ID=MC-002
STATUS=MIGRATED
ROLE=FALLBACK_BENCHMARK_FOR_SOURCE_SPLITTING_HEIGHT
PROOF_ROLE=FALLBACK_ONLY
ACTIVE_DEPENDENCY=NO
```

The Cassels small integral zero theorem remains legally migrated and historically valid.

R5 does not optimize its constant and does not use it as the active source-chart engine.  The active chart analysis is conditional on an exact allowed-ruling source point and uses the R20 source Veronese construction plus the R5 transverse source direction.

The generic fallback remains

\[
D_{\rm Cassels}
\le
160000\,C_C(3)G^{12}u^2,
\]

and with the old coarse \(E\le u\),

\[
J_{\rm fallback}
\le
160000\,C_C(3)G^{12}u^4.
\]

No historical migration is deleted.
