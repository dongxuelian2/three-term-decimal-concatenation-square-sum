# MC-001 — R5 Status

```text
MIGRATION_CARD_ID=MC-001
STATUS=SUPERSEDED
PROOF_ROLE=PROVENANCE_ONLY
ACTIVE_DEPENDENCY=NO
```

R5 does not reopen the Huang fixed-data primitive local-counting migration.  R3 already replaced the primitive-sector distribution layer by elementary \(\mathbf P^1(\mathbb Q)\) approximation.
