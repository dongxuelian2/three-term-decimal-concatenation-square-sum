# 75-R5 — Existing Special Source Point Audit

## Search scope

The R13–R20 lineage was audited for objects that could already be reused as an exact allowed-ruling source point:

- primitive source rays;
- boundary source rows;
- source norm vectors;
- isotropic rows;
- Veronese seeds;
- Gaussian/composition seeds;
- semantic source vectors;
- rational ruling witnesses.

## Result

No previously certified artifact supplies a point \(p=(Z,a,x)\) simultaneously satisfying

\[
Q_\tau(p)=0,
\qquad
p\in L_{\rm source},
\qquad
p\ \text{primitive},
\qquad
x\equiv\pm Z\pmod u,
\]

with a source-specific uniform bound on the relevant digit coordinate \(a_p\).

R20 proves existence of source-lattice integral points on a rationally split fibre by homogeneous scaling, but that theorem is qualitative in height.  It does not furnish the R5 clearance-useful denominator bound.

## Status

```text
EXISTING_ALLOWED_RULING_SMALL_SOURCE_POINT=NOT_FOUND
R20_QUALITATIVE_SOURCE_POINT_EXISTENCE=REUSED
R20_QUANTITATIVE_SOURCE_HEIGHT=OPEN
```
