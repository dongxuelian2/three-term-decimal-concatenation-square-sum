# 75-R5 — Allowed-\(u\) Preimages

## 1. Linear unit condition

For C1 the sufficient allowed preimage is

\[
\boxed{
\mathcal B_u^{\rm suff}
=
\{[s:t]\in\mathbf P^1(\mathbb Z/u\mathbb Z):
(s-\sigma M_st,u)=1\}.
}
\]

Since \((M_s,u)=1\), the map

\[
[s:t]\mapsto[s-\sigma M_st:t]
\]

is a projective automorphism modulo \(u\).

## 2. Projective density

For a prime-power component \(p^e\), the proportion of projective classes whose first coordinate is a unit equals

\[
\frac{p}{p+1}.
\]

By CRT, the sufficient preimage density is

\[
\boxed{
\delta_u^{\rm suff}
=
\prod_{p\mid u}\frac{p}{p+1}.
}
\]

This is a closed whole-modulus cardinality statement, not a prime-by-prime obstruction classification.

## 3. Height inflation

Fix a real target parameter interval of width \(\delta\).  For fixed \(t\), varying \(s\) through an interval of length at least \(j(u)\) forces one value with

\[
(s-\sigma M_st,u)=1.
\]

Thus

\[
t\ll j(u)\delta^{-1}
\]

suffices and

\[
\boxed{
E_\tau(\Phi_p^\perp)
\ll
j(u).
}
\]

Using the frozen whole-modulus estimate,

\[
j(u)=G^{o(1)}.
\]

Therefore

\[
\boxed{
E=u
\quad\rightsquigarrow\quad
E=G^{o(1)}.
}
\]

R5 does **not** prove \(E=O(1)\).
