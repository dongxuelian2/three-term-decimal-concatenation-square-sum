# 75-R5 — Joint Cost Definition

## 1. Good source charts

A chart \(\Phi:\mathbf P^1\to C_\tau\) is admitted to \(\mathscr G_\tau\) only if it is:

1. source-integral;
2. primitive-compatible;
3. equipped with a source digit-height distortion \(D_\tau(\Phi)\);
4. compatible with the allowed projective \(u\)-open with cost \(E_\tau(\Phi)\);
5. compatible with the relevant real digit component;
6. compatible with the R14 multiplier and R20 inverse reconstruction.

## 2. Joint optimization object

\[
\boxed{
\mathfrak J_\tau
=
\inf_{\Phi\in\mathscr G_\tau}
D_\tau(\Phi)E_\tau(\Phi)^2.
}
\]

For an explicit candidate \(\Phi^{\rm src}_\tau\),

\[
J^{\rm src}_\tau
=
D_\tau(\Phi^{\rm src}_\tau)
E_\tau(\Phi^{\rm src}_\tau)^2.
\]

## 3. Clearance interface

The only R5 clearance comparison is

\[
\boxed{
J^{\rm src}_\tau\,j(10u)
<
G\Psi(R_{\rm LOW}).
}
\]

For \(0<R_{\rm LOW}\le1\),

\[
\Psi(R_{\rm LOW})\ge \frac{R_{\rm LOW}^3}{36},
\]

so

\[
\boxed{
R_{\rm LOW}>
R_*^{\rm src}
:=
\left(
36\frac{J^{\rm src}_\tau j(10u)}{G}
\right)^{1/3}.
}
\]

R5 may define an Ultra-LOW locus only after the right side is shown to be genuinely \(<1\), preferably \(o(1)\).
