# 75-R5 — Source-Lattice Ruling Lift

## 1. Exact saturated source core

Use

\[
\begin{aligned}
F_0(Z,a,x)
={}&G^3(GA+2)Z^2
-4u(G^2A^2+GA-1)Za\\
&-4G^3KuZx
+4u^2A^3a^2\\
&+8Ku^2(GA-1)ax
+G^2Ax^2,
\end{aligned}
\]

with

\[
A=2u+1,\qquad uq=G+1.
\]

The primitive source form \(Q_\tau\) is obtained after exact source-basis pullback and primitive-content division.

## 2. Natural ruling substitution

Put

\[
x=\sigma Z+u\lambda,
\qquad
\sigma\in\{\pm1\}.
\]

Then

\[
\boxed{
F_0(Z,a,\sigma Z+u\lambda)
=
u\,\mathcal Q_\sigma(Z,a,\lambda),
}
\]

where

\[
\begin{aligned}
\mathcal Q_\sigma={}&
G^2Au\,\lambda^2\\
&+\Bigl(
2\sigma G^2AZ
-4G^3KuZ
+8Ku^2(GA-1)a
\Bigr)\lambda\\
&+\Bigl(
G^2[2(G^2+1)+uq^2]
-4\sigma G^3K
\Bigr)Z^2\\
&+\Bigl(
-4(G^2A^2+GA-1)
+8\sigma Ku(GA-1)
\Bigr)Za\\
&+4uA^3a^2.
\end{aligned}
\tag{R5-LIFT}
\]

This identity has been symbolically cross-checked under \(A=2u+1\), \(uq=G+1\), \(\sigma^2=1\).

## 3. Verdict

\[
\boxed{
x\equiv\pm Z\pmod u
\text{ does not linearize the exact source conic.}
}
\]

For fixed \(Z\), the lift remains a genuine quadratic equation in \((a,\lambda)\).

## 4. Cost of taking \(Z=1\)

The source lattice has the form

\[
Z\equiv\rho_s a\pmod{M_s},
\qquad
M_s=\frac{G}{\gcd(G,2d(q+4))}.
\]

The source coefficient \(\rho_s\) is a unit modulo \(M_s\).  Hence \(Z=1\) requires only

\[
\boxed{
a\equiv\rho_s^{-1}\pmod{M_s},
}
\]

so one may choose a positive representative with

\[
1\le a\le M_s\le G.
\]

The cost \(O(M_s)\) is a lattice-selection cost only.  It does not solve \(\mathcal Q_\sigma=0\).
