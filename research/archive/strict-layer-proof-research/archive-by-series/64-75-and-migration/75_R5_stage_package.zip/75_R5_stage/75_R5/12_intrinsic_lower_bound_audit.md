# 75-R5 — Intrinsic Lower-Bound Audit

## 1. Binary section

Restrict the source conic to \(a=0\).  Up to irrelevant square scalars the resulting binary form is

\[
A x^2
-4GKuZx
+G(GA+2)Z^2.
\]

Its discriminant is

\[
\boxed{
\Delta_{a=0}
=
4(N_0-1),
}
\]

where

\[
N_0
=
4K^2G^2u^2-(GA+1)^2+2.
\]

Source-basis replacement \(Z\mapsto M_sw_1\) multiplies this discriminant by a square; primitive-content division also changes it by a square.

Hence the square-class attached to the \(a\)-height binary form of any birational integral chart is governed by

\[
\boxed{
N_0-1.
}
\]

## 2. Squarefree-kernel lower-bound mechanism

Let

\[
\operatorname{sf}(N_0-1)
\]

be the positive squarefree kernel.

For a binary quadratic \(f_\Phi(s,t)=a(\Phi(s,t))\) whose coefficients are bounded by the chart distortion \(D(\Phi)\), a safe discriminant estimate gives

\[
|\operatorname{disc} f_\Phi|
\le 13D(\Phi)^2.
\]

Therefore

\[
\boxed{
D(\Phi)
\ge
\sqrt{
\frac{\operatorname{sf}(N_0-1)}{13}
}.
}
\tag{INTRINSIC}
\]

## 3. Status

This is a chart-independent **mechanism**, but R5 does not prove a uniform lower bound

\[
\operatorname{sf}(N_0-1)\ge G^\delta.
\]

Consequently the USSPAL route is not yet structurally dead.

```text
INTRINSIC_LOWER_BOUND_MECHANISM=PROVED
UNIFORM_G_EXPONENT_BARRIER=UNRESOLVED
```
