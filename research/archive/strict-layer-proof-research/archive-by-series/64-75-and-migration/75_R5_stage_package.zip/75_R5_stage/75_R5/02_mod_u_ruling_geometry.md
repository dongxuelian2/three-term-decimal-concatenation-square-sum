# 75-R5 — Mod-\(u\) Ruling Geometry

## Frozen special-fibre statement

On the actual source model,

\[
\boxed{
Q_\tau(Z,a,x)
\equiv
\varepsilon(x^2-Z^2)
\pmod u,
\qquad
\varepsilon\in(\mathbb Z/u\mathbb Z)^\times.
}
\]

Therefore the two full projective ruling graphs are

\[
x\equiv Z\pmod u,
\qquad
x\equiv -Z\pmod u.
\]

In particular the allowed locus contains

\[
[Z:a:x]=[1:r:+1],
\qquad
[1:r:-1]
\]

for every \(r\bmod u\).

## Source-coordinate compatibility

The source lattice modulus \(M_s\) divides \(G\), while

\[
uq=G+1.
\]

Hence

\[
\boxed{(M_s,u)=1.}
\]

Thus the source lattice congruence and the \(u\)-ruling coordinate are CRT-independent at the whole-modulus level.  There is no source-lattice reason to pay a full factor \(u\).

## R5 consequence

The local-open problem is not a sparse-residue problem.  The correct objective is to choose a chart whose mod-\(u\) image is automatically contained in one ruling, up to a single unit condition.
