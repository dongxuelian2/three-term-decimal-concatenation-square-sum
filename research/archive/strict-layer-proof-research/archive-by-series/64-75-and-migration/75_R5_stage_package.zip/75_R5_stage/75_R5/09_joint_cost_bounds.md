# 75-R5 — Joint Cost Bounds

## Best conditional source-specific cost

For the allowed-ruling transverse Veronese chart,

\[
D(\Phi_p^\perp)
\le
a_p\mathcal H_{\perp,\tau},
\]

and

\[
E(\Phi_p^\perp)\ll j(u).
\]

Therefore

\[
\boxed{
J_{p,\sigma}^{\perp}
=
D(\Phi_p^\perp)E(\Phi_p^\perp)^2
\ll
a_p\mathcal H_{\perp,\tau}j(u)^2.
}
\tag{JOINT-R5}
\]

## Generic fallback

\[
\boxed{
J_{\rm fallback}
\le
160000C_C(3)G^{12}u^4.
}
\]

## Certified exponent gain

The allowed-\(u\) contribution changes from

\[
u^2
\]

to

\[
j(u)^2=G^{o(1)}.
\]

If \(u\asymp G^\theta\), this is the local exponent improvement

\[
\boxed{
G^{2\theta}
\longrightarrow
G^{o(1)}.
}
\]

## What is not certified

A total \(G\)-exponent gain for \(J_\tau\) is **not** yet proved, because no uniform upper bound has been established for

\[
a_p\mathcal H_{\perp,\tau}
\]

for an exact allowed-ruling source basepoint.

```text
LOCAL_u_EXPONENT_GAIN=PROVED
TOTAL_JOINT_EXPONENT_GAIN=UNRESOLVED
```
