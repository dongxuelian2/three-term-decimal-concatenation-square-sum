# 75-R5 — N1 Side Audit

## Scope

R5 allocates only a low-cost audit to N1.  The frozen rational split test remains

\[
\boxed{
(-1,N_0)=0.
}
\]

The current source-specific construction is conditional on having an exact rationally split fibre and an exact allowed-ruling source basepoint.

## Result

The mod-\(u\) identities

\[
x\equiv\pm Z\pmod u
\]

do not by themselves produce a global rational isotropic point.  The direct exact lift remains the quadratic equation (R5-LIFT), and no composition constructor was found.

Therefore no additional N1 family is automatically closed or automatically split in R5.

```text
N1_STATUS=OPEN
SPLIT_FAMILY_STATUS=UNCHANGED
FREE_N1_CLOSURE=NONE
```
