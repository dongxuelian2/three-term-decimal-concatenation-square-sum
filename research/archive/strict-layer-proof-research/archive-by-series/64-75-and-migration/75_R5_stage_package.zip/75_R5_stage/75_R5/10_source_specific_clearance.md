# 75-R5 — Source-Specific Clearance

For C1,

\[
J_{p,\sigma}^{\perp}
\ll
a_p\mathcal H_{\perp,\tau}j(u)^2.
\]

Hence the R5 source-specific threshold is

\[
\boxed{
R_*^{\rm src}
\ll
\left(
36\frac{
a_p\mathcal H_{\perp,\tau}
j(u)^2j(10u)
}{G}
\right)^{1/3}.
}
\]

Since \(j(u),j(10u)=G^{o(1)}\), a sufficient quantitative target is

\[
\boxed{
a_p\mathcal H_{\perp,\tau}
\le
G^{1-\delta+o(1)}
}
\]

for some \(\delta>0\).  Then

\[
R_*^{\rm src}
\le
G^{-\delta/3+o(1)}
\to0.
\]

This identifies the exact remaining positive theorem:

> **Allowed-Ruling Source Denominator Theorem.**  
> On every relevant rationally split fibre, produce an exact primitive source point on one full allowed \(u\)-ruling with
> \[
> a_p\mathcal H_{\perp,\tau}\le G^{1-\delta+o(1)}.
> \]

No generic small-zero theorem currently supplies this bound.
