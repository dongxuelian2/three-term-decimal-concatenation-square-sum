# 75-R5 Stage Package

This directory freezes the output of **75 第五轮**.

## Terminal status

\[
\boxed{
\texttt{R5_TERMINAL_VERDICT=SOURCE_SPECIFIC_ADVANTAGE_UNRESOLVED}
}
\]

\[
\boxed{
N2=\texttt{OPEN\_REDUCED}.
}
\]

## Strongest positive result

Conditional on one exact allowed-ruling source basepoint, the R20 source-adapted Veronese chart admits a source transversal for which

\[
\boxed{
E(\Phi)=O(j(u))=G^{o(1)}
}
\]

rather than \(E\le u\).

The matching distortion is

\[
\boxed{
D(\Phi)\le a_p\mathcal H_{\perp,\tau}.
}
\]

Thus the residual positive theorem is no longer a generic small-zero theorem; it is an **allowed-ruling source denominator theorem** controlling \(a_p\).

## Strongest negative result

The current cubic clearance threshold has the absolute structural floor

\[
R_*^{\rm src}\ge(36/G)^{1/3},
\]

so the old integer lower bound \(R_{\rm LOW}\gtrsim G^{-1}\) cannot by itself finish the collision.

## Directory

- `00`–`16`: stage research files.
- `17_R5-certificate.txt`: compact frozen-state certificate.
- sibling `75_MIGRATIONS/`: migration ledger update.
- `SHA256SUMS.txt`: integrity hashes.
