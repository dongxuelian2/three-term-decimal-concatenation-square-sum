# 75-R5 — R4 Imported Frozen State

**Project:** 三项十进制拼接平方和问题  
**Round:** 75 第五轮  
**Imported status:** `N2=OPEN_REDUCED`

## Frozen inputs

R4 is imported without reopening its generic optimization layer.

\[
\mathfrak D_\tau\le 16C_C(3)H(Q_\tau)^2
\]

and, for the actual family,

\[
\mathfrak D_\tau
\le 160000\,C_C(3)G^{12}u^2
=
193600\,C_C(3)\frac{G^{14}}{q^2}.
\]

The old coarse allowed-\(u\) cost is

\[
\mathfrak E_\tau\le u.
\]

Hence the R4 fallback joint cost is

\[
\boxed{
J_{\rm fallback}
\le
160000\,C_C(3)G^{12}u^4.
}
\]

## Frozen migration ledger

- `MC-001`: `SUPERSEDED_FOR_P2_USSPAL_ENGINE`; retained for provenance.
- `MC-002`: `MIGRATED`; role = `FALLBACK_BENCHMARK_FOR_SOURCE_SPLITTING_HEIGHT`.
- No numerical optimization of Cassels constants is reopened in R5.

## Frozen source interface

The source conic is the primitive pullback \(Q_\tau\) of the saturated ternary core \(F_0(Z,a,x)\) to the exact source basis.  R20 provides an integral degree-two chord/Veronese parameterization once an integral isotropic source basepoint is supplied.

## R5 strategic replacement

R5 does **not** optimize \(\mathfrak D_\tau\) and \(\mathfrak E_\tau\) separately.  It studies

\[
\boxed{
\mathfrak J_\tau
=
\inf_{\Phi\in\mathscr G_\tau}
D_\tau(\Phi)E_\tau(\Phi)^2.
}
\]

The only acceptable improvement is source-specific and joint.
