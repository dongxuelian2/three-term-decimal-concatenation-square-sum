# 75-R5 — Candidate Split Charts

## Candidate C1 — conditional allowed-ruling transverse Veronese chart

Assume an exact source-integral isotropic point

\[
p=(z,a_p,x_p)
\]

satisfies

\[
z\in(\mathbb Z/u\mathbb Z)^\times,
\qquad
x_p\equiv\sigma z\pmod u,
\qquad
\sigma\in\{\pm1\}.
\]

R20 provides the integral chord/Veronese construction

\[
\Phi_p(y)
=
Q_\tau(y)p-\mathcal B(p,y)y,
\]

where

\[
\mathcal B(v,w)=Q_\tau(v+w)-Q_\tau(v)-Q_\tau(w).
\]

Choose the source-lattice transversal

\[
y(s,t)=(M_st,0,s).
\]

This is source-integral because \((M_s,0,0)\) and \((0,0,1)\) are source-lattice directions.

## Mod-\(u\) degeneration

Modulo \(u\),

\[
Q_\tau=\varepsilon(x^2-Z^2).
\]

Define

\[
L_\sigma(s,t)=s-\sigma M_st.
\]

A direct substitution into the chord formula gives

\[
\boxed{
\Phi_Z
\equiv
\varepsilon z\,L_\sigma(s,t)^2
\pmod u,
}
\]

and

\[
\boxed{
\Phi_x
\equiv
-\sigma\Phi_Z
\pmod u.
}
\tag{VER-U}
\]

Thus every parameter pair satisfying

\[
(L_\sigma(s,t),u)=1
\]

maps into the **opposite full allowed ruling** with unit \(Z\)-coordinate.

## Candidate status

```text
CHART=C1_ALLOWED_RULING_TRANSVERSE_VERONESE
SOURCE_INTEGRAL=PASS
MOD_u_RULING=PASS_CONDITIONAL_ON_BASEPOINT
PRIMITIVE_COMPATIBILITY=PASS_AFTER_PARAMETER_GCD_EXTRACTION
REAL_COVERAGE=PASS_CONDITIONAL_ON_BASEPOINT_COMPONENT
BASEPOINT_HEIGHT=OPEN
```

This is the R5 best chart.
