# 75-R5 — Chart Distortion Table

## 1. Exact digit-coordinate simplification for C1

For the transversal

\[
y(s,t)=(M_st,0,s),
\]

the \(a\)-component of the R20 chord formula simplifies because \(y_a=0\):

\[
\boxed{
a(\Phi_p(s,t))
=
a_p\,Q_\tau(y(s,t)).
}
\]

Using the pre-content source core,

\[
Q_\tau(M_st,0,s)
=
\frac{
G^2A s^2
-4G^3KuM_s st
+G^3(GA+2)M_s^2t^2
}{C_\Gamma}.
\]

Define

\[
\boxed{
\mathcal H_{\perp,\tau}
=
\frac{
G^2A
+4G^3KuM_s
+G^3(GA+2)M_s^2
}{C_\Gamma}.
}
\]

Then

\[
\boxed{
D(\Phi_p^\perp)
\le
a_p\mathcal H_{\perp,\tau}.
}
\tag{D-PERP}
\]

The full Euclidean basepoint height has disappeared from this bound.  Only \(a_p\) remains.

## 2. Natural-chart floor

The R5 coefficient-content audit gives the safe bound

\[
C_\Gamma\le 8AK.
\]

Hence

\[
\frac{G^2A}{C_\Gamma}
\ge
\frac{G^2}{8K}
=
\frac{10^\ell}{8}.
\]

Therefore

\[
\boxed{
D(\Phi_p^\perp)
\ge
\frac{a_p10^\ell}{8}.
}
\tag{D-FLOOR}
\]

With \(\ell\ge6\),

\[
D(\Phi_p^\perp)\ge125000\,a_p.
\]

This floor is not by itself a uniform \(G^\delta\) obstruction.

## 3. Comparison table

| Constructor | \(D(\Phi)\) | Local cost \(E(\Phi)\) | Joint cost | Status |
|---|---:|---:|---:|---|
| R4 generic Cassels | \(\le160000C_C(3)G^{12}u^2\) | \(\le u\) | \(\le160000C_C(3)G^{12}u^4\) | fallback |
| C1 transverse Veronese | \(\le a_p\mathcal H_{\perp,\tau}\) | \(O(j(u))\) | \(O(a_p\mathcal H_{\perp,\tau}j(u)^2)\) | best, conditional |
