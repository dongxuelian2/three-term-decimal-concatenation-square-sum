# Migration Card MC-002 — Cao–Xu Toric Strong Approximation

## MIGRATION_CARD_ID
`MC-002`

## STATUS
`PARTIALLY_MIGRATED`

## EXTERNAL_THEOREM
Cao–Xu, Theorem 1.2: smooth toric varieties satisfy strong approximation with Brauer–Manin obstruction off infinity.

## THEOREM_CARD_REF
`75_R2/THEOREM_CARDS/TC-002_Cao_Xu_Theorem_1_2.md`

## SOURCE
Yang Cao and Fei Xu, Ann. Inst. Fourier 68 (2018), 1879–1908, Theorem 1.2, p.1881.

## PROJECT_TARGET
B1/B2 qualitative external skeleton; not B3.

## OUR_OBJECT
Split generic punctured source cone \(X_\tau^\times\).

## EXTERNAL_OBJECT
Smooth toric variety over \(\mathbb Q\).

## OBJECT_MAP
\(X_\tau^\times\mapsto X\) after N1 split certification. Integral source conditions remain encoded through the R20 model and chosen finite opens.

## HYPOTHESIS_LEDGER
- smooth generic punctured cone: **PASS**.
- toric on split fibre: **PASS**.
- BM-compatible finite adelic open: **PASS/CONTROLLED** for actual ray layer.
- prescribed moving real component/height: **FAIL AS A CONCLUSION OF THIS THEOREM**.

## LOCAL_PLACE_LEDGER
All finite bad places remain explicit in the source open; theorem does not justify replacing the R20 integral model by a smooth model at bad primes.

## ARCHIMEDEAN_LEDGER
The theorem is off infinity; it supplies no B3 radial/sector control. The paper explicitly warns that the proof cannot force prescribed real connected components.

## PRIMITIVITY_LEDGER
Not theorem-native in the source ray×multiplier sense; handled by R14/source lattice.

## SEMANTIC_PRESERVATION
```text
SOURCE_ROW=PRESERVED_EXTERNALLY_ONLY_VIA_R20_LOCAL_OPEN_INTERFACE
SOURCE_LATTICE=PRESERVED
PRIMITIVITY=BRIDGE_REQUIRED
DIGIT_REGION=NOT_APPLICABLE
POWER_TEN_PARAMETER=NOT_APPLICABLE
ORIGINAL_RECONSTRUCTION=PRESERVED
```

## BRAUER_RECIPROCITY_STATUS
`CONTROLLED`

## REQUIRED_BRIDGES
No bridge for its limited qualitative role. B3 is outside theorem scope.

## BRIDGE_DIFFICULTY
`ROUTINE` for the limited role.

## IMPORTED_CONCLUSION
> On each rationally split generic fibre, the smooth toric punctured cone has the standard strong-approximation-with-Brauer–Manin framework at finite places; therefore no bespoke finite Spin-orbit theory is needed merely to formulate the finite approximation problem.

## M_LEVEL
`M4`

## G_LEVEL
`G2`

## DEPENDENCY_GRAPH_POSITION
`N1(split) -> MC-002 qualitative BM skeleton -> projective/ray quantitative layer`

## REPLACED_INTERNAL_MACHINERY
Supports permanent retirement of generic finite toric/Spin re-architecture; does not replace R14 radial shell.

## CURRENT_BLOCKER
`NONE_WITHIN_LIMITED_SCOPE`

## NEXT_ACTION
Use only as qualitative support; do not spend R3 budget extending it to the real height problem.

## UPDATE_LOG
- **2026-08-18 / 75-R2:** created and marked `PARTIALLY_MIGRATED` after exact real-place limitation audit.
