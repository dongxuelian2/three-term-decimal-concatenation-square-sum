# Migration Card MC-003 — Kelmer–Yu Shrinking-Sector Approximation

## MIGRATION_CARD_ID
`MC-003`

## STATUS
`BRIDGE_REQUIRED`

## EXTERNAL_THEOREM
Kelmer–Yu, Theorem 1.7, with Remark 1.19.

## THEOREM_CARD_REF
`75_R2/THEOREM_CARDS/TC-003_Kelmer_Yu_Theorem_1_7.md`

## SOURCE
Dubi Kelmer and Shucheng Yu, arXiv:2212.11035v2, Theorem 1.7, Remark 1.19.

## PROJECT_TARGET
B3 shrinking/moving projective sector.

## OUR_OBJECT
The projective source conic \(C_\tau\) with source height \(a_0\), compact target subarc \(J_\tau\), and finite source open.

## EXTERNAL_OBJECT
Fixed rational ellipsoid / light cone, primitive rational points of denominator height \(<T\), angular ball of radius \(r\).

## OBJECT_MAP
After a rational real normalization of a fixed split conic, map source projective points to the ellipsoid. Source height and angular metric differ by fibre-dependent constants that must be audited uniformly.

## HYPOTHESIS_LEDGER
- signature (2,1): **PASS**, corresponds to n=1.
- rational isotropy: **PASS CONDITIONALLY** on N1 split.
- no exceptional pole: **PASS** for n=1 according to the paper.
- shrinking sectors at all centers to r ~ T^-1/2: **PASS fixed form**.
- finite congruence/local source open: **UNKNOWN / not in Thm. 1.7**.
- uniform constants over moving source family: **UNKNOWN**.

## LOCAL_PLACE_LEDGER
No full source local-open support in this theorem; requires combination with Huang-style congruence counting or a congruence-cover extension.

## ARCHIMEDEAN_LEDGER
The theorem is the best verified exponent-level match: \(r\gtrsim C_QT^{-1/2}\) on a fixed ternary split cone.

## PRIMITIVITY_LEDGER
The theorem counts primitive rational points natively.

## SEMANTIC_PRESERVATION
```text
SOURCE_ROW=PRESERVED_AFTER_PROJECTIVE_QUOTIENT_AND_R20_RECONSTRUCTION
SOURCE_LATTICE=BRIDGE_REQUIRED
PRIMITIVITY=PRESERVED
DIGIT_REGION=PARTIALLY_PRESERVED_AS_SHRINKING_SECTOR
POWER_TEN_PARAMETER=BRIDGE_REQUIRED
ORIGINAL_RECONSTRUCTION=PRESERVED
```

## BRAUER_RECIPROCITY_STATUS
`CONTROLLED` only after projective quotient; theorem itself is not the B2 proof.

## REQUIRED_BRIDGES
- uniform source-height/metric distortion;
- congruence/local-open refinement;
- coupled scale clearance with R14 multiplier interval.

## BRIDGE_DIFFICULTY
`MAJOR`

## IMPORTED_CONCLUSION
> For each fixed rationally isotropic ternary light cone, all-center primitive rational approximation reaches the natural projective radius scale \(r\asymp T^{-1/2}\).

## M_LEVEL
`M3`

## G_LEVEL
`G2`

## DEPENDENCY_GRAPH_POSITION
`projective source ray target -> MC-003 exponent engine -> USSPAL uniformization -> R14 multiplier`

## REPLACED_INTERNAL_MACHINERY
Provides a standard target exponent for the quantitative projective-shell part; does not itself retire R14.

## CURRENT_BLOCKER
`MOVING_FORM_PLUS_LOCAL_LEVEL_UNIFORMITY`

## NEXT_ACTION
Prove a source-family uniform version or derive one directly from an explicit P1 parameterization with controlled coefficients.

## UPDATE_LOG
- **2026-08-18 / 75-R2:** created after targeted B3 search; status `BRIDGE_REQUIRED`.
