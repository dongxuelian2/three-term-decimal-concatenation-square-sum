# Theorem Card TC-001 — Huang, Ternary Quadratic Forms III, Theorem 1.3

- **SOURCE:** Zhizhong Huang, *Quantitative strong approximation for ternary quadratic forms III*, arXiv:2512.13091v1 (2025), Theorem 1.3; §§3–4 for projective/Brauer interpretation.
- **OBJECT:** punctured affine cone of a fixed nondegenerate indefinite integral ternary quadratic form.
- **NORMALIZED STATEMENT:** for fixed form \(F\), fixed congruence level/residue \((L,\Gamma)\), fixed smooth compactly supported weight \(w\), the primitive zero count has a linear-in-\(B\) asymptotic with a secondary term encoding reciprocity/Brauer effects and exponentially decaying relative-type error.
- **SOURCE ANOMALY:** v1 defines \(\Omega=8L\Delta\) and then literally assumes \(\Omega\mid L\). This must be clarified before formal theorem import.
- **OUR OBJECT MAP:** \(F\leftrightarrow Q_\tau\) in a source basis; primitive vector \(\leftrightarrow\) primitive source ray; local residue \(\leftrightarrow\) source projective/local open after finite decomposition; weight \(\leftrightarrow\) a smoothed subregion of the digit sector.
- **PASS:** ternary, indefinite, split/rationally isotropic fibre, primitive target, local congruence framework.
- **UNKNOWN/FAIL:** literal v1 condition; uniformity as \(F,L,w\) move; one-shot coupled scale \(B=G_\tau\).
- **M_LEVEL:** M3 as a fixed-data theorem; not direct M4 for P2.
