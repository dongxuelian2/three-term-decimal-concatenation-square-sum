# Theorem Card TC-003 — Kelmer–Yu, Theorem 1.7

- **SOURCE:** Dubi Kelmer and Shucheng Yu, *Second moment of the light-cone Siegel transform and applications*, arXiv:2212.11035v2, Theorem 1.7 and Remark 1.19.
- **OBJECT:** primitive rational points on a fixed rational ellipsoid / primitive integral points on its light cone.
- **TERNARY SPECIALIZATION:** signature \((2,1)\) corresponds to \(n=1\); the paper states there is no exceptional pole for \(n=1,2\), so the all-center shrinking-sector threshold reaches \(r\asymp T^{-1/2}\).
- **OUR OBJECT MAP:** normalized projective source conic \(C_\tau\) -> rational ellipsoid/conic chart; source primitive height -> rational denominator height up to a fibre-dependent distortion constant.
- **PASS:** primitive projective points, shrinking sectors, all centers, fixed split form.
- **UNKNOWN:** uniformity in moving \(Q_\tau\), source basis distortion and local congruence level.
- **M_LEVEL:** M3 partial B3 engine.
