# Theorem Card TC-002 — Cao–Xu, Theorem 1.2

- **SOURCE:** Yang Cao and Fei Xu, *Strong approximation with Brauer–Manin obstruction for toric varieties*, Ann. Inst. Fourier 68 (2018), Theorem 1.2, p.1881.
- **STATEMENT:** any smooth toric variety over a number field satisfies strong approximation with Brauer–Manin obstruction off the infinite places.
- **OUR OBJECT MAP:** on a rationally split fibre, \(X_\tau^\times\) is a smooth toric surface.
- **PASS:** generic split toric object.
- **LIMITATION:** qualitative off-infinity approximation only; the authors explicitly state that their proof does not force prescribed real connected components. It therefore cannot prove the moving source digit-height condition.
- **M_LEVEL:** M4/M5 only for the qualitative finite/BM skeleton, not for N2.
