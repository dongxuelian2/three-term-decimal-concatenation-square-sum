# 75-R2 — Primitive Condition Audit

## Compared methods

- **P1 adelic primitive locus:** unsuitable as the sole encoding; global gcd one involves all primes.
- **P2 finite exclusions + density:** possible analytically but unnecessarily weak for the source semantics.
- **P3 Möbius inversion:** standard in Huang/Heath-Brown counting and useful inside an external theorem.
- **P4 torsor coprimality coordinates:** possible after choosing a split parameterization, but source-integral coefficient distortion moves with the fibre.
- **P5 saturated source lattice:** exactly matches the existing R13–R14 semantics.

## Selected method

\[
\boxed{\textbf{P5 as semantic layer, with theorem-native primitive counting when imported.}}
\]

R13–R14 already prove the correct decomposition
\[
x=n x_0,
\]
where \(x_0\) is primitive in a source-lattice basis and \(n\) is the actual radial multiplier. This prevents the false requirement that the final digit row itself be primitive.

The external quantitative theorem should therefore be asked only to find a **primitive ray representative** in a projective sector/local open. The multiplier is then chosen by the existing whole-modulus radial argument.

## Radial multiplier condition

For an admissible primitive ray, write
\[
\chi=\frac{x_0}{Aa_0},\qquad H_0=\frac G{a_0},
\]
\[
\theta(\chi)=\max\left(\frac1{10},\frac1{10\chi}\right),\qquad
\kappa(\chi)=1-\theta(\chi).
\]
The continuous interval length is \(H_0\kappa(\chi)\). R14 supplies a legal multiplier coprime to \(10u\) once this interval dominates the whole-modulus reduced-residue gap (recorded internally through Jacobsthal / successor radius).

Hence the primitive problem and the radial integer problem are now rigorously separated.

```text
PRIMITIVITY_STATUS=SOLVED_BY_SOURCE_PRIMITIVE_RAY_PLUS_RADIAL_MULTIPLIER
```
