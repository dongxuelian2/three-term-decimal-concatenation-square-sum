# 75-R2 — Split / Nonsplit Audit

## Exact verdict

The relevant split statement is the rational isotropy of the source ternary conic, not a later boundary discriminant square and not an ambient Euclidean composition identity.

The frozen R8–R10 criterion is
\[
C_\tau(\mathbb Q)\ne\varnothing
\iff (-1,N_0)=0
\iff N_0\in N_{\mathbb Q(i)/\mathbb Q}(\mathbb Q(i)^\times).
\]

Therefore:

```text
SPLIT_CRITERION=PROVED
UNIFORM_SPLIT_ON_ALL_ACTUAL_q_GT_1_POWER_TEN_TUPLES=OPEN
P2_SCOPE=CONDITIONAL_ON_RATIONAL_SPLIT_FIBRE
```

No split-torus theorem is used on nonsplit fibres.

## Geometric consequence on a split fibre

If \(C_\tau(\mathbb Q)\ne\varnothing\), then \(C_\tau\simeq\mathbb P^1\). Under the conic embedding, \(\mathcal O_C(1)\) corresponds to \(\mathcal O_{\mathbb P^1}(2)\), so the punctured affine cone is the nonzero total space of the inverse degree-two line bundle, equivalently the index-two intermediate \(\mathbb G_m\)-torsor between \(\mathbb A^2\setminus0\) and \(\mathbb P^1\).

This is a generic-fibre statement only. The R20 semantic dilatation remains the authoritative integral model.

## N1

```text
N1_STATUS=EXACT_CRITERION_PROVED; ACTUAL_POWER_TEN_FAMILY_CLASSIFICATION_OPEN
```
