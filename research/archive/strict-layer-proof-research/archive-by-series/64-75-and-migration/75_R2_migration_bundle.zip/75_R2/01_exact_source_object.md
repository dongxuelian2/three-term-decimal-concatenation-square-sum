# 75-R2 — Exact Source Object

## 1. Fixed actual fibre

Fix an actual J=2 q>1 tuple
\[
\tau=(G,K,u,q),\qquad G=10^g,\ K=10^k,\ uq=G+1,
\]
and write
\[
A=2u+1,
\]
\[
F_0=GA(GA+2),\quad W_0=G^4A^2+400u^2,
\]
\[
T_0=2KGu,\quad N_0=T_0^2-(GA+1)^2+2,
\]
\[
S_0=G^2AT_0+20u,\quad D_0=S_0^2-F_0W_0.
\]
The generic source cone is the nondegenerate ternary cone
\[
X_\tau=\{Q_\tau=0\}\subset\mathbb A^3_\mathbb Q,
\qquad Q_\tau(R,V,H)=R^2-D_0V^2-F_0N_0H^2.
\]

## 2. Integral source semantics

The integral object is not raw \(\mathbb Z^3\). It is the R20 semantic graph model
\[
\mathscr X_{{\rm sem},\tau}:\quad
Q_\tau(R,q^2v,H)=0,
\qquad \ell_M^{\rm sem}(R,q^2v,H)=M_0w,
\]
inside the inherited semantic lattice \(L_0\). Its integer points are exactly the source packet kernel.

The punctured locus is
\[
X_\tau^\times=X_\tau\setminus\{0\}.
\]
Because \(Q_\tau\) is nondegenerate, the affine cone has unique singular point at the vertex; hence \(X_\tau^\times\) is smooth of dimension two.

The projective base is
\[
C_\tau=\operatorname{Proj}(Q_\tau=0)\subset\mathbb P^2.
\]
Scaling defines the canonical map
\[
\pi:X_\tau^\times\to C_\tau,\qquad x\mapsto[x],
\]
whose group is \(\mathbb G_m\).

## 3. Source coordinates and reconstruction

R20 gives exact source height functionals
\[
h=\frac H{\mu_0},\qquad \mu_0=20G^2q^4(G+1),
\]
\[
a=\frac{R-\lambda_hH/\mu_0}{q^5D_0}.
\]
Thus the digit window is a condition on the actual source functionals \(a,h\), not on an arbitrary Euclidean norm in ambient coordinates.

## 4. Primitive locus

Let \(\Gamma_{\rm src,\tau}\) denote the rank-three source lattice. For a source-lattice basis, a nonzero vector is source-primitive if its three basis coordinates have gcd one. R13–R14 give the semantically correct decomposition
\[
x=n x_0,
\]
where \(x_0\) is a primitive isotropic source ray and \(n>0\) is a radial multiplier. The actual row need not itself be primitive.

## 5. Correct standard descriptions

For a rationally split fibre:

- \(C_\tau\simeq\mathbb P^1\);
- \(X_\tau^\times\to C_\tau\) is a \(\mathbb G_m\)-torsor;
- as a split generic variety it is a smooth toric surface;
- after choosing a rational split coordinate it is equivalent to the punctured cone \(xy=z^2\), but this is **not** an integral source-model identification over \(\mathbb Z\).

Hence the canonical migration object is
\[
\boxed{\text{source integral model }\mathscr X_{\rm sem}\quad+\quad
       \text{generic }\mathbb G_m\text{-torsor }X^\times\to C.}
\]
