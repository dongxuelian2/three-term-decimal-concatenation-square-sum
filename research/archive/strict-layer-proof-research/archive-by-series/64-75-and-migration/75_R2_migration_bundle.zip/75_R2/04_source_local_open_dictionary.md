# 75-R2 — Source Local-Open Dictionary (B1)

## Verdict

```text
B1=COMPLETE
LOCAL_OPEN_DICTIONARY=COMPLETE_ON_SPLIT_FIBRE
```

The finite source conditions divide into **built-in integral-model data** and **genuine finite local opens**.

## Built into the source model

- \(V=q^2v\): conductor coordinate, internal to \(\mathscr X_{\rm sem}\).
- \(\ell_M^{\rm sem}=M_0w\): semantic row, internal to \(\mathscr X_{\rm sem}\).
- source lattice/contact congruences: encoded in \(L_0\) / \(\Gamma_{\rm src}\).
- the residual \(\mathbb Z/\gcd(M_0,800)\) special-fibre defect is not an independent admissibility obstruction.

These are not reintroduced as an external congruence packet.

## Genuine local conditions

For the primitive projective ray, the remaining finite requirements can be represented by open compact subsets of the appropriate source integral points/projective conic:

- decimal places \(p=2,5\): inherited source/contact integrality and ten-unit conditions;
- \(p\mid u\): R14 primitive unit-open, nonempty as one composite modulus object;
- gcd/unit conditions such as \(\gcd(Z_0,u)=1\), \(\gcd(x_0,u)=1\): projective unit-open conditions on the ray;
- theorem-specific bad primes \(p\mid 2\Delta_\tau\): retained explicitly in the local level when a theorem requires them.

At primes dividing \(q\), \(M_0\), or the conductor, one works in \(\mathscr X_{{\rm sem},\tau}(\mathbb Z_p)\); no smooth-special-fibre claim is made.

Thus one may package the ray layer as a finite projective adelic open
\[
U_f^{\rm proj}=\prod_{p<\infty}U_p^{\rm proj}\subset C_\tau(\mathbb A_f),
\]
with all but finitely many \(U_p^{\rm proj}=C_\tau(\mathbb Z_p)\).

## Important non-open datum

Global source primitivity is not itself one fixed finite product of local opens at finitely many places. It is treated by the primitive-ray normalization / theorem-native primitive representatives, not by pretending that `gcd=1` is a single fixed local condition.
