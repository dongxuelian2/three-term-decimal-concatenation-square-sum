# 75-R2 — R1 Imported State

## Provenance lock

This round imports only actual proved state from 65-R20 and 75-R1. No structure is inferred from prompt titles.

### Frozen facts

1. The q-free ambient ternary quadric is
   \[
   \mathscr X_0:\quad Q_0(R,V,H)=R^2-D_0V^2-F_0N_0H^2=0.
   \]
2. The correct integral source model is the semantic graph/dilatation model
   \[
   \mathscr X_{\rm sem}:\quad
   Q_0(R,q^2v,H)=0,\qquad
   \ell_M^{\rm sem}(R,q^2v,H)=M_0w,
   \]
   with
   \[
   [\ell_M^{\rm sem}]_{\mathcal B_{\partial,0}}=(1,\beta_0,0),\qquad
   \beta_0=u(1+2u)^3.
   \]
3. Projection gives an exact integral-point bijection
   \[
   \mathscr X_{\rm sem}(\mathbb Z)
   \cong \mathscr X_0(L_0)\cap\ker\pi_{\rm src}.
   \]
4. R15 source model -> R20 semantic model is an integral isomorphism.
5. The apparent packet \(\mathbb Z/(M_0q^2)\) is a model-change cokernel; finite packet, ruling-orbit, and conductor routes are retired.
6. On a rationally split fibre, source-integral isotropic rays exist and can be primitive-normalized in a source-lattice basis.
7. The inherited digit-height shell remains unresolved and includes
   \[
   1\le a<G,\qquad h>0,\qquad h/a\in\mathscr I_\eta,
   \]
   plus LOW / thin-shell conditions where applicable.
8. Rational splitting is equivalent to the already isolated Gaussian norm/Brauer condition \((-1,N_0)=0\), but its truth on every actual power-ten q>1 tuple remains open.

## R1 terminal state accepted

```text
R1_TERMINAL_VERDICT=GENERAL_TOOL_REARCHITECTURE_FOUND
P2_INITIAL_M_LEVEL=M3
P2_INITIAL_G_LEVEL=G2
P2_BRIDGES=B1_SOURCE_LOCAL_OPEN_DICTIONARY+B2_RECIPROCITY_AUDIT+B3_MOVING_ARCHIMEDEAN_HEIGHT
```

## Round discipline

R2 does not reopen finite Spin orbits, source-packet automaticity, bad-reduction ruling classification, conductor enumeration, or R15–R20 model reconstruction.
