# 75-R2 — Remaining New Mathematics

After the P2 migration audit, the q>1 frontier contains two logically distinct obligations.

## N1 — family split classification

The exact criterion is known:
\[
(-1,N_0)=0.
\]
What remains is to decide it on the actual power-ten/cyclotomic family. This is an arithmetic/algebraic gate independent of the P2 height migration.

## N2' — uniform moving projective-ray distribution

On split fibres, N2 has been reduced to USSPAL + the explicit clearance inequality
\[
 a_0<\frac{G\kappa(J)}{j(10u)}.
\]
This is now the only genuinely new theorem inside P2.

## N3 — reciprocity

Closed/controlled for the actual projective-ray conditions by R14's explicit global weak-approximation construction. No new independent reciprocity theorem is required for P2 unless future local conditions are strengthened beyond the current projective unit-open.

## Not new mathematics anymore

- \(q^2\) conductor packet;
- \(M_0\) source packet;
- bad-reduction ruling pair;
- finite Spin orbit automaticity;
- primitive-mod-u ray obstruction;
- projective finite/real compatibility;
- source reconstruction after semantic lifting.

## Frontier shift

Conditional on rational splitting, the q>1 frontier has shifted from finite arithmetic/algebraic packet lifting to
\[
\boxed{\text{uniform quantitative distribution in a moving decimal height/sector window}.}
\]
Globally, N1 remains as an orthogonal split/nonsplit precondition.
