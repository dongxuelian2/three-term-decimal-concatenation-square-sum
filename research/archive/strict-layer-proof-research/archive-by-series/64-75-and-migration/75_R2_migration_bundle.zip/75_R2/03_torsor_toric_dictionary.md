# 75-R2 — Torsor / Toric Dictionary

## Dictionary

For each rationally split actual q>1 fibre \(\tau\):

| Project datum | Standard datum | Verdict |
|---|---|---|
| punctured source cone \(X_\tau^\times\) | smooth quasi-affine toric surface | PASS over \(\mathbb Q\) |
| projectivization | smooth conic \(C_\tau\simeq\mathbb P^1\) | PASS on split fibre |
| radial scaling | \(\mathbb G_m\)-torsor \(X_\tau^\times\to C_\tau\) | PASS |
| primitive source ray | rational point of \(C_\tau\) + primitive source representative | PASS |
| radial multiplier \(n\) | integral point in the torsor fibre, constrained by source digit interval | PROJECT-SPECIFIC |
| R20 divisibility rows | integral dilatation/source lattice | PRESERVED, not external packet |
| digit shell | moving Archimedean region in source height coordinates | BRIDGE REQUIRED |

## Torsor data

- Group: \(\mathbb G_m\).
- Fibre: scalar multiples of one nonzero isotropic ray.
- Base: \(C_\tau\).
- Split status: on P2 scope, \(C_\tau\simeq\mathbb P^1\) over \(\mathbb Q\).
- Global triviality: not assumed; the torsor class has index two.
- Universal cover: \(\mathbb A^2\setminus0\to X_\tau^\times\) has degree two in the standard split model.
- Dense torus on the split surface: two-dimensional split torus; character lattice \(\mathbb Z^2\).
- Integral model: **R20 semantic graph/dilatation**, not the naive closure of \(xy=z^2\).
- Local sections: available Zariski-locally on the split conic; no single global source-integral trivialization is asserted.

## Brauer warning

The punctured cone can have nonconstant Brauer classes even when the projective conic is \(\mathbb P^1\). Therefore one must not replace B2 by `Br=0`. The safer interface is to quotient first to the projective primitive-ray problem, where the actual R14 weak-approximation construction gives a global point, and only then restore the radial multiplier.

## Preferred P2 architecture

\[
\boxed{
\mathscr X_{\rm sem}
\to X^\times
\to C\simeq\mathbb P^1
\xrightarrow{\text{quantitative primitive-ray distribution}}
[x_0]
\xrightarrow{\text{R14 radial multiplier}}
 n x_0
\xrightarrow{\text{R20 reconstruction}}
\text{source row}.}
\]

This quotient-first architecture is semantically closer than trying to make one affine-cone theorem simultaneously carry primitive-ray data and decimal radial scaling.
