# 75-R2 — Brauer / Reciprocity Audit (B2)

## External warning

A punctured split ternary cone is not automatically reciprocity-free. Huang's ternary-cone analysis explicitly exhibits real-sign/congruence reciprocity for primitive affine points and interprets the secondary term through Brauer–Manin phenomena. The same paper identifies the punctured cone as an index-two intermediate \(\mathbb G_m\)-torsor over the split conic.

Therefore:

```text
BRAUER_RECIPROCITY_STATUS != NO_OBSTRUCTION_IN_GENERAL
```

## Actual source conditions

For the **actual source ray layer**, R14 already proves something stronger than abstract adelic compatibility: on a rationally split conic, ordinary weak approximation on \(C_\tau\simeq\mathbb P^1\) simultaneously hits

1. the prescribed nonempty real projective W-sector, and
2. the composite finite primitive unit-open,

then source-lattice denominator clearing and primitive normalization preserve the projective unit-open.

Thus the relevant ray-level adelic neighborhood contains an actual diagonal rational point. Any putative Brauer/reciprocity obstruction to that ray layer is therefore absent by construction.

The remaining radial multiplier is one global integer selected after the ray; its whole-modulus coprimality condition is handled by R14's exact interval/successor mechanism rather than by an independent Brauer calculation.

## Projective quotient cancellation

This matches the standard external picture: Huang shows that when one passes from a fixed primitive affine residue to a projective conic neighborhood, summing over unit scalings cancels the nonprincipal real-character correction terms. This is precisely why the projective-ray quotient is the correct interface for P2.

## Verdict

```text
RECIPROCITY_STATUS=CONTROLLED_BY_EXPLICIT_PROJECTIVE_RAY_CONSTRUCTION
N3_STATUS=PROVED_CONTROLLED_ON_P2_SPLIT_FIBRE
NEW_BRAUER_OBSTRUCTION_FOUND=FALSE
```

This verdict does **not** assert that the full punctured cone has trivial Brauer group; it asserts that the actual source local-open + real ray conditions used by P2 are already globally compatible.
