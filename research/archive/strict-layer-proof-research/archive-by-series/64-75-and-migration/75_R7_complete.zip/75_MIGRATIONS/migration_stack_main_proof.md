# Migration Stack — Main Proof after 75-R7

| Card / Stack | Status after R7 | Active dependency |
|---|---|---|
| MC-001 | SUPERSEDED (reaffirmed) | NO |
| MC-002 | MIGRATED / FALLBACK benchmark (reaffirmed) | NO |
| Laurent Migration Card | NOT CREATED | NO |
| ESS Migration Card | NOT CREATED | NO |
| Gamma10 Weapon Stack Card | NOT CREATED | NO |

R7 created no new Migration Card and no Weapon Stack Card because N4-A failed before theorem activation.

```text
ACTIVE_EXTERNAL_WEAPONS=0
LAURENT=A_RESERVE
ESS=A_RESERVE
USSPAL_CURRENT_INTERFACE=RETIRED
N4A_CURRENT_INTERFACE=RETIRED_PENDING_NEW_SOURCE_IMAGE
NEXT_ARCHITECTURE=N0_DISCRIMINANT_FIRST_ACTUAL_SPLIT_CLASSIFICATION
```
