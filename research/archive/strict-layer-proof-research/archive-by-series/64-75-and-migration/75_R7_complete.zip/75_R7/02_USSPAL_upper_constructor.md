# 75-R7 Interface A — USSPAL Upper Constructor Lane

## Target

Seek a uniform fixed \(\delta>0\) with
\[
\boxed{a_p\mathcal H_{\perp,\tau}\le G^{1-\delta+o(1)}}.
\]
Only the frozen allowed-ruling transverse Veronese interface is permitted.

## U1. What the exact lift changes

Phase A1 replaces the unknown basepoint denominator by the explicit system
\[
Y^2=\mathscr D_\sigma(Z,\lambda),
\]
\[
\varepsilon Y\equiv\beta_\sigma(Z,\lambda)\pmod{2A^3u},
\]
\[
Z\equiv\rho_s a\pmod{M_s},
\qquad
a=\frac{-\beta_\sigma+\varepsilon Y}{2A^3u}.
\]
The binary discriminant is
\[
4A^4G^2u^2N_0,
\]
so every constructor still has to solve the same moving fibre arithmetic encoded by \(N_0\).

## U2. Special substitutions audited

### \(\lambda=0\)

Then \(x=\sigma Z\), and
\[
\mathscr D_\sigma(Z,0)=Z^2\mathscr D_\sigma(1,0).
\]
This converts the square condition to a square test on one moving coefficient but does not make that coefficient a square identically. The source congruence for \(a\) remains.

**Verdict:** no uniform constructor.

### \(Z=1\)

R5 already shows that \(Z=1\) costs only one source congruence class for \(a\). Phase A1 shows that this class must additionally lie on the binary square locus
\[
Y^2=\mathscr D_\sigma(1,\lambda).
\]
Its discriminant still contains \(N_0\); no exact factorization makes this a uniformly bounded-height square.

**Verdict:** no uniform constructor.

### Power-ten/source substitutions

Using \(uq=G+1\) simplifies the binary discriminant to the already-known relation
\[
-\Delta_{\rm fib}=q^2N_0
\]
rather than cancelling it.

**Verdict:** exact simplification, but no exponent-saving constructor.

## U3. No new external theorem promoted

The resulting object is a moving binary norm/square equation with an additional source congruence. R7 explicitly forbids reopening generic Pell infrastructure or another generic Cassels campaign. No new theorem is needed to state the exact problem, and no new external theorem was found whose hypotheses directly supply a source-valid low-height solution with the required exponent.

Therefore no Migration Card is created.

## U4. Upper-lane verdict

The best certified positive statement remains the R5 conditional one:
\[
E(\Phi)=O(j(u))=G^{o(1)}
\]
**if** an exact allowed-ruling basepoint is supplied.

But Phase A1 does not yield
\[
a_p\mathcal H_{\perp,\tau}\le G^{1-\delta+o(1)}.
\]
The upper lane therefore fails its success criterion.

```text
UPPER_CONSTRUCTOR_STATUS=FAIL_NO_STRICT_POWER_SAVING
BEST_UPPER_BOUND=NO_NEW_BOUND_BEYOND_R5_CONDITIONAL/GENERIC_FALLBACK
NEW_EXTERNAL_THEOREM=NONE
MIGRATION_CARD=NONE
```

---

STAGE_INPUTS=01_allowed_ruling_exact_equation.md; frozen R5 chart and R20 reconstruction
NEW_PROVED_RESULTS=No strict upper theorem; exact audit shows lambda=0, Z=1, and uq=G+1 substitutions retain the N0 moving discriminant
NEW_REDUCTIONS=Constructor search reduced to the explicit binary square+source-congruence system
NEGATIVE_RESULTS=No allowed special substitution supplies a uniform low-a_p source point; no strict exponent upper bound
REJECTED_ROUTES=Generic Pell infrastructure; generic Cassels re-optimization; additional chart construction
EXTERNAL_SOURCES_USED=NONE_NEW
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=04_USSPAL_survival_verdict.md
UNRESOLVED_ITEMS=None needed for the interface decision once the independent lower barrier is applied
PHASE_STATUS=FROZEN
