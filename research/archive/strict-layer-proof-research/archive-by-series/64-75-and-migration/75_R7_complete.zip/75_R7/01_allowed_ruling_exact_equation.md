# 75-R7 Phase A1 — Exact Allowed-Ruling Lift Equation

## Frozen input

Use the R4 source core
\[
F_0(Z,a,x)=G^3(GA+2)Z^2-4u(G^2A^2+GA-1)Za-4G^3KuZx
+4u^2A^3a^2+8Ku^2(GA-1)ax+G^2Ax^2,
\]
with
\[
A=2u+1,\qquad uq=G+1,
\]
and the saturated source lattice
\[
\Gamma_\tau=\{(Z,a,x)\in\mathbb Z^3:Z\equiv\rho_s a\pmod{M_s}\},\qquad
M_s=\frac{G}{\gcd(G,2d(q+4))}.
\]
No new chart or external theorem is introduced.

## A1. Exact allowed-ruling substitution

Fix \(\sigma\in\{+1,-1\}\) and impose
\[
\boxed{x=\sigma Z+u\lambda},\qquad \lambda\in\mathbb Z.
\]
Then \(F_0=0\) is exactly quadratic in \(a\):
\[
\boxed{4A^3u^2a^2+4u\,\beta_{\sigma}(Z,\lambda)a+G^2\gamma_{\sigma}(Z,\lambda)=0},
\]
where, writing \(X_\sigma=\sigma Z+u\lambda\),
\[
\boxed{\beta_{\sigma}
=Z(1-AG-A^2G^2)+2Ku(AG-1)X_\sigma},
\]
\[
\boxed{\gamma_{\sigma}
=(AG^2+2G)Z^2+A X_\sigma^2-4GKuZX_\sigma}.
\]
Thus the R5 phrase “genuine quadratic lift” has been fully explicitized.

## A2. Exact discriminant square equation

The quadratic discriminant in \(a\) is
\[
\Delta_{a,\sigma}=16u^2\,\mathscr D_\sigma(Z,\lambda),
\]
with
\[
\boxed{
\mathscr D_\sigma(Z,\lambda)
=
4K^2u^2(AG-1)^2X_\sigma^2
-A^4G^2X_\sigma^2
+4Ku(2AG-1)ZX_\sigma
+(1-2AG-A^2G^2)Z^2.
}
\]
Hence an integral lift necessarily satisfies
\[
\boxed{Y^2=\mathscr D_\sigma(Z,\lambda)}
\]
for some \(Y\in\mathbb Z\), and then
\[
\boxed{
a=\frac{-\beta_\sigma+\varepsilon Y}{2A^3u},\qquad \varepsilon\in\{\pm1\}.
}
\]
The exact congruence condition is
\[
\boxed{\varepsilon Y\equiv\beta_\sigma(Z,\lambda)\pmod{2A^3u}}.
\]
Therefore “discriminant is a square” alone is not sufficient.

## A3. Binary quadratic discriminant and return to the fibre invariant

Regard \(\mathscr D_\sigma\) as a binary quadratic form in \((Z,\lambda)\):
\[
\mathscr D_\sigma=c_\sigma Z^2+b_\sigma Z\lambda+d\lambda^2.
\]
A direct exact simplification gives
\[
\boxed{b_\sigma^2-4c_\sigma d
=4A^4G^2u^2N_0},
\]
independently of \(\sigma\), where
\[
\boxed{N_0=4K^2G^2u^2-(AG+1)^2+2}.
\]
Using the already frozen identity
\[
\boxed{-\Delta_{\rm fib}=q^2N_0},
\]
this is equivalently
\[
\boxed{\operatorname{disc}_{Z,\lambda}(\mathscr D_\sigma)
=-\frac{4A^4G^2u^2}{q^2}\Delta_{\rm fib}}.
\]
Thus the allowed-ruling lift does **not** create a new discriminant: it returns exactly to the same smooth-fibre arithmetic kernel.

## A4. Canonical norm completion

Let \(d\) denote the \(\lambda^2\)-coefficient of \(\mathscr D_\sigma\). Then
\[
\boxed{(2d\lambda+b_\sigma Z)^2-4dY^2
=4A^4G^2u^2N_0\,Z^2}.
\]
This is the exact binary norm form attached to the lift. Its moving squarefree obstruction is therefore controlled by the squarefree content of \(N_0\) (equivalently \(-\Delta_{\rm fib}\) after removal of the fixed square \(q^2\)).

Define the canonical discriminant-content invariant
\[
\boxed{C_{\Gamma,\tau}^{\rm disc}:=\operatorname{sf}(N_0)}.
\]
This is not yet a height theorem; it is the exact arithmetic object replacing the black-box denominator condition.

## A5. Full integral/source criterion

An allowed-ruling source point on this chart requires simultaneously:

1. \(Y^2=\mathscr D_\sigma(Z,\lambda)\);
2. \(\varepsilon Y\equiv\beta_\sigma\pmod{2A^3u}\);
3. \(a=(-\beta_\sigma+\varepsilon Y)/(2A^3u)\in\mathbb Z\);
4. source lattice: \(Z\equiv\rho_s a\pmod{M_s}\);
5. allowed ruling: \(x=\sigma Z+u\lambda\), hence \(x\equiv\sigma Z\pmod u\);
6. primitive/source ten-unit and real digit-sector conditions from the frozen R5/R20 interface.

So the exact lift is a binary quadratic/norm representation problem **plus** one source congruence, not an unconstrained Pell equation and not a free square test.

---

STAGE_INPUTS=75-R4 SOURCE_QUADRATIC_FORM; 75-R5 allowed-ruling substitution; 65-R7/R18 fibre discriminant identities; Phase-0 frozen state
NEW_PROVED_RESULTS=Explicit quadratic lift in a; exact square discriminant equation; binary discriminant equals 4*A^4*G^2*u^2*N0 and hence -(4*A^4*G^2*u^2/q^2)*Delta_fib; exact source-congruence converse conditions
NEW_REDUCTIONS=a_p black box reduced to an integral binary quadratic/norm representation plus fixed source congruence; canonical discriminant content sf(N0)
NEGATIVE_RESULTS=Allowed-ruling substitution does not introduce an independent easier discriminant; it returns to the existing fibre arithmetic kernel
REJECTED_ROUTES=Treating discriminant-square as sufficient; reopening generic Pell/unit-orbit machinery
EXTERNAL_SOURCES_USED=NONE_NEW
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=02_USSPAL_upper_constructor.md; 03_USSPAL_intrinsic_lower_barrier.md
UNRESOLVED_ITEMS=minimum-height integral solution of the exact square+congruence system; quantitative effect of sf(N0)
PHASE_STATUS=FROZEN
