# 75-R6 Phase V — Net Complexity Audit

The audit compares **live obligations removed** against **new obligations introduced**. Replacing already-solved historical machinery is not counted as a current gain.

---

# 1. Baseline P2/USSPAL

### Existing chain

\[
\text{split source fibre}
\to
\text{source allowed-ruling chart}
\to
\mathbf P^1\text{ primitive approximation}
\to
\text{radial clearance}
\to
\text{source reconstruction}.
\]

### Live core

\[
\boxed{
T_{\rm denom}=
\text{allowed-ruling source denominator / low-height basepoint theorem}.
}
\]

### Complexity

```text
LIVE_MAJOR_OBLIGATIONS=1_PRIMARY_QUANTITATIVE_THEOREM + N1_split_if_not_preclassified
NEW_EXTERNAL_HYPOTHESES=NONE
SOURCE_SEMANTICS=ALREADY_EXACT
NET_POSITION=BASELINE
```

---

# 2. WC-007 Laurent

### Old obligations potentially removed

Conditionally:

- q>1 exact-power incidence;
- q=1 exact-power/root recurrence layer;
- repeated exponent-family degeneracy analysis;
- possibly part of the need for fibrewise height realization if exponent structure alone yields finiteness/contradiction.

### New obligations introduced now

- N4-A exact source-image algebraicization;
- exact reconstruction after elimination;
- classification of Laurent degenerate affine-subgroup components;
- source inequalities on returned components.

The first is itself a major open bridge.

```text
CURRENT_DELTA_PROOF=NEGATIVE
CONDITIONAL_AFTER_N4_A=STRONGLY_POSITIVE
```

---

# 3. WC-006 ESS

### Potential gain

A strong finite bound for nondegenerate group solutions could compress exact-power families.

### Current new obligations

- eliminate \(u,q\) and source variables into a finite-rank multiplicative group;
- linearize the final equation;
- classify vanishing subsums;
- reconstruct source points.

This exact reduction is strictly stronger than simply recognizing \(\Gamma_{10}\).

```text
CURRENT_DELTA_PROOF=STRONGLY_NEGATIVE
CONDITIONAL_AFTER_EXACT_GROUP_REDUCTION=STRONGLY_POSITIVE
```

---

# 4. WC-002 Wei–Xu

### Potentially removed

- fixed norm-torsor integral local-global arguments;
- explicit finite Brauer/Artin obstruction bookkeeping.

### Still live

- q>1 split;
- q>1 moving digit-height;
- q=1 moving order/discriminant/support;
- exact powers.

### New bridges

- exact integral torsor identification in every moving source fibre;
- uniform Brauer/admissible group data;
- source primitive/digit recovery.

```text
CURRENT_DELTA_PROOF=NEGATIVE
```

---

# 5. WC-001 CT–Xu

It can compress homogeneous-space local-global arguments but not the moving radial shell.

Since R20/R3 already solved the local projective/source part:

```text
LIVE_OBLIGATIONS_REMOVED=0_OR_MINOR
NEW_MODEL_HYPOTHESIS_AUDITS=SEVERAL
CURRENT_DELTA_PROOF=NEGATIVE
```

---

# 6. WC-003 Cao–Xu

Finite-place toric approximation is already weaker than the current internal projective + real-sector control.

```text
CURRENT_DELTA_PROOF=STRONGLY_NEGATIVE_AS_ACTIVE_ENGINE
```

---

# 7. WC-004 Huang

Fixed-data counting is superseded by elementary \(\mathbf P^1\).

```text
CURRENT_DELTA_PROOF=STRONGLY_NEGATIVE
```

---

# 8. WC-005 universal torsor

For \(C\simeq\mathbf P^1\), the torsor simply recovers primitive two-coordinate parameterization without lowering the source denominator gate.

```text
CURRENT_DELTA_PROOF=NEGATIVE
```

---

# 9. WC-008 DML

To use one-orbit DML one would need a new orbit model for independent \(g,k\) and all source variables. Laurent already handles \(\mathbb Z^r\) characters more naturally.

```text
CURRENT_DELTA_PROOF=STRONGLY_NEGATIVE
```

---

# 10. WC-009 MRR

Historically:

```text
HISTORICAL_DELTA_PROOF=STRONGLY_POSITIVE
```

because the dilatation language correctly recognized the finite packet/model-change layer.

Currently:

```text
LIVE_GATE_DELTA_PROOF=NEUTRAL
```

because that layer is retired.

---

# 11. Net-complexity conclusion

No newly audited external candidate has

\[
\Delta_{\rm proof}>0
\]

**at the current proved interface**.

The only candidates with potentially very large positive payoff are Laurent/ESS, and both sit strictly *after* an unproved N4-type reformulation.

Therefore:

```text
NO_CURRENT_EXTERNAL_CANDIDATE_HAS_POSITIVE_NET_COMPLEXITY=TRUE
NO_FORMAL_PROMOTION_JUSTIFIED=TRUE
```

---

STAGE_INPUTS=08_weapon_ranking.md; candidate sheets; replacement stress tests
NEW_PROVED_RESULTS=Audit conclusion: no current external candidate yields positive live-gate net complexity under proved source semantics
NEW_REDUCTIONS=Conditional value of Laurent/ESS isolated behind explicit trigger theorems
REJECTED_ROUTES=Counting historical replacement as current gain; ignoring bridge costs
EXTERNAL_SOURCES_USED=No new sources beyond frozen candidate set
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=terminal external arsenal map and R7 strategy
UNRESOLVED_ITEMS=N2 denominator/basepoint; N4-A; q1 moving norm/support
PHASE_STATUS=FROZEN
