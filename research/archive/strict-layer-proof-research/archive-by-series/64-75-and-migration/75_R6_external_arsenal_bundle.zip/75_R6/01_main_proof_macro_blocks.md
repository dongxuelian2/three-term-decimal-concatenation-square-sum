# 75-R6 Phase I — Main-Proof Macro Obligation Graph

**Project:** 三项十进制拼接平方和问题  
**Round:** 75-R6  
**Phase:** I — Main-Proof Re-expansion  
**Input freeze:** `75_R6/00_previous_migration_state.md`  
**Discipline:** 本文件从 actual artifacts 重建当前主证明结构；不以某个候选 theorem family 为组织轴。

---

# 1. Re-expanded proof architecture

当前 Strict Layer / Exact Resonance / \(J=2\) 的 proof architecture 不应再写成单一的

\[
a_p\mathcal H_{\perp,\tau}
\]

问题。更准确的结构是：

\[
\boxed{
\text{Exact-Resonance Structural Base}
\longrightarrow
\begin{cases}
q>1\text{ source-semantic conic branch},\\
q=1\text{ root/norm branch},
\end{cases}
}
\]

并且两条分支共同受到：

\[
\boxed{
\text{exact powers of ten}
+
\text{source integrality}
+
\text{primitive/reducedness}
+
\text{digit inequalities}
}
\]

的约束。

---

# 2. Main-Proof Obligation Graph

## O-S0 — Exact-resonance \(J=2\) structural base

Actual \(J=2\) source proves the specialization relations used by 65/75, including the reduced-denominator specialization \(u_0=u\) and the resulting J2 Bézout/cyclotomic chart.

**Status:** `PROVED`

**Warning:** the same formulas are not automatically general-\(J\). In particular, general resonance only has the source-valid reduced denominator \(u_0\), and the general-J RCE was not recovered.

---

# 3. \(q>1\) branch

## O-Q1 — Actual rational split / nonsplit classification

For the actual source family, decide the split criterion

\[
(-1,N_0)=0
\]

throughout the power-ten/cyclotomic parameter family.

The criterion itself is explicit. What is not proved is the family-wide classification.

**Status:** `OPEN_MAJOR`

**Downstream effect:** on a nonsplit fibre the projective source conic has no rational point, so the source-point branch is extinguished; on a split fibre one enters the source-integral/digit-height problem.

---

## O-Q2 — Source-semantic integral model and reconstruction

The q-free ambient ternary quadric is not itself the source object. R20 internalizes the conductor/source rows into the semantic model using

\[
V=q^2v,\qquad \ell_M^{\rm sem}=M_0w,
\]

and proves exact source reconstruction.

**Status:** `PROVED`

---

## O-Q3 — Finite packet / conductor / bad-ruling lifting

R20 proves semantic conductor-ruling lifting and identifies the old moving finite packet as integral-model change data.

**Status:** `RETIRED`

This is not a current arithmetic gate.

---

## O-Q4 — Primitive projective local conditions + real projective sector

On a rationally split source conic:

- the primitive mod-\(u\) open is nonempty as one whole-modulus object;
- weak approximation on \(\mathbf P^1\) gives finite-projective + real-sector matching;
- source-lattice primitive normalization preserves the projective class.

**Status:** `PROVED`

The old finite/projective reciprocity question is therefore not an independent current gate.

---

## O-Q5 — Moving source digit-height / radial incidence

After choosing a primitive source ray, the proof still needs a legal radial multiplier and the full inherited decimal shell.

Current 75-R5 interface:

\[
\boxed{
\text{source Veronese}
+
\text{allowed-}u\text{ ruling chart}
+
\text{elementary }\mathbf P^1\text{ approximation}
}
\]

with joint cost controlled by the source-specific basepoint/denominator/distortion and a subpolynomial \(u\)-cost.

**Status:** `INTERNALLY_REDUCED`

**Major unresolved core:** source-denominator / low-height allowed-ruling basepoint / chart distortion sufficient for clearance.

Because closing it is necessary for the split q>1 branch, it remains a **major** residual theorem even though the interface has been strongly reduced.

---

## O-Q6 — Exact power-ten incidence for q>1

The surviving q>1 equations are not merely a family indexed by arbitrary real/integer \(G,K\); they lie on

\[
G=10^g,\qquad K=10^k,
\]

together with the exact source/cyclotomic relations.

No actual artifact has yet produced a standard algebraic object whose intersection with the power-ten subgroup/semigroup is exactly the source solution locus.

**Status:** `OPEN_MAJOR`

---

## O-Q7 — q>1 branch closure

The branch can close by either:

1. proving all actual fibres nonsplit; or
2. proving split fibres cannot meet the source digit-height/power-ten incidence; or
3. proving a stronger cross-gate theorem that bypasses the split-fibre local chart altogether.

**Status:** `OPEN_MAJOR`

---

# 4. \(q=1\) branch

The \(q=1\) branch is not a specialization already absorbed by the q>1 semantic conic campaign. Its current provenance remains separate.

## O-1Q1 — Carry-saturated / full-root independent object

Earlier J2 campaigns proved that after quotienting the consumed carry chain, the full-root normal form remains nonzero. In q=1 the surviving interfaces include exact root/norm relations rather than another carry residual ladder.

**Status:** `PROVED` as an independent object; its solution set is not classified.

---

## O-1Q2 — q=1 Gaussian / norm / support arithmetic

The q=1 line has been compressed to Gaussian/norm/Pell-type structures with exact support restrictions. Existing artifacts prove useful support theorems but explicitly do **not** close the branch.

**Status:** `OPEN_MAJOR`

This is the primary q=1 arithmetic block.

---

## O-1Q3 — q=1 exact power-ten/root incidence

The q=1 residual equations still contain exact powers \(G=10^g\), \(K=10^k\) and exact digit/root restrictions. Periodic residue cells do not freeze all polynomial coefficients, and no global rational-root/Pell closure is currently proved.

**Status:** `OPEN_MAJOR`

---

## O-1Q4 — q=1 final closure

Neither the positive nor negative q=1 frontier is closed.

**Status:** `OPEN_MAJOR`

---

# 5. Cross-branch obligations

## O-X1 — Source integrality / original reconstruction

For q>1 this is already exact through the R20 semantic model. For q=1, the corresponding source reconstruction remains branch-specific and must be preserved by any imported theory.

**Status:** `PROVED` for q>1; `ORTHOGONAL` as a cross-branch unification problem.

---

## O-X2 — Primitive / reducedness semantics

Primitive source-ray semantics are controlled on split q>1 conics. q=1 retains branch-specific primitive/support restrictions.

**Status:** `INTERNALLY_REDUCED`

A claimed cross-branch external theorem must specify exactly what "primitive" means in both branches.

---

## O-X3 — Archimedean / digit inequalities

Digit conditions are not merely open real sectors; they include moving radial/height windows tied to the exact decimal scale.

**Status:** `OPEN_MAJOR`

This is a cross-gate condition whenever an external theory forgets radial scale.

---

## O-X4 — Exact powers of ten as arithmetic object

\[
(10^g,10^k)
\]

appears in both q>1 and q=1 branches.

The current architecture treats this mostly as a parameter restriction. R6 must test whether it can instead become a standard object:

- cyclic/finitely generated subgroup of a torus;
- \(S\)-unit datum;
- semigroup orbit;
- exponential-Diophantine sequence.

**Status:** `OPEN_MAJOR`

---

# 6. Generality-only obligations

## O-GJ1 — General-\(J\) source-valid structural transport

The source-valid reduced-denominator envelope exists:

\[
\bar A_J=Ju_0+1,\qquad
\bar B_J=JG+q_0,
\]

with the exact unimodular identity in the reduced variables.

But the full J2 RCE/conic chart is not yet transported.

**Status:** `ORTHOGONAL`

**Internal mathematical state:** partially proved envelope, global transport open.

---

## O-GJ2 — Original-problem uniform architecture

It is not known whether all \(J\) can be realized as one standard family of integral homogeneous/toric/exponential objects with \(J\) as a discrete invariant.

**Status:** `ORTHOGONAL`

This is not required to close current J2, but every R6 weapon receives a generality score against it.

---

# 7. Dependency DAG

A compact dependency representation is:

\[
\boxed{
O\text{-S0}
\longrightarrow
\begin{cases}
O\text{-Q1}
\longrightarrow
\begin{cases}
\text{nonsplit}\Rightarrow\varnothing,\\
\text{split}\Rightarrow O\text{-Q2}\to O\text{-Q4}\to O\text{-Q5},
\end{cases}\\[4mm]
O\text{-1Q1}\to O\text{-1Q2}\to O\text{-1Q3}.
\end{cases}
}
\]

with the global incidence layer

\[
\boxed{
O\text{-X3}+O\text{-X4}
}
\]

meeting both branches.

For q>1:

\[
O\text{-Q2}=PROVED,\qquad
O\text{-Q3}=RETIRED,\qquad
O\text{-Q4}=PROVED.
\]

Thus the genuine q>1 residual is not "integral points on a quadric" in the abstract. It is

\[
\boxed{
\text{actual split classification}
+
\text{source-preserving moving digit-height realization}
+
\text{exact power-ten incidence}.
}
\]

For q=1, the unresolved core is

\[
\boxed{
\text{Gaussian/norm/support arithmetic}
+
\text{exact power-ten/root incidence}.
}
\]

---

# 8. Macro-block A — Integral Quadrics / Homogeneous Spaces

### Standard-looking content

- ternary quadratic cone / projective conic;
- primitive integral points;
- finite local conditions;
- Spin/orthogonal homogeneous-space language;
- integral models and source lattices.

### Current obligations touched

\[
O\text{-Q1}, O\text{-Q2}, O\text{-Q4}, O\text{-Q5}.
\]

### Already standardized internally

- source integral model: solved;
- finite packet: retired;
- projective primitive local matching: solved.

### What would constitute a weapon

Only a theorem stack that does more than reprove those solved pieces, e.g.

\[
\boxed{
O\text{-Q1}+O\text{-Q5}
}
\]

or that gives a uniform family theorem including the actual moving source height.

**Current R6 search priority:** `MEDIUM-HIGH`

**Main risk:** generic homogeneous-space theorems forget the moving decimal radial shell.

---

# 9. Macro-block B — Tori / Norm Forms / Brauer–Manin

### Standard-looking content

- q>1 split criterion as Gaussian norm/Brauer condition;
- q=1 Gaussian/norm/Pell structures;
- split/nonsplit conics;
- norm-one torus / torsors;
- local-global principles.

### Current obligations touched

\[
O\text{-Q1}, O\text{-1Q2}, O\text{-X4}.
\]

### What would constitute a weapon

A single norm-torus/torsor framework that:

1. treats q>1 split/nonsplit and q=1 norm arithmetic in one language;
2. retains enough integrality/support information to remove real obligations;
3. preferably interfaces naturally with the power-ten base.

**Current R6 search priority:** `HIGH`

**Main risk:** rational Hasse/Brauer theory may be far weaker than the required integral/support + decimal problem.

---

# 10. Macro-block C — Universal Torsors / Cox / Integral Parameterization

### Standard-looking content

- rational parameterization versus source-integral realization;
- primitive/coprmality coordinates;
- saturation;
- denominator control;
- integral conic parameterization.

### Current obligations touched

\[
O\text{-Q2}, O\text{-Q4}, O\text{-Q5}, O\text{-X2}.
\]

### Existing internal baseline

R20 already gives an exact source model and degree-2 integral parameterization once a source basepoint exists.

### What would constitute a weapon

A standard torsor/Cox formalism must replace the remaining **source denominator/basepoint** issue or unify q=1/q>1 source semantics. Merely reproducing a rational parametrization is not enough.

**Current R6 search priority:** `MEDIUM`

**Main risk:** the current low-dimensional internal source parameterization may already be cheaper than universal-torsor machinery.

---

# 11. Macro-block D — Arithmetic Dynamics / Semigroup Orbit / \(S\)-Unit

### Standard-looking content

\[
G=10^g,\qquad K=10^k.
\]

### Current obligations touched

\[
O\text{-Q6}, O\text{-1Q3}, O\text{-X4},
\]

and potentially \(O\text{-Q1}\) if the split criterion becomes an exponential equation.

### What would constitute a weapon

A theorem that makes exact powers of ten part of the **object**, not an afterthought; ideally it should turn both branches into:

- subgroup–subvariety intersections;
- \(S\)-unit equations;
- semigroup-orbit intersections;
- exponential-polynomial zero sets.

**Current R6 search priority:** `VERY_HIGH`

**Main risk:** current equations also contain divisor/source variables not known to lie in a finitely generated multiplicative group.

---

# 12. Macro-block E — Counting / Equidistribution / Height Zeta

### Standard-looking content

- primitive points on quadrics;
- real sectors;
- congruence conditions;
- moving height windows;
- family variation.

### Current obligations touched

\[
O\text{-Q5}, O\text{-X3}.
\]

### Existing internal baseline

Fixed-fibre counting is already superseded by an elementary \(\mathbf P^1\) lemma. A new counting theorem is only valuable if it is **uniform at family level** and avoids the source denominator/distortion problem.

### What would constitute a weapon

A theorem whose uniform constants are controlled in precisely the moving family and whose output directly fits the decimal scale.

**Current R6 search priority:** `MEDIUM`

**Main risk:** family uniformity may simply repackage the current blocker.

---

# 13. Macro-block F — Diophantine Geometry / Subspace-Type Finiteness

### Standard-looking content

- exact full-root polynomials;
- norm-form equations;
- exponential-Diophantine equations;
- finitely generated multiplicative groups;
- integral points on low-genus families;
- torus/subvariety intersections.

### Current obligations touched

\[
O\text{-Q6}, O\text{-1Q3}, O\text{-X4},
\]

possibly also \(O\text{-Q1}\) if the norm split condition can be algebraicized with exact power-ten parameters.

### What would constitute a weapon

Even an ineffective theorem can be useful if it converts the infinite exponent family into a rigorously finite exceptional structure that the rest of the proof can absorb.

**Current R6 search priority:** `VERY_HIGH`

**Main risk:** existential source/norm variables may prevent a direct application of toric Mordell–Lang/Subspace theorems.

---

# 14. Repeated-invention audit — preliminary answers

### RQ1 — source lattice + primitive + coprimality = universal torsor?

**Preliminary:** partly analogous, but not established. R20's source-lattice model is already exact and low-dimensional; a universal torsor must outperform it at the denominator/basepoint gate to matter.

### RQ2 — finite packet/model change = affine modification/dilatation?

**Yes at the formal level.** This is already the R1 standard-language import; mathematically the source identification still came from R20.

### RQ3 — split conic + norm structure = norm-one torus torsor?

**Yes structurally on the split generic fibre**, but the current residual is not exhausted by this statement.

### RQ4 — power-ten section = cyclic subgroup intersection?

**Not yet proved as an exact reduction.** This is a central Phase II target.

### RQ5 — digit inequalities = height inequalities?

**Partly.** The issue is that the height is source-dependent and moving with the decimal scale; standard fixed-height counting does not automatically apply.

### RQ6 — q=1/q>1 = degeneration family?

**Unknown.** This is an explicit Phase II search question.

### RQ7 — Hermitian/composition = arithmetic invariant theory?

**Structurally plausible**, but the old Hermitian class quotient was too coarse because it forgot the prescribed source diagonal/power-ten section.

### RQ8 — exact resonance = special fibre/intersection?

**Plausible as a geometric rephrasing**, but no external theorem replacement is yet certified.

---

# 15. Phase-I verdict

The macro graph contains three genuinely central cross-architecture opportunities:

\[
\boxed{
\textbf{B: norm/tori unification}
}
\]

\[
\boxed{
\textbf{D/F: exact power-ten algebraicization}
}
\]

\[
\boxed{
\textbf{A/E: family-uniform source-height realization}
}
\]

with universal torsors/Cox and arithmetic invariant theory as secondary candidates.

Crucially, the R6 search must not spend most of its effort on already-solved:

- finite source packet lifting;
- fixed-data primitive counting;
- projective weak approximation;
- generic rational parameterization.

---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75-R1 terminal recompression; 65-R20 semantic model; R14 primitive shell; R12/R1 q=1 and general-J provenance artifacts  
NEW_PROVED_RESULTS=NONE; Phase I re-expanded the dependency graph without adding a theorem  
NEW_REDUCTIONS=Separated q>1 split classification, q>1 source digit-height, q=1 norm/support, and cross-branch exact-power incidence into independent macro obligations  
REJECTED_ROUTES=Treating all J2 as one USSPAL gate; reopening finite packet; treating fixed-fibre counting as the default global architecture  
EXTERNAL_SOURCES_USED=NONE_NEW; Phase I uses frozen internal/source artifacts only  
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE  
OUTPUT_DEPENDENCIES=75_R6/02_external_weapon_search_map.md; Phase II Weapon Discovery  
UNRESOLVED_ITEMS=O-Q1,O-Q5,O-Q6,O-Q7,O-1Q2,O-1Q3,O-1Q4,O-X3,O-X4 plus generality-only O-GJ1/O-GJ2  
PHASE_STATUS=FROZEN
