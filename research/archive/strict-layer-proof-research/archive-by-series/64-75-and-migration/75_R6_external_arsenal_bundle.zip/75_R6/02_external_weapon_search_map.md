# 75-R6 Phase I — External Weapon Search Map

**Project:** 三项十进制拼接平方和问题  
**Round:** 75-R6  
**Phase:** I — Main-Proof Re-expansion / Search Map  
**Input:** `75_R6/01_main_proof_macro_blocks.md`

This is **not** a literature survey. Every search lane is bound to a current obligation and a proposed replacement.

---

# 1. Search discipline

Every Phase-II query must carry:

```text
TARGET_MACRO_BLOCK=
TARGET_OBLIGATIONS=
EXPECTED_REPLACEMENT=
```

A theorem family that cannot plausibly replace a current obligation is classified:

```text
RELATED_BUT_NONWEAPON
```

before deep migration work.

---

# 2. Search priorities

| Family | Target blocks | Target obligations | Expected replacement if successful | Priority |
|---|---|---|---|---|
| WF-A Strong approximation / integral homogeneous spaces | A | O-Q1,O-Q4,O-Q5 | replace split/local/integral realization by one theorem stack | HIGH |
| WF-B Universal torsors / descent | C | O-Q2,O-Q5,O-X2 | replace source denominator + primitive/coprmality reconstruction | MEDIUM |
| WF-C Integral toric varieties / torus torsors | B,C | O-Q1,O-Q5,O-1Q2 | unify norm/conic integral realization | HIGH |
| WF-D Norm-form Hasse/weak approximation | B | O-Q1,O-1Q2 | one norm-torus framework for q>1 and q=1 | VERY_HIGH |
| WF-E Subspace theorem / \(S\)-unit equations | D,F | O-Q6,O-1Q3,O-X4 | convert exact power-ten family to finite exceptional structure | VERY_HIGH |
| WF-F Rational points on conic bundles / quadratic fibrations | A,F | O-Q1,O-Q5, possibly q1/q>1 | family-level replacement for fibrewise charts | MEDIUM |
| WF-G Uniform counting on quadrics/homogeneous spaces | E | O-Q5,O-X3 | bypass source-chart optimization by uniform family theorem | MEDIUM |
| WF-H Arithmetic invariant theory / composition | B,F | O-Q1,O-1Q2 | organize Gaussian/Hermitian/composition data without losing section | MEDIUM |
| WF-I Semigroup orbit / arithmetic dynamics | D,F | O-Q6,O-1Q3,O-X4 | treat \(10^\mathbb Z\) as an orbit and intersect with algebraic conditions | VERY_HIGH |
| WF-J Integral models / dilatations / affine modifications | A,C | O-Q2 and generality O-GJ1 | replace bespoke model-change machinery across families | LOW for current gate / HIGH persistence |

---

# 3. WF-A — Strong approximation / integral homogeneous spaces

```text
TARGET_MACRO_BLOCK=A
TARGET_OBLIGATIONS=O-Q1,O-Q4,O-Q5
EXPECTED_REPLACEMENT=split criterion + finite local source realization + primitive/integral point existence, ideally with useful real-place control
```

### Search questions

1. Are there strong-approximation theorems for affine quadrics/homogeneous spaces whose integral-model hypotheses tolerate bad reduction/conductor models?
2. Can prescribed real connected components or bounded sectors be retained?
3. Is any quantitative form uniform enough in a moving ternary family?
4. Can primitive points be imposed without reintroducing the retired packet machinery?

### Immediate rejection condition

If the theorem only proves finite-place approximation while the moving radial height remains untouched, it is at most a skeleton, not an R6 weapon.

---

# 4. WF-B — Universal torsors / descent / Cox coordinates

```text
TARGET_MACRO_BLOCK=C
TARGET_OBLIGATIONS=O-Q2,O-Q5,O-X2
EXPECTED_REPLACEMENT=one standard coordinate system encoding source integrality + coprimality + denominators, with lower bridge cost than R20/R5
```

### Search questions

1. Does an integral universal-torsor formalism on rational conics/quadric surfaces give exact integral image criteria?
2. Can source full-rank sublattices and primitive conditions be made coordinate-native?
3. Does the torsor expose a smaller height than \(a_p\mathcal H_{\perp,\tau}\)?
4. Can the same formalism accommodate q=1?

### Immediate rejection condition

If it merely recreates an integral \(\mathbf P^1\) parameterization already supplied by R20, classify `RELATED_BUT_NONWEAPON`.

---

# 5. WF-C — Integral toric varieties / torus torsors

```text
TARGET_MACRO_BLOCK=B,C
TARGET_OBLIGATIONS=O-Q1,O-Q5,O-1Q2
EXPECTED_REPLACEMENT=norm/conic local-global skeleton plus source-integral realization
```

### Search questions

1. Can the punctured source cone and q=1 norm equation be placed in one integral torus-torsor framework?
2. Is the relevant obstruction completely Brauer-Manin?
3. Are integral points with local open conditions controlled?
4. Does the theorem preserve the source integral model rather than only the generic torus?

### Immediate rejection condition

If passage to the ambient torus loses the source lattice or the decimal radial height, it cannot exceed reserve status.

---

# 6. WF-D — Norm-form equations / Hasse norm / weak approximation

```text
TARGET_MACRO_BLOCK=B
TARGET_OBLIGATIONS=O-Q1,O-1Q2
EXPECTED_REPLACEMENT=one Gaussian norm theorem stack covering q>1 split/nonsplit and the q=1 norm/Pell layer
```

### Search questions

1. Does the quadratic Hasse norm theorem completely characterize q>1 rational splitting by local data in a reusable way?
2. What integral refinement exists for Gaussian norm equations with coprimality/support restrictions?
3. Can weak approximation on norm-one tori absorb the q>1 projective local conditions?
4. Is there a unified degeneration from q>1 conic to q=1 norm data?

### Cross-Gate target

A successful stack should touch **both q>1 and q=1**, otherwise it is likely a standardization rather than a main-proof weapon.

---

# 7. WF-E — Subspace theorem / \(S\)-unit finiteness

```text
TARGET_MACRO_BLOCK=D,F
TARGET_OBLIGATIONS=O-Q6,O-1Q3,O-X4
EXPECTED_REPLACEMENT=replace infinite power-ten exponent families by finite unions of exceptional subtori/cosets or finite nondegenerate solution sets
```

### Search questions

1. Can an exact source relation be rewritten as a linear equation in finitely many \(S\)-units?
2. Can polynomial relations be converted to a torus-subvariety intersection?
3. What degeneracy classification is returned?
4. Is the theorem effective enough to be useful, or at least structurally finite enough for a later exact finite audit?

### Immediate veto

Variables such as \(u,q\) may divide \(10^g+1\) without themselves being \(S\)-units. A theorem cannot be invoked until this semantic mismatch is eliminated.

---

# 8. WF-F — Conic bundles / quadratic fibrations

```text
TARGET_MACRO_BLOCK=A,F
TARGET_OBLIGATIONS=O-Q1,O-Q5,possible O-1Q2
EXPECTED_REPLACEMENT=one family theorem replacing fibrewise split charts and controlling rational/integral points across varying parameters
```

### Search questions

1. Are there effective rational-point height bounds uniform in conic bundles?
2. Do integral-point analogues retain local and Archimedean conditions?
3. Can singular/split degeneration include q=1 as a special fibre?
4. Does the base being the power-ten semigroup yield extra structure?

### Immediate rejection condition

A theorem whose constants depend on an uncontrolled discriminant/source frame merely renames the R5 blocker.

---

# 9. WF-G — Uniform counting / height zeta / homogeneous dynamics

```text
TARGET_MACRO_BLOCK=E
TARGET_OBLIGATIONS=O-Q5,O-X3
EXPECTED_REPLACEMENT=uniform primitive source-point existence in the moving digit-height shell without choosing a low-distortion source chart
```

### Search questions

1. Is there a family-uniform counting theorem for ternary quadrics with moving lattice/level?
2. Can the decimal shell shrink at the required rate?
3. Are error terms explicit in discriminant/lattice covolume?
4. Does it genuinely avoid source splitting distortion?

### Baseline comparison

It must outperform the elementary \(\mathbf P^1\) engine plus R5 source-specific optimization.

---

# 10. WF-H — Arithmetic invariant theory / composition

```text
TARGET_MACRO_BLOCK=B,F
TARGET_OBLIGATIONS=O-Q1,O-1Q2
EXPECTED_REPLACEMENT=organize Gaussian norm, determinant(-2) Hermitian data, and composition in a section-preserving orbit framework
```

### Search questions

1. Is the determinant-\((-2)\) Hermitian orbit a standard arithmetic invariant-theory representation with a theorem about prescribed invariants/diagonals?
2. Can the prescribed power-ten diagonal section be retained?
3. Does composition produce source-attached small points rather than ambient norm representations?
4. Can q=1 and q>1 be two fibres/invariants of one representation?

### Immediate rejection condition

If the orbit quotient again forgets the prescribed source diagonal/radial section, R10–R12 already show it is too coarse.

---

# 11. WF-I — Semigroup orbit / arithmetic dynamics

```text
TARGET_MACRO_BLOCK=D,F
TARGET_OBLIGATIONS=O-Q6,O-1Q3,O-X4
EXPECTED_REPLACEMENT=encode multiplication by 10 as an algebraic self-map and apply orbit-intersection finiteness/structure theorems
```

### Search questions

1. Can the solution condition become an algebraic subvariety hit by the orbit \(G\mapsto10G\)?
2. With independent \(g,k\), is the right object one orbit, a \(\mathbb N^2\)-semigroup orbit, or a finitely generated subgroup?
3. Which dynamical Mordell–Lang / toric Mordell–Lang theorem actually matches that object?
4. Does the theorem constrain all coordinates or only the power-ten coordinates?

### Immediate veto

If auxiliary source coordinates remain arbitrary and are not coordinates of the orbit/group, a subgroup-intersection theorem does not apply merely after projection.

---

# 12. WF-J — Dilatations / affine modifications / integral models

```text
TARGET_MACRO_BLOCK=A,C
TARGET_OBLIGATIONS=O-Q2; generality O-GJ1
EXPECTED_REPLACEMENT=standard persistent integral-model language across source rows and possible general-J transport
```

### Current state

This family has already succeeded as a standardization tool in 75-R1. For R6 it is not automatically a current major-gate weapon because the relevant finite packet gate is retired.

### Cross-Gate test candidate

It can pass the historical replacement/persistence test only if Phase II shows that the same formalism also materially simplifies another **current** block or general-J transport.

---

# 13. Exact-power-ten sub-map

The exact-power audit gets its own internal search matrix:

| Encoding | Desired standard object | Success condition |
|---|---|---|
| P10-A | \(S\)-unit equation | all multiplicative variables in a finite-rank group; exact equivalence proved |
| P10-B | torus subgroup intersection | exact subvariety \(V\subset\mathbb G_m^n\) and subgroup \(\Gamma\) with source solutions \(=V\cap\Gamma\) or controlled fibres |
| P10-C | semigroup orbit | one/finitely generated algebraic self-map orbit encoding both exponents and all constrained coordinates |
| P10-D | exponential-Diophantine equation | eliminate auxiliary data without losing source semantics |
| P10-E | Subspace theorem | finite-rank multiplicative group statement with exact nondegeneracy dictionary |

Priority order:

\[
\boxed{
P10\text{-B/E}
>
P10\text{-D}
>
P10\text{-C}
>
P10\text{-A}
}
\]

subject to actual applicability.

---

# 14. q=1 unification sub-map

Phase II must explicitly test:

1. q=1 as a singular/degenerate fibre of the q>1 conic/norm family;
2. q=1 and q>1 as torsors under the same Gaussian norm-one torus;
3. q=1 and q>1 as two source-integral models over one parameter base;
4. q=1 and q>1 only sharing power-ten algebraicization, with arithmetic fibres remaining different.

The default is **not** to force unification.

---

# 15. Promotion discipline for Phase II

A candidate family proceeds from search result to Weapon Candidate Sheet only if there is a plausible answer to:

\[
\boxed{
\text{What exact current obligations disappear if this theorem is validly imported?}
}
\]

Each sheet must then test CG1–CG5.

Phase II should prefer fewer deep, verified theorem families over a long bibliography.

---

STAGE_INPUTS=75_R6/01_main_proof_macro_blocks.md; frozen R1-R5 migration state  
NEW_PROVED_RESULTS=NONE; this file specifies theorem-discovery targets rather than proving applicability  
NEW_REDUCTIONS=Bound every literature lane to explicit obligations and replacement criteria; elevated exact-power and norm/tori searches to highest priority  
REJECTED_ROUTES=Unscoped literature survey; fixed-fibre counting for its own sake; universal torsor work that only reproduces R20; toric/S-unit naming without exact incidence  
EXTERNAL_SOURCES_USED=NONE_NEW  
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE  
OUTPUT_DEPENDENCIES=Phase II Weapon Candidate discovery and theorem-card verification  
UNRESOLVED_ITEMS=Whether any WF-A..WF-J family passes Cross-Gate and semantic-preservation tests  
PHASE_STATUS=FROZEN
