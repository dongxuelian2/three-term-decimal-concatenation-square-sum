# WC-001 — Integral Homogeneous Spaces / Integral Quadratic Representations

```text
WEAPON_ID=WC-001
THEORY_FAMILY=Strong approximation and Brauer–Manin criteria on integral homogeneous spaces / quadratic representations
PRIMARY_SOURCES=J.-L. Colliot-Thélène & F. Xu, Compos. Math. 145 (2009), Theorem 3.7; quadratic-representation theorems in Sections 6–9
STANDARD_OBJECT=Integral model of G/H with G semisimple simply connected and connected stabilizer; quadratic-representation homogeneous spaces
TARGET_MAIN_PROOF_BLOCK=A
OBLIGATIONS_REPLACED=Potentially O-Q1 + O-Q4 + part of O-Q5
REQUIRED_REFORMULATION=Identify the exact punctured source-semantic conic/cone as an integral model of the required homogeneous space and transport source primitivity plus digit shell
EXPECTED_SCOPE=q>1 split/nonsplit/local-global skeleton
KNOWN_HYPOTHESIS_RISKS=Smooth homogeneous-space generic fibre; connected stabilizer; required noncompactness/isotropy at omitted archimedean places; exact model compatibility
SEMANTIC_RISKS=The theorem decides/explains integral existence from adelic/Brauer data but does not encode the moving decimal radial window or source-specific height clearance
EXPECTED_GENERALITY=STRICT_LAYER_FAMILY
ESTIMATED_MIGRATION_COST=HIGH
EXPECTED_PROOF_PAYOFF=MEDIUM
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

## Primary theorem verification

The primary 2009 paper is source-verified. Theorem 3.7 treats a separated \(O_S\)-model whose generic fibre is \(G/H\), with \(G\) semisimple simply connected and \(H\) connected, and identifies the Brauer condition relevant to integral points; the surrounding strong-approximation result uses noncompactness at suitable archimedean places. The quadratic-representation sections specialize the framework to orthogonal/Spin settings.

## Current exact applicability

The q>1 source-semantic model has already solved the finite source packet and projective local-matching layers. Thus the only valuable use would be to replace **both** split/local-global work and the surviving source digit-height gate.

That replacement fails at the second half: the imported theorem is qualitative adelic existence/density. It does not give a source-height upper bound or force an integral point into the moving decimal annulus whose radius/width scale with \(G=10^g\).

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL_CURRENTLY
CG2_HISTORICAL_REPLACEMENT_TEST=PASS
CG3_UNIFORM_FAMILY_TEST=PARTIAL
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS
```

The historical/persistence tests pass: this theorem family is a legitimate standard replacement for broad local-global homogeneous-space arguments. But the current major q>1 residual is farther downstream, so it is not promoted.

## Semantic preservation verdict

```text
SOURCE_LATTICE=POTENTIALLY_PRESERVABLE_VIA_INTEGRAL_MODEL
PRIMITIVITY=NOT_NATIVE
DIGIT_INEQUALITIES=NOT_PRESERVED
POWER_TEN_PARAMETER=EXTERNAL_TO_THEOREM
SEMANTIC_VETO=YES_FOR_O-Q5_REPLACEMENT
```

## Net-complexity pre-audit

It would replace already-retired or already-solved local-global machinery while creating a substantial model-identification bridge and leaving O-Q5 intact.

```text
NET_COMPLEXITY=NEUTRAL_TO_NEGATIVE_FOR_CURRENT_FRONTIER
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
