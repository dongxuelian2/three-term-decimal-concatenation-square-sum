# WC-008 — Dynamical Mordell–Lang / Semigroup-Orbit Encoding

```text
WEAPON_ID=WC-008
THEORY_FAMILY=Dynamical Mordell–Lang for étale maps
PRIMARY_SOURCES=J.P. Bell, D. Ghioca, T.J. Tucker, arXiv:0808.3266, Theorem 1.3
STANDARD_OBJECT=Intersection of a subvariety with one forward orbit of an étale endomorphism
TARGET_MAIN_PROOF_BLOCK=D+F
OBLIGATIONS_REPLACED=Potentially O-Q6 + O-1Q3 + O-X4
REQUIRED_REFORMULATION=Encode all constrained variables as coordinates of a single algebraic orbit or a theorem-valid finitely generated semigroup action
EXPECTED_SCOPE=Exact power-ten sequence
KNOWN_HYPOTHESIS_RISKS=The theorem is a one-map/one-orbit statement; current problem has independent g,k plus auxiliary arithmetic variables; source fibres are not orbit coordinates
SEMANTIC_RISKS=Projection to G,K alone discards existential source coordinates
EXPECTED_GENERALITY=GENERAL_J_PLAUSIBLE
ESTIMATED_MIGRATION_COST=VERY_HIGH
EXPECTED_PROOF_PAYOFF=LOW_UNDER_CURRENT_ENCODING
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```

## Primary theorem verification

Theorem 1.3 states that for an étale endomorphism \(\Phi:X\to X\), the intersection of a subvariety with a forward orbit \(O_\Phi(\alpha)\) is a finite union of suborbits/arithmetic-progressions in the iterate index.

Multiplication by \(10\) on \(\mathbb G_m\) or a related torus makes \(10^g\) look dynamical, but that observation is insufficient.

## Exact semantic mismatch

The source solutions are not determined by one orbit point:

- \(g\) and \(k\) are independent exponent indices;
- \(u,q\) are constrained divisors/source variables, not iterates of a fixed algebraic point;
- conic/norm/source coordinates vary over fibres above \((10^g,10^k)\).

A subvariety in the \((G,K)\)-torus can constrain the projection of solutions, but DML does not say that every point of that projection lifts to a legal source point.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL_CURRENTLY
CG2_HISTORICAL_REPLACEMENT_TEST=FAIL
CG3_UNIFORM_FAMILY_TEST=FAIL_CURRENT_ENCODING
CG4_EXACT_POWER_TEST=PASS_ONLY_FOR_THE_POWER_COORDINATES
CG5_FINAL_PROOF_PERSISTENCE_TEST=FAIL_WITHOUT_ORBIT_REFORMULATION
```

## Verdict

Laurent's \(\mathbb Z^r\) exponential-polynomial framework is strictly better adapted to two independent exponents. Hence DML is not the preferred N4 interface.


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
