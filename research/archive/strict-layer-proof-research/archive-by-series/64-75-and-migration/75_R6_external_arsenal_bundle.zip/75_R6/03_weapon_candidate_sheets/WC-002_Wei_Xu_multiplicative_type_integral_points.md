# WC-002 — Integral Points on Multiplicative-Type Groups / Norm-Torus Torsors

```text
WEAPON_ID=WC-002
THEORY_FAMILY=Integral points on torsors under groups of multiplicative type; finite Brauer–Manin obstruction; norm-one tori
PRIMARY_SOURCES=Dasheng Wei & Fei Xu, arXiv:1004.2613, Theorems 1.10, 2.4, 3.2; Proposition 4.3
STANDARD_OBJECT=Separated integral model whose generic fibre is a trivial torsor under a group of multiplicative type
TARGET_MAIN_PROOF_BLOCK=B+C
OBLIGATIONS_REPLACED=Potentially O-Q1 + O-1Q2 + finite/local integral realizability
REQUIRED_REFORMULATION=Put q>1 split source conic and q=1 norm objects into exact trivial torsors under appropriate norm-one tori while retaining source models
EXPECTED_SCOPE=q>1 and q=1 norm/local-global skeleton
KNOWN_HYPOTHESIS_RISKS=Generic fibre must be a trivial torsor for the central theorem; q>1 triviality is itself tied to rational splitting; q=1 order/norm target moves
SEMANTIC_RISKS=Source support, primitive conditions, moving digit shell, and moving right-hand side are not removed
EXPECTED_GENERALITY=STRICT_LAYER_FAMILY
ESTIMATED_MIGRATION_COST=HIGH
EXPECTED_PROOF_PAYOFF=MEDIUM_HIGH_IF_UNIFICATION_WORKS
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

## Primary theorem verification

Source-verified statements:

- Theorem 1.10: admissible subgroups exist for the indicated integral models with trivial multiplicative-type generic torsor.
- Theorem 2.4: for an \(X\)-admissible subgroup \(\Xi\), global integral points exist iff the product of local integral points survives a finite Brauer group \(b(\Xi)\).
- Theorem 3.2: a strong-approximation statement for the multiplicative-type group modulo the adelic pairing.
- Proposition 4.3: an explicit Artin-map criterion for integral solutions to a sum-of-two-squares norm equation over the specified quadratic setting.

## Why this is stronger than mere terminology

Unlike generic “norm torus language”, Wei–Xu gives an actual finite obstruction and an integral-point criterion. It is therefore a real theorem stack, not just a change of vocabulary.

## Current failure point

For q>1, using the trivial-torsor theorem requires a rational split point; hence it does not decide O-Q1 by itself. Once split, R20/R3 already supply the finite/source/projective realization more cheaply.

For q=1, the 24 residual negative objects are norm/Pell equations whose coefficients/order/discriminant move with \(G,K\); a fixed-torus integral-point criterion does not automatically uniformize that family or impose the exact decimal interval.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=PARTIAL_NOT_PASS
CG2_HISTORICAL_REPLACEMENT_TEST=PASS
CG3_UNIFORM_FAMILY_TEST=FAIL_CURRENT_FORMULATION
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS
```

## q=1/q>1 unification test

```text
COMMON_LANGUAGE=NORM_TORUS_TORSORS
COMMON_FIXED_THEOREM_STACK=PLAUSIBLE_LOCALLY
SINGLE_SOURCE_FAMILY=NOT_CONSTRUCTED
Q1_QGT1_UNIFIED_GATE_CLOSURE=NO
```

## Semantic preservation verdict

```text
SOURCE_INTEGRAL_MODEL=POSSIBLE
PRIMITIVITY=BRIDGE_REQUIRED
SOURCE_SUPPORT=BRIDGE_REQUIRED
DIGIT_SHELL=NOT_NATIVE
POWER_TEN=NOT_NATIVE
SEMANTIC_VETO=YES_FOR_CROSS_BRANCH_CLOSURE
```

## Net-complexity pre-audit

```text
NET_COMPLEXITY=POSITIVE_AS_STANDARD_LOCAL_GLOBAL_REFERENCE
NET_COMPLEXITY_FOR_CURRENT_MAJOR_GATES=NEUTRAL
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
