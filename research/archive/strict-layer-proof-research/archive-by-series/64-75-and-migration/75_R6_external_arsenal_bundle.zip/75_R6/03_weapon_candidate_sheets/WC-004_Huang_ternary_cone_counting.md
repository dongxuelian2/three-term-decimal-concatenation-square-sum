# WC-004 — Quantitative Primitive Counting on Ternary Cones

```text
WEAPON_ID=WC-004
THEORY_FAMILY=Quantitative strong approximation / primitive integral-point counting on ternary quadratic cones
PRIMARY_SOURCES=Zhizhong Huang, Quantitative strong approximation for ternary quadratic forms III, arXiv:2512.13091, Theorems 1.2 and 1.3
STANDARD_OBJECT=Punctured affine cone of a nonsingular integral ternary quadratic form with congruence and primitive conditions
TARGET_MAIN_PROOF_BLOCK=A+E
OBLIGATIONS_REPLACED=Fixed-fibre version of O-Q4/O-Q5
REQUIRED_REFORMULATION=Uniform control of theorem constants over the moving source family, including source-lattice distortion and shrinking/moving decimal windows
EXPECTED_SCOPE=Fixed ternary forms; potentially families only after additional uniformity theorem
KNOWN_HYPOTHESIS_RISKS=Constants and local levels depend on fixed form/data; current source family moves
SEMANTIC_RISKS=The source denominator/distortion reappears in the passage from source coordinates to ambient height
EXPECTED_GENERALITY=J2_ONLY_AT_PRESENT
ESTIMATED_MIGRATION_COST=HIGH
EXPECTED_PROOF_PAYOFF=LOW_AFTER_R3
PRELIMINARY_VERDICT=REJECT
```

## Source and historical status

This is the theorem family behind canonical MC-001. R3 proved that the fixed-fibre primitive projective approximation layer is elementary on \(C\simeq\mathbf P^1\), so the heavy fixed-data counting engine was superseded.

The same paper itself notes the projective conic/\(\mathbf P^1\) viewpoint; that is exactly the cheaper interface now used internally.

## Could it revive at family level?

Only if a genuinely **family-uniform** theorem were obtained with constants explicit enough to dominate the moving decimal shell while not paying the current source-frame distortion. The cited theorems do not establish that current requirement.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL
CG2_HISTORICAL_REPLACEMENT_TEST=FAIL_BECAUSE_INTERNAL_REPLACEMENT_ALREADY_CHEAPER
CG3_UNIFORM_FAMILY_TEST=FAIL_FOR_CITED_THEOREM
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=FAIL_AS_ACTIVE_ENGINE
```

## Canonical migration status

```text
RELATED_MIGRATION_CARD=MC-001
MC-001_STATUS=SUPERSEDED
R6_REACTIVATION=NO
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
