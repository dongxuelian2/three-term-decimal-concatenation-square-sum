# WC-007 — Laurent Exponential-Polynomial Structure Theorem

```text
WEAPON_ID=WC-007
THEORY_FAMILY=Exponential-polynomial equations / linear recurrences via the Subspace Theorem
PRIMARY_SOURCES=Michel Laurent, Astérisque 147–148 (1987), Théorème 1, pp. 121–139
STANDARD_OBJECT=Finite systems of exponential-polynomial functions F:Z^r→C, finite sums of characters with polynomial coefficients
TARGET_MAIN_PROOF_BLOCK=D+F
OBLIGATIONS_REPLACED=Potentially O-Q6 + O-1Q3 + O-X4; possibly parts of old moving-root/carry family analysis
REQUIRED_REFORMULATION=Construct an exact finite exponential-polynomial system in exponent variables whose integer zero set is equivalent to source solutions, with all auxiliary source data either eliminated or encoded in fixed characters/polynomial coefficients
EXPECTED_SCOPE=Power-ten exponent architecture; potentially both q=1 and q>1
KNOWN_HYPOTHESIS_RISKS=Current source coefficients contain moving arithmetic parameters not functions solely of exponent variables; q1 quadratic order/discriminant moves; general elimination not constructed
SEMANTIC_RISKS=Elimination may introduce extraneous exponent solutions and lose primitive/source reconstruction
EXPECTED_GENERALITY=GENERAL_J_PLAUSIBLE
ESTIMATED_MIGRATION_COST=VERY_HIGH
EXPECTED_PROOF_PAYOFF=VERY_HIGH_IF_BRIDGE_EXISTS
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

## Primary theorem verification

Laurent defines exponential-polynomial functions on \(\mathbb Z^r\) as finite sums of multiplicative characters with polynomial coefficients and studies common integer zeros.

**Théorème 1** has two relevant layers:

1. with constant polynomial coefficients, maximal compatible solution sets are finite unions of affine subgroups modulo the character-equality subgroup;
2. with nonzero polynomial coefficients, each solution admits a decomposition into a component near such a subgroup plus a subgroup component, with the transverse part only logarithmically large.

The paper explicitly bases the theorem on Schmidt's Subspace Theorem and its \(p\)-adic generalization, so the structural result is ineffective.

## Why this is the strongest N4 reserve

Unlike DML, Laurent's ambient object naturally allows **several independent exponent variables** \((g,k,\ldots)\), and unlike ESS it allows polynomial coefficients in those exponent variables.

If the exact source master equations could be reduced to this class, then powers of ten would cease to be an external parameter and become the intrinsic character

\[
(g,k)\mapsto 10^{ag+bk}.
\]

That is exactly the architecture-level opportunity R6 was asked to look for.

## Why it is not yet migratable

The current actual artifacts explicitly show that fixing residue/carry cells does not freeze all moving coefficient data; variables such as source-core/carry parameters remain genuinely moving. Likewise the q=1 norm/Pell coefficients and discriminant depend on \(G,K\) and additional source data.

No source-valid elimination has produced

\[
\boxed{\mathcal S_{\rm source}
=
\{(g,k,\ldots)\in\mathbb Z^r:F_1=\cdots=F_m=0\}}
\]

for a fixed finite exponential-polynomial system with exact reconstruction.

Therefore the bridge required to apply Laurent is essentially N4 itself.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=PASS_AS_ARCHITECTURAL_TARGET
CG2_HISTORICAL_REPLACEMENT_TEST=PASS_AS_ARCHITECTURAL_TARGET
CG3_UNIFORM_FAMILY_TEST=PASS
CG4_EXACT_POWER_TEST=PASS
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS
CURRENT_APPLICABILITY=FAIL_SEMANTIC_BRIDGE
```

This is the **best Cross-Gate candidate** of Phase II, but a Cross-Gate pass does not override the Semantic Preservation veto.

## Semantic preservation veto

```text
EXACT_ELIMINATION_TO_EXP_POLY=NOT_PROVED
SOURCE_RECONSTRUCTION_FROM_EXPONENT_SOLUTION=NOT_PROVED
PRIMITIVE_CONDITION_AFTER_ELIMINATION=NOT_PROVED
SEMANTIC_VETO=YES
```

## R6 interpretation

```text
POWER_TEN_STANDARD_OBJECT=EXPONENTIAL_POLYNOMIAL_CHARACTERS_ON_Z^r
POWER_TEN_WEAPON_STATUS=HIGH_VALUE_RESERVE_NOT_MIGRATABLE
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
