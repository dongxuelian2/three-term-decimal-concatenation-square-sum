# WC-005 — Universal Torsors / Cox Coordinates for Integral Parameterization

```text
WEAPON_ID=WC-005
THEORY_FAMILY=Universal torsors / Cox-coordinate parameterization of rational and integral points
PRIMARY_SOURCES=Universal-torsor literature; for the current conic specialization, Huang arXiv:2512.13091 §4 identifies the split projective conic with P^1 and its universal torsor with A^2\\{0}; standard integral universal-torsor counting papers used as comparison
STANDARD_OBJECT=Universal torsor over a rational variety; for C≅P^1, A^2\\{0}
TARGET_MAIN_PROOF_BLOCK=C
OBLIGATIONS_REPLACED=Potentially O-Q2 + O-Q4 + O-Q5 source parameterization/coprimality
REQUIRED_REFORMULATION=Show a torsor coordinate choice lowers the allowed-ruling basepoint/denominator cost below the existing source Veronese chart
EXPECTED_SCOPE=Split q>1 conic; possible broader rational varieties
KNOWN_HYPOTHESIS_RISKS=No theorem found that makes the source denominator uniformly smaller
SEMANTIC_RISKS=Integral image and height pullback remain coordinate/model dependent
EXPECTED_GENERALITY=STRICT_LAYER_FAMILY
ESTIMATED_MIGRATION_COST=MEDIUM_HIGH
EXPECTED_PROOF_PAYOFF=LOW
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```

## Structural identification

On the current split conic, universal-torsor language does **not** reveal a higher-dimensional hidden machine: \(C\simeq\mathbf P^1\), and the universal torsor is essentially the primitive pair \((s,t)\in\mathbf A^2\setminus\{0\}\) modulo scaling.

That is precisely the structural level already exploited by:

\[
\text{R20 source Veronese}+\text{R3 primitive }\mathbf P^1\text{ approximation}.
\]

## RQ1 verdict

```text
SOURCE_LATTICE_PRIMITIVE_COPRIMALITY_IS_TORSOR_LIKE=YES
CURRENT_INTERNAL_COORDINATES_ALREADY_REALIZE_CHEAP_VERSION=YES
UNIVERSAL_TORSOR_LOWERS_CURRENT_DENOMINATOR_BLOCKER=NOT_SHOWN
```

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL
CG2_HISTORICAL_REPLACEMENT_TEST=FAIL_CURRENTLY
CG3_UNIFORM_FAMILY_TEST=PARTIAL
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=FAIL_AS_DISTINCT_THEOREM_STACK
```

## Net complexity

Replacing a two-parameter source conic chart by general Cox/universal-torsor machinery increases formal overhead without removing the active denominator/basepoint theorem.

```text
NET_COMPLEXITY=NEGATIVE
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
