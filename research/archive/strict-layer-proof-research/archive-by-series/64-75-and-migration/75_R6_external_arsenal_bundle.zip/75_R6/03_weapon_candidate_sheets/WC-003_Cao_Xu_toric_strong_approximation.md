# WC-003 — Toric Strong Approximation with Brauer–Manin Obstruction

```text
WEAPON_ID=WC-003
THEORY_FAMILY=Strong approximation with Brauer–Manin obstruction on smooth toric varieties
PRIMARY_SOURCES=Yang Cao & Fei Xu, arXiv:1311.7655v2, main theorem numbered Theorem 1.3 in that version
STANDARD_OBJECT=Smooth toric variety over a number field
TARGET_MAIN_PROOF_BLOCK=B+C
OBLIGATIONS_REPLACED=Potentially O-Q4 and finite-place part of O-Q5
REQUIRED_REFORMULATION=Identify the punctured split source cone with the appropriate smooth toric variety and source integral open
EXPECTED_SCOPE=q>1 split punctured cone
KNOWN_HYPOTHESIS_RISKS=The source model and primitive subset are not automatically the toric integral model used by the theorem
SEMANTIC_RISKS=Archimedean digit component is not controlled
EXPECTED_GENERALITY=STRICT_LAYER_FAMILY
ESTIMATED_MIGRATION_COST=MEDIUM
EXPECTED_PROOF_PAYOFF=LOW
PRELIMINARY_VERDICT=RELATED_BUT_NONWEAPON
```

## Primary theorem verification

The primary arXiv version states that any smooth toric variety satisfies strong approximation with Brauer–Manin obstruction off the archimedean places.

This is exactly the right *qualitative* standard object for the punctured split cone. It was already recognized during 75-R1.

## Decisive limitation for 75-R6

The theorem works **off infinity**. The current gate is a moving Archimedean/radial decimal shell, not merely finite-place approximation. Replacing R3/R20 by this theorem would therefore remove no current major obligation.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL
CG2_HISTORICAL_REPLACEMENT_TEST=FAIL_FOR_CURRENT_ACTIVE_MACHINERY
CG3_UNIFORM_FAMILY_TEST=FAIL
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS_AS_BACKGROUND_ONLY
```

A background citation is not enough to classify it as an active weapon.

## Semantic preservation verdict

```text
FINITE_LOCAL_DATA=YES_IN_PRINCIPLE
REAL_DIGIT_REGION=NO
SOURCE_PRIMITIVITY=NOT_NATIVE
POWER_TEN=NO
SEMANTIC_VETO=YES_FOR_ACTIVE_MIGRATION
```

## Net-complexity

```text
NET_COMPLEXITY=NEGATIVE_IF_USED_AS_P2_ENGINE
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
