# WC-006 — Subspace Theorem / \(S\)-Unit Linear Equations

```text
WEAPON_ID=WC-006
THEORY_FAMILY=Subspace-Theorem finiteness for linear equations in finite-rank multiplicative groups
PRIMARY_SOURCES=J.-H. Evertse, H.P. Schlickewei, W.M. Schmidt, Ann. of Math. 155 (2002), Theorem 1.1; arXiv:math/0409604
STANDARD_OBJECT=a1*x1+...+an*xn=1 with x in a finite-rank subgroup Γ⊂(K*)^n; nondegenerate solutions
TARGET_MAIN_PROOF_BLOCK=D+F
OBLIGATIONS_REPLACED=Potentially O-Q6 + O-1Q3 + O-X4
REQUIRED_REFORMULATION=Eliminate/encode all source variables so that every multiplicative variable belongs to one finite-rank group and the surviving relation is a finite sum of group elements
EXPECTED_SCOPE=Exact-power-ten finiteness if exact S-unit reduction exists
KNOWN_HYPOTHESIS_RISKS=u and q are divisors of 10^g+1 rather than S-units; source coordinates are not known to lie in a fixed finite-rank multiplicative group; degeneracies must be classified
SEMANTIC_RISKS=Projection to only G,K forgets existence and integrality of source fibres
EXPECTED_GENERALITY=GENERAL_J_PLAUSIBLE
ESTIMATED_MIGRATION_COST=VERY_HIGH
EXPECTED_PROOF_PAYOFF=VERY_HIGH_CONDITIONAL
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

## Primary theorem verification

Theorem 1.1 applies to a subgroup \(\Gamma\subset(K^\*)^n\) of finite rank \(r\) and bounds the number of **nondegenerate** solutions of a linear equation

\[
a_1x_1+\cdots+a_nx_n=1.
\]

The essential theorem input is therefore much more specific than “some variables are powers of ten”.

## Exact-power test

\[
G=10^g,\qquad K=10^k
\]

certainly lie in a rank-one multiplicative subgroup, but the actual source equations also contain \(u,q\) and source variables. In J2,

\[
uq=G+1
\]

does **not** imply \(u,q\in\langle 2,5\rangle\); typically they are divisors of \(10^g+1\), which is precisely outside the \(S=\{2,5\}\) unit group.

Thus the source solution set has not been reduced to an ESS equation.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=PASS_CONDITIONAL_ONLY
CG2_HISTORICAL_REPLACEMENT_TEST=PASS_CONDITIONAL_ONLY
CG3_UNIFORM_FAMILY_TEST=PASS_AT_THEOREM_LEVEL
CG4_EXACT_POWER_TEST=PASS_AT_STANDARD_OBJECT_LEVEL
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS_IF_EXACT_REDUCTION_EXISTS
CURRENT_APPLICABILITY=FAIL
```

For R6 classification, conditional passes are **not counted as unconditional External-Weapon passes**.

## Semantic veto

```text
EXACT_S_UNIT_REDUCTION=NOT_CONSTRUCTED
SOURCE_FIBRE_PRESERVATION=NOT_PROVED
SEMANTIC_VETO=YES
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
