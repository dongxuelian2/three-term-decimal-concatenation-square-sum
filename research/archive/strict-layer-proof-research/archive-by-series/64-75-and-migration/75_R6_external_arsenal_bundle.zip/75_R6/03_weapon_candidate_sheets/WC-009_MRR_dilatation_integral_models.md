# WC-009 — Dilatations / Affine Modifications / Integral Model Change

```text
WEAPON_ID=WC-009
THEORY_FAMILY=Dilatations and affine modifications as standard integral-model formalism
PRIMARY_SOURCES=Mayeux–Richarz–Romagny formalism already verified and theorem-carded in 75-R1
STANDARD_OBJECT=Integral model obtained by dilatation/affine modification along prescribed closed data
TARGET_MAIN_PROOF_BLOCK=A+C
OBLIGATIONS_REPLACED=Historically O-Q2/O-Q3 source-packet model-change machinery; possibly general-J model transport
REQUIRED_REFORMULATION=None for the already-recognized R20 model-change interpretation; new work would be required for general-J
EXPECTED_SCOPE=Integral-model architecture, not current quantitative closure
KNOWN_HYPOTHESIS_RISKS=None decisive for the already-retired packet layer
SEMANTIC_RISKS=Formal model language does not itself prove which source rows define the correct model
EXPECTED_GENERALITY=GENERAL_J_PLAUSIBLE
ESTIMATED_MIGRATION_COST=LOW_FOR_LANGUAGE_HIGH_FOR_NEW_APPLICATIONS
EXPECTED_PROOF_PAYOFF=HIGH_HISTORICALLY_LOW_FOR_CURRENT_GATE
PRELIMINARY_VERDICT=KEEP_AS_RESERVE
```

## RQ2 verdict

The finite packet/model-change structure is indeed best understood as standard dilatation/affine-modification data. This was one of the genuine successful standard-theory recoveries of 75-R1.

But R20 has already **retired that gate**. Re-promoting the formalism now would count historical replacement as if it were a new current weapon.

## Cross-Gate Test

```text
CG1_TWO_GATE_TEST=FAIL_CURRENT_MAJOR_GATES
CG2_HISTORICAL_REPLACEMENT_TEST=PASS
CG3_UNIFORM_FAMILY_TEST=PLAUSIBLE
CG4_EXACT_POWER_TEST=FAIL
CG5_FINAL_PROOF_PERSISTENCE_TEST=PASS_AS_MODEL_LANGUAGE
```

## Verdict

```text
CURRENT_ACTIVE_WEAPON=NO
STANDARD_THEORY_REPLACEMENT_ALREADY_ACHIEVED=YES
FORMAL_MIGRATION_CARD_NEW=NO
```


---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; cited primary theorem sources; actual 65/75 source artifacts
NEW_PROVED_RESULTS=NONE unless explicitly stated above; this is a weapon-candidate applicability audit
NEW_REDUCTIONS=Candidate-specific standard-theory comparison and bridge identification as recorded above
REJECTED_ROUTES=Any route explicitly classified RELATED_BUT_NONWEAPON or REJECT above
EXTERNAL_SOURCES_USED=Primary sources listed in PRIMARY_SOURCES
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; Weapon Candidate Sheets precede formal migration
OUTPUT_DEPENDENCIES=75_R6/04_promoted_weapon_registry.md; Phase-IV replacement stress tests
UNRESOLVED_ITEMS=Candidate-specific bridge and semantic-preservation issues listed above
PHASE_STATUS=FROZEN
