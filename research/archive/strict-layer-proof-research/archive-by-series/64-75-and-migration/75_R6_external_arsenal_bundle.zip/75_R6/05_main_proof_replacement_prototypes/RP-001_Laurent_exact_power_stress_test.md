# RP-001 — Laurent Exact-Power Main-Proof Replacement Stress Test

**Status:** `NON_MIGRATING_STRESS_TEST`  
**Candidate:** WC-007  
**Purpose:** test whether Laurent's exponential-polynomial theorem can replace a real current proof chain *today*.

---

# BEFORE

The current cross-branch exact-power architecture is schematically:

\[
\boxed{
\text{J2 structural state}
\to
(G,K)=(10^g,10^k)
\to
\begin{cases}
q>1:\ \text{split/source conic variables }(u,q,\mathbf x,\ldots),\\
q=1:\ \text{norm/root variables }(a,\tau,Y,\ldots),
\end{cases}
\to
\text{branch equations}
\to
\text{digit/source legality}.
}
\]

For q>1, the power-ten parameters are tied to divisor/source variables such as \(u,q\), including \(uq=G+1\) in J2.  
For q=1, the exact fixed-\(\tau\) norm equation has coefficients/discriminant depending on \(G,K\) and source data.

The open global gate is:

\[
O\text{-X4}/N4=
\text{construct an exact standard arithmetic object encoding the power-ten incidence}.
\]

---

# PROPOSED AFTER

The hoped-for replacement is:

\[
\boxed{
\text{source structural equations}
\overset{\mathcal E}{\longrightarrow}
\{F_i(\mathbf n)=0\}_{i=1}^m
\overset{\text{Laurent Thm. 1}}{\longrightarrow}
\text{affine-subgroup / near-subgroup structure}
\longrightarrow
\text{finite subgroup/coset audit}
\longrightarrow
\text{source reconstruction}.
}
\]

Here \(\mathbf n\in\mathbb Z^r\) would contain \(g,k\) and any other genuine exponent coordinates, and every \(F_i\) must be a **fixed** exponential-polynomial:

\[
F_i(\mathbf n)=\sum_\ell P_{i,\ell}(\mathbf n)\chi_{i,\ell}(\mathbf n).
\]

---

# REQUIRED NEW BRIDGE \(\mathcal E\)

For this to be legal, \(\mathcal E\) must prove all of:

1. every legal source solution maps to a zero of the fixed system;
2. every zero retained after the theorem admits source reconstruction, or extraneous components are explicitly identified and removed;
3. divisor variables \(u,q\) and primitive/source coordinates are eliminated or encoded without turning into arbitrary moving coefficients;
4. all carry/floor charting becomes a **finite fixed** collection of exponential-polynomial systems;
5. q=1 moving norm/Pell discriminants are either eliminated or represented inside the same fixed character system;
6. the digit/source inequalities survive as a final condition on the returned affine subgroups/cosets.

No current artifact proves this bridge.

---

# REMOVED — if \(\mathcal E\) existed

Conditionally, Laurent could replace:

- repeated casewise polynomial-in-\(10^g\) analysis;
- ad hoc recurrence-intersection arguments;
- a large class of “does this moving exponential relation have infinitely many exponent solutions?” subproblems;
- potentially the exact-power portion of both q>1 and q=1.

This would be a genuine architectural replacement.

---

# RETAINED

Even after Laurent:

- source reconstruction;
- primitive/reducedness legality;
- inequalities/digit intervals;
- degenerate affine-subgroup components;
- possibly split/nonsplit source geometry if not eliminated by \(\mathcal E\).

remain to be handled.

---

# NEW RISKS

1. **Ineffectivity:** Laurent's structure theorem is Subspace-Theorem based.
2. **Degenerate components:** affine-subgroup families can survive and must be interpreted back in source variables.
3. **Semantic projection:** elimination can produce exponent points with no source lift.
4. **Bridge hardness:** constructing \(\mathcal E\) is at least the current N4 task and may be harder.

---

# Net Complexity Audit

### Current, unconditional comparison

```text
OLD_OBLIGATIONS_REMOVED=0
NEW_OBLIGATIONS_INTRODUCED=1_MAJOR_EXACT_EXP_POLY_REFORMULATION + degeneration/reconstruction audits
NET_COMPLEXITY_CHANGE=NEGATIVE
```

### Conditional comparison after a future exact N4 algebraicization

```text
OLD_OBLIGATIONS_REMOVED=MULTIPLE_EXACT_POWER_SUBPROBLEMS
NEW_OBLIGATIONS_INTRODUCED=AFFINE_SUBGROUP_DEGENERACY_CLASSIFICATION
NET_COMPLEXITY_CHANGE=STRONGLY_POSITIVE_PLAUSIBLE
```

Thus Laurent is a **high-value reserve weapon behind N4**, not a current replacement of N4.

---

# Replacement verdict

```text
REPLACEMENT_PROTOTYPE_STATUS=FAIL_CURRENTLY
FAILURE_POINT=SOURCE_TO_FIXED_EXPONENTIAL_POLYNOMIAL_BRIDGE
BRIDGE_DIFFICULTY=EQUAL_TO_OR_GREATER_THAN_CURRENT_N4
FORMAL_MIGRATION=NO
P2_BYPASS=NOT_ESTABLISHED
```

---

STAGE_INPUTS=WC-007; 75_R6 macro graph; actual q>1 source-semantic and q=1 norm/root artifacts
NEW_PROVED_RESULTS=No new source theorem; audit proves the candidate replacement cannot currently start before solving an N4-equivalent bridge
NEW_REDUCTIONS=Localized exact failure to source-valid fixed exponential-polynomial reformulation, rather than to Laurent's theorem itself
REJECTED_ROUTES=Calling powers of ten alone an exponential-polynomial reduction; projecting away source variables without reconstruction
EXTERNAL_SOURCES_USED=Michel Laurent, Astérisque 147-148 (1987), Théorème 1
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=06_power_ten_rearchitecture_audit.md; weapon ranking
UNRESOLVED_ITEMS=Exact source exponential-polynomial algebraicization; degeneration/reconstruction if later achieved
PHASE_STATUS=FROZEN
