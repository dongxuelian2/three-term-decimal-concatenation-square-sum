# RP-002 — Wei–Xu Norm-Torus Main-Proof Replacement Stress Test

**Status:** `NON_MIGRATING_STRESS_TEST`  
**Candidate:** WC-002  
**Purpose:** test whether a multiplicative-type/norm-torus theorem stack can simultaneously absorb q>1 and q=1 live gates.

---

# BEFORE

## q>1

\[
\boxed{
\text{actual split test}
\to
\text{R20 source-semantic conic}
\to
\text{primitive projective finite/real matching}
\to
\text{source digit-height/radial incidence}.
}
\]

R20/R3 already prove the middle finite/source/projective pieces.

## q=1

\[
\boxed{
\text{exact root/norm reduction}
\to
24\text{ residue-constrained moving Pell/norm objects}
\to
\text{source support + interval + exact-power conditions}.
}
\]

---

# PROPOSED AFTER

Hope:

\[
\boxed{
\text{both branches}
\to
\text{integral norm-torus torsors}
\overset{\text{Wei--Xu}}{\longrightarrow}
\text{finite Brauer/Artin criterion for integral points}
\to
\text{source conclusion}.
}
\]

---

# q>1 applicability

Once the conic is rationally split, the punctured conic/cone admits torus/torsor language. Wei–Xu can provide a standard integral-point/Brauer framework **for an appropriate trivial torsor**.

However:

1. triviality does not decide the original split condition O-Q1;
2. source finite/projective lifting is already proved internally;
3. the theorem supplies existence among integral points satisfying adelic conditions, not an upper-height representative in the moving decimal radial shell.

Hence O-Q5 remains.

---

# q=1 applicability

The q=1 negative line has fixed-\(\tau\) Pell/norm descriptions, but across the power-ten family:

- the quadratic coefficient/discriminant moves with \(G,K\);
- the associated order/field can move;
- the arithmetic progression/source support moves;
- the required real interval is part of the contradiction.

A theorem for a fixed multiplicative-type torsor does not collapse this family to one fixed Artin/Brauer computation.

---

# REMOVED

At most, the imported stack could standardize:

- fixed norm-torsor integral local-global criteria;
- finite Brauer/Artin obstruction language;
- some branch-local existence proofs.

But those are not the live q>1 digit-height gate, and they do not close q=1.

---

# RETAINED

- O-Q1 split classification;
- O-Q5 source radial/digit height;
- q=1 moving norm family;
- exact powers \(10^g,10^k\);
- source support/primitivity.

---

# NEW RISKS

- proving each source fibre is the exact integral torsor model;
- computing admissible/Brauer groups uniformly in a moving family;
- real-component/digit-window control;
- reconstructing source primitive coordinates.

---

# Net Complexity Audit

```text
OLD_LIVE_MAJOR_OBLIGATIONS_REMOVED=0
ALREADY_SOLVED_OBLIGATIONS_STANDARDIZED=SEVERAL
NEW_BRIDGES_CREATED=INTEGRAL_TORSOR_IDENTIFICATION + MOVING_BRAUER_DATA + DIGIT_HEIGHT_STILL_REQUIRED
NET_COMPLEXITY_CHANGE=NEGATIVE_FOR_CURRENT_FRONTIER
```

---

# q=1/q>1 unification verdict

There is a genuine common **norm-torus language**, but not a single current theorem instantiation that removes both branches' live arithmetic.

```text
COMMON_STANDARD_LANGUAGE=YES
COMMON_GATE_CLOSURE=NO
Q1_QGT1_UNIFICATION=FORMAL_ONLY_AT_PRESENT
REPLACEMENT_PROTOTYPE_STATUS=FAIL_CURRENTLY
FORMAL_MIGRATION=NO
```

---

STAGE_INPUTS=WC-002; q>1 R20/R3/R5 state; q=1 norm/Pell source artifacts
NEW_PROVED_RESULTS=No new theorem; audit establishes that the common norm-torus language does not remove the moving digit/power/source obligations
NEW_REDUCTIONS=Separated fixed-torsor local-global standardization from moving-family closure
REJECTED_ROUTES=Treating q>1 split trivial torsor as a split proof; treating q=1 moving Pell family as one fixed norm torus
EXTERNAL_SOURCES_USED=Wei–Xu arXiv:1004.2613, Theorems 1.10, 2.4, 3.2 and Proposition 4.3
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=07_q1_unification_audit.md; weapon ranking
UNRESOLVED_ITEMS=O-Q1,O-Q5,q1 moving norm/support,power-ten algebraicization
PHASE_STATUS=FROZEN
