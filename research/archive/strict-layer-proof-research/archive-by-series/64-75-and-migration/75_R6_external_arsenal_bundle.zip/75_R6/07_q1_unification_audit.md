# 75-R6 — q=1 / q>1 External-Weapon Unification Audit

**Discipline:** no new q=1 internal case split.  
**Goal:** determine whether a single mature external framework can legitimately contain both q=1 and q>1.

---

# 1. Actual branch asymmetry

## q>1

The current source object is an integral ternary quadratic/conic model after R20 semantic reconstruction. The rational split question is explicit; on split fibres, the remaining gate is a source-preserving moving digit-height incidence.

## q=1

The current negative frontier is a finite collection of residue-constrained Pell/norm orbit problems. For fixed residue/source data one has a binary quadratic norm equation, but its coefficients and discriminant/order move with the power-ten parameters and retained source data.

Thus q=1 is **not** presently just “the q→1 fibre” of the exact q>1 source conic construction.

---

# 2. Candidate unification U1 — one homogeneous-space theorem

CT–Xu provides a broad standard language for integral homogeneous spaces and quadratic representations.

But the two branches would still require different identifications:

- q>1: ternary conic/Spin source model;
- q=1: binary norm/Pell torsor with moving order/support.

No single theorem instantiation was found that simultaneously removes both live gates.

```text
U1_COMMON_LANGUAGE=YES
U1_SINGLE_CURRENT_APPLICATION=NO
```

---

# 3. Candidate unification U2 — norm-one tori / multiplicative type

This is the strongest common **geometric vocabulary**.

- q>1 split conics can be described using a one-dimensional torus/torsor after choosing a rational point.
- q=1 Pell/norm equations are likewise torsors/orbits under norm-one tori.

Wei–Xu gives genuine integral-point criteria for fixed trivial multiplicative-type torsors.

But the common vocabulary does not create a common fixed integral family:

1. q>1 triviality is downstream of the actual split condition;
2. q=1's quadratic order/discriminant moves;
3. the source support/primitive conditions differ;
4. neither side's exact decimal height is controlled.

```text
U2_COMMON_NORM_TORUS_LANGUAGE=YES
U2_SINGLE_FIXED_TORUS=NO
U2_SINGLE_INTEGRAL_MODEL=NO
U2_CROSS_BRANCH_GATE_CLOSURE=NO
```

---

# 4. Candidate unification U3 — universal torsor/Cox coordinates

For the split q>1 conic, the universal torsor reduces essentially to primitive \((s,t)\)-coordinates on \(\mathbf A^2\setminus\{0\}\), already realized by R20/R3.

The q=1 norm/Pell line does not thereby become the same torsor.

```text
U3_UNIFICATION=NO
```

---

# 5. Candidate unification U4 — common exact-power torus base

Both branches share:

\[
(G,K)=(10^g,10^k)\in\Gamma_{10}\subset\mathbb G_m^2.
\]

This is the strongest genuine common external object found in R6.

It gives the architecture

\[
\boxed{
\text{source solution variety/family}
\longrightarrow
\Gamma_{10}
}
\]

with q=1 and q>1 as different arithmetic fibres/lift conditions over the same exact-power base.

What is missing is an exact algebraic description of the admissible image/lift.

```text
U4_COMMON_BASE=YES
U4_COMMON_FIBRE_THEOREM=NO
U4_CURRENT_WEAPON=NO
```

---

# 6. Candidate unification U5 — degeneration family q=1 ↔ q>1

A genuine theorem-level unification would require constructing an integral family

\[
\mathscr X\to\mathscr B
\]

in which q=1 and q>1 arise as controlled fibres/degenerations and for which one external theorem is stable through the degeneration.

No such exact flat/source-integral family has been produced by current artifacts or the external audit.

In particular, it is unsafe to identify q=1 with a “singular fibre” merely by analogy.

```text
U5_DEGENERATION_FAMILY=NOT_CONSTRUCTED
```

---

# 7. Unification verdict

The audit finds two persistent **common languages**:

\[
\boxed{\text{norm-torus language}}
\]

and

\[
\boxed{\Gamma_{10}\subset\mathbb G_m^2\text{ exact-power base}}.
\]

Neither currently supplies a single theorem stack closing both branches.

The second is more valuable architecturally because it is exact and genuinely common before branch arithmetic diverges.

```text
Q1_UNIFICATION_STATUS=COMMON_POWER_TORUS_BASE_ONLY
Q1_QGT1_COMMON_NORM_LANGUAGE=YES
Q1_QGT1_SINGLE_EXTERNAL_WEAPON=NO
Q1_QGT1_SINGLE_INTEGRAL_FAMILY=NOT_CONSTRUCTED
```

---

# 8. Consequence for R7

q=1 should **not** be forced into the q>1 USSPAL machinery.

Nor should q>1 be rewritten into the moving q=1 Pell family.

Any later unification should occur one level higher, through the exact-power base or a genuinely constructed family, not by branch-specific coordinate analogy.

---

STAGE_INPUTS=Phase-I obligation graph; WC-001,WC-002,WC-005,WC-007; RP-002; actual q=1 and q>1 frozen artifacts
NEW_PROVED_RESULTS=No new source theorem; audit establishes only the exact shared Gamma_10 power-coordinate base
NEW_REDUCTIONS=q=1/q>1 unification target moved from fibre equations to a potential common exact-power base
REJECTED_ROUTES=Forcing q=1 as an unproved degeneration of q>1; claiming one fixed norm torus; universal-torsor identification of both branches
EXTERNAL_SOURCES_USED=CT–Xu integral homogeneous-space framework; Wei–Xu multiplicative-type torsors; Laurent exact-power framework
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=weapon ranking; final external-arsenal map
UNRESOLVED_ITEMS=Exact common source-image over Gamma_10; q=1 moving norm/support closure; q>1 N1/N2
PHASE_STATUS=FROZEN
