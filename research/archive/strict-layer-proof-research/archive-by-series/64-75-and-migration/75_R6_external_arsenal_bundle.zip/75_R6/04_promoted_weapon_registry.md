# 75-R6 Phase III — Promoted Weapon Registry

**Input:** Phase-0 frozen migration state + Phase-I obligation graph + nine Phase-II Weapon Candidate Sheets  
**Promotion cap:** 3  
**Actual promoted count:** 0

---

# 1. Promotion rule

A candidate is formally promoted only if all of the following hold simultaneously:

1. at least one Cross-Gate test is a genuine current `PASS`;
2. exact theorem hypotheses have a source-valid instantiation;
3. source lattice / primitive / reconstruction / digit / exact-power semantics are either preserved by the theorem or recovered by bridges **strictly cheaper than the obligation replaced**;
4. net proof complexity is positive;
5. a concrete Imported Conclusion can already be written for the current source problem.

An architecture-level theorem that would be excellent **after** an unproved reformulation is not yet migratable.

---

# 2. Candidate promotion table

| Candidate | Cross-Gate signal | Current applicability | Semantic veto | Net complexity | Priority grade | Promotion |
|---|---|---|---|---|---|---|
| WC-001 CT–Xu integral homogeneous spaces | CG2/CG5 | qualitative local-global only | YES for digit-height | neutral/negative current | B | NO |
| WC-002 Wei–Xu multiplicative type | CG2/CG5 | fixed/trivial norm torsors | YES for moving source/digit family | neutral current | B | NO |
| WC-003 Cao–Xu toric SA | background CG5 | finite-place toric SA | YES at infinity | negative | C | NO |
| WC-004 Huang ternary counting | none current | fixed-data theorem | superseded | negative | REJECT | NO |
| WC-005 universal torsor/Cox | none current | current conic already P1 | no denominator gain | negative | C | NO |
| WC-006 ESS S-unit | strong conditional CG3/4/5 | exact S-unit reduction absent | YES | potentially huge but bridge=N4 | A-RESERVE | NO |
| WC-007 Laurent exponential-polynomial | CG1/2/3/4/5 architecture-level | exact exp-poly source reduction absent | YES | potentially huge but bridge=N4 | A-RESERVE | NO |
| WC-008 BGT DML | power-coordinate CG4 only | wrong orbit object | YES | negative vs Laurent | C | NO |
| WC-009 MRR dilatations | CG2/CG5 historical | already standardized retired layer | no current-gate payoff | neutral | B-RESERVE | NO |

---

# 3. Best candidate: WC-007 Laurent

WC-007 is the only candidate whose **standard object matches the strategic exact-power requirement itself** rather than merely treating a fibre after \(G,K\) have been fixed.

If one had an exact source-valid finite system

\[
F_1(g,k,\ldots)=\cdots=F_m(g,k,\ldots)=0
\]

with each \(F_i\) exponential-polynomial on a fixed \(\mathbb Z^r\), Laurent's theorem would be persistent, cross-gate, family-level and naturally exact-power aware.

But current source artifacts prove only **partial master-root feasibility**. They explicitly retain moving source/carry/core variables not yet represented as fixed exponent characters or polynomial coefficients. In q=1, even the Pell/norm discriminant/order moves with \(G,K\) and source data.

Therefore the exact reformulation demanded by Laurent is not a minor bridge. It is the unresolved N4 algebraicization problem.

A formal Migration Card would have to claim an imported conclusion whose hypotheses have not been established. That is forbidden.

```text
WC007_PROMOTION=DENIED
REASON=SEMANTIC_BRIDGE_EQUALS_OPEN_N4
```

---

# 4. Why WC-006 ESS is not promoted

ESS would be even stronger if the source equations reduced to a linear equation in a finite-rank multiplicative group. But:

\[
uq=10^g+1
\]

does not place \(u,q\) in the \(S=\{2,5\}\)-unit group; they are typically divisors of \(10^g+1\). Source coordinates also lie outside any currently identified fixed finite-rank multiplicative subgroup.

Hence the reduction needed before ESS applies is stronger than the current exact-power algebraicization itself.

```text
WC006_PROMOTION=DENIED
REASON=NO_EXACT_FINITE_RANK_MULTIPLICATIVE_GROUP_ENCODING
```

---

# 5. Why norm/homogeneous-space stacks are not promoted

WC-001/WC-002 are mathematically legitimate theorem stacks and may ultimately appear as standard background references. But R20/R3 have already solved the finite source-model and projective local-matching parts more cheaply.

Their imported conclusions do not control the active moving decimal radial shell and do not remove the source denominator/basepoint distortion. Therefore promoting them would replace solved historical machinery rather than a live major gate.

```text
WC001_PROMOTION=DENIED
WC002_PROMOTION=DENIED
REASON=NO_CURRENT_MAJOR_GATE_REMOVED
```

---

# 6. Formal migration action

No Phase-II candidate survives both the Semantic Preservation veto and the Net Complexity test.

Therefore:

```text
WEAPON_CANDIDATES_PROMOTED=0
NEW_MIGRATION_CARDS=NONE
NEW_WEAPON_STACK_CARDS=NONE
FORMAL_PROMOTION_STATUS=NO_LEGAL_PROMOTION
```

This invokes the user-authorized negative branch:

\[
\boxed{
\texttt{NO\_CANDIDATE\_WORTH\_PROMOTION\_UNDER\_CURRENT\_SOURCE\_SEMANTICS}
}
\]

It does **not** mean all external theory is irrelevant. It means no newly audited theorem can currently replace a live main-proof gate at positive net complexity.

---

# 7. Phase-IV stress-test targets

Although there is no formal promoted weapon, Phase IV will still perform two **non-migrating replacement stress tests** so that the negative verdict is demonstrated on real proof chains rather than asserted abstractly:

1. `RP-001_Laurent_exact_power_stress_test.md`
2. `RP-002_WeiXu_norm_torus_stress_test.md`

These are not Migration Cards and do not create external dependencies.

---

STAGE_INPUTS=75_R6/00_previous_migration_state.md; 75_R6/01_main_proof_macro_blocks.md; 75_R6/02_external_weapon_search_map.md; all WC-001..WC-009
NEW_PROVED_RESULTS=No new mathematical theorem; proved audit fact: no candidate currently has both a valid source instantiation and positive live-gate replacement
NEW_REDUCTIONS=WC-007 isolated as best exact-power reserve; its missing bridge identified exactly with N4-level source-valid exponential-polynomial algebraicization
REJECTED_ROUTES=Forced promotion of qualitative homogeneous-space/tori results; forced ESS application; forced DML orbit interpretation; reactivation of MC-001
EXTERNAL_SOURCES_USED=All primary sources frozen in Phase-II candidate sheets
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE
OUTPUT_DEPENDENCIES=Phase-IV replacement stress tests; later ranking and terminal verdict
UNRESOLVED_ITEMS=N4 exact source exponential-polynomial/S-unit reformulation; N2 denominator/basepoint distortion; q=1 norm/support closure
PHASE_STATUS=FROZEN
