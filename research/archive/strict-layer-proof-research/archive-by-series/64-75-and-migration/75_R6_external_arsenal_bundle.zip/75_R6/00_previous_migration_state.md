# 75-R6 Phase 0 — Previous Migration State Freeze

**Project:** 三项十进制拼接平方和问题  
**Round:** 75-R6  
**Phase:** 0 — Previous Migration State Freeze  
**Protocol:** Phase-Frozen Artifact Protocol  
**Scope:** 只冻结 75-R1 至 R5 的实际迁移状态与必要的 65-R20 source-of-truth；本文件不进入 Phase I，不进行新的 external-weapon discovery。

---

## 0. Source-of-truth precedence

本阶段采用以下 provenance precedence：

1. **75-R5 final migration registry / certificate / SHA ledger**；
2. 75-R4 terminal verdict；
3. 75-R3 terminal verdict 与更新后的 P2 stack；
4. 75-R2 terminal verdict / theorem registry / dry run；
5. 75-R1 terminal verdict / 65 terminal recompression；
6. 65-R20 semantic-conductor-ruling actual report and certificate。

若旧 manifest、旧 migration stack 与后续 round 的 canonical registry 冲突，以**后续明确更新并带 SHA 的 artifact**为准。

本阶段使用的核心 actual artifacts：

- `75_R1/12_R1_terminal_verdict.md`
- `75_R1/00_65_terminal_recompression.md`
- `75_R2/12_R2_terminal_verdict.md`
- `75_R2/08_quantitative_theorem_registry.md`
- `75_R2/10_migration_dry_run.md`
- `75_R3/14_R3_terminal_verdict.md`
- `75_R3` updated `migration_stack_P2.md`
- `75_R4/15_R4_terminal_verdict.md`
- `75_MIGRATIONS/MC-001_Huang_Ternary_Cone_Primitive_Local_Counting.md`
- `75_MIGRATIONS/MC-002_Cassels_Small_Zero.md`
- `75_R5/16_R5_terminal_verdict.md`
- `75_R5/17_R5-certificate.txt`
- `75_R5/SHA256SUMS.txt`
- `75_MIGRATIONS/migration_stack_P2.md` as frozen after R5
- `J2-65-R20-Semantic-Conductor-Ruling-Report.md`
- `J2-65-R20-certificate.txt` / R20 execution certificate where required.

---

# 1. Frozen 65/R20 semantic base

The following are **PROVED** and must not be reopened merely as a consequence of changing external-theory strategy.

### P0.1 — Semantic integral model is exact

The source packet rows are internalized by semantic graph/dilatation coordinates, including

\[
V=q^2v,\qquad \ell_M^{\rm sem}=M_0w.
\]

R20 proves that the semantic model has exactly the intended source-integral points; the source model and semantic model are integrally equivalent at the relevant level.

**Status:** `PROVED`

### P0.2 — Finite packet is model-change data, not an independent obstruction

The apparent moving packet \(\mathbf Z/(M_0q^2)\) is absorbed into the semantic integral model.  
The mixed ruling defect collapses to a bounded whole-module defect

\[
\mathbb Z/\gcd(M_0,800)\mathbb Z,
\]

and is not a remaining source-nonemptiness obstruction.

**Status:** `PROVED / RETIRED_AS_GATE`

### P0.3 — Semantic conductor–ruling lifting

\[
\texttt{SEMANTIC_CONDUCTOR_RULING_LIFTING=PROVED}.
\]

Consequently:

\[
\texttt{FINITE_SOURCE_PACKET_RETIRED=TRUE},
\qquad
\texttt{R15_R20_LAYER_RETIRED=TRUE}.
\]

This does **not** imply \(q>1\Rightarrow\varnothing\).

### P0.4 — Source-adapted integral degree-2 conic parameterization

Once a source-integral isotropic basepoint exists, R20 supplies an integral degree-2 conic/Veronese parameterization in the source lattice. Rational parameterization alone is not treated as a substitute for source-integral realization.

**Status:** `PROVED`

### P0.5 — Primitive source-ray scaling

On a rationally split fibre, any rational isotropic ray can be cleared into the full-rank source lattice and primitive-normalized in a source-lattice basis.

**Status:** `PROVED`

---

# 2. 75-R1 frozen migration/standardization state

75-R1 identifies the surviving q>1 object as:

\[
\boxed{\text{integral ternary quadratic cone with a source integral model}}
\]

whose punctured split generic fibre is a \(\mathbb G_m\)-torsor over a rational conic / smooth toric variety.

### R1-A — Mayeux–Richarz–Romagny dilatation / affine-blowup formalism

**Role:** standard-theory replacement for bespoke Rees/dilatation language.  
**R1 level:** `M5`, `G2` (formal tool plausibly more general).  
**Semantic bridge:** already supplied internally by R20.  
**Current R6 classification:** `MIGRATED_STANDARD_FORMALISM`, but **not an active theorem dependency for the P2 quantitative closure**.

It may be reused architecturally in later phases, but Phase 0 does not yet promote it as an External Weapon.

### R1-B — Cao–Xu toric strong approximation / Brauer–Manin skeleton

**Role in R1/R2:** qualitative finite-place/Brauer skeleton for the split punctured cone.  
**Limitation:** does not supply the moving Archimedean digit/radial-height theorem.  
**Current R6 classification:** `VALID_STANDARD_SKELETON / NOT_ACTIVE_P2_DEPENDENCY`.

### R1-C — CT–Xu homogeneous-space/BM and O'Dorney integral-conic frameworks

**Role:** standard-language and structural comparison.  
**Current R6 classification:** `RESERVE_STANDARD_THEORY`, not a proved replacement for the surviving digit-height/power-ten gate.

### R1-D — power-ten multiplicative-group language

\[
(G,K)=(10^g,10^k)
\]

is naturally semigroup / finitely generated multiplicative-group data.

However no actual artifact through R5 constructs a single algebraic incidence variety whose intersection with the relevant cyclic/finitely generated subgroup is exactly the source solution set.

**Status:** `CANDIDATE_LANGUAGE_ONLY`, not a migrated reduction.

---

# 3. 75-R2 frozen state

R2 terminal verdict:

```text
R2_TERMINAL_VERDICT=SOURCE_HEIGHT_BRIDGE_REDUCED
P2_M_LEVEL=M5
P2_M5_BASIS=M5-B_N2_REDUCED_TO_USSPAL
P2_G_LEVEL=G2
```

The reduction is **not** a proof of N2 and is **not** a direct imported source-height theorem.

Frozen R2 facts:

- exact source-semantic punctured ternary cone: `PROVED`;
- split criterion is explicit, but actual power-ten family split/nonsplit classification remains open;
- torsor dictionary is valid on rationally split fibres;
- local-open dictionary: `COMPLETE`;
- primitivity: source primitive ray + radial multiplier;
- projective reciprocity / finite-real compatibility: `CONTROLLED`;
- moving Archimedean annular/digit sector: explicitly defined;
- N3 reciprocity gate: `PROVED_CONTROLLED`;
- N2: reduced to USSPAL + radial clearance;
- fixed-data external theorems do not provide the required moving-family uniformity.

---

# 4. 75-R3 frozen internal replacement

R3 terminal verdict:

```text
R3_TERMINAL_VERDICT=USSPAL_ELEMENTARY_REDUCTION
N2_STATUS=OPEN_REDUCED
```

The decisive R3 replacement is internal:

\[
\boxed{
\text{source-adapted }\mathbf P^1
+
\text{Primitive Sector-Congruence Lemma}
}
\]

This proves the fixed-fibre primitive projective approximation layer elementarily.

Frozen consequences:

1. fixed-data primitive sector approximation is `PROVED_ELEMENTARY`;
2. primitive extraction costs no extra height factor;
3. \(M_0q^2\) is excluded from the USSPAL local level;
4. the moving quantitative problem is compressed to
   \[
   C_{\rm fam}\le \mathfrak D_\tau\,\mathfrak E_\tau^2;
   \]
5. the clearance test is explicit and LOW degeneration is genuine;
6. Huang/Kelmer–Yu are no longer necessary engines for fixed-data approximation.

Hence:

```text
MC001_STATUS=SUPERSEDED_FOR_P2_USSPAL_FIXED_DATA_ENGINE
FIXED_DATA_COUNTING_THEORY=SUPERSEDED_BY_ELEMENTARY_P1
USSPAL_GLOBAL_STATUS=OPEN_REDUCED
```

---

# 5. 75-R4 frozen external migration

R4 terminal verdict:

```text
R4_TERMINAL_VERDICT=SPLITTING_DISTORTION_EXPLICITLY_BOUNDED
N2_STATUS=OPEN_REDUCED
```

R4 formally migrated Cassels' small integral zero theorem to the exact source-basis ternary form.

It yields a legal generic fallback bound of the shape

\[
\|p\|_\infty\le C_C(3)H(Q_\tau),
\qquad
\mathfrak D_\tau
\le 16C_C(3)H(Q_\tau)^2.
\]

This makes the splitting distortion explicit but is **clearance-insufficient**.

Frozen consequences:

- full integral Witt-frame completion is not required;
- R20's degree-2 source parameterization bypasses that machinery;
- generic Cassels height is a fallback benchmark only;
- N2 remains open;
- no nontrivial Ultra-LOW closure follows from the generic bound.

---

# 6. 75-R5 frozen source-specific state

R5 certificate:

```text
R5_TERMINAL_VERDICT=SOURCE_SPECIFIC_ADVANTAGE_UNRESOLVED
STATUS=N2_OPEN_REDUCED
```

Certified R5 gains include:

1. exact ruling substitution produces a genuine quadratic lift;
2. source lattice and full allowed \(u\)-ruling are whole-modulus compatible;
3. no composition-assisted low-height source point constructor was certified;
4. conditional transverse Veronese images land in the allowed ruling;
5. allowed-\(u\) parameter cost improves to
   \[
   E=O(j(u))=G^{o(1)};
   \]
6. source distortion reduces to an allowed-ruling basepoint/denominator factor times explicit transverse height;
7. the local-\(u\) component of the joint cost improves from polynomial \(u^2\) to subpolynomial \(G^{o(1)}\);
8. a squarefree-discriminant lower-bound mechanism was identified;
9. old integer quantization alone does not close the current cubic clearance threshold.

Not certified:

- an exact low-height allowed-ruling source basepoint;
- \(E=O(1)\);
- a total joint-cost exponent sufficient for closure;
- nontrivial Ultra-LOW compression;
- N2 closure;
- a uniform intrinsic exponent barrier.

The current P2/USSPAL interface is therefore frozen as:

```text
INTERFACE=P2_USSPAL
STATUS=OPEN_REDUCED
KNOWN_JOINT_COST=a_p * H_perp,tau * j(u)^2
LOCAL_u_GAIN=E=O(j(u))=G^o(1)
CURRENT_ADVANTAGE=local-u exponent collapse
CURRENT_BLOCKER=allowed-ruling source denominator / low-height basepoint / chart distortion
NEXT_PRIMARY_THEOREM=ALLOWED_RULING_SOURCE_DENOMINATOR_THEOREM
NEXT_DUAL_NEGATIVE_THEOREM=UNIFORM_SQUAREFREE_OR_SOURCE_CONTENT_HEIGHT_BARRIER
```

---

# 7. Canonical Migration Card registry at the end of R5

## MC-001 — Huang ternary-cone primitive local counting

```text
MIGRATION_CARD_ID=MC-001
STATUS=SUPERSEDED
ACTIVE_DEPENDENCY=NO
ROLE=PROVENANCE_ONLY
```

Superseded by:

\[
\boxed{
\text{R20 source-adapted }\mathbf P^1
+
\text{R3 Primitive Sector-Congruence Lemma}
}
\]

The theorem remains a valid fixed-data template and provenance reference, but it is not part of the active P2 proof engine.

## MC-002 — Cassels small integral zero

```text
MIGRATION_CARD_ID=MC-002
STATUS=MIGRATED
PROOF_ROLE=FALLBACK_ONLY
ACTIVE_DEPENDENCY=NO
```

It is legally applicable in the exact source basis, but its generic coefficient-height exponent is too large for the clearance collision.

## MC-003

R5 canonical registry states:

```text
MC-003=NOT_CREATED
ROLE=REJECTED_CANDIDATE_NOTE_ONLY
ACTIVE_DEPENDENCY=NO
```

No new theorem is to be treated as a formally migrated MC-003.

---

# 8. Migration-ID provenance conflict and canonical resolution

There is a **historical numbering conflict** that must be frozen now.

The older R2 manifest / early P2 stack listed:

```text
MC-002=Cao_Xu_Toric_Strong_Approximation
MC-003=Kelmer_Yu_Shrinking_Sector
```

Later R3/R4/R5 artifacts superseded that registry and R5's SHA-backed canonical migration state is:

```text
MC-001=Huang / SUPERSEDED
MC-002=Cassels / MIGRATED_FALLBACK_ONLY
MC-003=NOT_CREATED / rejected-candidate note only
```

Therefore, for all of R6:

1. **the R5 registry is canonical**;
2. old R2 labels `MC-002 Cao–Xu` and `MC-003 Kelmer–Yu` are archival identifiers only and must not be cited as current Migration Card IDs;
3. Cao–Xu and Kelmer–Yu remain theorem-family provenance / Theorem Card references, not active migration cards;
4. any future formal migration receives a fresh non-conflicting MC identifier.

This is a provenance correction only; it changes no mathematical verdict.

R5 SHA ledger confirms the canonical migration files:

```text
c39b10470b5ccc95da359b56d2631fb6ad31f878fee1a282005ac86c498a02fc  75_MIGRATIONS/MC-001_status_R5.md
3bcfa4e516449f84288059f52b179d69e4d7f664ad127469e07705ca651c64af  75_MIGRATIONS/MC-002_Cassels_Small_Zero_R5_Update.md
0cffe728a7c76f15e1f5c1ce4e08ee5aa084050f10dd2479cdf8c60bb91590b5  75_MIGRATIONS/MC-003_rejected_candidate_note.md
b9e1eee2efd56acafd2759a3062423f2f2ec29b43b5b763aec62fb3471f7a4b9  75_MIGRATIONS/migration_stack_P2.md
```

---

# 9. Current canonical P2 migration stack

At the end of R5, the active engine is predominantly internal:

\[
\boxed{
\text{R20 source Veronese}
+
\text{R5 allowed-ruling transverse chart}
+
\text{R3 elementary primitive sector approximation}
}
\]

with R14 radial multiplier and R20 inverse reconstruction retained downstream.

Canonical external-card status:

| Card | Status | Current role | Active dependency |
|---|---|---|---|
| MC-001 Huang | SUPERSEDED | provenance / fixed-data benchmark | NO |
| MC-002 Cassels | MIGRATED | generic small-zero fallback benchmark | NO |
| MC-003 | NOT CREATED | rejected-candidate note only | NO |

Hence:

```text
ACTIVE_EXTERNAL_THEOREM_DEPENDENCIES_FOR_P2=NONE
ACTIVE_EXTERNAL_STANDARDIZATION_DEPENDENCY=MRR_DILATATION_FORMALISM_OPTIONAL_ARCHITECTURAL_LANGUAGE
```

This does **not** mean external theory is useless; it means no external quantitative theorem is currently indispensable to the surviving P2 engine.

---

# 10. Existing internal replacements that must remain frozen

The following internal reductions/replacements are already accomplished and must not be casually re-imported as external gates:

### IR-1 — finite source packet / conductor-ruling orbit machinery

`RETIRED` by R20 semantic model.

### IR-2 — fixed-data ternary-cone counting for P2

`SUPERSEDED` by elementary \(\mathbf P^1\) primitive sector-congruence approximation.

### IR-3 — primitive extraction height factor

`RETIRED`; primitive normalization adds no height cost at the projective-ray layer.

### IR-4 — full integral Witt-frame construction

`NOT_NEEDED`; R20 chord/Veronese source parameterization bypasses it.

### IR-5 — primitive modulo-\(u\) obstruction

`RETIRED` on split source conics.

### IR-6 — projective finite-real compatibility as an independent gate

`CONTROLLED`; R14 weak approximation / source-lattice lift handles it on split fibres.

### IR-7 — generic polynomial splitting distortion as a closure engine

`INSUFFICIENT`; retained only as a fallback benchmark.

---

# 11. Current unresolved gates — frozen without upgrading "reduced" to "proved"

## G1 / N1 — actual q>1 rational split/nonsplit classification

Residual explicit test:

\[
(-1,N_0)=0,
\]

with the exact \(N_0\) depending on the actual power-ten source family.

**Status:** `OPEN_MAJOR`

No family-wide split/nonsplit verdict is proved.

## G2 / N2 — split-fibre primitive digit-height incidence

On a rationally split source-semantic conic, realize a primitive source point in the full moving decimal radial/digit shell.

Current P2 realization:

\[
\text{USSPAL / source-chart interface}.
\]

**Status:** `OPEN_MAJOR / INTERNALLY_REDUCED`

Current blocker is not primitive projective approximation itself; it is the source-specific denominator/basepoint/distortion needed to make the height clearance effective.

## G3 / N4 — exact power-ten algebraicization

Construct an exact standard arithmetic object encoding the surviving equations together with

\[
G=10^g,\qquad K=10^k.
\]

**Status:** `OPEN_MAJOR / G3_RESERVE`

No S-unit / toric / cyclic-subgroup theorem is yet legally applicable to the full source solution set because the exact incidence object has not been built.

## G4 / N5 — q=1 closure

The q=1 branch remains independent of the q>1 semantic conic migration.

**Status:** `OPEN_MAJOR`

## G5 / N6 — general-J source transport

General-J transport must use only source-valid structure and the reduced denominator \(u_0\); the J2 identity \(u\mid G+1\) must not be silently exported.

**Status:** `OPEN_MAJOR / ORTHOGONAL_TO_CURRENT_J2_CLOSURE`

## G6 — original-problem-level uniform architecture

Whether all surviving branches fit one standard family of integral homogeneous/toric/exponential objects remains unresolved.

**Status:** `OPEN_MAJOR / ARCHITECTURAL`

---

# 12. Current global status after Phase 0 freeze

```text
J2_STATUS=OPEN
q_GT_1_STATUS=OPEN
FINITE_SOURCE_PACKET=RETIRED
N1_SPLIT_CLASSIFICATION=OPEN
N2_SOURCE_DIGIT_HEIGHT=OPEN_REDUCED
N3_RECIPROCITY=CONTROLLED
N4_EXACT_POWER_TEN_ALGEBRAICIZATION=OPEN
q1_STATUS=OPEN
GENERAL_J_STATUS=OPEN
```

No result in R1–R5 justifies upgrading any of the open gates above to `PROVED`.

---

# 13. Frozen strategic baseline for Phase I

Phase I must begin from the **whole main-proof graph**, not from the local quantity
\(a_p\mathcal H_{\perp,\tau}\).

The baseline comparison point is:

```text
P2_USSPAL_STATUS=OPEN_REDUCED
P2_USSPAL_ACTIVE_EXTERNAL_DEPENDENCY=NONE
P2_USSPAL_ACTIVE_INTERNAL_ENGINE=R20_SOURCE_VERONESE + R5_ALLOWED_RULING_TRANSVERSE_CHART + R3_ELEMENTARY_P1
P2_USSPAL_LOCAL_u_COST=SUBPOLYNOMIAL
P2_USSPAL_BLOCKER=SOURCE_DENOMINATOR_BASEPOINT_DISTORTION
P2_USSPAL_MAY_BE_DEMOTED_TO_RESERVE=YES_IF_R6_FINDS_BETTER_CROSS_GATE_WEAPON
```

R6 is therefore free to discover that P2 is noncanonical, but it is **not** free to forget the source-semantic restrictions already proved necessary.

---

# 14. Phase-0 machine-readable freeze block

```text
PHASE_0_STATUS=FROZEN

PREVIOUS_MIGRATION_STATE=FROZEN
CANONICAL_MIGRATION_REGISTRY=R5_LATEST_SHA_BACKED_STATE

MC001_STATUS=SUPERSEDED
MC001_ACTIVE_DEPENDENCY=NO

MC002_STATUS=MIGRATED
MC002_ROLE=FALLBACK_BENCHMARK
MC002_ACTIVE_DEPENDENCY=NO

MC003_STATUS=NOT_CREATED
MC003_ROLE=REJECTED_CANDIDATE_NOTE_ONLY

R2_LEGACY_MC002_CAO_XU=ARCHIVAL_ID_ONLY
R2_LEGACY_MC003_KELMER_YU=ARCHIVAL_ID_ONLY

ACTIVE_EXTERNAL_DEPENDENCIES_FOR_P2=NONE
ACTIVE_INTERNAL_P2_ENGINE=R20_SOURCE_VERONESE+R5_ALLOWED_RULING_TRANSVERSE_CHART+R3_ELEMENTARY_P1

FINITE_PACKET_STATUS=RETIRED
SOURCE_SEMANTIC_MODEL=PROVED_EXACT
SOURCE_RECONSTRUCTION=PROVED
PRIMITIVE_PROJECTIVE_APPROXIMATION=PROVED_ELEMENTARY

N1_STATUS=OPEN_MAJOR
N2_STATUS=OPEN_MAJOR_INTERNALLY_REDUCED
N3_STATUS=PROVED_CONTROLLED
N4_STATUS=OPEN_MAJOR
Q1_STATUS=OPEN_MAJOR
GENERAL_J_STATUS=OPEN_MAJOR

USSPAL_STATUS=OPEN_REDUCED
USSPAL_CURRENT_BLOCKER=SOURCE_DENOMINATOR_BASEPOINT_DISTORTION
USSPAL_LOCAL_u_GAIN=SUBPOLYNOMIAL
```

---

STAGE_INPUTS=75-R1..R5 actual terminal artifacts; latest R5 migration registry and SHA ledger; 65-R20 semantic-conductor-ruling report/certificate  
NEW_PROVED_RESULTS=NONE; Phase 0 is a provenance/state freeze, not a new mathematics phase  
NEW_REDUCTIONS=Canonicalized the migration registry; froze P2 as OPEN_REDUCED with no active external theorem dependency; isolated historical MC-ID collision  
REJECTED_ROUTES=Reopening finite-packet/Spin/ruling classification; treating fixed-data counting as active P2 engine; treating Cassels fallback as clearance closure; treating S-unit/toric naming as an exact reduction  
EXTERNAL_SOURCES_USED=Previously verified R1-R5 external theorem records only; no new external source imported in Phase 0  
MIGRATION_CARDS_CREATED_OR_UPDATED=NONE; current canonical status frozen as MC-001 SUPERSEDED, MC-002 MIGRATED/FALLBACK_ONLY, MC-003 NOT_CREATED  
OUTPUT_DEPENDENCIES=Phase I must use this frozen state as its sole previous-migration baseline  
UNRESOLVED_ITEMS=N1 split classification; N2 source digit-height incidence; N4 exact power-ten algebraicization; q=1; general-J transport; original-problem uniform architecture  
PHASE_STATUS=FROZEN
