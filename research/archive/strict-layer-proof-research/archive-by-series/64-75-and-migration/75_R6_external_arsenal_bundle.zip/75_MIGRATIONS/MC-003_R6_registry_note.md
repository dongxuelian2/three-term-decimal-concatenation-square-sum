# MC-003 — R6 Registry Note

```text
MIGRATION_CARD_ID=MC-003
CANONICAL_STATUS=NOT_CREATED
```

Historical R2 artifacts used `MC-003` as an early label for a Kelmer–Yu candidate. R5 and the R6 Phase-0 provenance freeze make that label archival only.

R6 creates no MC-003 theorem migration.

```text
R6_ACTION=NO_CARD_CREATED
```
