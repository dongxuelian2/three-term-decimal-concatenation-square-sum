# MC-002 — Cassels Small Zero — R6 Status Update

```text
MIGRATION_CARD_ID=MC-002
THEOREM_FAMILY=Cassels small integral zero for indefinite integral quadratic forms
PRE_R6_STATUS=MIGRATED_FALLBACK_ONLY
R6_STATUS=MIGRATED_FALLBACK_ONLY
ACTIVE_DEPENDENCY=NO
FINAL_PROOF_ROLE=GENERIC_SPLITTING_HEIGHT_BENCHMARK_IF_NEEDED
```

R6 found no architecture in which the generic Cassels coefficient-height bound becomes the active closure theorem. The theorem remains legally migrated and source-basis compatible, but quantitatively too expensive for the current digit-clearance collision.

```text
PROMOTION_TO_ACTIVE_STACK=NO
STATUS_CHANGE=NONE
```
