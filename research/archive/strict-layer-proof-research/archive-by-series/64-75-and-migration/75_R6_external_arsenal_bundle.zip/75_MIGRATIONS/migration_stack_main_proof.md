# 75 Migration Stack — Main Proof after R6

## Active proof engine

```text
ACTIVE_EXTERNAL_WEAPON_STACK=NONE
ACTIVE_P2_EXTERNAL_THEOREM_DEPENDENCIES=NONE
ACTIVE_INTERNAL_ENGINE=R20_SOURCE_SEMANTIC_MODEL + R20/R5_SOURCE_VERONESE_ALLOWED_RULING_CHART + R3_ELEMENTARY_P1
```

## Migration cards

```text
MC-001=SUPERSEDED / provenance only
MC-002=MIGRATED / fallback benchmark only
MC-003=NOT_CREATED
NEW_R6_MC=NONE
```

## Standard background

- MRR dilatation / affine-modification formalism — persistent model language.
- CT–Xu integral homogeneous-space/Brauer–Manin stack — reserve.
- Wei–Xu multiplicative-type/norm-torus integral points — reserve.
- Cao–Xu toric strong approximation — background only.

## High-value external reserves

1. Laurent exponential-polynomial structure theorem.
   - Activate only after exact N4-A source-image algebraicization.
2. ESS finite-rank multiplicative-group equation theorem.
   - Activate only after exact group reduction/linearization.

## Weapon Stack Cards

```text
NEW_WEAPON_STACK_CARDS=NONE
REASON=NO_FORMAL_WEAPON_PROMOTED
```

## R7

```text
PRIMARY_INTERFACE=P2_USSPAL
SECONDARY_RESERVE=N4_A_Gamma10_TO_LAURENT
```
