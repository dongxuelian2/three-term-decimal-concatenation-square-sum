# Remaining New Mathematics after R3

The bridge has been stripped to three objects.

## T1 — Source Splitting-Distortion Bound

Bound
\[
\mathfrak D_\tau
\]
uniformly or by an explicit power of \(G,u,q,K\).

Equivalent forms include:

- a quantitative small primitive isotropic source basepoint bound;
- a bounded-height source-integral \(\mathbf P^1\) trivialization;
- a bound for the coefficient norm and inverse real/p-adic distortion of an R20 source-adapted split chart.

This is the principal remaining USSPAL theorem.

## T2 — Allowed-Class \(u\)-Open Approximation

Improve the fixed-class fallback
\[
\mathfrak E_\tau\le u
\]
by exploiting that the R14 local condition is a large open union of admissible projective classes.

Target:
\[
\mathfrak E_\tau=u^{o(1)}
\quad\text{or at least}\quad
\mathfrak E_\tau\ll u^\theta,\ \theta<1/2.
\]

This is an elementary \(\mathbf P^1\) avoidance/covering problem.

## T3 — LOW Reach versus Splitting Distortion

Use the explicit R15 semialgebraic sector to bound
\[
R_\tau^{\rm LOW}
\]
relative to \(\mathfrak D_\tau\), or prove that failure of such a bound forces a smaller algebraic degeneration locus.

## Orthogonal gate

N1 remains:
\[
(-1,N_0)=0?
\]

It should stay a side audit unless a low-cost structural criterion appears.

## Retired for P2

- Huang fixed-data cone counting as the main USSPAL engine;
- Kelmer–Yu shrinking-sector theorem as necessary machinery;
- finite packet/Spin/ruling route;
- exact fixed residue as the intended local model.
