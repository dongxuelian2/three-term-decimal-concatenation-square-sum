# Projective Parameterization

R20 supplies the source-integral formula
\[
F_{\rm sem}(s,t)
=
Q_\Gamma(y)p-\mathcal B(p,y)y,
\]
for an integral isotropic source basepoint \(p\).

It has:

```text
DEGREE=2
COEFFICIENT_RING=Z in a source-lattice basis
ISOTROPY=IDENTICAL
PACKET_PULLBACK=ABSORBED_BY_SOURCE_MODEL
```

Let
\[
A_{\tau,p}(s,t):=a(F_{\rm sem}(s,t)).
\]
Then \(A_{\tau,p}\) is a binary quadratic form and
\[
|A_{\tau,p}(s,t)|
\le
\mathcal A_{\tau,p} H(s,t)^2,
\qquad
H(s,t)=\max(|s|,|t|).
\]

After taking the global source content
\[
c_{\rm sem}(s,t)=\gcd(F_1,F_2,F_3),
\]
the primitive ray has
\[
a_0=\frac{A_{\tau,p}(s,t)}{c_{\rm sem}(s,t)}
\le
A_{\tau,p}(s,t).
\]

Thus primitive extraction has multiplicative height cost exactly at most \(1\).

## Important limitation

The existence of a split chart is not the missing theorem.
The missing quantitative statement is a family bound for a chart with controlled

- \(\mathcal A_{\tau,p}\),
- inverse real distortion,
- finite-place saturation.

Equivalently, one needs a controlled source splitting frame / small source isotropic basepoint.

This limitation prevents R3 from declaring USSPAL proved.
