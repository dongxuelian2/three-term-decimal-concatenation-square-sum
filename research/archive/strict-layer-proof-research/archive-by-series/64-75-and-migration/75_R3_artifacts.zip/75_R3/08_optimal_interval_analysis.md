# Optimal Interval Analysis

Consider the LOW-admissible boundary component with normalized reach
\[
R>0,
\]
i.e. \((0,R)\) is contained in the admissible \(\xi\)-sector.

For subintervals \(J=[x,R]\), maximize
\[
f_R(x)=
\frac{(R-x)^2}{4}
\min\left(\frac9{10},\frac{x}{1+x}\right).
\]

## Unsaturated regime

For \(x<9\),
\[
f_R(x)=\frac{(R-x)^2x}{4(1+x)}.
\]
Differentiation gives
\[
f'_R(x)
=
\frac{(x-R)(2x^2+3x-R)}{4(1+x)^2}.
\]

Hence the interior maximizer is
\[
\boxed{
x_*(R)=\frac{\sqrt{9+8R}-3}{4}.
}
\]

It reaches \(x_*=9\) exactly at
\[
R=189.
\]

Therefore, for \(0<R\le189\),
\[
\boxed{
\Psi(R)=
\frac{(R-x_*)^2}{4}\frac{x_*}{1+x_*}.
}
\]

## Saturated regime

For \(R\ge189\), the optimum begins at the saturation point \(x=9\):
\[
\boxed{
\Psi(R)=\frac9{40}(R-9)^2.
}
\]

## Small-boundary asymptotic

As \(R\to0\),
\[
x_*(R)=\frac R3+O(R^2),
\]
hence
\[
\boxed{
\Psi(R)=\frac{R^3}{27}+O(R^4).
}
\]

Thus the normalized LOW clearance degenerates **cubically** in the available boundary-component reach.

## Safe elementary lower bound

Choosing \(x=R/3\) gives, for \(0<R\le1\),
\[
\boxed{
\Psi(R)\ge\frac{R^3}{36}.
}
\tag{PSI-LOW}
\]

This bound is used for the explicit degeneration theorem.
