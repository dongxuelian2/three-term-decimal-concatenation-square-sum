# USSPAL R3 Verdict

## What R3 proves

### 1. Fixed-data primitive approximation is elementary

Once a source-integral split chart is fixed, primitive projective approximation with one finite projective residue class satisfies
\[
H(s,t)\ll m\rho^{-1},
\]
hence
\[
a_0\ll
\mathcal A_{\tau,\Phi}
\Lambda_{\tau,\Phi}^2
m^2\rho^{-2}.
\]

No ternary homogeneous-dynamics theorem is needed for this layer.

### 2. Primitive extraction costs nothing asymptotically

Global gcd division preserves the projective residue because the gcd is coprime to the modulus and only decreases height.

### 3. The remaining moving constant is localized

After R20 source normalization and R3 \(\mathbf P^1\) reduction,
\[
\boxed{
C_{\rm fam}\le\mathfrak D_\tau\mathfrak E_\tau^2.
}
\]

The only genuinely new moving ingredients are:

- source-integral splitting-frame / chart distortion \(\mathfrak D_\tau\);
- quantitative exploitation of the many allowed \(u\)-classes, \(\mathfrak E_\tau\);
- the normalized real-sector reach \(R_\tau^{\rm LOW}\).

### 4. Clearance failure has an exact degeneration inequality

\[
\Psi(R_\tau^{\rm LOW})
\le
\frac{\mathfrak D_\tau\mathfrak E_\tau^2j(10u)}{G}.
\]

## What R3 does not prove

R3 does not prove a uniform power-ten bound for \(\mathfrak D_\tau\). This is the same small-source-splitting-frame problem that R2 identified as hidden in a moving conic normalization.

Therefore:
```text
USSPAL_STATUS=ELEMENTARY_REDUCTION_COMPLETE; UNIFORM_SPLITTING_DISTORTION_OPEN
N2_STATUS=OPEN_REDUCED
```

The correct success level is **SUCCESS-B**, with an additional explicit uniformity obstruction and degeneration theorem.
