# N1 Split/Nonsplit Side Audit

Scope: \(q>1\) only.

The actual R1/R2 rational-split gate is
\[
\boxed{
(-1,N_0)=0
}
\]
with
\[
N_0
=
4u^2G^2K^2-(GA+1)^2+2,
\qquad
A=2u+1,
\qquad
uq=G+1.
\]

Equivalently, with
\[
B=2G+q,\qquad GA+1=uB,
\]
\[
\boxed{
N_0=2+u^2(4K^2G^2-B^2).
}
\]

This is the Gaussian norm test
\[
N_0\in N_{\mathbf Q(i)/\mathbf Q}(\mathbf Q(i)^\times).
\]

## Audit against existing structure

Known exact congruences include
\[
N_0\equiv2\pmod{u^2},
\qquad
N_0\equiv1-2AG\pmod{G^2}.
\]

R10's composite Gaussian congruence audit shows these congruences do not by themselves decide global splitting.

The unique determinant-\((-2)\) Hermitian class also does not imply that every prescribed diagonal pair occurs.

Hence:

```text
N1_STATUS=OPEN
SPLIT_FAMILY_STATUS=NOT_AUTOMATICALLY_ALL_SPLIT; NOT_CLASSIFIED
RESIDUAL_SPLIT_TEST=(-1,N0)=0
```

## Important non-conflation

The later R17 condition
\[
D_0=Y^2
\]
is the split **étale/order** locus of the boundary norm presentation. It is not a replacement for the R1/R2 rational source-conic split test \((-1,N_0)=0\).

No prime-by-prime classification is opened in R3.
