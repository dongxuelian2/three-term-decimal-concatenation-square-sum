# Boundary Degeneration Dictionary

Define
\[
R_\tau^{\rm LOW}
:=
\sup\{R>0:(0,R)\subset\mathscr I_{\xi,\tau}\},
\qquad
\xi=\frac{h}{Aa}.
\]

R15 proves:

- \(\xi=0\) is a genuine W-admissible real boundary point;
- \(R_\tau^{\rm LOW}>0\) for each fixed fibre;
- no uniform positive lower bound for projective clearance was proved;
- on rationally split fibres rational points are dense near that real boundary, so the boundary is not excluded by real/source geometry.

Therefore old LOW machinery does **not** close the degeneration. It gives the exact coordinate and proves the degeneration is genuine.

## R3 quantitative degeneration theorem

Let
\[
C_{\rm fam}\le \mathfrak D_\tau\mathfrak E_\tau^2
\]
be the elementary source-\(\mathbf P^1\) bound and put
\[
\varepsilon_\tau
:=
\frac{
\mathfrak D_\tau\mathfrak E_\tau^2\,j(10u)
}{G}.
\]

The boundary component alone supplies clearance at least
\[
\Psi(R_\tau^{\rm LOW}).
\]

Therefore failure of the canonical clearance inequality implies
\[
\boxed{
\Psi(R_\tau^{\rm LOW})\le\varepsilon_\tau.
}
\tag{DEG-EXACT}
\]

If
\[
\varepsilon_\tau<\frac1{36},
\]
then failure forces \(R_\tau^{\rm LOW}<1\), and (PSI-LOW) yields
\[
\boxed{
R_\tau^{\rm LOW}
\le
(36\varepsilon_\tau)^{1/3}.
}
\tag{DEG-CUBIC}
\]

Thus once the splitting/local constant is sublinear enough, every clearance failure is quantitatively pushed into a cubic LOW-boundary degeneration locus.

This is a genuine theorem, but it does not by itself bound \(\mathfrak D_\tau\).
