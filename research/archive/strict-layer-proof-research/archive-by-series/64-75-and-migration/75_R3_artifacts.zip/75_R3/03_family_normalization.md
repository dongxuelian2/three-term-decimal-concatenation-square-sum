# Family Normalization Audit

## NORM-A — Integral equivalence

`NOT_PROVED / NOT_EXPECTED AS FINITE-CLASS REDUCTION`.

The source forms and source lattices move. R20 gives an integral isomorphism between the true R15 source model and the semantic graph model, but this is not a proof that all fibres lie in finitely many \(GL_3(\mathbf Z)\)-classes.

## NORM-B — Rational/projective normalization

`YES ON EACH N1-SPLIT FIBRE`.

Every rationally split projective conic is \(\mathbf P^1\). The important caveat is quantitative:
the height of a splitting map and its inverse is not uniform for free.

This is exactly the residual splitting-distortion invariant \(\mathfrak D_\tau\).

## NORM-C — Torsor normalization

`YES GEOMETRICALLY`.

The punctured split cone is a \(\mathbf G_m\)-torsor over the projective conic. This removes no source-height distortion by itself.

## NORM-D — Source-lattice normalization

`YES; STRONGEST SUCCESSFUL NORMALIZATION`.

R20 internalizes
\[
V=q^2v,\qquad \ell_M^{\rm sem}=M_0w
\]
as graph coordinates and proves integral equivalence to the R15 source model.

Consequences:

- \(M_0q^2\) is not an independent local modulus;
- primitive source semantics is handled in a source-lattice basis;
- the fixed decimal/contact lattice remains structural;
- source-adapted degree-2 parameterization is available once an integral isotropic basepoint is chosen.

## Residual normalization obstruction

R2 already warned that a *uniform small-height basepoint theorem* would contain most of the moving-height problem.

R3 sharpens this:

\[
\boxed{
\text{moving conic uniformity}
\longrightarrow
\text{source-integral splitting-frame distortion } \mathfrak D_\tau.
}
\]

So the family is reduced from “moving variety + moving lattice + moving local packet + moving weight” to

\[
\boxed{
\mathbf P^1
+
\text{one moving splitting-distortion invariant}
+
\text{one }u\text{-open}
+
\text{one real interval}.
}
\]
