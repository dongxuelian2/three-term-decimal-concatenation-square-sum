# Clearance Function

Use the normalized LOW coordinate
\[
\xi=\frac{h}{Aa}=\frac{\eta}{A}.
\]

Then
\[
\boxed{
\kappa(\xi)=
\min\left(\frac9{10},\frac{\xi}{1+\xi}\right).
}
\]

This is monotone and has transition at
\[
\xi=9.
\]

For an interval
\[
J=[x,R]\subset(0,R_{\rm adm}),
\]
use the local \(\xi\)-coordinate inradius
\[
\rho_\xi(J)=\frac{R-x}{2}.
\]

Then
\[
\boxed{
\mathcal C_\xi(J)
=
\frac{(R-x)^2}{4}
\min\left(\frac9{10},\frac{x}{1+x}\right).
}
\]

Conversion from the R2 intrinsic projective metric to this normalized LOW chart is absorbed into the splitting/chart distortion factor \(\mathfrak D_\tau\).

## R15 dictionary

\[
h=10x_{\rm old}-Aa,
\]
\[
\eta=h/a,
\]
\[
\xi=h/(Aa),
\]
\[
\chi=x_{\rm old}/(Aa)=(1+\xi)/10.
\]

Thus R3's degeneration coordinate is exactly the old LOW contact coordinate, normalized by \(A\); no new boundary variable has been invented.
