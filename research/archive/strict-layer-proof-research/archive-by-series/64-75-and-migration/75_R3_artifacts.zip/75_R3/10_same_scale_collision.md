# Same-Scale Collision

The elementary R3 engine gives
\[
C_{\rm fam}\le\mathfrak D_\tau\mathfrak E_\tau^2.
\]

After optimizing the interval,
\[
\boxed{
\mathfrak D_\tau\mathfrak E_\tau^2
<
\frac{G}{j(10u)}
\mathcal C_\tau^{\max}
}
\tag{COLL}
\]
is the canonical collision.

Using the LOW component alone,
\[
\mathcal C_\tau^{\max}\ge\Psi(R_\tau^{\rm LOW}).
\]

Hence it suffices that
\[
\boxed{
\mathfrak D_\tau\mathfrak E_\tau^2\,j(10u)
<
G\,\Psi(R_\tau^{\rm LOW}).
}
\tag{COLL-LOW}
\]

R14 gives
\[
j(10u)=O((\log G)^2).
\]

## Fixed-class fallback

The proved primitive sector-congruence lemma permits
\[
\mathfrak E_\tau\le u.
\]
With
\[
u=\frac{G+1}{q},
\]
(COLL) becomes
\[
\boxed{
q^2
>
\frac{
\mathfrak D_\tau\,j(10u)\,(G+1)^2
}{
G\,\mathcal C_\tau^{\max}
}.
}
\tag{Q-FALLBACK}
\]

Thus a strategy that artificially freezes one residue class pays an \(u^2\) penalty.

## Exponent audit

Write structurally
\[
q=G^\sigma,\qquad
\mathfrak D_\tau=G^\delta,\qquad
\mathcal C_\tau^{\max}=G^{-\lambda}
\]
up to subpolynomial factors.

For the fixed-class fallback
\[
\mathfrak E_\tau=u\asymp G^{1-\sigma},
\]
the left exponent is
\[
\gamma=\delta+2-2\sigma,
\]
while the right exponent is
\[
\gamma'=1-\lambda.
\]

Therefore
\[
\boxed{
\gamma'-\gamma
=
2\sigma-1-\delta-\lambda.
}
\]

This proves that the one-residue implementation is structurally unsuitable in the small-\(q\)/large-\(u\) regime unless splitting distortion and clearance are extraordinarily favorable.

For an improved allowed-class lemma
\[
\mathfrak E_\tau=G^\epsilon,
\]
the gap becomes
\[
\boxed{
\gamma'-\gamma
=
1-\lambda-\delta-2\epsilon.
}
\]

This is why the correct R4 local target is the **union of allowed unit classes**, not a fixed residue.
