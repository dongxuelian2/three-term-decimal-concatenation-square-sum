# USSPAL — R3 Normalized Exact Statement

Scope throughout: actual \(q>1\) rationally split fibres.

Let \(C_\tau\) be the projective source conic of the R20 semantic integral model and let
\(U_{f,\tau}^{\rm proj}\) be the actual admissible finite projective source open.
For a compact real interval
\[
J\Subset\mathscr I_{\eta,\tau},
\]
let \(\rho_\tau(J)>0\) be a chosen projective inradius.

USSPAL asks for a primitive source ray \(x_0\) such that
\[
[x_0]_\infty\in J,\qquad [x_0]_f\in U_{f,\tau}^{\rm proj},
\]
and
\[
a_0(x_0)\le C_{\rm fam}(\tau,U_f)\rho_\tau(J)^{-2}.
\]

R14 then supplies the radial multiplier whenever
\[
\frac{G}{a_0(x_0)}\kappa_\tau(J)>j(10u).
\]

Hence the sufficient collision is
\[
\boxed{
C_{\rm fam}\rho^{-2}<\frac{G\kappa}{j(10u)}.
}
\]

## R3 normalized LOW coordinate

Put
\[
h=10x-Aa,\qquad
\eta=\frac ha,\qquad
\xi:=\frac{\eta}{A}=\frac{h}{Aa}.
\]

Then
\[
\chi=\frac{x}{Aa}=\frac{1+\xi}{10},
\]
and the exact R14/R15 clearance becomes
\[
\boxed{
\kappa(\xi)=
\min\!\left(\frac9{10},\frac{\xi}{1+\xi}\right).
}
\]

Thus the parameter \(A=2u+1\) is removed from the *shape* of the clearance function; it survives only in the map from the original projective coordinate to \(\xi\).

No claim of a uniform lower bound on \(\xi\) is made.
