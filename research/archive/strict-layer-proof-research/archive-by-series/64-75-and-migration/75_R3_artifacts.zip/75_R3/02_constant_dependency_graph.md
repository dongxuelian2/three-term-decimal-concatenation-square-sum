# \(C_{\rm fam}\) Dependency Graph

## 1. MC-001 raw theorem dependencies

MC-001 is fixed-data. Its verified statement does not expose a family-uniform numerical constant with sufficient dependence for the power-ten family.

Therefore the following are `UNIFORMITY GAP` if MC-001 is used directly:

```text
FORM/DISCRIMINANT_DEPENDENCE=UNIFORMITY_GAP
LATTICE/COVOLUME_DEPENDENCE=UNIFORMITY_GAP
LOCAL_LEVEL_DEPENDENCE=UNIFORMITY_GAP
WEIGHT_DERIVATIVE_DEPENDENCE=UNIFORMITY_GAP
THEOREM_THRESHOLD_DEPENDENCE=UNIFORMITY_GAP
SOURCE_HEIGHT_NORMALIZATION_DEPENDENCE=UNIFORMITY_GAP
```

## 2. R3 source-adapted replacement

Take a source-integral split chart
\[
\Phi_{\tau,p}:\mathbf P^1\longrightarrow C_\tau
\]
coming from an integral isotropic source basepoint \(p\), using R20
\[
F_{\rm sem}(s,t)=Q_\Gamma(y)p-\mathcal B(p,y)y.
\]

Define:

- \(\mathcal A_{\tau,\Phi}\): coefficient \(L^1\)-norm of the binary quadratic form
  \(a\circ F_{\rm sem}(s,t)\);
- \(\Lambda_{\tau,\Phi}(J)\): projective chart distortion, normalized so that if
  \(\delta_\Phi(J)\) is the pullback affine interval length then
  \[
  \delta_\Phi(J)^{-1}\le \Lambda_{\tau,\Phi}(J)\rho_\tau(J)^{-1};
  \]
- \(m_{\tau,\Phi}(U_f)\): an effective parameter-space level for one nonempty
  unimodular projective residue class in \(\Phi^{-1}(U_f)\);
- \(C_{\rm ch}\): fixed bounded-slope affine-chart constant.

The R3 Primitive Sector-Congruence Lemma gives
\[
H(s,t)\le C_{\rm ch}\,m_{\tau,\Phi}\,\delta_\Phi(J)^{-1}.
\]

Since \(F_{\rm sem}\) is quadratic,
\[
a(F_{\rm sem}(s,t))
\le
\mathcal A_{\tau,\Phi}H(s,t)^2.
\]

Primitive content extraction only decreases source height. Therefore
\[
\boxed{
C_{\rm fam}
\le
C_{\rm ch}^2\,
\mathcal A_{\tau,\Phi}\,
\Lambda_{\tau,\Phi}^2\,
m_{\tau,\Phi}(U_f)^2.
}
\tag{C-FAM-PHI}
\]

## 3. Source-level versus chart-level modulus

The genuine source projective finite condition has moving modulus \(u\) (a unit/open condition), not \(M_0q^2\).

Any factor in \(m_{\tau,\Phi}\) beyond the source \(u\)-open is a *chart/saturation/bad-reduction factor of the chosen trivialization*, not a resurrected source packet obstruction.

Define the normalized splitting-distortion invariant
\[
\boxed{
\mathfrak D_\tau
:=
\inf_\Phi
C_{\rm ch}^2
\mathcal A_{\tau,\Phi}
\Lambda_{\tau,\Phi}^2
\left(\frac{m_{\tau,\Phi}}{\mathfrak E_\tau}\right)^2,
}
\]
where \(\mathfrak E_\tau\) is the effective cost of choosing among the allowed \(u\)-classes.
The fixed-class fallback gives
\[
\mathfrak E_\tau\le u.
\]

Then the elementary engine has the canonical bound
\[
\boxed{
C_{\rm fam}\le \mathfrak D_\tau\,\mathfrak E_\tau^2.
}
\tag{C-FAM}
\]

This is the R3 replacement for the opaque MC-001 constant.

## 4. What disappeared

Not independent factors anymore:

- \(M_0q^2\) packet modulus;
- conductor density;
- bad-reduction ruling orbit count;
- primitive extraction factor;
- an affine-cone Brauer correction.

What remains genuinely moving:

1. source-integral splitting/trivialization height;
2. inverse projective chart distortion;
3. chart saturation at the actual \(u\)-open;
4. the allowed-class approximation cost \(\mathfrak E_\tau\);
5. the real sector width/degeneration.
