# Local Level Compression

## True source-level finite data

After R14 and R20:

1. \(M_0q^2\) is a model-change cokernel, not an independent projective local condition.
2. the R14 primitive-mod-\(u\) **obstruction** is retired, but the desired source ray still belongs to a nonempty *unit/open* subset modulo \(u\);
3. the fixed decimal/contact factor is part of the source integral model;
4. \(10u\) belongs to the later radial multiplier sieve, not to the projective USSPAL level.

Therefore

```text
SOURCE_PROJECTIVE_MOVING_LEVEL=u-open
M0q2_AS_USSPAL_LEVEL=FALSE
RADIAL_10u_AS_USSPAL_LEVEL=FALSE
FIXED_DECIMAL_10=SOURCE_LATTICE_STRUCTURE
```

The correct finite set is a union of allowed classes, not one prescribed worst class.

## Parameter-space level

For a chosen split chart \(\Phi\), define
\[
m_{\tau,\Phi}(U_f)
\]
as the least effective modulus needed to exhibit one nonempty unimodular projective class in the pullback of the source \(u\)-open.

A chart may have extra bad-reduction/saturation factors. Such factors belong to the splitting-distortion audit and must not be relabelled as \(M_0q^2\) arithmetic.

## Fallback and target

- fixed-class fallback:
  \[
  \mathfrak E_\tau\le u;
  \]
- desired allowed-class improvement:
  \[
  \mathfrak E_\tau=o(u),
  \]
  ideally polylogarithmic in \(u\).

The latter is now an elementary \(\mathbf P^1\) avoidance problem, not a ternary-cone counting theorem.
