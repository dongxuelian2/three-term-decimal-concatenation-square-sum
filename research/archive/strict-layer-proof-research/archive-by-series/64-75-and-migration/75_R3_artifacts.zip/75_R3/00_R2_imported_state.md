# 75-R3 — Imported R2 State

## Frozen input

```text
R2_TERMINAL_VERDICT=SOURCE_HEIGHT_BRIDGE_REDUCED
P2_M_LEVEL=M5
P2_M5_BASIS=M5-B_N2_REDUCED_TO_USSPAL
P2_G_LEVEL=G2
MC-001=BRIDGE_REQUIRED
N2_STATUS=REDUCED_TO_USSPAL
N1_STATUS=EXACT_SPLIT_CRITERION_PROVED; FAMILY_CLASSIFICATION_OPEN
```

R2's exact bridge target is

\[
a_0(x_0)\le C_{\rm fam}(\tau,U_f)\rho_\tau(J)^{-2},
\]

followed by

\[
C_{\rm fam}(\tau,U_f)\rho_\tau(J)^{-2}
<
\frac{G\kappa_\tau(J)}{j(10u)}.
\]

These are two different logical layers:

1. primitive-ray existence/height;
2. radial clearance.

## Frozen retirements

The following do not re-enter R3 as independent gates:

- \(M_0q^2\) finite source packet;
- conductor/ruling orbit classification;
- finite-module Spin transitivity;
- primitive-mod-\(u\) nonemptiness;
- R15–R20 packet machinery;
- Hermitian/unit-orbit refinements.

## Primary provenance

- `12_R2_terminal_verdict.md`
- `09_height_bridge_analysis.md`
- `MC-001_Huang_Ternary_Cone_Primitive_Local_Counting.md`
- `J2-65-R14-Adelic-Primitive-Shell-Report.md`
- `J2-65-R20-Semantic-Conductor-Ruling-Report.md`
