# Generality Map

## G3 candidates
- semantic dilatation/affine-blowup formalism as a general integral-model tool;
- multiplicative-group / torus language for powers of ten;
- possibly a general source-cone \(\mathbb G_m\)-torsor architecture if ternary/rank structure persists across J.

## G2 tools
- Cao–Xu toric SA for a family of split punctured cones;
- CT–Xu homogeneous-space BM framework;
- O'Dorney integral conic + quaternion-order + invariant-lattice package;
- Ferrand conductor-square patching;
- full-rank source-lattice primitive scaling.

## G1 objects
- exact q-free coefficients \(D_0,F_0,N_0\);
- determinant-\((-2)\) Hermitian collapse;
- R17 Gaussian composition identity;
- mixed ruling defect \(Z/\gcd(M_0,800)Z\).

## G0 only
- any future single bad-prime calculation not shown to control a family.

## General-J veto from 65-R1
Pre-J2, the proved relation is \(u_0\mid G+1\), not \(u\mid G+1\). Any claimed G2/G3 theorem written using \(q=(G+1)/u\) before re-specialization fails provenance.
