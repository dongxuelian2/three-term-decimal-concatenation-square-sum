# TC_D_01 — Cao–Xu Strong Approximation for Toric Varieties


## SOURCE
Y. Cao, F. Xu, *Strong Approximation with Brauer–Manin Obstruction for Toric Varieties*, Ann. Inst. Fourier 68 (2018), 1879–1908.

## EXACT_LOCATION
Theorem 1.2, p.1881; Corollary 1.3.

## OBJECT_CLASS
Smooth toric varieties over number fields.

## NORMALIZED_STATEMENT
Any smooth toric variety over a number field satisfies strong approximation with Brauer–Manin obstruction off all archimedean places.

## OUR_OBJECT_MAPPING
On a split nondegenerate ternary cone,
\[
W^\circ=(Q_0=0)\setminus\{0\}
\]
is a \(\mathbb G_m\)-torsor over the conic and a smooth toric variety (also explicitly noted by Huang).

## HYPOTHESIS_LEDGER
- number field: PASS;
- smooth toric generic variety: PASS for split punctured nondegenerate cone;
- semantic integral model represented by local opens: plausible/PASS after choosing source-lattice coordinates, but must be written;
- BM-compatible adelic datum: UNKNOWN on the actual gate.

## BAD_PRIME_AUDIT
Strong approximation is a generic-variety statement; bad integral primes are encoded by chosen local neighborhoods, not erased.

## INTEGRALITY_AUDIT
Can encode finitely many congruence/source conditions via finite local opens, but does not itself certify the R20 source model. R20 supplies that model.

## ARCHIMEDEAN_AUDIT
FAIL for the full digit shell. The paper explicitly says its proof cannot force a rational point into prescribed connected components at real places; the theorem is off infinity.

## SEMANTIC_PRESERVATION
Finite source semantics can be preserved after R20 model identification. Moving radial digit height is not preserved.

## MISSING_BRIDGES
B1 explicit source-lattice finite-adelic open model;
B2 prove BM compatibility/non-obstruction for the exact fibre;
B3 **Archimedean moving-height bridge**.

## PAYOFF
Could replace ad hoc finite congruence approximation on a whole G2 family and provide a standard BM framework; does not close G2 without B3.

## M_LEVEL
M3 on the full target; high-probability M4 after explicit finite semantic mapping, but still missing the height bridge.
## G_LEVEL
G2, potentially G3 if the general-J cone family persists.
## VERDICT
IMPORT_AFTER_BRIDGE.
