# TC_A_02 — Colliot-Thélène–Xu Theorem 6.3


## SOURCE
Colliot-Thélène–Xu 2009, same paper.

## EXACT_LOCATION
Theorem 6.3, §6.

## OBJECT_CLASS
Representation of one quadratic form by another in codimension \(m-n=2\); norm-one torus stabilizer.

## NORMALIZED_STATEMENT
For the representation variety with \(m-n=2\), let \(d=-\disc(f)\disc(g)\), \(K=k[t]/(t^2-d)\), \(T=R^1_{K/k}\mathbb G_m\). Given local integral points, the rational variety has a point; the quotient Brauer group is trivial if \(d\) is square and of order two otherwise, with the relevant torsor/Brauer class controlling integral representation.

## OBJECT_MAPPING
This is a close standard analogue of R8–R9’s norm-torus/Brauer compression.

## HYPOTHESIS_LEDGER
- Exact quadratic-representation variety: FAIL/UNKNOWN for our homogeneous zero cone.
- Norm-one torus pattern: PASS structurally.
- Integral source model: not supplied by theorem.
- Nonzero represented form in the standard setup vs \(Q=0\): structural mismatch.

## BAD_PRIME_AUDIT
Handled through local integral data, but no automatic source-row preservation.

## SEMANTIC_PRESERVATION
FAIL for direct use: the theorem explains the norm/Brauer layer but not radial source reconstruction.

## MISSING_BRIDGES
An exact isomorphism from the source problem to the theorem’s representation variety would be required; current artifacts do not provide it.

## PAYOFF
Explains that R8/R9 sit in a mature norm-torus/Brauer ecosystem; does not close G1 or G2.

## M_LEVEL
M1–M2.
## G_LEVEL
G2 as a theory family.
## VERDICT
LITERATURE_ONLY.
