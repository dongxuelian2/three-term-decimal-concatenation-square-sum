# TC_D_02 — Huang Quantitative Strong Approximation on Ternary Cones


## SOURCE
Z. Huang, *Quantitative strong approximation for ternary quadratic forms III*, arXiv:2512.13091v1 (submitted 2025).

## EXACT_LOCATION
Theorem 1.3; Example 1.4; §1 equations (1.3)–(1.6).

## OBJECT_CLASS
Primitive integral points on punctured affine cones \(W^\circ=(F=0)\setminus\{0\}\), with congruence class and smooth real weight.

## NORMALIZED_STATEMENT
The paper aims at an asymptotic formula for primitive integral zeroes in a fixed congruence class with Archimedean weight. It defines \(\Omega=8L\Delta\), then Theorem 1.3 is printed with the assumption \(\Omega\mid L\).

## HYPOTHESIS_LEDGER
- nondegenerate indefinite integral ternary form: MATCHES our generic split shape;
- primitive congruence plus real weight: EXCELLENT MATCH;
- printed \(\Omega\mid L\) with \(\Omega=8L\Delta\): **FAIL AS WRITTEN** for nonzero discriminant.

## BAD_PRIME_AUDIT
The paper explicitly tries to absorb all bad primes into \(\Omega\), but the current theorem text is internally inconsistent.

## ARCHIMEDEAN_AUDIT
Conceptually excellent: smooth weights can model expanding sectors/shells after scaling.

## SEMANTIC_PRESERVATION
Would still require source-lattice coordinates and parameter-uniformity in \(G,K,u\).

## CRITICAL WARNING
Example 1.4 shows a primitive positive congruence problem where a real sign and finite congruence interact by reciprocity, killing global primitive points. Therefore “projective weak approximation + primitive separately” is not a universal theorem.

## MISSING_BRIDGES
B0 first obtain a corrected/clarified theorem statement;
B1 source-lattice coordinate map;
B2 uniformity in moving coefficients/modulus/height.

## PAYOFF
If corrected and uniform enough, this is the closest external analytic theorem family to G2. In current v1 it is not formally importable.

## M_LEVEL
M0 source existence verified, but applicability FAIL at M2 due theorem-text hypothesis.
## G_LEVEL
G2.
## VERDICT
REJECT_AS_WRITTEN / WATCH_FOR_CORRECTION.
