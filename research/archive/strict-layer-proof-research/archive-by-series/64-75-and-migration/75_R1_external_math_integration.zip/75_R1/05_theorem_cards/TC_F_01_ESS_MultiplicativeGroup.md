# TC_F_01 — Evertse–Schlickewei–Schmidt Multiplicative-Group Equation


## SOURCE
J.-H. Evertse, H. P. Schlickewei, W. M. Schmidt, *Linear equations in variables which lie in a multiplicative group*, Ann. Math. 155 (2002), 807–836.

## EXACT_LOCATION
Main theorem / publisher abstract, pp.807–836.

## OBJECT_CLASS
Linear equations with variables in a finite-rank multiplicative subgroup \(\Gamma\subset(K^\times)^n\).

## NORMALIZED_STATEMENT
For characteristic-zero \(K\), finite-rank \(\Gamma\), the number of nondegenerate solutions
\[
a_1x_1+\cdots+a_nx_n=1,\qquad x\in\Gamma,
\]
admits an explicit bound depending only on \(n\) and the rank of \(\Gamma\).

## OUR_OBJECT_MAPPING
\((G,K)=(10^g,10^k)\) lies in a rank-2 multiplicative group. However no exact surviving source equation has been reduced to the theorem’s linear form.

## HYPOTHESIS_LEDGER
- finite-rank group: PASS;
- exact linear equation in group variables: FAIL/NOT CONSTRUCTED;
- nondegenerate subsums: UNKNOWN;
- source reconstruction: absent.

## SEMANTIC_PRESERVATION
Not reached.

## PAYOFF
Potentially G3 once an exact toric/linear incidence is constructed; currently it cannot be invoked to deduce finiteness of the concatenation problem.

## M_LEVEL
M1.
## G_LEVEL
G3.
## VERDICT
GENERAL_TOOL_RESERVE.
