# TC_A_01 — Colliot-Thélène–Xu Theorem 3.7


## SOURCE
J.-L. Colliot-Thélène, F. Xu, *Brauer–Manin obstruction for integral points of homogeneous spaces and representation by integral quadratic forms*, Compositio Math. 145 (2009), 309–363; arXiv:0712.1957.

## EXACT_LOCATION
Theorem 3.7, §3.

## OBJECT_CLASS
Integral models of homogeneous spaces \(X=G/H\).

## NORMALIZED_STATEMENT
Let \(k\) be a number field, \(S\) contain the archimedean places, \(G/k\) semisimple simply connected, \(H\subset G\) connected, and \(\mathbf X/O_S\) a separated finite-type model with generic fibre \(G/H\). Under the theorem’s isotropy/strong-approximation hypotheses, Brauer–Manin compatible adelic integral data can be approximated by global \(S\)-integral points.

## HYPOTHESES
- H1 number field / S-integers;
- H2 \(G\) semisimple simply connected;
- H3 \(H\) connected;
- H4 generic fibre exactly \(G/H\);
- H5 noncompact/isotropic factor at the omitted place(s);
- H6 adelic datum orthogonal to relevant Brauer classes.

## OUR_OBJECT_MAPPING
Candidate \(G=\operatorname{Spin}(Q_0)\), \(X\) an orbit/homogeneous space related to the punctured quadric.

## HYPOTHESIS_LEDGER
- H1 PASS.
- H2 PASS on split nondegenerate rational ternary quadratic space at generic-fibre level.
- H3 UNKNOWN until the precise stabilizer/orbit is fixed.
- H4 UNKNOWN for the **semantic integral model**; ambient generic cone is not automatically the required \(G/H\) model.
- H5 likely PASS on indefinite split real fibre, but branch-by-branch proof required.
- H6 UNKNOWN; BM class must be evaluated.

## BAD_PRIME_AUDIT
The theorem is global/adelic but does not make a bad integral model smooth. M0 degeneration and primes 2,5 remain part of the chosen local integral opens/model.

## INTEGRALITY_AUDIT
Integral model is an input. Therefore it cannot justify replacing \(\mathscr X_{\rm sem}\) by the raw ambient \(Q_0\)-model.

## ARCHIMEDEAN_AUDIT
Approximation can depend on omitted-place setup, but this theorem does not by itself solve a moving bounded decimal radial shell.

## SEMANTIC_PRESERVATION_AUDIT
Ambient use: FAIL/M3 ceiling.
Semantic-model use: potentially PASS after exact model/homogeneous-space identification.

## MISSING_BRIDGES
B1 identify the exact punctured source-semantic object as the required \(G/H\);
B2 calculate stabilizer/Brauer data;
B3 translate moving digit-height shell to allowable local/height data.

## PAYOFF
Standardizes ambient Spin/BM arguments and prevents false finite-orbit transitivity claims.

## M_LEVEL
M2–M3 current.
## G_LEVEL
G2.
## VERDICT
IMPORT_AFTER_BRIDGE.
