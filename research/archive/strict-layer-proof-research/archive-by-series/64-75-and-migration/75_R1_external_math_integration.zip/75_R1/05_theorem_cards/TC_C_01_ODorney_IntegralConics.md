# TC_C_01 — O’Dorney Integral Conic / Quaternion-Order Framework


## SOURCE
E. M. O'Dorney, *Diophantine approximation on conics*, Proc. Amer. Math. Soc. 151 (2023), 1889–1905; arXiv:2205.12829v2.

## EXACT_LOCATION
Introduction/main theorem; proof framework via Gross–Lucianovic correspondence and invariant lattices (paper §§3–5).

## OBJECT_CLASS
Isotropic integral ternary conics, quaternionic subrings of \(M_2(\mathbb Q)\)/\(M_2(\mathbb Z)\), invariant lattices, integral height structures.

## NORMALIZED_STATEMENT
Rationally split conics are projectively \(\mathbb P^1\), but their integral Diophantine behavior depends on the integral ternary form. O'Dorney encodes an integral conic by a quaternionic subring and classifies invariant lattices in the two-dimensional representation, reducing the approximation spectra to special integral models \(XZ=nY^2\).

## OBJECT_MAPPING
Our pair \((Q_0,\Gamma_{\rm src})\) should be regarded as an **integral conic plus lattice/order datum**, not merely a rational Veronese.

## HYPOTHESIS_LEDGER
- isotropic ternary integral form: conditional PASS on split fibres;
- exact invariant-lattice identification for \(\Gamma_{\rm src}\): UNKNOWN but concrete;
- theorem target is approximation spectrum, not our decimal shell: mismatch.

## SEMANTIC_PRESERVATION
Potentially high: the framework explicitly remembers integral lattice data. It still needs a source-to-invariant-lattice map.

## PAYOFF
Best standard-language recovery for the R12/R17 lesson “rational conic equivalence does not imply integral source equivalence”.

## M_LEVEL
M2–M3.
## G_LEVEL
G2.
## VERDICT
GENERAL_TOOL_RESERVE / IMPORT_AFTER_BRIDGE.
