# TC_B_02 — Ferrand Conductor / Descent / Pinching


## SOURCE
D. Ferrand, *Conducteur, descente et pincement*, Bull. Soc. Math. France 131 (2003), 553–585.

## EXACT_LOCATION
Main algebraic result §2.2; geometric existence of pinching §5.4.

## OBJECT_CLASS
Conductor squares, fiber products of rings, pushouts/pinching of schemes, descent of flat modules.

## NORMALIZED_STATEMENT
Ferrand develops conductor-controlled fiber-product rings and dual pushouts of schemes. The relevant module categories become equivalent on flat modules; under mild affine-neighborhood hypotheses the pinching pushout exists.

## OBJECT_MAPPING
Potential standard language for comparing a non-normal/saturated integral model with its normalization and conductor locus.

## HYPOTHESIS_LEDGER
- an actual normalization/conductor square: UNKNOWN for the exact R17–R20 coordinate rings unless constructed;
- finite morphism / conductor setup: plausible but not automatically identical to q² order inclusion;
- flatness requirements: UNKNOWN.

## SEMANTIC_PRESERVATION
Not automatic. It can formalize a bridge only after the source coordinate rings are put into a conductor square.

## PAYOFF
Useful reserve if 75-R2/85 must compare source model, normalization and bad fibres globally; does not replace R20’s explicit mixed-ruling calculation.

## M_LEVEL
M1–M2 current.
## G_LEVEL
G2/G3 formal.
## VERDICT
GENERAL_TOOL_RESERVE.
