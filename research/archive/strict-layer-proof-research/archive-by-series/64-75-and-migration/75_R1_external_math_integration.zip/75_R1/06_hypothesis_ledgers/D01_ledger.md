# Cao-Xu — Hypothesis Ledger

- smooth toric W°=PASS split
- BM local datum=UNKNOWN
- finite source open=BRIDGE
- real component control=FAIL
- moving height=FAIL
