# O'Dorney — Hypothesis Ledger

- integral ternary conic=PASS conditional split
- invariant source lattice map=UNKNOWN
- digit shell target=NO
