# Bhargava — Hypothesis Ledger

- representation match=UNKNOWN
- discriminant match=UNKNOWN
- source reconstruction=FAIL
