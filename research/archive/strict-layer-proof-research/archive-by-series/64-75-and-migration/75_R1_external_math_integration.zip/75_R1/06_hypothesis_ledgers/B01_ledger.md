# MRR dilatation — Hypothesis Ledger

- principal divisor=PASS
- center encoding=ROUTINE
- generic fibre=PASS
- source Z-points=PASS via R20
- bad-fibre smoothness=NOT CLAIMED
