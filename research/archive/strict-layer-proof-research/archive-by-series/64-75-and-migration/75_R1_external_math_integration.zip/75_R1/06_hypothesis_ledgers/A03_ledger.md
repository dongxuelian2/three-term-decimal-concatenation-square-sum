# Kneser/PR — Hypothesis Ledger

- Spin SC=PASS
- noncompact split place=PASS conditional
- group-to-source orbit=FAIL
- height=FAIL
