# Huang — Hypothesis Ledger

- form match=PASS
- primitive+congruence+weight match=PASS
- Omega=8LDelta and Omega
- L=FAIL AS WRITTEN
- uniformity=UNKNOWN
