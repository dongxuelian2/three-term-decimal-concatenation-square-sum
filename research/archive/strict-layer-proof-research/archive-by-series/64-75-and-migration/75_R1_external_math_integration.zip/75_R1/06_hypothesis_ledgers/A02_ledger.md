# CTX 6.3 — Hypothesis Ledger

- norm torus pattern=PASS
- exact representation variety=FAIL/UNKNOWN
- zero-cone match=FAIL
- source semantics=MISSING
