# Ferrand — Hypothesis Ledger

- conductor square=UNKNOWN
- finite normalization=UNKNOWN
- flat module patching=CONDITIONAL
- source semantics=UNKNOWN
