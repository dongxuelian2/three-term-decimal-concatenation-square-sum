# CTX 3.7 — Hypothesis Ledger

- G/H exact model=UNKNOWN
- G semisimple SC=PASS on split Spin
- H connected=UNKNOWN
- SA isotropy=LIKELY PASS split real
- BM datum=UNKNOWN
- source model=MISSING
- digit height=MISSING
