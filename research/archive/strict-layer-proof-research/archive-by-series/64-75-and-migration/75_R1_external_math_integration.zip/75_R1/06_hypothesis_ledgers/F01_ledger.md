# ESS — Hypothesis Ledger

- finite-rank power group=PASS
- linear equation=FAIL/NOT BUILT
- nondegenerate subsums=UNKNOWN
- source semantics=NOT REACHED
