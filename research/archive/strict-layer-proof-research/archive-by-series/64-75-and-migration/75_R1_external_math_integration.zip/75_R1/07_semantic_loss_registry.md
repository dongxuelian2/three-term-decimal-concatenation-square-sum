# Semantic-Loss Registry — Applicability Veto List

## SL1 Projective radial loss
Compression to a point on \(C\simeq\mathbb P^1\) removes the integer radial multiplier.
**Veto:** any projective weak-approximation theorem is M4 only if radial primitive/height reconstruction is separately proved.

## SL2 Norm/Brauer loss
The Gaussian norm/Brauer class records rational solubility but forgets source lattice and decimal incidence.
**Veto:** norm-solubility never implies original concatenation solution.

## SL3 Gaussian witness noncanonicity
Clearing denominators in a rational Gaussian witness introduces a norm-one torsor choice.
**Veto:** integral Gaussian coordinates are not source coordinates.

## SL4 Hermitian quotient loss
Passing to \(GL_2(\mathbb Z[i])\)-class forgets the prescribed diagonal/source ray.
**Veto:** class number one is not source automaticity.

## SL5 Field/order loss
Replacing \(\sqrt D=q^2\sqrt{D_0}\) at field level forgets the order inclusion of index \(q^2\).
**Veto:** rational isomorphism does not imply integral isomorphism.

## SL6 Ambient q-free quadric loss
Raw \(Q_0=0\) omits semantic source rows.
**Repair in R20:** semantic dilatation and exact integral source-model isomorphism.

## SL7 Rational parameterization loss
A rational \(\mathbb P^1\to C\) has denominators/content.
**Repair:** source-basis degree-2 formula after an integral source basepoint; height still survives.

## SL8 Smooth-generic/bad-fibre loss
Spin transitivity over smooth finite quadratic modules does not apply at \(M_0\), where \(Q_0\) degenerates.
**Repair in R20:** mixed-thickening computation + model change; Spin route retired.

## SL9 Finite-adelic/Archimedean-height loss
Strong approximation off infinity can satisfy finite local opens while saying nothing about the prescribed real digit sector/radial interval.
**Veto:** Cao–Xu toric SA is M3 for full digit shell without a real-height bridge.

## SL10 Primitive-real-finite reciprocity
Huang Example 1.4 shows primitive + positivity + congruence can be globally incompatible.
**Veto:** do not multiply independent local/projective existence claims into an affine primitive existence theorem.

## SL11 “Power-ten torus” loss
Embedding \(10^g,10^k\) into a torus does not create an algebraic incidence equation.
**Veto:** S-unit/Mordell–Lang results remain M1 until the exact source incidence variety is produced.
