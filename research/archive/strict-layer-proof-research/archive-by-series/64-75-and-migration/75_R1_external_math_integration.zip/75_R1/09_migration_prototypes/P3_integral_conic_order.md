# PROTOTYPE P3 — Integral Conic × Quaternion Order × Invariant Lattice

## TARGET_GATE
Standardize \((Q_0,\Gamma_{\rm src})\) and source-adapted Veronese without semantic loss.

## EXTERNAL_THEOREM_STACK
TC_C_01 O'Dorney; Clifford/quaternion correspondence as background.

## ADAPTATION_MAP
Integral ternary conic ↔ split quaternionic order/subring; source lattice ↔ invariant lattice in the 2D representation.

## REQUIRED_BRIDGES
Construct the exact quaternion order associated with \(Q_0\) and identify the R20 source lattice among its invariant lattices.

## BRIDGE_DIFFICULTY
MODERATE.

## SEMANTIC CHECK
Promising because the external framework explicitly carries integral lattice data.

## GENERALITY
G2.

## EXPECTED PAYOFF
Could replace several ad hoc “source-adapted Veronese / lattice content” arguments by one canonical integral-conic package.

## VERDICT
GENERAL_TOOL_RESERVE.
