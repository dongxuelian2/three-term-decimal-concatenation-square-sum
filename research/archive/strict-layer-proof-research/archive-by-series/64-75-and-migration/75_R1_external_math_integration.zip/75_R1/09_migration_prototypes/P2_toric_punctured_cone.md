# PROTOTYPE P2 — Punctured Source Cone × Toric Strong Approximation

## TARGET_GATE
G2 split-fibre primitive digit-height incidence.

## EXTERNAL_THEOREM_STACK
TC_D_01 Cao–Xu + TC_C_01 O'Dorney + TC_B_01 semantic dilatation as integral-model interface.

## ADAPTATION_MAP
- generic split source cone \(W^\circ=(Q_0=0)\setminus\{0\}\);
- \(W^\circ\to C\) is a \(\mathbb G_m\)-torsor;
- choose a source-lattice basis so primitive source points are integral points of the punctured integral model;
- finite source congruences become finite local open conditions.

## REQUIRED_BRIDGES
B1 explicit source integral model/local-open dictionary — MODERATE but largely supplied by R20.
B2 BM compatibility/nonvanishing for the actual local packet — MODERATE.
B3 moving Archimedean radial/digit-height theorem, simultaneous with primitive finite data — MAJOR.

## BRIDGE_DIFFICULTY
B3 MAJOR, but smaller and better isolated than the old R19 “one giant Spin theorem”.

## SEMANTIC CHECK
Finite source semantics can be exact; radial height remains the only major semantic gap.

## GENERALITY
G2; may become G3 if the same torsor architecture survives general J.

## EXPECTED PAYOFF
Rewrites the q>1 split-fibre problem as a standard toric/BM finite layer plus one explicit height bridge.

## VERDICT
IMPORT_AFTER_BRIDGE.
