# Rejected External Routes

## REJECT_AMBIENT_ONLY
- raw Spin strong approximation used directly on \(Q_0\);
- homogeneous-space integral points without identifying \(\mathscr X_{\rm sem}\).

Reason: ambient-to-source leap.

## REJECT_BAD_PRIME_SMOOTHNESS
Any finite-ring transitivity theorem requiring nondegenerate smooth rank-3 quadratic module at \(M_0\).

Reason: R19 proves
\[
Q_0\equiv(R-20uV)(R+20uV)\pmod{M_0}.
\]

## REJECT_NONINTEGRAL
Rational Veronese / \(\mathbb P^1\) parameterization as a substitute for source integral parameterization.

Reason: denominators, content, source lattice.

## REJECT_LOSES_PRIMITIVITY
Projective approximation theorem used to infer a primitive affine shell point.

Reason: radial/content loss; Huang Example 1.4 supplies a concrete reciprocity warning.

## REJECT_NO_ARCHIMEDEAN_CONTROL
Cao–Xu Theorem 1.2 used as if it controlled digit sector/radial height.

Reason: theorem is off infinity and paper explicitly notes lack of prescribed real component control.

## REJECT_THEOREM_TEXT_INCONSISTENT
Huang Theorem 1.3 v1 as a formal citation.

Reason: paper defines \(\Omega=8L\Delta\), then assumes \(\Omega\mid L\); for nondegenerate integer \(\Delta\neq0\), literal divisibility is impossible.

## REJECT_BRIDGE_AS_HARD_AS_ORIGINAL
ESS/S-unit/Laurent invoked before an exact algebraic torus incidence is constructed.

Reason: producing that incidence is currently a major bridge and may be equivalent to the original elimination problem.

## REJECT_COMPOSITION_WITHOUT_SOURCE_MAP
Bhargava/Gauss/Hermitian composition invoked to turn R17 ambient Gaussian identity into source-lattice composition.

Reason: R17 explicitly proves only a formal Euclidean similitude, not source preservation.

## RETIRED_INTERNAL_ROUTES
Hermitian-continuant, Pell/infrastructure, finite packet/Spin ruling orbit and primitive-mod-u routes remain retired unless an external theorem explicitly repairs the recorded semantic loss.
