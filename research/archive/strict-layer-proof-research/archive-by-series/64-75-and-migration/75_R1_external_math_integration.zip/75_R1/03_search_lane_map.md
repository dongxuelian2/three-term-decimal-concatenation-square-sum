# Literature Lane Map — Broad Reconnaissance

## Lane A — Quadrics / Spin / homogeneous spaces

Retained theorem families:
1. Kneser–Platonov strong approximation for semisimple simply connected groups (canonical source: Platonov–Rapinchuk, §7.4, Thm. 7.12, p. 427).
2. Colliot-Thélène–Xu 2009, Thm. 3.7: integral points on homogeneous spaces \(G/H\), BM obstruction, connected stabilizer.
3. Colliot-Thélène–Xu 2009, Thm. 6.1: quadratic-form representation with \(m-n\ge3\).
4. Colliot-Thélène–Xu 2009, Thm. 6.3: codimension-two representation; norm-one torus and order-two Brauer class.
5. Spinor genus / integral quadratic lattice representation as classical background.

Applicability verdict:
- excellent standard language for ambient arithmetic;
- current rank-3 homogeneous **zero cone** is not literally the nonzero affine quadric \(f=a\) in CT–Xu §6;
- source semantics and moving height remain outside the theorem.
- R19 smooth finite Spin orbit route is not revived.

## Lane B — integral models / bad reduction / conductor

Retained:
1. Mayeux–Richarz–Romagny: dilatations / affine blow-ups; Definition 2.1, Lemmas 2.3–2.4, generic-complement isomorphism and smoothness criteria.
2. Ferrand 2003: conductor, descent, pinching; flat-module patching (§2.2), existence of pushouts (§5.4).
3. normalization/conductor-square formalism.
4. Néron blowups of group schemes where group structure is genuinely present.

Applicability:
- R20's \(V=q^2v,\ \ell=M_0w\) is standard affine-blowup/dilatation language.
- This can be imported now for the model-change layer.
- It does not automatically prove mixed-ruling arithmetic or source reconstruction; R20 supplies that internal bridge.
- “normalization” and “dilatation” must not be conflated.

## Lane C — integral parametrization / saturation / Veronese

Retained:
1. rational conic \(\simeq\mathbb P^1\) / Veronese parameterization.
2. O'Dorney 2023: integral ternary conics via quaternionic subrings and invariant lattices; rationally equivalent conics can differ integrally.
3. universal-torsor / Cox-coordinate language as a reserve, not yet a direct match.
4. affine blow-up algebras for integral image/divisibility charts.

Applicability:
- excellent conceptual replacement for “rational Veronese ⇒ integral source parametrization” mistakes.
- source lattice should be treated as part of the integral conic/quaternion-order datum.
- no external theorem found that removes the actual moving content/height bridge.

## Lane D — strong approximation / sectors / primitive shell

Retained:
1. Cao–Xu 2018 Thm. 1.2: smooth toric varieties satisfy strong approximation with BM obstruction off infinity.
2. CT–Xu 2009 Thm. 3.7 as homogeneous-space counterpart.
3. Huang 2025 preprint on primitive integral points with congruence + real weights on punctured ternary cones.
4. Heath-Brown circle-method family for primitive zeros of indefinite ternary quadratic forms (as referenced by Huang).

Critical findings:
- \(W^\circ=(F=0)\setminus\{0\}\) is naturally a \(\mathbb G_m\)-torsor over the conic and a smooth toric variety on split fibres.
- Cao–Xu explicitly does **not** force prescribed real connected components; therefore digit sectors are not swallowed.
- Huang Example 1.4 exhibits reciprocity between real sign, primitivity, and a finite congruence.
- Huang Thm. 1.3 in v1 is textually inconsistent as written: \(\Omega=8L\Delta\) and assumption \(\Omega\mid L\). It cannot be imported without clarification/correction.

## Lane E — composition / Hermitian / norm structures

Retained:
1. Gaussian norm multiplicativity / orthogonal similitude as the correct standard reading of R17 composition.
2. even Clifford algebra / Spin of ternary quadratic spaces.
3. binary Hermitian-form reduction over \(\mathbb Z[i]\) / Bianchi–Humbert tradition.
4. Bhargava higher composition laws / integral prehomogeneous-vector-space orbits as a G2/G3 comparison family.

Applicability:
- R17's exact identity is already explained by norm multiplicativity; standard composition laws do not supply source-lattice preservation.
- determinant-\((-2)\) Hermitian class collapse is a low-dimensional class-number/reduction phenomenon, but R12 proves the moduli quotient is semantically too coarse.
- Bhargava-type composition is structurally interesting but no exact representation-space map from the source problem is currently proved.

## Lane F — power-of-ten / torus / exponential Diophantine

Retained:
1. Evertse–Schlickewei–Schmidt 2002: linear equations in finite-rank multiplicative groups.
2. Laurent-type toric Mordell–Lang family: subvariety of a torus intersected with a finitely generated subgroup.
3. S-unit equations / Subspace Theorem.
4. arithmetic dynamics/semigroup-orbit language as a reserve.

Applicability:
- \(G,K\) are certainly multiplicative-semigroup coordinates.
- ESS requires an exact linear relation \(a_1x_1+\cdots+a_nx_n=1\) with variables in a finite-rank multiplicative group.
- current source/digit system has not been reduced to such an equation.
- therefore G3 potential, M0–M2 current applicability only.
