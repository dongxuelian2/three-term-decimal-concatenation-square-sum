# Literature Registry

Only sources with theorem-level or structural relevance are retained.

| ID | Lane | Source | Exact location used | Role | Status |
|---|---|---|---|---|---|
| L-A1 | A | Colliot-Thélène–Xu, Compos. Math. 145 (2009), 309–363, arXiv:0712.1957 | Thm. 3.7 | integral homogeneous-space SA/BM | DEEP |
| L-A2 | A/E | same | Thm. 6.3 | norm-one torus/Brauer in codim 2 quadratic representations | DEEP |
| L-A3 | A | Platonov–Rapinchuk, Algebraic Groups and Number Theory | §7.4, Thm. 7.12, p.427 (English ed.), verified via CT–Xu proof | simply-connected group SA | DEEP |
| L-B1 | B/C | Mayeux–Richarz–Romagny, arXiv:2001.03597 | Def. 2.1; Lem. 2.3–2.4; Intro theorem | dilatation / affine blowup / Rees | DEEP |
| L-B2 | B | Ferrand, Bull. SMF 131 (2003), 553–585 | §2.2; §5.4 | conductor-square descent and pinching | DEEP |
| L-C1 | C | O'Dorney, Proc. AMS 151 (2023), 1889–1905, arXiv:2205.12829v2 | main theorem/framework; quaternionic subring + invariant lattices | integral conic language | DEEP |
| L-D1 | D | Cao–Xu, Ann. Inst. Fourier 68 (2018), 1879–1908 | Thm. 1.2, Cor. 1.3 | toric SA/BM off infinity | DEEP |
| L-D2 | D | Huang, arXiv:2512.13091v1 (2025) | Thm. 1.3; Ex. 1.4; intro §1 | primitive ternary cone with local/real data | DEEP/REJECT-AS-WRITTEN |
| L-E1 | E | Bhargava, Higher composition laws I, Ann. Math. 159? / series source | composition-law family | comparison / reserve | DEEP-FAMILY |
| L-F1 | F | Evertse–Schlickewei–Schmidt, Ann. Math. 155 (2002), 807–836 | main theorem / pp.807–836 | finite-rank multiplicative-group equations | DEEP |
| L-F2 | F | Laurent, Invent. Math. 78 (1984), 299–327 | exponential Diophantine / toric Mordell–Lang family | semigroup/group intersection | RECON |
| L-D3 | D | Iwaniec, Demonstratio Math. 11 (1978), 225–231 | Jacobsthal bound family | validates R14’s Jacobsthal vocabulary | AUX |

## Source-verification notes

- CT–Xu HTML explicitly states the exact hypotheses of Thm. 3.7 and cites Kneser / Platonov–Rapinchuk for group strong approximation.
- Cao–Xu PDF states Thm. 1.2 and immediately warns that their proof does not force prescribed real connected components.
- Huang HTML currently prints \(\Omega=8L\Delta\) and then “Assume \(\Omega\mid L\)” in Thm. 1.3. This is recorded literally and treated as an applicability failure, not silently repaired.
- O'Dorney’s abstract explicitly says the proof passes from integral conics to quaternionic subrings of \(M_2(\mathbb Z)\) and classifies invariant lattices.
- ESS publisher page gives exact field/group/equation hypotheses and uniform finiteness conclusion.
