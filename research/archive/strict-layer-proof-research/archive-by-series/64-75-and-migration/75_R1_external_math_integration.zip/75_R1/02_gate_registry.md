# Gate Registry — Post-65 / Start of 75

The terminal gate set is deliberately small and proposition-shaped.

## G1 — q>1 Rational Split / Gaussian Norm Gate

**Statement to decide.** For every actual q>1 power-of-ten Exact-Resonance J=2 parameter tuple satisfying all surviving structural conditions, determine whether
\[
\mathscr X_{0,\mathbb Q}(\mathbb Q)\neq\varnothing,
\]
equivalently in the R9 normalization,
\[
(-1,N_0)=0\quad\Longleftrightarrow\quad
N_0\in N_{\mathbb Q(i)/\mathbb Q}(\mathbb Q(i)^\times).
\]

**Why it survives.** R20's source-lattice scaling and integral parameterization are explicitly conditional on a rationally split fibre.

## G2 — Split-Fibre Primitive Digit-Height Gate

**Statement to prove/disprove.** Assume G1 PASS on a fibre. Let \(\Gamma_{\rm src}\) be the exact semantic source lattice. Prove existence (or impossibility) of
\[
x\in\Gamma_{\rm src},\quad Q_0(x)=0,\quad x\ {\rm primitive\ in}\ \Gamma_{\rm src},
\]
satisfying the full inherited digit/height/radial inequalities for the actual decimal scale \(G\).

Finite packet membership and projective real-arc membership alone are insufficient.

## G3 — Exact Power-of-Ten Incidence Gate

**Statement.** Construct an algebraic/arithmetical incidence object \(V\) and a reconstruction map such that actual solutions correspond exactly to a specified subset of
\[
V(\mathbb Q)\cap\langle(10,1),(1,10)\rangle
\]
(or a justified semigroup analogue), with no loss of source, primitive, or digit data.

Until this object exists, S-unit/Mordell–Lang theorems are non-applicable.

## G4 — q=1 Gate

**Statement.** Close or structurally migrate the q=1 positive and negative subfrontiers using the same source-valid standard language. q>1 integral-model results do not imply q=1 closure.

## G5 — General-J Transport Gate

**Statement.** Reconstruct the source-semantic lattice/conic/torus architecture for general J using the source-valid reduced denominator \(u_0\), prove exact re-specialization at J=2, and identify which external theorems are uniform in J.

## G6 — Original Concatenation / General Architecture Gate

**Statement.** Exhibit a standard family (integral homogeneous spaces, toric incidence, torsors, or a combination) whose integral points are in bijection with original concatenation solutions across J and digit lengths.

## Dependency skeleton

\[
G1 \longrightarrow G2,\qquad
(G1,G2)\ \text{interact with}\ G3.
\]

G4 is a separate J2 branch. G5/G6 are architectural/generalization gates, not prerequisites for a current q>1 proof.

## Explicitly NOT a current gate

`Semantic Conductor–Ruling Lifting` is closed in R20.
`Finite source packet automaticity` is retired.
`Smooth Spin finite-module transitivity` is not a valid replacement.
